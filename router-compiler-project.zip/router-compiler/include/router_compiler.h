#ifndef ROUTER_COMPILER_H
#define ROUTER_COMPILER_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* --- primitive helpers used by tests --- */
int  rc_parse_ip(const char *s, uint32_t *out);
int  rc_parse_uint(const char *s, unsigned long long lo,
                   unsigned long long hi, unsigned long long *out);
int  rc_mask_ok(uint32_t m);
int  rc_plen(uint32_t m);
int  rc_classful(uint32_t ip, uint32_t *base);
int  rc_canon_iface(const char *in, char *out, unsigned long n);
int  rc_join_iface(int argc, char **argv, char *out, unsigned long n);
int  rc_ieq(const char *a, const char *b);
int  rc_is_prefix_ci(const char *t, const char *w);
const char *rc_ipstr(uint32_t ip);

/* --- CLI helpers --- */
void rc_reset_config(void);
int  rc_execute_line(const char *line);          /* feed one line */
int  rc_validate(int *warns);
void rc_set_quit_flag(int v);
int  rc_get_quit_flag(void);
int  rc_load_file(const char *path);
int  rc_save_file(const char *path);
void rc_gen_config_lines(void (*cb)(const char *line, void *ud), void *ud);
int  rc_run_cli(void);                            /* interactive loop */

#ifdef __cplusplus
}
#endif
#endif