	.file	"router_compiler.c"
	.text
	.p2align 4
	.type	h_disable, @function
h_disable:
.LFB48:
	.cfi_startproc
	movl	$0, mode(%rip)
	xorl	%eax, %eax
	ret
	.cfi_endproc
.LFE48:
	.size	h_disable, .-h_disable
	.p2align 4
	.type	h_exit, @function
h_exit:
.LFB50:
	.cfi_startproc
	movl	mode(%rip), %eax
	cmpl	$2, %eax
	je	.L4
	ja	.L5
	testl	%eax, %eax
	je	.L13
	movl	$0, mode(%rip)
	xorl	%eax, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L5:
	subl	$3, %eax
	cmpl	$2, %eax
	ja	.L14
	movl	$2, mode(%rip)
	xorl	%eax, %eax
	movq	$0, cur_if(%rip)
	ret
	.p2align 4,,10
	.p2align 3
.L14:
	movl	$0, mode(%rip)
.L13:
	movl	$1, quit_flag(%rip)
	xorl	%eax, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L4:
	movl	$1, mode(%rip)
	xorl	%eax, %eax
	ret
	.cfi_endproc
.LFE50:
	.size	h_exit, .-h_exit
	.p2align 4
	.type	h_quit, @function
h_quit:
.LFB51:
	.cfi_startproc
	movl	$1, quit_flag(%rip)
	xorl	%eax, %eax
	ret
	.cfi_endproc
.LFE51:
	.size	h_quit, .-h_quit
	.p2align 4
	.type	h_end, @function
h_end:
.LFB52:
	.cfi_startproc
	movl	$1, mode(%rip)
	xorl	%eax, %eax
	movq	$0, cur_if(%rip)
	ret
	.cfi_endproc
.LFE52:
	.size	h_end, .-h_end
	.p2align 4
	.type	h_no_secret, @function
h_no_secret:
.LFB56:
	.cfi_startproc
	cmpb	$0, 64+cfg(%rip)
	movl	$1, %eax
	je	.L17
	movb	$0, 64+cfg(%rip)
	xorl	%eax, %eax
.L17:
	ret
	.cfi_endproc
.LFE56:
	.size	h_no_secret, .-h_no_secret
	.p2align 4
	.type	h_no_ip_address, @function
h_no_ip_address:
.LFB60:
	.cfi_startproc
	movq	cur_if(%rip), %rax
	movl	$1, %edx
	movl	148(%rax), %ecx
	testl	%ecx, %ecx
	je	.L20
	movl	$0, 148(%rax)
	xorl	%edx, %edx
	movq	$0, 140(%rax)
.L20:
	movl	%edx, %eax
	ret
	.cfi_endproc
.LFE60:
	.size	h_no_ip_address, .-h_no_ip_address
	.p2align 4
	.type	h_no_description, @function
h_no_description:
.LFB65:
	.cfi_startproc
	movq	cur_if(%rip), %rdx
	movl	$1, %eax
	cmpb	$0, 40(%rdx)
	je	.L23
	movb	$0, 40(%rdx)
	xorl	%eax, %eax
.L23:
	ret
	.cfi_endproc
.LFE65:
	.size	h_no_description, .-h_no_description
	.p2align 4
	.type	h_no_clock, @function
h_no_clock:
.LFB67:
	.cfi_startproc
	movq	cur_if(%rip), %rdx
	movl	$1, %eax
	cmpq	$0, 160(%rdx)
	je	.L26
	movq	$0, 160(%rdx)
	xorl	%eax, %eax
.L26:
	ret
	.cfi_endproc
.LFE67:
	.size	h_no_clock, .-h_no_clock
	.p2align 4
	.type	h_autosum, @function
h_autosum:
.LFB75:
	.cfi_startproc
	movl	688+cfg(%rip), %eax
	testl	%eax, %eax
	jne	.L31
	movl	$1, 688+cfg(%rip)
	ret
	.p2align 4,,10
	.p2align 3
.L31:
	movl	$1, %eax
	ret
	.cfi_endproc
.LFE75:
	.size	h_autosum, .-h_autosum
	.p2align 4
	.type	h_no_autosum, @function
h_no_autosum:
.LFB76:
	.cfi_startproc
	movl	688+cfg(%rip), %edx
	movl	$1, %eax
	testl	%edx, %edx
	je	.L32
	movl	$0, 688+cfg(%rip)
	xorl	%eax, %eax
.L32:
	ret
	.cfi_endproc
.LFE76:
	.size	h_no_autosum, .-h_no_autosum
	.p2align 4
	.type	h_no_router_id, @function
h_no_router_id:
.LFB78:
	.cfi_startproc
	movl	720+cfg(%rip), %edx
	movl	$1, %eax
	testl	%edx, %edx
	je	.L35
	movl	$0, 720+cfg(%rip)
	xorl	%eax, %eax
.L35:
	ret
	.cfi_endproc
.LFE78:
	.size	h_no_router_id, .-h_no_router_id
	.section	.rodata.str1.1,"aMS",@progbits,1
.LC1:
	.string	"RIP enabled"
.LC2:
	.string	"config"
	.text
	.p2align 4
	.type	h_router_rip, @function
h_router_rip:
.LFB70:
	.cfi_startproc
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	movl	680+cfg(%rip), %eax
	testl	%eax, %eax
	jne	.L39
	movq	.LC0(%rip), %rax
	movl	$1, 688+cfg(%rip)
	movq	%rax, 680+cfg(%rip)
.L39:
	xorl	%eax, %eax
	leaq	.LC1(%rip), %rdx
	movl	$1, %edi
	movl	$4, mode(%rip)
	leaq	.LC2(%rip), %rsi
	call	rlog_log@PLT
	xorl	%eax, %eax
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE70:
	.size	h_router_rip, .-h_router_rip
	.p2align 4
	.type	route_find, @function
route_find:
.LFB39:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movq	%rsi, %rdx
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movl	672+cfg(%rip), %ebp
	subl	$1, %ebp
	js	.L53
	movq	664+cfg(%rip), %r15
	movl	(%rdi), %r14d
	movq	%rdi, %r13
	xorl	%r12d, %r12d
	jmp	.L52
	.p2align 4,,10
	.p2align 3
.L43:
	movl	4(%r13), %eax
	cmpl	%eax, 4(%rdi)
	jne	.L58
	movl	52(%rdi), %eax
	movl	52(%r13), %ecx
	cmpl	%ecx, %eax
	je	.L47
	subl	%ecx, %eax
.L48:
	testl	%eax, %eax
	js	.L44
.L45:
	leal	-1(%rbx), %ebp
	cmpl	%r12d, %ebp
	jl	.L42
.L52:
	leal	(%r12,%rbp), %eax
	movl	%eax, %ebx
	shrl	$31, %ebx
	addl	%eax, %ebx
	sarl	%ebx
	movslq	%ebx, %rcx
	movq	%rcx, %rax
	salq	$4, %rax
	subq	%rcx, %rax
	leaq	(%r15,%rax,4), %rdi
	cmpl	%r14d, (%rdi)
	je	.L43
.L58:
	jnb	.L45
.L44:
	leal	1(%rbx), %r12d
	cmpl	%r12d, %ebp
	jge	.L52
.L42:
	xorl	%eax, %eax
.L50:
	movl	%r12d, (%rdx)
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L47:
	.cfi_restore_state
	testl	%eax, %eax
	jne	.L60
	addq	$12, %rdi
	leaq	12(%r13), %rsi
	movq	%rdx, 8(%rsp)
	call	strcmp@PLT
	movq	8(%rsp), %rdx
	testl	%eax, %eax
	jne	.L48
	movl	%ebx, %r12d
	movl	$1, %eax
	jmp	.L50
	.p2align 4,,10
	.p2align 3
.L60:
	movl	8(%r13), %eax
	cmpl	%eax, 8(%rdi)
	jne	.L58
	movl	%ebx, %r12d
	movl	$1, %eax
	jmp	.L50
.L53:
	xorl	%r12d, %r12d
	jmp	.L42
	.cfi_endproc
.LFE39:
	.size	route_find, .-route_find
	.section	.rodata.str1.8,"aMS",@progbits,1
	.align 8
.LC3:
	.string	"Enter configuration commands, one per line.  End with 'end'."
	.section	.rodata.str1.1
.LC4:
	.string	"entered config mode"
.LC5:
	.string	"cli"
	.text
	.p2align 4
	.type	h_configure, @function
h_configure:
.LFB49:
	.cfi_startproc
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	movl	loading(%rip), %eax
	movl	$2, mode(%rip)
	testl	%eax, %eax
	je	.L64
.L62:
	xorl	%eax, %eax
	leaq	.LC4(%rip), %rdx
	leaq	.LC5(%rip), %rsi
	xorl	%edi, %edi
	call	rlog_log@PLT
	xorl	%eax, %eax
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L64:
	.cfi_restore_state
	leaq	.LC3(%rip), %rdi
	call	puts@PLT
	jmp	.L62
	.cfi_endproc
.LFE49:
	.size	h_configure, .-h_configure
	.section	.rodata.str1.1
.LC6:
	.string	"%04d  0x%02X  %-11s %s"
.LC7:
	.string	"%s\n"
	.text
	.p2align 4
	.type	emit, @function
emit:
.LFB94:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	movq	%rdx, %r13
	movq	%rcx, %rdx
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	movl	%esi, %r12d
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	movq	%rdi, %rbx
	subq	$688, %rsp
	.cfi_def_cfa_offset 736
	movq	%r8, 544(%rsp)
	movq	%r9, 552(%rsp)
	testb	%al, %al
	je	.L70
	movaps	%xmm0, 560(%rsp)
	movaps	%xmm1, 576(%rsp)
	movaps	%xmm2, 592(%rsp)
	movaps	%xmm3, 608(%rsp)
	movaps	%xmm4, 624(%rsp)
	movaps	%xmm5, 640(%rsp)
	movaps	%xmm6, 656(%rsp)
	movaps	%xmm7, 672(%rsp)
.L70:
	leaq	32(%rsp), %rbp
	leaq	8(%rsp), %rcx
	movl	$200, %esi
	movl	$32, 8(%rsp)
	leaq	736(%rsp), %rax
	movq	%rbp, %rdi
	movl	$48, 12(%rsp)
	leaq	240(%rsp), %r14
	movq	%rax, 16(%rsp)
	leaq	512(%rsp), %rax
	movq	%rax, 24(%rsp)
	call	vsnprintf@PLT
	movl	(%rbx), %ecx
	subq	$8, %rsp
	.cfi_def_cfa_offset 744
	movq	%r13, %r9
	leaq	.LC6(%rip), %rdx
	movl	%r12d, %r8d
	movl	$260, %esi
	movq	%r14, %rdi
	leal	1(%rcx), %eax
	movl	%eax, (%rbx)
	xorl	%eax, %eax
	pushq	%rbp
	.cfi_def_cfa_offset 752
	call	snprintf@PLT
	movq	%r14, %rdi
	call	puts@PLT
	movq	8(%rbx), %rdi
	popq	%rax
	.cfi_def_cfa_offset 744
	popq	%rdx
	.cfi_def_cfa_offset 736
	testq	%rdi, %rdi
	je	.L67
	movq	%r14, %rdx
	leaq	.LC7(%rip), %rsi
	xorl	%eax, %eax
	call	fprintf@PLT
.L67:
	movq	16(%rbx), %rax
	movq	%rax, %rdx
	salq	$6, %rdx
	addq	%rax, %rdx
	leaq	(%rax,%rdx,2), %rax
	movzbl	32(%rsp), %edx
	addq	%r12, %rax
	movq	%rax, 16(%rbx)
	testb	%dl, %dl
	je	.L65
	movq	%rbp, %rsi
	.p2align 5
	.p2align 4
	.p2align 3
.L69:
	movq	%rax, %rcx
	addq	$1, %rsi
	salq	$6, %rcx
	addq	%rax, %rcx
	leaq	(%rax,%rcx,2), %rax
	addq	%rdx, %rax
	movzbl	(%rsi), %edx
	testb	%dl, %dl
	jne	.L69
	movq	%rax, 16(%rbx)
.L65:
	addq	$688, %rsp
	.cfi_def_cfa_offset 48
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE94:
	.size	emit, .-emit
	.section	.rodata.str1.1
.LC8:
	.string	"r"
.LC9:
	.string	"startup-config.cfg"
.LC10:
	.string	"startup-config is not present"
	.text
	.p2align 4
	.type	h_show_startup, @function
h_show_startup:
.LFB84:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	leaq	.LC8(%rip), %rsi
	leaq	.LC9(%rip), %rdi
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$312, %rsp
	.cfi_def_cfa_offset 336
	call	fopen@PLT
	testq	%rax, %rax
	je	.L84
	movq	%rax, %rbp
	movq	%rsp, %rbx
	jmp	.L80
	.p2align 4,,10
	.p2align 3
.L82:
	movq	stdout(%rip), %rsi
	movq	%rbx, %rdi
	call	fputs@PLT
.L80:
	movq	%rbp, %rdx
	movl	$300, %esi
	movq	%rbx, %rdi
	call	fgets@PLT
	testq	%rax, %rax
	jne	.L82
	movq	%rbp, %rdi
	call	fclose@PLT
.L81:
	addq	$312, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L84:
	.cfi_restore_state
	leaq	.LC10(%rip), %rdi
	call	puts@PLT
	jmp	.L81
	.cfi_endproc
.LFE84:
	.size	h_show_startup, .-h_show_startup
	.p2align 4
	.type	h_no_router_rip, @function
h_no_router_rip:
.LFB71:
	.cfi_startproc
	movl	680+cfg(%rip), %eax
	testl	%eax, %eax
	jne	.L94
	movl	$1, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L94:
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	movq	696+cfg(%rip), %rdi
	call	free@PLT
	xorl	%eax, %eax
	movq	$0, 696+cfg(%rip)
	movq	$0, 704+cfg(%rip)
	movl	$0, 680+cfg(%rip)
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE71:
	.size	h_no_router_rip, .-h_no_router_rip
	.section	.rodata.str1.1
.LC11:
	.string	"administratively down"
	.section	.rodata.str1.8
	.align 8
.LC12:
	.string	"%%LINK-5-CHANGED: Interface %s, changed state to %s\n"
	.section	.rodata.str1.1
.LC13:
	.string	"down"
	.section	.rodata.str1.8
	.align 8
.LC14:
	.string	"%%LINEPROTO-5-UPDOWN: Line protocol on Interface %s, changed state to %s\n"
	.text
	.p2align 4
	.type	h_shutdown, @function
h_shutdown:
.LFB62:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movq	cur_if(%rip), %rbx
	movl	152(%rbx), %ebp
	testl	%ebp, %ebp
	jne	.L99
	movl	$1, 152(%rbx)
	movl	loading(%rip), %eax
	testl	%eax, %eax
	jne	.L95
	leaq	.LC11(%rip), %rdx
	movq	%rbx, %rsi
	leaq	.LC12(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
	leaq	.LC13(%rip), %rdx
	movq	%rbx, %rsi
	xorl	%eax, %eax
	leaq	.LC14(%rip), %rdi
	call	printf@PLT
.L95:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	movl	%ebp, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L99:
	.cfi_restore_state
	movl	$1, %ebp
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	movl	%ebp, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE62:
	.size	h_shutdown, .-h_shutdown
	.section	.rodata.str1.1
.LC15:
	.string	"Router"
	.text
	.p2align 4
	.type	h_no_hostname, @function
h_no_hostname:
.LFB54:
	.cfi_startproc
	cmpl	$1953853266, cfg(%rip)
	je	.L106
.L102:
	movl	$1953853266, cfg(%rip)
	xorl	%eax, %eax
	movl	$7497076, 3+cfg(%rip)
	ret
	.p2align 4,,10
	.p2align 3
.L106:
	cmpl	$7497076, 3+cfg(%rip)
	jne	.L102
	movl	$1, %eax
	ret
	.cfi_endproc
.LFE54:
	.size	h_no_hostname, .-h_no_hostname
	.section	.rodata.str1.8
	.align 8
.LC16:
	.string	"No errors recorded in this session."
	.section	.rodata.str1.1
.LC17:
	.string	"%d error(s) recorded:\n"
.LC18:
	.string	"%3d. [%s] \"%s\"\n       -> %s\n"
	.text
	.p2align 4
	.type	h_show_errors, @function
h_show_errors:
.LFB90:
	.cfi_startproc
	movl	nerr(%rip), %esi
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	testl	%esi, %esi
	je	.L114
	leaq	.LC17(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
	movl	nerr(%rip), %eax
	testl	%eax, %eax
	jle	.L109
	xorl	%ebp, %ebp
	xorl	%ebx, %ebx
	leaq	.LC18(%rip), %r12
	.p2align 4
	.p2align 3
.L111:
	movq	errlog(%rip), %rdx
	addl	$1, %ebx
	xorl	%eax, %eax
	movq	%r12, %rdi
	movl	%ebx, %esi
	addq	%rbp, %rdx
	addq	$520, %rbp
	leaq	64(%rdx), %rcx
	leaq	320(%rdx), %r8
	call	printf@PLT
	cmpl	nerr(%rip), %ebx
	jl	.L111
.L109:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	xorl	%eax, %eax
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L114:
	.cfi_restore_state
	leaq	.LC16(%rip), %rdi
	call	puts@PLT
	popq	%rbx
	.cfi_def_cfa_offset 24
	xorl	%eax, %eax
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE90:
	.size	h_show_errors, .-h_show_errors
	.section	.rodata.str1.1
.LC19:
	.string	"out of memory\n"
	.text
	.p2align 4
	.type	xrealloc.part.0, @function
xrealloc.part.0:
.LFB123:
	.cfi_startproc
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	movl	$14, %edx
	movl	$1, %esi
	movq	stderr(%rip), %rcx
	leaq	.LC19(%rip), %rdi
	call	fwrite@PLT
	movl	$1, %edi
	call	exit@PLT
	.cfi_endproc
.LFE123:
	.size	xrealloc.part.0, .-xrealloc.part.0
	.section	.rodata.str1.1
.LC20:
	.string	"  %s:%d: %% %s\n"
.LC21:
	.string	"%s:%d %s"
.LC22:
	.string	"parser"
.LC23:
	.string	"%% %s\n"
.LC24:
	.string	"%s"
.LC25:
	.string	"%s:%d"
.LC26:
	.string	"cmd #%d"
	.text
	.p2align 4
	.type	err, @function
err:
.LFB28:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	subq	$416, %rsp
	.cfi_def_cfa_offset 448
	movq	%rsi, 248(%rsp)
	movq	%rdx, 256(%rsp)
	movq	%rcx, 264(%rsp)
	movq	%r8, 272(%rsp)
	movq	%r9, 280(%rsp)
	testb	%al, %al
	je	.L127
	movaps	%xmm0, 288(%rsp)
	movaps	%xmm1, 304(%rsp)
	movaps	%xmm2, 320(%rsp)
	movaps	%xmm3, 336(%rsp)
	movaps	%xmm4, 352(%rsp)
	movaps	%xmm5, 368(%rsp)
	movaps	%xmm6, 384(%rsp)
	movaps	%xmm7, 400(%rsp)
.L127:
	leaq	448(%rsp), %rax
	leaq	32(%rsp), %rbp
	movq	%rdi, %rdx
	movl	$200, %esi
	movq	%rax, 16(%rsp)
	leaq	8(%rsp), %rcx
	leaq	240(%rsp), %rax
	movq	%rbp, %rdi
	movl	$8, 8(%rsp)
	movl	$48, 12(%rsp)
	movq	%rax, 24(%rsp)
	call	vsnprintf@PLT
	movl	loading(%rip), %edx
	testl	%edx, %edx
	je	.L119
	movl	load_line(%rip), %edx
	movq	load_name(%rip), %rsi
	movq	%rbp, %rcx
	xorl	%eax, %eax
	leaq	.LC20(%rip), %rdi
	call	printf@PLT
	movl	load_line(%rip), %r8d
	movq	%rbp, %r9
	xorl	%eax, %eax
	movq	load_name(%rip), %rcx
	leaq	.LC21(%rip), %rdx
	movl	$2, %edi
	leaq	.LC22(%rip), %rsi
	call	rlog_log@PLT
.L120:
	movslq	nerr(%rip), %rbx
	movl	cerr(%rip), %eax
	movq	errlog(%rip), %rdi
	cmpl	%eax, %ebx
	jl	.L121
	testl	%eax, %eax
	jne	.L129
	movl	$4160, %esi
	movl	$8, %eax
.L122:
	movl	%eax, cerr(%rip)
	call	realloc@PLT
	movq	%rax, %rdi
	testq	%rax, %rax
	je	.L130
	movq	%rax, errlog(%rip)
.L121:
	leal	1(%rbx), %eax
	movl	%eax, nerr(%rip)
	movq	%rbx, %rax
	salq	$6, %rax
	addq	%rbx, %rax
	leaq	(%rdi,%rax,8), %rbx
	movl	loading(%rip), %eax
	testl	%eax, %eax
	jne	.L131
	movl	st(%rip), %ecx
	movl	$64, %esi
	movq	%rbx, %rdi
	xorl	%eax, %eax
	leaq	.LC26(%rip), %rdx
	call	snprintf@PLT
.L125:
	leaq	.LC24(%rip), %r12
	leaq	64(%rbx), %rdi
	movl	$256, %esi
	xorl	%eax, %eax
	movq	%r12, %rdx
	leaq	C(%rip), %rcx
	call	snprintf@PLT
	movq	%rbp, %rcx
	movq	%r12, %rdx
	movl	$200, %esi
	leaq	320(%rbx), %rdi
	xorl	%eax, %eax
	call	snprintf@PLT
	addq	$416, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 32
	movl	$-1, %eax
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L119:
	.cfi_restore_state
	movq	%rbp, %rsi
	leaq	.LC23(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
	movq	%rbp, %rcx
	movl	$2, %edi
	xorl	%eax, %eax
	leaq	.LC24(%rip), %rdx
	leaq	.LC22(%rip), %rsi
	call	rlog_log@PLT
	jmp	.L120
	.p2align 4,,10
	.p2align 3
.L131:
	movl	load_line(%rip), %r8d
	movl	$64, %esi
	movq	%rbx, %rdi
	xorl	%eax, %eax
	movq	load_name(%rip), %rcx
	leaq	.LC25(%rip), %rdx
	call	snprintf@PLT
	jmp	.L125
	.p2align 4,,10
	.p2align 3
.L129:
	addl	%eax, %eax
	movslq	%eax, %rdx
	movq	%rdx, %rsi
	salq	$6, %rsi
	addq	%rdx, %rsi
	salq	$3, %rsi
	jmp	.L122
.L130:
	call	xrealloc.part.0
	.cfi_endproc
.LFE28:
	.size	err, .-err
	.section	.rodata.str1.1
.LC27:
	.string	"Password: "
.LC28:
	.string	"Access denied"
.LC29:
	.string	"entered privileged EXEC"
	.text
	.p2align 4
	.type	h_enable, @function
h_enable:
.LFB47:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	subq	$112, %rsp
	.cfi_def_cfa_offset 128
	cmpb	$0, 64+cfg(%rip)
	je	.L133
	movl	loading(%rip), %eax
	testl	%eax, %eax
	je	.L149
.L133:
	xorl	%eax, %eax
	leaq	.LC29(%rip), %rdx
	leaq	.LC5(%rip), %rsi
	xorl	%edi, %edi
	movl	$1, mode(%rip)
	call	rlog_log@PLT
	xorl	%eax, %eax
.L132:
	addq	$112, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L149:
	.cfi_restore_state
	leaq	.LC27(%rip), %rdi
	xorl	%eax, %eax
	movq	%rsp, %rbx
	call	printf@PLT
	movq	stdout(%rip), %rdi
	call	fflush@PLT
	movq	stdin(%rip), %rdx
	movl	$100, %esi
	movq	%rsp, %rdi
	call	fgets@PLT
	testq	%rax, %rax
	je	.L134
	movq	%rsp, %rdi
	call	strlen@PLT
	testq	%rax, %rax
	jne	.L135
	jmp	.L138
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L139:
	movb	$0, (%rbx,%rax)
	testq	%rax, %rax
	je	.L138
.L135:
	subq	$1, %rax
	movzbl	(%rbx,%rax), %edx
	cmpb	$10, %dl
	je	.L139
	cmpb	$13, %dl
	je	.L139
.L138:
	leaq	64+cfg(%rip), %rsi
	movq	%rbx, %rdi
	call	strcmp@PLT
	testl	%eax, %eax
	je	.L133
	leaq	.LC28(%rip), %rdi
	xorl	%eax, %eax
	call	err
.L134:
	movl	$-1, %eax
	jmp	.L132
	.cfi_endproc
.LFE47:
	.size	h_enable, .-h_enable
	.section	.rodata.str1.1
.LC30:
	.string	"No startup-config to erase."
.LC31:
	.string	"[OK] startup-config erased"
	.text
	.p2align 4
	.type	h_erase, @function
h_erase:
.LFB101:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	leaq	.LC9(%rip), %rdi
	call	remove@PLT
	testl	%eax, %eax
	jne	.L154
	leaq	.LC31(%rip), %rdi
	movl	%eax, %ebx
	call	puts@PLT
.L150:
	movl	%ebx, %eax
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L154:
	.cfi_restore_state
	leaq	.LC30(%rip), %rdi
	xorl	%eax, %eax
	movl	$-1, %ebx
	call	err
	jmp	.L150
	.cfi_endproc
.LFE101:
	.size	h_erase, .-h_erase
	.section	.rodata.str1.1
.LC32:
	.string	"up"
	.text
	.p2align 4
	.type	h_no_shutdown, @function
h_no_shutdown:
.LFB63:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movl	$1, %eax
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movq	cur_if(%rip), %rbx
	movl	152(%rbx), %edx
	testl	%edx, %edx
	je	.L155
	movl	$0, 152(%rbx)
	movl	loading(%rip), %eax
	testl	%eax, %eax
	jne	.L158
	leaq	.LC32(%rip), %rbp
	movq	%rbx, %rsi
	leaq	.LC12(%rip), %rdi
	xorl	%eax, %eax
	movq	%rbp, %rdx
	call	printf@PLT
	movq	%rbp, %rdx
	movq	%rbx, %rsi
	xorl	%eax, %eax
	leaq	.LC14(%rip), %rdi
	call	printf@PLT
.L158:
	xorl	%eax, %eax
.L155:
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE63:
	.size	h_no_shutdown, .-h_no_shutdown
	.p2align 4
	.type	addf, @function
addf:
.LFB26:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	movq	%rdi, %rbx
	subq	$520, %rsp
	.cfi_def_cfa_offset 560
	movq	%rdx, 352(%rsp)
	movq	%rcx, 360(%rsp)
	movq	%r8, 368(%rsp)
	movq	%r9, 376(%rsp)
	testb	%al, %al
	je	.L173
	movaps	%xmm0, 384(%rsp)
	movaps	%xmm1, 400(%rsp)
	movaps	%xmm2, 416(%rsp)
	movaps	%xmm3, 432(%rsp)
	movaps	%xmm4, 448(%rsp)
	movaps	%xmm5, 464(%rsp)
	movaps	%xmm6, 480(%rsp)
	movaps	%xmm7, 496(%rsp)
.L173:
	leaq	560(%rsp), %rax
	leaq	32(%rsp), %rbp
	movq	%rsi, %rdx
	movl	$300, %esi
	movq	%rax, 16(%rsp)
	movq	%rbp, %rdi
	leaq	336(%rsp), %rax
	leaq	8(%rsp), %rcx
	movl	$16, 8(%rsp)
	movl	$48, 12(%rsp)
	movq	%rax, 24(%rsp)
	call	vsnprintf@PLT
	movslq	8(%rbx), %rdx
	movl	12(%rbx), %eax
	movq	(%rbx), %rdi
	cmpl	%eax, %edx
	jl	.L164
	testl	%eax, %eax
	jne	.L178
	movl	$64, %esi
	movl	$8, %eax
.L165:
	movl	%eax, 12(%rbx)
	call	realloc@PLT
	movq	%rax, %rdi
	testq	%rax, %rax
	je	.L179
	movq	%rax, (%rbx)
	movslq	8(%rbx), %rdx
.L164:
	leal	1(%rdx), %eax
	leaq	(%rdi,%rdx,8), %r13
	movq	%rbp, %rdi
	movl	%eax, 8(%rbx)
	call	strlen@PLT
	leaq	1(%rax), %r12
	movq	%rax, %rbx
	movq	%r12, %rdi
	call	malloc@PLT
	testq	%rax, %rax
	je	.L180
	cmpl	$8, %r12d
	jnb	.L168
	testb	$4, %r12b
	jne	.L181
	testl	%r12d, %r12d
	je	.L169
	movzbl	32(%rsp), %edx
	movb	%dl, (%rax)
	testb	$2, %r12b
	jne	.L182
.L169:
	movq	%rax, 0(%r13)
	addq	$520, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L168:
	.cfi_restore_state
	movl	%r12d, %r12d
	shrl	$3, %ebx
	movq	%rax, %rdi
	movq	%rbp, %rsi
	movq	-8(%rbp,%r12), %rdx
	movl	%ebx, %ecx
	movq	%rdx, -8(%rax,%r12)
	rep movsq
	jmp	.L169
	.p2align 4,,10
	.p2align 3
.L178:
	addl	%eax, %eax
	movslq	%eax, %rsi
	salq	$3, %rsi
	jmp	.L165
	.p2align 4,,10
	.p2align 3
.L181:
	movl	32(%rsp), %edx
	movl	%r12d, %r12d
	movl	%edx, (%rax)
	movl	-4(%rbp,%r12), %edx
	movl	%edx, -4(%rax,%r12)
	jmp	.L169
	.p2align 4,,10
	.p2align 3
.L182:
	movl	%r12d, %r12d
	movzwl	-2(%rbp,%r12), %edx
	movw	%dx, -2(%rax,%r12)
	jmp	.L169
.L180:
	movq	stderr(%rip), %rcx
	movl	$14, %edx
	movl	$1, %esi
	leaq	.LC19(%rip), %rdi
	call	fwrite@PLT
	movl	$1, %edi
	call	exit@PLT
.L179:
	call	xrealloc.part.0
	.cfi_endproc
.LFE26:
	.size	addf, .-addf
	.section	.rodata.str1.1
.LC33:
	.string	""
.LC34:
	.string	"%*s^\n"
	.text
	.p2align 4
	.type	bad_arg, @function
bad_arg:
.LFB30:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movl	%edi, %ebx
	subq	$376, %rsp
	.cfi_def_cfa_offset 400
	movq	%rdx, 208(%rsp)
	movq	%rcx, 216(%rsp)
	movq	%r8, 224(%rsp)
	movq	%r9, 232(%rsp)
	testb	%al, %al
	je	.L188
	movaps	%xmm0, 240(%rsp)
	movaps	%xmm1, 256(%rsp)
	movaps	%xmm2, 272(%rsp)
	movaps	%xmm3, 288(%rsp)
	movaps	%xmm4, 304(%rsp)
	movaps	%xmm5, 320(%rsp)
	movaps	%xmm6, 336(%rsp)
	movaps	%xmm7, 352(%rsp)
.L188:
	leaq	400(%rsp), %rax
	leaq	32(%rsp), %rbp
	movq	%rsi, %rdx
	movl	$160, %esi
	movq	%rax, 16(%rsp)
	leaq	8(%rsp), %rcx
	leaq	192(%rsp), %rax
	movq	%rbp, %rdi
	movl	$16, 8(%rsp)
	movl	$48, 12(%rsp)
	movq	%rax, 24(%rsp)
	call	vsnprintf@PLT
	movl	loading(%rip), %eax
	testl	%eax, %eax
	jne	.L185
	addl	708+C(%rip), %ebx
	leaq	C(%rip), %rax
	movslq	%ebx, %rdi
	cmpl	704+C(%rip), %edi
	jl	.L190
	movq	%rax, %rdi
	call	strlen@PLT
	movl	%eax, %esi
.L187:
	addl	prompt_len(%rip), %esi
	leaq	.LC33(%rip), %rdx
	leaq	.LC34(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
.L185:
	movq	%rbp, %rsi
	leaq	.LC24(%rip), %rdi
	xorl	%eax, %eax
	call	err
	addq	$376, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	movl	$-1, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L190:
	.cfi_restore_state
	movl	640(%rax,%rdi,4), %esi
	jmp	.L187
	.cfi_endproc
.LFE30:
	.size	bad_arg, .-bad_arg
	.section	.rodata.str1.1
.LC35:
	.string	"RIP version must be 1 or 2."
	.text
	.p2align 4
	.type	h_rip_version, @function
h_rip_version:
.LFB74:
	.cfi_startproc
	movq	(%rsi), %rax
	movzbl	(%rax), %edx
	cmpl	$49, %edx
	jne	.L197
	cmpb	$0, 1(%rax)
	jne	.L197
.L193:
	movsbl	(%rax), %eax
	movl	$1, %edx
	subl	$48, %eax
	cmpl	%eax, 684+cfg(%rip)
	je	.L206
	movl	%eax, 684+cfg(%rip)
	xorl	%edx, %edx
.L206:
	movl	%edx, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L197:
	cmpl	$50, %edx
	je	.L208
.L198:
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	leaq	.LC35(%rip), %rsi
	xorl	%edi, %edi
	xorl	%eax, %eax
	call	bad_arg
	movl	$-1, %eax
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L208:
	cmpb	$0, 1(%rax)
	je	.L193
	jmp	.L198
	.cfi_endproc
.LFE74:
	.size	h_rip_version, .-h_rip_version
	.section	.rodata.str1.8
	.align 8
.LC36:
	.string	"Description too long (max 99 characters)."
	.text
	.p2align 4
	.type	h_description, @function
h_description:
.LFB64:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movslq	708+C(%rip), %rax
	cmpl	704+C(%rip), %eax
	jge	.L212
	leaq	C(%rip), %rdx
	movslq	640(%rdx,%rax,4), %rbx
	addq	%rdx, %rbx
	movq	%rbx, %rdi
	call	strlen@PLT
	cmpq	$99, %rax
	ja	.L216
.L210:
	movq	cur_if(%rip), %rax
	movq	%rbx, %rsi
	leaq	40(%rax), %rbp
	movq	%rbp, %rdi
	call	strcmp@PLT
	movl	%eax, %edx
	movl	$1, %eax
	testl	%edx, %edx
	jne	.L217
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L212:
	.cfi_restore_state
	leaq	.LC33(%rip), %rbx
	jmp	.L210
	.p2align 4,,10
	.p2align 3
.L217:
	movq	%rbx, %rcx
	movq	%rbp, %rdi
	leaq	.LC24(%rip), %rdx
	xorl	%eax, %eax
	movl	$100, %esi
	call	snprintf@PLT
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L216:
	.cfi_restore_state
	leaq	.LC36(%rip), %rsi
	xorl	%edi, %edi
	xorl	%eax, %eax
	call	bad_arg
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	movl	$-1, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE64:
	.size	h_description, .-h_description
	.section	.rodata.str1.1
.LC37:
	.string	"Password too long (max 63)."
	.text
	.p2align 4
	.type	h_secret, @function
h_secret:
.LFB55:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movq	(%rsi), %rbx
	movq	%rbx, %rdi
	call	strlen@PLT
	cmpq	$63, %rax
	ja	.L224
	leaq	64+cfg(%rip), %rbp
	movq	%rbx, %rsi
	movq	%rbp, %rdi
	call	strcmp@PLT
	movl	%eax, %edx
	movl	$1, %eax
	testl	%edx, %edx
	jne	.L225
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L225:
	.cfi_restore_state
	movq	%rbx, %rcx
	movq	%rbp, %rdi
	leaq	.LC24(%rip), %rdx
	xorl	%eax, %eax
	movl	$64, %esi
	call	snprintf@PLT
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L224:
	.cfi_restore_state
	leaq	.LC37(%rip), %rsi
	xorl	%edi, %edi
	xorl	%eax, %eax
	call	bad_arg
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	movl	$-1, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE55:
	.size	h_secret, .-h_secret
	.section	.rodata.str1.8
	.align 8
.LC38:
	.string	"Hostname must start with a letter and be at most 63 characters."
	.align 8
.LC39:
	.string	"Hostname may contain only letters, digits, '-' and '_'."
	.section	.rodata.str1.1
.LC40:
	.string	"hostname -> %s"
	.text
	.p2align 4
	.type	h_hostname, @function
h_hostname:
.LFB53:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$8, %rsp
	.cfi_def_cfa_offset 48
	movq	(%rsi), %rbp
	call	__ctype_b_loc@PLT
	movq	(%rax), %r13
	movzbl	0(%rbp), %eax
	movzwl	0(%r13,%rax,2), %r12d
	testw	$1024, %r12w
	je	.L227
	movq	%rbp, %rdi
	movq	%rax, %rbx
	call	strlen@PLT
	cmpq	$63, %rax
	ja	.L227
	testb	%bl, %bl
	je	.L228
	leaq	1(%rbp), %rax
	jmp	.L229
	.p2align 4,,10
	.p2align 3
.L252:
	movzbl	%bl, %edx
	movzwl	0(%r13,%rdx,2), %r12d
.L229:
	cmpb	$45, %bl
	setne	%cl
	cmpb	$95, %bl
	setne	%dl
	testb	%dl, %cl
	je	.L231
	andl	$8, %r12d
	je	.L251
.L231:
	movzbl	(%rax), %ebx
	addq	$1, %rax
	testb	%bl, %bl
	jne	.L252
.L228:
	leaq	cfg(%rip), %rbx
	movq	%rbp, %rsi
	movq	%rbx, %rdi
	call	strcmp@PLT
	movl	%eax, %edx
	movl	$1, %eax
	testl	%edx, %edx
	je	.L226
	movq	%rbp, %rcx
	leaq	.LC24(%rip), %rdx
	movq	%rbx, %rdi
	xorl	%eax, %eax
	movl	$64, %esi
	call	snprintf@PLT
	xorl	%eax, %eax
	movq	%rbp, %rcx
	movl	$1, %edi
	leaq	.LC40(%rip), %rdx
	leaq	.LC2(%rip), %rsi
	call	rlog_log@PLT
	xorl	%eax, %eax
.L226:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L227:
	.cfi_restore_state
	leaq	.LC38(%rip), %rsi
	xorl	%edi, %edi
	xorl	%eax, %eax
	call	bad_arg
.L230:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	movl	$-1, %eax
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L251:
	.cfi_restore_state
	leaq	.LC39(%rip), %rsi
	xorl	%edi, %edi
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L230
	.cfi_endproc
.LFE53:
	.size	h_hostname, .-h_hostname
	.section	.rodata.str1.1
.LC41:
	.string	"  %-34s %-26s %s\n"
.LC42:
	.string	"% Unrecognized command"
	.section	.rodata.str1.8
	.align 8
.LC43:
	.string	"  (abbreviations work: conf t, int g0/0, sh ip int br, no sh ...)"
	.text
	.p2align 4
	.type	show_help, @function
show_help:
.LFB108:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	leaq	CMDS(%rip), %rbx
	subq	$168, %rsp
	.cfi_def_cfa_offset 224
	movl	%edi, 24(%rsp)
	movl	$0, 28(%rsp)
	jmp	.L269
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L258:
	addq	$48, %rbx
	leaq	2448+CMDS(%rip), %rax
	cmpq	%rbx, %rax
	je	.L300
.L269:
	movl	(%rbx), %edx
	movl	mode(%rip), %eax
	btl	%eax, %edx
	jnc	.L258
	movq	8(%rbx), %rcx
	movzbl	(%rcx), %edx
	movq	%rcx, 16(%rsp)
	testb	%dl, %dl
	je	.L255
	leaq	32(%rsp), %r8
	xorl	%r9d, %r9d
	movq	%r8, (%rsp)
	cmpb	$32, %dl
	jne	.L257
	.p2align 4
	.p2align 4
	.p2align 3
.L259:
	movzbl	1(%rcx), %edx
	addq	$1, %rcx
	cmpb	$32, %dl
	je	.L259
	testb	%dl, %dl
	je	.L260
.L257:
	movq	%rcx, %rsi
	testb	$-33, %dl
	je	.L301
.L274:
	movl	$1, %eax
	jmp	.L261
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L303:
	addq	$1, %rax
	cmpq	$24, %rax
	je	.L302
.L261:
	movb	%dl, -1(%r8,%rax)
	movzbl	(%rsi,%rax), %edx
	leaq	(%rsi,%rax), %rdi
	movq	%rdi, %rcx
	testb	$-33, %dl
	jne	.L303
	cltq
	addl	$1, %r9d
	addq	$24, %r8
	movb	$0, -24(%r8,%rax)
	testb	%dl, %dl
	jne	.L259
	.p2align 4
	.p2align 3
.L260:
	movl	24(%rsp), %eax
	cmpl	%r9d, %eax
	cmovle	%eax, %r9d
	testl	%r9d, %r9d
	jle	.L255
	leaq	C(%rip), %rbp
	movslq	%r9d, %r9
	leaq	0(%rbp,%r9,8), %rax
	movq	%rax, 8(%rsp)
.L271:
	movq	512(%rbp), %r13
	movzbl	0(%r13), %r14d
	testb	%r14b, %r14b
	je	.L258
	movq	(%rsp), %r15
	.p2align 4
	.p2align 3
.L266:
	movzbl	(%r15), %r12d
	testb	%r12b, %r12b
	je	.L258
	call	__ctype_tolower_loc@PLT
	movzbl	%r12b, %ecx
	movzbl	%r14b, %edx
	movq	(%rax), %rax
	movl	(%rax,%rcx,4), %edi
	cmpl	%edi, (%rax,%rdx,4)
	jne	.L258
	movzbl	1(%r13), %r14d
	addq	$1, %r13
	addq	$1, %r15
	testb	%r14b, %r14b
	jne	.L266
	addq	$24, (%rsp)
	addq	$8, %rbp
	cmpq	%rbp, 8(%rsp)
	jne	.L271
.L255:
	movq	40(%rbx), %rcx
	movq	16(%rbx), %rdx
	xorl	%eax, %eax
	addq	$48, %rbx
	movq	16(%rsp), %rsi
	leaq	.LC41(%rip), %rdi
	call	printf@PLT
	leaq	2448+CMDS(%rip), %rax
	addl	$1, 28(%rsp)
	cmpq	%rbx, %rax
	jne	.L269
.L300:
	movl	28(%rsp), %eax
	leaq	.LC42(%rip), %rdi
	testl	%eax, %eax
	je	.L299
	leaq	.LC43(%rip), %rdi
.L299:
	addq	$168, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	jmp	puts@PLT
	.p2align 4,,10
	.p2align 3
.L302:
	.cfi_restore_state
	movb	$0, 23(%r8)
	addl	$1, %r9d
	addq	$24, %r8
	cmpb	$32, %dl
	je	.L259
	movq	%rdi, %rsi
	testb	$-33, %dl
	jne	.L274
.L301:
	movb	$0, (%r8)
	addl	$1, %r9d
	jmp	.L260
	.cfi_endproc
.LFE108:
	.size	show_help, .-show_help
	.p2align 4
	.type	h_help, @function
h_help:
.LFB109:
	.cfi_startproc
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	xorl	%edi, %edi
	movl	$0, 704+C(%rip)
	call	show_help
	xorl	%eax, %eax
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE109:
	.size	h_help, .-h_help
	.p2align 4
	.type	route_installed, @function
route_installed:
.LFB44:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movl	52(%rdi), %ebp
	testl	%ebp, %ebp
	jne	.L327
	movzbl	12(%rdi), %r12d
	leaq	12(%rdi), %rbx
	testb	%r12b, %r12b
	je	.L319
	call	__ctype_tolower_loc@PLT
	movq	%rbx, %rdx
	movq	(%rax), %rsi
	movl	$5381, %eax
	.p2align 5
	.p2align 4
	.p2align 3
.L313:
	movl	%eax, %ecx
	addq	$1, %rdx
	sall	$5, %ecx
	addl	%ecx, %eax
	movzbl	(%rsi,%r12,4), %ecx
	movzbl	(%rdx), %r12d
	addl	%ecx, %eax
	testb	%r12b, %r12b
	jne	.L313
	andl	$63, %eax
.L312:
	leaq	cfg(%rip), %rdx
	movq	128(%rdx,%rax,8), %r12
	testq	%r12, %r12
	jne	.L315
	jmp	.L306
	.p2align 4,,10
	.p2align 3
.L328:
	movq	168(%r12), %r12
	testq	%r12, %r12
	je	.L306
.L315:
	movq	%rbx, %rsi
	movq	%r12, %rdi
	call	strcmp@PLT
	testl	%eax, %eax
	jne	.L328
	movl	152(%r12), %eax
	xorl	%ebp, %ebp
	testl	%eax, %eax
	sete	%bpl
.L306:
	movl	%ebp, %eax
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L327:
	.cfi_restore_state
	movq	640+cfg(%rip), %rax
	movl	8(%rdi), %edi
	testq	%rax, %rax
	je	.L316
	xorl	%edx, %edx
	.p2align 4
	.p2align 3
.L310:
	movl	148(%rax), %esi
	testl	%esi, %esi
	je	.L309
	movl	152(%rax), %ecx
	testl	%ecx, %ecx
	jne	.L309
	movl	140(%rax), %esi
	movl	144(%rax), %ecx
	xorl	%edi, %esi
	testl	%ecx, %esi
	jne	.L309
	testq	%rdx, %rdx
	je	.L317
	cmpl	%ecx, 144(%rdx)
	cmovb	%rax, %rdx
	.p2align 4
	.p2align 3
.L309:
	movq	176(%rax), %rax
	testq	%rax, %rax
	jne	.L310
	xorl	%ebp, %ebp
	testq	%rdx, %rdx
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	setne	%bpl
	movl	%ebp, %eax
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L317:
	.cfi_restore_state
	movq	%rax, %rdx
	jmp	.L309
	.p2align 4,,10
	.p2align 3
.L319:
	movl	$5, %eax
	jmp	.L312
.L316:
	xorl	%ebp, %ebp
	jmp	.L306
	.cfi_endproc
.LFE44:
	.size	route_installed, .-route_installed
	.p2align 4
	.type	lookup, @function
lookup:
.LFB45:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movl	$-1, %r15d
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	movl	%edi, %r12d
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$40, %rsp
	.cfi_def_cfa_offset 96
	movq	640+cfg(%rip), %rdx
	movl	$999, 24(%rsp)
	movl	$0, 28(%rsp)
	testq	%rdx, %rdx
	jne	.L339
	jmp	.L330
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L331:
	movq	176(%rdx), %rdx
	testq	%rdx, %rdx
	je	.L330
.L339:
	movl	148(%rdx), %r8d
	testl	%r8d, %r8d
	je	.L331
	movl	152(%rdx), %edi
	testl	%edi, %edi
	jne	.L331
	movl	140(%rdx), %r10d
	movl	144(%rdx), %r9d
	movl	%r10d, %eax
	xorl	%r12d, %eax
	testl	%r9d, %eax
	jne	.L331
	testl	%r9d, %r9d
	je	.L332
	xorl	%edi, %edi
	movl	%r9d, %eax
	.p2align 4
	.p2align 4
	.p2align 3
.L333:
	movl	%eax, %r8d
	andl	$1, %r8d
	addl	%r8d, %edi
	shrl	%eax
	jne	.L333
	cmpl	%r15d, %edi
	jg	.L349
	xorl	%edi, %edi
	movl	%r9d, %eax
	.p2align 4
	.p2align 4
	.p2align 3
.L337:
	movl	%eax, %r8d
	andl	$1, %r8d
	addl	%r8d, %edi
	shrl	%eax
	jne	.L337
	cmpl	%r15d, %edi
	jne	.L331
	movl	24(%rsp), %eax
	testl	%eax, %eax
	je	.L331
	.p2align 4
	.p2align 3
.L349:
	xorl	%r15d, %r15d
	movl	%r9d, %eax
	.p2align 4
	.p2align 4
	.p2align 3
.L338:
	movl	%eax, %edi
	andl	$1, %edi
	addl	%edi, %r15d
	shrl	%eax
	jne	.L338
.L335:
	andl	%r9d, %r10d
	movb	$67, (%rsi)
	movd	%r9d, %xmm3
	movq	%rdx, 16(%rsi)
	movd	%r10d, %xmm0
	movq	176(%rdx), %rdx
	punpckldq	%xmm3, %xmm0
	movq	$0, 24(%rsi)
	movl	$0, 12(%rsi)
	movl	$0, 24(%rsp)
	movl	$1, 28(%rsp)
	movq	%xmm0, 4(%rsi)
	testq	%rdx, %rdx
	jne	.L339
	.p2align 4
	.p2align 3
.L330:
	movslq	672+cfg(%rip), %rax
	testl	%eax, %eax
	jle	.L329
	movq	%rax, %rdx
	movq	664+cfg(%rip), %r13
	salq	$4, %rdx
	subq	%rax, %rdx
	leaq	0(%r13,%rdx,4), %rbp
	.p2align 4
	.p2align 3
.L346:
	movl	4(%r13), %r14d
	testl	%r14d, %r14d
	je	.L350
	movl	%r14d, %eax
	xorl	%ebx, %ebx
	.p2align 4
	.p2align 4
	.p2align 3
.L342:
	movl	%eax, %edx
	andl	$1, %edx
	addl	%edx, %ebx
	shrl	%eax
	jne	.L342
.L341:
	movl	%r14d, %eax
	movl	0(%r13), %edx
	andl	%r12d, %eax
	cmpl	%edx, %eax
	je	.L365
.L343:
	addq	$60, %r13
	cmpq	%r13, %rbp
	jne	.L346
.L329:
	movl	28(%rsp), %eax
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L365:
	.cfi_restore_state
	movq	%r13, %rdi
	movq	%rsi, 8(%rsp)
	movl	%edx, 20(%rsp)
	call	route_installed
	movq	8(%rsp), %rsi
	testl	%eax, %eax
	je	.L343
	cmpl	%ebx, %r15d
	movl	20(%rsp), %edx
	jge	.L344
	movl	56(%r13), %ecx
	movl	%ecx, 24(%rsp)
.L345:
	movd	%edx, %xmm0
	movd	%r14d, %xmm1
	movb	$83, (%rsi)
	movl	%ebx, %r15d
	punpckldq	%xmm1, %xmm0
	movl	%eax, 28(%rsp)
	movq	%xmm0, 4(%rsi)
	movl	8(%r13), %edx
	movd	24(%rsp), %xmm0
	movl	%edx, 12(%rsi)
	movd	52(%r13), %xmm2
	leaq	12(%r13), %rdx
	movq	%rdx, 16(%rsi)
	punpckldq	%xmm2, %xmm0
	movq	%xmm0, 24(%rsi)
	jmp	.L343
	.p2align 4,,10
	.p2align 3
.L344:
	jne	.L343
	movl	56(%r13), %edi
	movl	24(%rsp), %ecx
	cmpl	%ecx, %edi
	jge	.L343
	movl	%edi, 24(%rsp)
	jmp	.L345
	.p2align 4,,10
	.p2align 3
.L350:
	xorl	%ebx, %ebx
	jmp	.L341
.L332:
	testl	%r15d, %r15d
	js	.L348
	jne	.L331
	movl	24(%rsp), %ecx
	testl	%ecx, %ecx
	je	.L331
	jmp	.L335
	.p2align 4,,10
	.p2align 3
.L348:
	xorl	%r15d, %r15d
	jmp	.L335
	.cfi_endproc
.LFE45:
	.size	lookup, .-lookup
	.section	.rodata.str1.8
	.align 8
.LC44:
	.string	"OSPF process id must be 1-65535."
	.align 8
.LC45:
	.string	"OSPF process %llu is not configured."
	.text
	.p2align 4
	.type	h_no_router_ospf, @function
h_no_router_ospf:
.LFB73:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movq	(%rsi), %rbp
	movzbl	0(%rbp), %ebx
	testb	%bl, %bl
	je	.L367
	call	__ctype_b_loc@PLT
	movq	(%rax), %rdx
	movzbl	%bl, %eax
	testb	$8, 1(%rdx,%rax,2)
	je	.L367
	movsbl	%bl, %esi
	movzbl	1(%rbp), %eax
	subl	$48, %esi
	movslq	%esi, %rsi
	testb	%al, %al
	je	.L368
	movzbl	%al, %ecx
	testb	$8, 1(%rdx,%rcx,2)
	je	.L367
	movsbl	%al, %eax
	leaq	(%rsi,%rsi,4), %rcx
	subl	$48, %eax
	cltq
	leaq	(%rax,%rcx,2), %rsi
	movzbl	2(%rbp), %eax
	testb	%al, %al
	je	.L368
	movzbl	%al, %ecx
	testb	$8, 1(%rdx,%rcx,2)
	je	.L367
	movsbl	%al, %eax
	leaq	(%rsi,%rsi,4), %rcx
	subl	$48, %eax
	cltq
	leaq	(%rax,%rcx,2), %rsi
	movzbl	3(%rbp), %eax
	testb	%al, %al
	je	.L368
	movzbl	%al, %ecx
	testb	$8, 1(%rdx,%rcx,2)
	je	.L367
	movsbl	%al, %eax
	leaq	(%rsi,%rsi,4), %rcx
	subl	$48, %eax
	cltq
	leaq	(%rax,%rcx,2), %rsi
	movzbl	4(%rbp), %eax
	testb	%al, %al
	je	.L368
	movzbl	%al, %ecx
	testb	$8, 1(%rdx,%rcx,2)
	je	.L367
	movsbl	%al, %eax
	leaq	(%rsi,%rsi,4), %rcx
	subl	$48, %eax
	cltq
	leaq	(%rax,%rcx,2), %rsi
	movzbl	5(%rbp), %eax
	testb	%al, %al
	je	.L368
	movzbl	%al, %ecx
	testb	$8, 1(%rdx,%rcx,2)
	je	.L367
	movsbl	%al, %eax
	leaq	(%rsi,%rsi,4), %rcx
	subl	$48, %eax
	cltq
	leaq	(%rax,%rcx,2), %rsi
	movzbl	6(%rbp), %eax
	testb	%al, %al
	je	.L368
	movzbl	%al, %ecx
	testb	$8, 1(%rdx,%rcx,2)
	je	.L367
	movsbl	%al, %eax
	leaq	(%rsi,%rsi,4), %rcx
	subl	$48, %eax
	cltq
	leaq	(%rax,%rcx,2), %rsi
	movzbl	7(%rbp), %eax
	testb	%al, %al
	je	.L368
	movzbl	%al, %ecx
	testb	$8, 1(%rdx,%rcx,2)
	je	.L367
	movsbl	%al, %eax
	leaq	(%rsi,%rsi,4), %rcx
	subl	$48, %eax
	cltq
	leaq	(%rax,%rcx,2), %rsi
	movzbl	8(%rbp), %eax
	testb	%al, %al
	je	.L368
	movzbl	%al, %ecx
	testb	$8, 1(%rdx,%rcx,2)
	je	.L367
	movsbl	%al, %eax
	leaq	(%rsi,%rsi,4), %rcx
	subl	$48, %eax
	cltq
	leaq	(%rax,%rcx,2), %rsi
	movzbl	9(%rbp), %eax
	testb	%al, %al
	je	.L368
	movzbl	%al, %ecx
	testb	$8, 1(%rdx,%rcx,2)
	je	.L367
	cmpb	$0, 10(%rbp)
	je	.L436
.L367:
	leaq	.LC44(%rip), %rsi
	xorl	%edi, %edi
	xorl	%eax, %eax
	call	bad_arg
.L371:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	movl	$-1, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L436:
	.cfi_restore_state
	movsbl	%al, %eax
	leaq	(%rsi,%rsi,4), %rdx
	subl	$48, %eax
	cltq
	leaq	(%rax,%rdx,2), %rsi
	.p2align 4
	.p2align 3
.L368:
	leaq	-1(%rsi), %rax
	cmpq	$65534, %rax
	ja	.L367
	movl	712+cfg(%rip), %eax
	testl	%eax, %eax
	je	.L369
	cmpl	%esi, 716+cfg(%rip)
	jne	.L369
	movq	728+cfg(%rip), %rdi
	call	free@PLT
	xorl	%eax, %eax
	movq	$0, 728+cfg(%rip)
	movq	$0, 736+cfg(%rip)
	movl	$0, 712+cfg(%rip)
	movl	$0, 720+cfg(%rip)
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L369:
	.cfi_restore_state
	leaq	.LC45(%rip), %rdi
	xorl	%eax, %eax
	call	err
	jmp	.L371
	.cfi_endproc
.LFE73:
	.size	h_no_router_ospf, .-h_no_router_ospf
	.section	.rodata.str1.8
	.align 8
.LC46:
	.string	"OSPF process %d already exists (this compiler supports one OSPF process)."
	.section	.rodata.str1.1
.LC47:
	.string	"OSPF %d enabled"
	.text
	.p2align 4
	.type	h_router_ospf, @function
h_router_ospf:
.LFB72:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movq	(%rsi), %rbp
	movzbl	0(%rbp), %ebx
	testb	%bl, %bl
	je	.L438
	call	__ctype_b_loc@PLT
	movq	(%rax), %rcx
	movzbl	%bl, %eax
	testb	$8, 1(%rcx,%rax,2)
	je	.L438
	movsbl	%bl, %eax
	movzbl	1(%rbp), %edx
	subl	$48, %eax
	cltq
	testb	%dl, %dl
	je	.L439
	movzbl	%dl, %esi
	testb	$8, 1(%rcx,%rsi,2)
	je	.L438
	movsbl	%dl, %edx
	leaq	(%rax,%rax,4), %rax
	subl	$48, %edx
	movslq	%edx, %rdx
	leaq	(%rdx,%rax,2), %rax
	movzbl	2(%rbp), %edx
	testb	%dl, %dl
	je	.L439
	movzbl	%dl, %esi
	testb	$8, 1(%rcx,%rsi,2)
	je	.L438
	movsbl	%dl, %edx
	leaq	(%rax,%rax,4), %rax
	subl	$48, %edx
	movslq	%edx, %rdx
	leaq	(%rdx,%rax,2), %rax
	movzbl	3(%rbp), %edx
	testb	%dl, %dl
	je	.L439
	movzbl	%dl, %esi
	testb	$8, 1(%rcx,%rsi,2)
	je	.L438
	movsbl	%dl, %edx
	leaq	(%rax,%rax,4), %rax
	subl	$48, %edx
	movslq	%edx, %rdx
	leaq	(%rdx,%rax,2), %rax
	movzbl	4(%rbp), %edx
	testb	%dl, %dl
	je	.L439
	movzbl	%dl, %esi
	testb	$8, 1(%rcx,%rsi,2)
	je	.L438
	movsbl	%dl, %edx
	leaq	(%rax,%rax,4), %rax
	subl	$48, %edx
	movslq	%edx, %rdx
	leaq	(%rdx,%rax,2), %rax
	movzbl	5(%rbp), %edx
	testb	%dl, %dl
	je	.L439
	movzbl	%dl, %esi
	testb	$8, 1(%rcx,%rsi,2)
	je	.L438
	movsbl	%dl, %edx
	leaq	(%rax,%rax,4), %rax
	subl	$48, %edx
	movslq	%edx, %rdx
	leaq	(%rdx,%rax,2), %rax
	movzbl	6(%rbp), %edx
	testb	%dl, %dl
	je	.L439
	movzbl	%dl, %esi
	testb	$8, 1(%rcx,%rsi,2)
	je	.L438
	movsbl	%dl, %edx
	leaq	(%rax,%rax,4), %rax
	subl	$48, %edx
	movslq	%edx, %rdx
	leaq	(%rdx,%rax,2), %rax
	movzbl	7(%rbp), %edx
	testb	%dl, %dl
	je	.L439
	movzbl	%dl, %esi
	testb	$8, 1(%rcx,%rsi,2)
	je	.L438
	movsbl	%dl, %edx
	leaq	(%rax,%rax,4), %rax
	subl	$48, %edx
	movslq	%edx, %rdx
	leaq	(%rdx,%rax,2), %rax
	movzbl	8(%rbp), %edx
	testb	%dl, %dl
	je	.L439
	movzbl	%dl, %esi
	testb	$8, 1(%rcx,%rsi,2)
	je	.L438
	movsbl	%dl, %edx
	leaq	(%rax,%rax,4), %rax
	subl	$48, %edx
	movslq	%edx, %rdx
	leaq	(%rdx,%rax,2), %rax
	movzbl	9(%rbp), %edx
	testb	%dl, %dl
	je	.L439
	movzbl	%dl, %esi
	testb	$8, 1(%rcx,%rsi,2)
	je	.L438
	cmpb	$0, 10(%rbp)
	je	.L507
.L438:
	leaq	.LC44(%rip), %rsi
	xorl	%edi, %edi
	xorl	%eax, %eax
	call	bad_arg
.L442:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	movl	$-1, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L507:
	.cfi_restore_state
	leaq	(%rax,%rax,4), %rcx
	movsbl	%dl, %eax
	subl	$48, %eax
	cltq
	leaq	(%rax,%rcx,2), %rax
	.p2align 4
	.p2align 3
.L439:
	leaq	-1(%rax), %rdx
	cmpq	$65534, %rdx
	ja	.L438
	movl	712+cfg(%rip), %edx
	movl	%eax, %ecx
	testl	%edx, %edx
	je	.L508
	movl	716+cfg(%rip), %esi
	cmpl	%eax, %esi
	jne	.L509
.L443:
	xorl	%eax, %eax
	leaq	.LC47(%rip), %rdx
	movl	$1, %edi
	movl	$5, mode(%rip)
	leaq	.LC2(%rip), %rsi
	call	rlog_log@PLT
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L508:
	.cfi_restore_state
	movl	$1, 712+cfg(%rip)
	movl	%eax, 716+cfg(%rip)
	jmp	.L443
.L509:
	leaq	.LC46(%rip), %rdi
	xorl	%eax, %eax
	call	err
	jmp	.L442
	.cfi_endproc
.LFE72:
	.size	h_router_ospf, .-h_router_ospf
	.section	.rodata.str1.1
.LC48:
	.string	"Serial"
	.section	.rodata.str1.8
	.align 8
.LC49:
	.string	"Clock rate can only be set on Serial interfaces."
	.align 8
.LC50:
	.string	"Clock rate must be 1200-8000000 (e.g. 64000)."
	.text
	.p2align 4
	.type	h_clock, @function
h_clock:
.LFB66:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	movl	$6, %edx
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	movq	%rsi, %rbx
	leaq	.LC48(%rip), %rsi
	subq	$8, %rsp
	.cfi_def_cfa_offset 48
	movq	cur_if(%rip), %rbp
	movq	%rbp, %rdi
	call	strncmp@PLT
	testl	%eax, %eax
	jne	.L580
	movq	(%rbx), %r12
	movzbl	(%r12), %ebx
	testb	%bl, %bl
	je	.L513
	movl	%eax, %r13d
	call	__ctype_b_loc@PLT
	movq	(%rax), %rdx
	movzbl	%bl, %eax
	testb	$8, 1(%rdx,%rax,2)
	je	.L513
	movsbl	%bl, %ebx
	movzbl	1(%r12), %eax
	subl	$48, %ebx
	movslq	%ebx, %rbx
	testb	%al, %al
	je	.L513
	movzbl	%al, %ecx
	testb	$8, 1(%rdx,%rcx,2)
	je	.L513
	movsbl	%al, %eax
	leaq	(%rbx,%rbx,4), %rcx
	subl	$48, %eax
	cltq
	leaq	(%rax,%rcx,2), %rcx
	movzbl	2(%r12), %eax
	testb	%al, %al
	je	.L513
	movzbl	%al, %esi
	testb	$8, 1(%rdx,%rsi,2)
	je	.L513
	movsbl	%al, %eax
	leaq	(%rcx,%rcx,4), %rcx
	subl	$48, %eax
	cltq
	leaq	(%rax,%rcx,2), %rax
	movzbl	3(%r12), %ecx
	testb	%cl, %cl
	je	.L514
	movzbl	%cl, %esi
	testb	$8, 1(%rdx,%rsi,2)
	je	.L513
	movsbl	%cl, %ecx
	leaq	(%rax,%rax,4), %rax
	subl	$48, %ecx
	movslq	%ecx, %rcx
	leaq	(%rcx,%rax,2), %rax
	movzbl	4(%r12), %ecx
	testb	%cl, %cl
	je	.L514
	movzbl	%cl, %esi
	testb	$8, 1(%rdx,%rsi,2)
	je	.L513
	movsbl	%cl, %ecx
	leaq	(%rax,%rax,4), %rax
	subl	$48, %ecx
	movslq	%ecx, %rcx
	leaq	(%rcx,%rax,2), %rax
	movzbl	5(%r12), %ecx
	testb	%cl, %cl
	je	.L514
	movzbl	%cl, %esi
	testb	$8, 1(%rdx,%rsi,2)
	je	.L513
	movsbl	%cl, %ecx
	leaq	(%rax,%rax,4), %rax
	subl	$48, %ecx
	movslq	%ecx, %rcx
	leaq	(%rcx,%rax,2), %rax
	movzbl	6(%r12), %ecx
	testb	%cl, %cl
	je	.L514
	movzbl	%cl, %esi
	testb	$8, 1(%rdx,%rsi,2)
	je	.L513
	movsbl	%cl, %ecx
	leaq	(%rax,%rax,4), %rax
	subl	$48, %ecx
	movslq	%ecx, %rcx
	leaq	(%rcx,%rax,2), %rax
	movzbl	7(%r12), %ecx
	testb	%cl, %cl
	je	.L514
	movzbl	%cl, %esi
	testb	$8, 1(%rdx,%rsi,2)
	je	.L513
	movsbl	%cl, %ecx
	leaq	(%rax,%rax,4), %rax
	subl	$48, %ecx
	movslq	%ecx, %rcx
	leaq	(%rcx,%rax,2), %rax
	movzbl	8(%r12), %ecx
	testb	%cl, %cl
	je	.L514
	movzbl	%cl, %esi
	testb	$8, 1(%rdx,%rsi,2)
	je	.L513
	movsbl	%cl, %ecx
	leaq	(%rax,%rax,4), %rax
	subl	$48, %ecx
	movslq	%ecx, %rcx
	leaq	(%rcx,%rax,2), %rax
	movzbl	9(%r12), %ecx
	testb	%cl, %cl
	je	.L514
	movzbl	%cl, %esi
	testb	$8, 1(%rdx,%rsi,2)
	je	.L513
	cmpb	$0, 10(%r12)
	je	.L581
.L513:
	leaq	.LC50(%rip), %rsi
	xorl	%edi, %edi
	xorl	%eax, %eax
	call	bad_arg
.L512:
	movl	$-1, %r13d
.L510:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	movl	%r13d, %eax
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L580:
	.cfi_restore_state
	leaq	.LC49(%rip), %rdi
	xorl	%eax, %eax
	call	err
	jmp	.L512
.L581:
	leaq	(%rax,%rax,4), %rdx
	movsbl	%cl, %eax
	subl	$48, %eax
	cltq
	leaq	(%rax,%rdx,2), %rax
	.p2align 4
	.p2align 3
.L514:
	leaq	-1200(%rax), %rdx
	cmpq	$7998800, %rdx
	ja	.L513
	cmpq	%rax, 160(%rbp)
	je	.L582
	movq	%rax, 160(%rbp)
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	movl	%r13d, %eax
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L582:
	.cfi_restore_state
	movl	$1, %r13d
	jmp	.L510
	.cfi_endproc
.LFE66:
	.size	h_clock, .-h_clock
	.section	.rodata.str1.1
.LC51:
	.string	"Status"
.LC52:
	.string	"Method"
.LC53:
	.string	"OK?"
.LC54:
	.string	"IP-Address"
.LC55:
	.string	"Interface"
	.section	.rodata.str1.8
	.align 8
.LC56:
	.string	"%-22s %-15s %-4s %-7s %-21s %s\n"
	.section	.rodata.str1.1
.LC57:
	.string	"Protocol"
.LC58:
	.string	"%u.%u.%u.%u"
.LC59:
	.string	"manual"
.LC60:
	.string	"YES"
.LC61:
	.string	"unset"
.LC62:
	.string	"unassigned"
.LC63:
	.string	"(no interfaces configured)"
	.text
	.p2align 4
	.type	h_show_ipbrief, @function
h_show_ipbrief:
.LFB85:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	leaq	.LC57(%rip), %rax
	leaq	.LC51(%rip), %r9
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	leaq	.LC52(%rip), %r8
	leaq	.LC53(%rip), %rcx
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	leaq	.LC54(%rip), %rdx
	leaq	.LC55(%rip), %rsi
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	leaq	.LC56(%rip), %r12
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	movq	%r12, %rdi
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$16, %rsp
	.cfi_def_cfa_offset 72
	pushq	%rax
	.cfi_def_cfa_offset 80
	xorl	%eax, %eax
	call	printf@PLT
	movq	640+cfg(%rip), %rbx
	popq	%r8
	.cfi_def_cfa_offset 72
	popq	%r9
	.cfi_def_cfa_offset 64
	testq	%rbx, %rbx
	je	.L584
	leaq	.LC32(%rip), %rbp
	jmp	.L588
	.p2align 4,,10
	.p2align 3
.L599:
	movl	140(%rbx), %eax
	movl	i.2(%rip), %r13d
	subq	$8, %rsp
	.cfi_def_cfa_offset 72
	movl	$16, %esi
	leal	1(%r13), %edx
	movzbl	%ah, %edi
	movl	%eax, %r8d
	movl	%eax, %ecx
	andl	$3, %r13d
	movzbl	%al, %eax
	movl	%edx, i.2(%rip)
	movl	%edi, %r9d
	pushq	%rax
	.cfi_def_cfa_offset 80
	leaq	b.1(%rip), %rdx
	salq	$4, %r13
	shrl	$16, %r8d
	addq	%rdx, %r13
	shrl	$24, %ecx
	movzbl	%r8b, %r8d
	xorl	%eax, %eax
	leaq	.LC58(%rip), %rdx
	movq	%r13, %rdi
	call	snprintf@PLT
	movq	%r15, (%rsp)
	movq	%r14, %r9
	movq	%r13, %rdx
	leaq	.LC59(%rip), %r8
	leaq	.LC60(%rip), %rcx
.L598:
	movq	%rbx, %rsi
	movq	%r12, %rdi
	xorl	%eax, %eax
	call	printf@PLT
	movq	176(%rbx), %rbx
	popq	%rdx
	.cfi_def_cfa_offset 72
	popq	%rcx
	.cfi_def_cfa_offset 64
	testq	%rbx, %rbx
	je	.L584
.L588:
	movl	152(%rbx), %edi
	movq	%rbp, %r15
	movq	%rbp, %r14
	testl	%edi, %edi
	je	.L585
	leaq	.LC13(%rip), %r15
	leaq	.LC11(%rip), %r14
.L585:
	movl	148(%rbx), %esi
	testl	%esi, %esi
	jne	.L599
	subq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 72
	movq	%r14, %r9
	leaq	.LC61(%rip), %r8
	pushq	%r15
	.cfi_def_cfa_offset 80
	leaq	.LC60(%rip), %rcx
	leaq	.LC62(%rip), %rdx
	jmp	.L598
	.p2align 4,,10
	.p2align 3
.L584:
	.cfi_restore_state
	movl	656+cfg(%rip), %eax
	testl	%eax, %eax
	je	.L600
.L589:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L600:
	.cfi_restore_state
	leaq	.LC63(%rip), %rdi
	call	puts@PLT
	jmp	.L589
	.cfi_endproc
.LFE85:
	.size	h_show_ipbrief, .-h_show_ipbrief
	.section	.rodata.str1.1
.LC64:
	.string	"do"
	.section	.rodata.str1.8
	.align 8
.LC65:
	.string	"Too many words on one line (max %d)."
	.section	.rodata.str1.1
.LC66:
	.string	"Incomplete command."
	.section	.rodata.str1.8
	.align 8
.LC67:
	.string	"Invalid input detected at '^' marker."
	.section	.rodata.str1.1
.LC68:
	.string	"Ambiguous command: \"%s\""
	.text
	.p2align 4
	.type	execute_line_impl, @function
execute_line_impl:
.LFB111:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movq	%rdi, %rax
	movl	$89, %ecx
	leaq	C(%rip), %rsi
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	leaq	.LC24(%rip), %rbx
	movq	%rbx, %rdx
	subq	$1224, %rsp
	.cfi_def_cfa_offset 1280
	addl	$1, st(%rip)
	leaq	496(%rsp), %rdi
	leaq	240(%rsp), %rbp
	movq	%rdi, 72(%rsp)
	rep movsq
	movq	%rax, %rcx
	movl	$256, %esi
	movq	%rbp, %rdi
	xorl	%eax, %eax
	call	snprintf@PLT
	xorl	%eax, %eax
	movq	%rbp, %rcx
	movq	%rbx, %rdx
	leaq	C(%rip), %rdi
	movl	$256, %esi
	call	snprintf@PLT
	leaq	C(%rip), %rdi
	call	strlen@PLT
	testq	%rax, %rax
	je	.L605
	movq	%rax, %rbx
	call	__ctype_b_loc@PLT
	movq	(%rax), %rdx
	jmp	.L604
	.p2align 6
	.p2align 4,,10
	.p2align 3
.L606:
	leaq	C(%rip), %rax
	movb	$0, (%rax,%rbx)
	testq	%rbx, %rbx
	je	.L605
.L604:
	subq	$1, %rbx
	leaq	C(%rip), %rax
	movzbl	(%rax,%rbx), %eax
	testb	$32, 1(%rdx,%rax,2)
	jne	.L606
.L605:
	movdqa	C(%rip), %xmm0
	leaq	256+C(%rip), %rbp
	xorl	%r13d, %r13d
	movq	%rbp, %r12
	leaq	256(%rbp), %r14
	movaps	%xmm0, 256+C(%rip)
	movdqa	16+C(%rip), %xmm0
	movaps	%xmm0, 272+C(%rip)
	movdqa	32+C(%rip), %xmm0
	movaps	%xmm0, 288+C(%rip)
	movdqa	48+C(%rip), %xmm0
	movaps	%xmm0, 304+C(%rip)
	movdqa	64+C(%rip), %xmm0
	movaps	%xmm0, 320+C(%rip)
	movdqa	80+C(%rip), %xmm0
	movaps	%xmm0, 336+C(%rip)
	movdqa	96+C(%rip), %xmm0
	movaps	%xmm0, 352+C(%rip)
	movdqa	112+C(%rip), %xmm0
	movaps	%xmm0, 368+C(%rip)
	movdqa	128+C(%rip), %xmm0
	movaps	%xmm0, 384+C(%rip)
	movdqa	144+C(%rip), %xmm0
	movaps	%xmm0, 400+C(%rip)
	movdqa	160+C(%rip), %xmm0
	movaps	%xmm0, 416+C(%rip)
	movdqa	176+C(%rip), %xmm0
	movaps	%xmm0, 432+C(%rip)
	movdqa	192+C(%rip), %xmm0
	movaps	%xmm0, 448+C(%rip)
	movdqa	208+C(%rip), %xmm0
	movaps	%xmm0, 464+C(%rip)
	movdqa	224+C(%rip), %xmm0
	movaps	%xmm0, 480+C(%rip)
	movdqa	240+C(%rip), %xmm0
	movaps	%xmm0, 496+C(%rip)
	movq	$0, 704+C(%rip)
.L603:
	movzbl	(%r12), %ebx
	movslq	%r13d, %r15
	testb	%bl, %bl
	je	.L607
	call	__ctype_b_loc@PLT
	movq	(%rax), %rdx
	jmp	.L616
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L608:
	movzbl	1(%r12), %ebx
	addq	$1, %r12
	testb	%bl, %bl
	je	.L607
.L616:
	testb	$32, 1(%rdx,%rbx,2)
	jne	.L608
	cmpl	$15, %r13d
	jg	.L728
	movq	%r12, %rax
	leaq	640+C(%rip), %rsi
	addl	$1, %r13d
	movq	%r12, (%r14,%r15,8)
	subq	%rbp, %rax
	movl	%eax, (%rsi,%r15,4)
	movl	%r13d, 704+C(%rip)
	movzbl	(%r12), %eax
	testb	%al, %al
	jne	.L611
	jmp	.L607
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L614:
	testb	%al, %al
	je	.L607
.L611:
	movzbl	%al, %ecx
	movq	%r12, %rsi
	movzbl	1(%r12), %eax
	addq	$1, %r12
	testb	$32, 1(%rdx,%rcx,2)
	je	.L614
	movb	$0, (%rsi)
	movl	704+C(%rip), %r13d
	jmp	.L603
	.p2align 4,,10
	.p2align 3
.L607:
	testl	%r13d, %r13d
	je	.L617
	movq	512+C(%rip), %r15
	movzbl	(%r15), %eax
	movb	%al, 83(%rsp)
	cmpb	$33, %al
	je	.L617
	leal	-1(%r13), %ebp
	leaq	C(%rip), %rsi
	movslq	%ebp, %rax
	movq	512(%rsi,%rax,8), %r12
	movq	%r12, %rdi
	call	strlen@PLT
	leaq	-1(%r12,%rax), %rax
	cmpb	$63, (%rax)
	je	.L619
	movzbl	83(%rsp), %eax
	movq	%r15, %rbx
	movl	$100, %ebp
	leaq	.LC64(%rip), %r14
	movzbl	%al, %r12d
	testb	%al, %al
	jne	.L620
	jmp	.L623
	.p2align 4,,10
	.p2align 3
.L666:
	movq	%rax, %r14
.L620:
	call	__ctype_tolower_loc@PLT
	movq	(%rax), %rax
	movl	(%rax,%rbp,4), %esi
	cmpl	%esi, (%rax,%r12,4)
	jne	.L623
	movzbl	1(%rbx), %r12d
	addq	$1, %rbx
	leaq	1(%r14), %rax
	testb	%r12b, %r12b
	je	.L729
	movzbl	1(%r14), %ebp
	testb	%bpl, %bpl
	jne	.L666
.L623:
	movl	mode(%rip), %ebp
.L621:
	movl	%ebp, %ecx
	movl	$1, %eax
	movq	%r15, 104(%rsp)
	leaq	CMDS(%rip), %r12
	sall	%cl, %eax
	testl	%r13d, %r13d
	movl	$-1, %r9d
	movl	%r13d, 68(%rsp)
	setg	95(%rsp)
	movl	%eax, %ecx
	xorl	%r14d, %r14d
	xorl	%eax, %eax
	movl	%r9d, 88(%rsp)
	movl	%r14d, %edx
	movl	%eax, %r13d
	movq	%r12, %r15
	movl	$0, 100(%rsp)
	movl	$-1, 96(%rsp)
	movl	$-1, 84(%rsp)
	jmp	.L652
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L651:
	addl	$1, %r13d
	addq	$48, %r15
	cmpl	$51, %r13d
	je	.L730
.L652:
	movl	%ecx, %eax
	andl	(%r15), %eax
	je	.L651
	movq	8(%r15), %r8
	movzbl	(%r8), %edi
	testb	%dil, %dil
	je	.L667
	leaq	112(%rsp), %rsi
	xorl	%r14d, %r14d
	movq	%rsi, %r11
	cmpb	$32, %dil
	jne	.L630
	.p2align 4
	.p2align 4
	.p2align 3
.L631:
	movzbl	1(%r8), %edi
	addq	$1, %r8
	cmpb	$32, %dil
	je	.L631
	testb	%dil, %dil
	je	.L731
.L630:
	movq	%r8, %r9
	testb	$-33, %dil
	je	.L633
.L734:
	movl	$1, %eax
	jmp	.L635
	.p2align 6
	.p2align 4,,10
	.p2align 3
.L733:
	addq	$1, %rax
	cmpq	$24, %rax
	je	.L732
.L635:
	movb	%dil, -1(%r11,%rax)
	movzbl	(%r9,%rax), %edi
	leaq	(%r9,%rax), %r10
	movq	%r10, %r8
	testb	$-33, %dil
	jne	.L733
	cltq
	addl	$1, %r14d
	addq	$24, %r11
	movb	$0, -24(%r11,%rax)
	testb	%dil, %dil
	jne	.L631
	jmp	.L637
	.p2align 4,,10
	.p2align 3
.L617:
	subl	$1, st(%rip)
.L610:
	movq	72(%rsp), %rsi
	movl	$89, %ecx
	leaq	C(%rip), %rdi
	rep movsq
	addq	$1224, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L728:
	.cfi_restore_state
	movl	$16, %esi
	leaq	.LC65(%rip), %rdi
	xorl	%eax, %eax
	call	err
	jmp	.L610
	.p2align 4,,10
	.p2align 3
.L732:
	movb	$0, 23(%r11)
	addl	$1, %r14d
	addq	$24, %r11
	cmpb	$32, %dil
	je	.L631
	movq	%r10, %r9
	testb	$-33, %dil
	jne	.L734
.L633:
	movb	$0, (%r11)
	addl	$1, %r14d
.L637:
	movl	68(%rsp), %eax
	testl	%eax, %eax
	jg	.L663
	jmp	.L651
	.p2align 4,,10
	.p2align 3
.L731:
	testl	%r14d, %r14d
	je	.L670
	cmpb	$0, 95(%rsp)
	je	.L670
.L663:
	movl	68(%rsp), %r10d
	xorl	%eax, %eax
	movzbl	83(%rsp), %ebx
	movl	%ecx, 48(%rsp)
	leaq	512+C(%rip), %rdi
	movl	%eax, %ecx
	movl	%r13d, 40(%rsp)
	movq	%rsi, %rax
	cmpl	%r10d, %r14d
	movl	$0, 36(%rsp)
	movq	%rdi, %rsi
	cmovle	%r14d, %r10d
	movl	%edx, 44(%rsp)
	movl	%r14d, 52(%rsp)
	movl	%r10d, 64(%rsp)
	movq	%r15, 56(%rsp)
	testb	%bl, %bl
	je	.L725
.L739:
	movq	(%rsi), %rbp
	movb	%bl, (%rsp)
	movq	%rax, %r15
	movq	%rax, %r13
	movq	%rsi, 16(%rsp)
	movl	%ecx, %r12d
	movq	%rbp, 8(%rsp)
	movq	%rax, 24(%rsp)
	jmp	.L640
	.p2align 4,,10
	.p2align 3
.L642:
	call	__ctype_tolower_loc@PLT
	movzbl	%r14b, %edx
	movzbl	%bl, %ecx
	movq	(%rax), %rax
	movl	(%rax,%rdx,4), %esi
	cmpl	%esi, (%rax,%rcx,4)
	jne	.L723
	movzbl	1(%rbp), %ebx
	addq	$1, %rbp
	addq	$1, %r13
	testb	%bl, %bl
	je	.L641
.L640:
	movzbl	0(%r13), %r14d
	testb	%r14b, %r14b
	jne	.L642
.L723:
	movl	40(%rsp), %r13d
	movl	44(%rsp), %edx
	movl	%r12d, %eax
	movl	48(%rsp), %ecx
	movl	52(%rsp), %r14d
	movq	56(%rsp), %r15
.L639:
	cmpl	%eax, %edx
	cmovl	%eax, %edx
	cmpl	%r14d, %eax
	jne	.L651
.L629:
	movl	88(%rsp), %eax
	cmpl	%eax, %r14d
	jg	.L671
	movl	84(%rsp), %ebx
	sete	%al
	cmpl	%ebx, 36(%rsp)
	jle	.L673
	testb	%al, %al
	je	.L673
	movl	%r13d, 96(%rsp)
	movl	$0, 100(%rsp)
.L649:
	movl	36(%rsp), %eax
	addl	$1, %r13d
	addq	$48, %r15
	movl	%eax, 84(%rsp)
	cmpl	$51, %r13d
	jne	.L652
.L730:
	movl	96(%rsp), %edi
	movq	104(%rsp), %r15
	movl	88(%rsp), %r9d
	movl	68(%rsp), %r13d
	testl	%edi, %edi
	js	.L735
	movl	100(%rsp), %ecx
	testl	%ecx, %ecx
	jne	.L736
	movslq	96(%rsp), %rax
	leaq	CMDS(%rip), %rsi
	movl	%r13d, %edi
	movl	%r9d, 708+C(%rip)
	subl	%r9d, %edi
	leaq	(%rax,%rax,2), %rax
	salq	$4, %rax
	leaq	(%rsi,%rax), %rbx
	cmpl	24(%rbx), %edi
	jl	.L654
	movl	28(%rbx), %eax
	cmpl	%eax, %edi
	jg	.L737
	leaq	512+C(%rip), %rdx
	movslq	%r9d, %rax
	leaq	(%rdx,%rax,8), %rsi
	call	*32(%rbx)
	movl	(%rbx), %edx
	testl	%edx, %edx
	je	.L610
	andl	$-61, %edx
	jne	.L610
	testl	%eax, %eax
	jne	.L662
	addl	$1, 4+st(%rip)
	jmp	.L610
	.p2align 4,,10
	.p2align 3
.L641:
	movl	%r12d, %ecx
	movq	16(%rsp), %rsi
	movq	24(%rsp), %rax
	addl	$1, %ecx
	movzbl	(%rsp), %ebx
	movq	8(%rsp), %rbp
	movq	%rax, (%rsp)
	movl	%ecx, %r12d
	movq	%rsi, %r13
	jmp	.L644
	.p2align 4,,10
	.p2align 3
.L646:
	call	__ctype_tolower_loc@PLT
	movq	(%rax), %rax
	movl	(%rax,%r14,4), %esi
	cmpl	%esi, (%rax,%rbx,4)
	jne	.L724
	movzbl	1(%rbp), %ebx
	addq	$1, %rbp
	leaq	1(%r15), %rax
	testb	%bl, %bl
	je	.L738
	movq	%rax, %r15
.L644:
	movzbl	(%r15), %r14d
	testb	%r14b, %r14b
	jne	.L646
	movq	(%rsp), %rax
	movl	%r12d, %ecx
	movq	%r13, %rsi
.L645:
	xorl	%edx, %edx
	cmpb	%r14b, %bl
	sete	%dl
	addl	%edx, 36(%rsp)
.L643:
	movl	64(%rsp), %edx
	addq	$8, %rsi
	addq	$24, %rax
	cmpl	%edx, %ecx
	jge	.L725
	movq	(%rsi), %rdx
	movzbl	(%rdx), %ebx
	testb	%bl, %bl
	jne	.L739
.L725:
	movl	%ecx, %eax
	movl	40(%rsp), %r13d
	movl	44(%rsp), %edx
	movl	48(%rsp), %ecx
	movl	52(%rsp), %r14d
	movq	56(%rsp), %r15
	jmp	.L639
.L724:
	movq	(%rsp), %rax
	movl	%r12d, %ecx
	movq	%r13, %rsi
	jmp	.L643
.L738:
	movq	(%rsp), %rax
	movzbl	1(%r15), %r14d
	movl	%r12d, %ecx
	movq	%r13, %rsi
	jmp	.L645
.L671:
	movl	%r14d, 88(%rsp)
	movl	%r13d, 96(%rsp)
	movl	$0, 100(%rsp)
	jmp	.L649
.L673:
	movl	84(%rsp), %ebx
	xorl	%esi, %esi
	cmpl	%ebx, 36(%rsp)
	sete	%sil
	andl	%esi, %eax
	movl	%ebx, 36(%rsp)
	orl	%eax, 100(%rsp)
	jmp	.L649
.L619:
	movb	$0, (%rax)
	cmpb	$0, (%r12)
	cmovne	%r13d, %ebp
	movl	%ebp, %edi
	call	show_help
	jmp	.L610
.L729:
	cmpb	$0, 1(%r14)
	movl	mode(%rip), %ebp
	jne	.L621
	cmpl	$1, %ebp
	jbe	.L621
	cmpl	$1, %r13d
	je	.L654
	movslq	644+C(%rip), %rdi
	movq	cur_if(%rip), %rbx
	leaq	C(%rip), %rax
	movl	$1, mode(%rip)
	addq	%rax, %rdi
	call	execute_line_impl
	movl	%ebp, mode(%rip)
	movq	%rbx, cur_if(%rip)
	jmp	.L610
.L667:
	movl	$0, 36(%rsp)
	xorl	%r14d, %r14d
	jmp	.L629
.L735:
	cmpl	%r13d, %edx
	jl	.L740
.L654:
	leaq	.LC66(%rip), %rdi
	xorl	%eax, %eax
	call	err
	jmp	.L610
.L670:
	movl	$0, 36(%rsp)
	xorl	%eax, %eax
	jmp	.L639
.L740:
	movl	loading(%rip), %esi
	testl	%esi, %esi
	jne	.L656
	movslq	%edx, %r9
	leaq	C(%rip), %rax
	movl	prompt_len(%rip), %esi
	leaq	.LC33(%rip), %rdx
	addl	640(%rax,%r9,4), %esi
	leaq	.LC34(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
.L656:
	leaq	.LC67(%rip), %rdi
	xorl	%eax, %eax
	call	err
	jmp	.L610
.L737:
	movl	loading(%rip), %edx
	testl	%edx, %edx
	jne	.L656
	addl	%r9d, %eax
	cmpl	%r13d, %eax
	jge	.L660
	cltq
	leaq	C(%rip), %rsi
	movl	640(%rsi,%rax,4), %eax
.L661:
	addl	prompt_len(%rip), %eax
	leaq	.LC33(%rip), %rdx
	leaq	.LC34(%rip), %rdi
	movl	%eax, %esi
	xorl	%eax, %eax
	call	printf@PLT
	jmp	.L656
.L736:
	movq	%r15, %rsi
	leaq	.LC68(%rip), %rdi
	xorl	%eax, %eax
	call	err
	jmp	.L610
.L662:
	jle	.L610
	addl	$1, 8+st(%rip)
	jmp	.L610
.L660:
	leaq	C(%rip), %rdi
	call	strlen@PLT
	jmp	.L661
	.cfi_endproc
.LFE111:
	.size	execute_line_impl, .-execute_line_impl
	.section	.rodata.str1.8
	.align 8
.LC69:
	.string	"%s is %s, line protocol is %s\n"
	.section	.rodata.str1.1
.LC70:
	.string	"  Description: %s\n"
.LC71:
	.string	"  Internet address is %s/%d\n"
	.section	.rodata.str1.8
	.align 8
.LC72:
	.string	"  Internet protocol processing disabled"
	.section	.rodata.str1.1
.LC73:
	.string	"  Clock rate %ld\n"
	.text
	.p2align 4
	.type	print_if_detail, @function
print_if_detail:
.LFB86:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	leaq	.LC13(%rip), %rcx
	leaq	.LC11(%rip), %rdx
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	movq	%rdi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movl	152(%rdi), %esi
	testl	%esi, %esi
	jne	.L742
	leaq	.LC32(%rip), %rcx
	movq	%rcx, %rdx
.L742:
	xorl	%eax, %eax
	movq	%rbp, %rsi
	leaq	.LC69(%rip), %rdi
	call	printf@PLT
	cmpb	$0, 40(%rbp)
	jne	.L754
	movl	148(%rbp), %ecx
	testl	%ecx, %ecx
	je	.L744
.L756:
	movl	144(%rbp), %eax
	xorl	%ebx, %ebx
	testl	%eax, %eax
	je	.L745
	.p2align 4
	.p2align 4
	.p2align 3
.L746:
	movl	%eax, %edx
	andl	$1, %edx
	addl	%edx, %ebx
	shrl	%eax
	jne	.L746
.L745:
	movl	140(%rbp), %eax
	movl	i.2(%rip), %r12d
	subq	$8, %rsp
	.cfi_def_cfa_offset 40
	leal	1(%r12), %edx
	movzbl	%ah, %esi
	movl	%eax, %r8d
	movl	%eax, %ecx
	andl	$3, %r12d
	movzbl	%al, %eax
	movl	%edx, i.2(%rip)
	movl	%esi, %r9d
	pushq	%rax
	.cfi_def_cfa_offset 48
	leaq	b.1(%rip), %rdx
	salq	$4, %r12
	shrl	$16, %r8d
	addq	%rdx, %r12
	shrl	$24, %ecx
	movzbl	%r8b, %r8d
	movl	$16, %esi
	leaq	.LC58(%rip), %rdx
	movq	%r12, %rdi
	xorl	%eax, %eax
	call	snprintf@PLT
	movl	%ebx, %edx
	movq	%r12, %rsi
	xorl	%eax, %eax
	leaq	.LC71(%rip), %rdi
	call	printf@PLT
	movq	160(%rbp), %rsi
	popq	%rax
	.cfi_def_cfa_offset 40
	popq	%rdx
	.cfi_def_cfa_offset 32
	testq	%rsi, %rsi
	jne	.L755
.L741:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L754:
	.cfi_restore_state
	leaq	40(%rbp), %rsi
	leaq	.LC70(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
	movl	148(%rbp), %ecx
	testl	%ecx, %ecx
	jne	.L756
.L744:
	leaq	.LC72(%rip), %rdi
	call	puts@PLT
	movq	160(%rbp), %rsi
	testq	%rsi, %rsi
	je	.L741
.L755:
	popq	%rbx
	.cfi_def_cfa_offset 24
	leaq	.LC73(%rip), %rdi
	popq	%rbp
	.cfi_def_cfa_offset 16
	xorl	%eax, %eax
	popq	%r12
	.cfi_def_cfa_offset 8
	jmp	printf@PLT
	.cfi_endproc
.LFE86:
	.size	print_if_detail, .-print_if_detail
	.section	.rodata.str1.1
.LC74:
	.string	"enabled"
.LC75:
	.string	"disabled"
.LC76:
	.string	"(not set)"
	.section	.rodata.str1.8
	.align 8
.LC77:
	.string	"No routing protocol is configured."
	.align 8
.LC78:
	.string	"Routing Protocol is \"rip\"\n  Version %d, automatic summarization %s\n  Routing for Networks:\n"
	.section	.rodata.str1.1
.LC79:
	.string	"    %s\n"
	.section	.rodata.str1.8
	.align 8
.LC80:
	.string	"Routing Protocol is \"ospf %d\"\n  Router ID %s\n  Routing for Networks:\n"
	.section	.rodata.str1.1
.LC81:
	.string	"    %s %s area %llu\n"
	.text
	.p2align 4
	.type	h_show_protocols, @function
h_show_protocols:
.LFB89:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$8, %rsp
	.cfi_def_cfa_offset 64
	movl	680+cfg(%rip), %r13d
	testl	%r13d, %r13d
	je	.L773
	movl	688+cfg(%rip), %r11d
	leaq	.LC74(%rip), %rax
	leaq	.LC75(%rip), %rdx
	movl	684+cfg(%rip), %esi
	leaq	.LC78(%rip), %rdi
	testl	%r11d, %r11d
	cmovne	%rax, %rdx
	xorl	%eax, %eax
	call	printf@PLT
	movl	704+cfg(%rip), %ebx
	testl	%ebx, %ebx
	jle	.L764
	xorl	%r14d, %r14d
	leaq	b.1(%rip), %r13
	leaq	.LC58(%rip), %r12
	leaq	.LC79(%rip), %rbp
	.p2align 4
	.p2align 3
.L765:
	movq	696+cfg(%rip), %rax
	movl	i.2(%rip), %ebx
	subq	$8, %rsp
	.cfi_def_cfa_offset 72
	movl	(%rax,%r14,4), %eax
	leal	1(%rbx), %edx
	andl	$3, %ebx
	addq	$1, %r14
	salq	$4, %rbx
	movl	%edx, i.2(%rip)
	movq	%r12, %rdx
	movzbl	%ah, %esi
	movl	%eax, %r8d
	movl	%eax, %ecx
	movzbl	%al, %eax
	pushq	%rax
	.cfi_def_cfa_offset 80
	addq	%r13, %rbx
	shrl	$16, %r8d
	movl	%esi, %r9d
	shrl	$24, %ecx
	movzbl	%r8b, %r8d
	movl	$16, %esi
	movq	%rbx, %rdi
	xorl	%eax, %eax
	call	snprintf@PLT
	xorl	%eax, %eax
	movq	%rbx, %rsi
	movq	%rbp, %rdi
	call	printf@PLT
	cmpl	%r14d, 704+cfg(%rip)
	popq	%r9
	.cfi_def_cfa_offset 72
	popq	%r10
	.cfi_def_cfa_offset 64
	jg	.L765
.L764:
	movl	712+cfg(%rip), %r8d
	testl	%r8d, %r8d
	jne	.L766
.L762:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L773:
	.cfi_restore_state
	movl	712+cfg(%rip), %r12d
	testl	%r12d, %r12d
	je	.L759
.L766:
	movl	720+cfg(%rip), %ebp
	leaq	.LC76(%rip), %rbx
	testl	%ebp, %ebp
	jne	.L774
.L761:
	movl	716+cfg(%rip), %esi
	movq	%rbx, %rdx
	leaq	.LC80(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
	movl	736+cfg(%rip), %ecx
	testl	%ecx, %ecx
	jle	.L762
	xorl	%r15d, %r15d
	leaq	b.1(%rip), %r13
	leaq	.LC58(%rip), %r12
	.p2align 4
	.p2align 3
.L768:
	movq	728+cfg(%rip), %rax
	movq	%r15, %rbx
	subq	$8, %rsp
	.cfi_def_cfa_offset 72
	movl	$16, %esi
	salq	$4, %rbx
	movl	i.2(%rip), %ebp
	addq	$1, %r15
	addq	%rbx, %rax
	movq	8(%rax), %r14
	movl	4(%rax), %eax
	leal	1(%rbp), %edx
	andl	$3, %ebp
	salq	$4, %rbp
	movl	%edx, i.2(%rip)
	movq	%r12, %rdx
	movzbl	%ah, %edi
	movl	%eax, %r8d
	movl	%eax, %ecx
	movzbl	%al, %eax
	pushq	%rax
	.cfi_def_cfa_offset 80
	addq	%r13, %rbp
	shrl	$16, %r8d
	movl	%edi, %r9d
	shrl	$24, %ecx
	movzbl	%r8b, %r8d
	movq	%rbp, %rdi
	xorl	%eax, %eax
	call	snprintf@PLT
	movq	728+cfg(%rip), %rax
	movl	(%rax,%rbx), %eax
	movl	i.2(%rip), %ebx
	leal	1(%rbx), %edx
	andl	$3, %ebx
	movl	%eax, %r8d
	movzbl	%ah, %esi
	salq	$4, %rbx
	shrl	$16, %r8d
	movl	%eax, %ecx
	movzbl	%al, %eax
	addq	%r13, %rbx
	movl	%eax, (%rsp)
	movl	%esi, %r9d
	shrl	$24, %ecx
	movl	%edx, i.2(%rip)
	movzbl	%r8b, %r8d
	movq	%r12, %rdx
	movq	%rbx, %rdi
	movl	$16, %esi
	xorl	%eax, %eax
	call	snprintf@PLT
	movq	%rbp, %rdx
	xorl	%eax, %eax
	movq	%r14, %rcx
	movq	%rbx, %rsi
	leaq	.LC81(%rip), %rdi
	call	printf@PLT
	cmpl	%r15d, 736+cfg(%rip)
	popq	%rax
	.cfi_def_cfa_offset 72
	popq	%rdx
	.cfi_def_cfa_offset 64
	jg	.L768
	jmp	.L762
	.p2align 4,,10
	.p2align 3
.L759:
	leaq	.LC77(%rip), %rdi
	call	puts@PLT
	jmp	.L762
	.p2align 4,,10
	.p2align 3
.L774:
	movl	724+cfg(%rip), %eax
	subq	$8, %rsp
	.cfi_def_cfa_offset 72
	movl	i.2(%rip), %ebx
	leaq	b.1(%rip), %r13
	leaq	.LC58(%rip), %r12
	movl	$16, %esi
	leal	1(%rbx), %edx
	movzbl	%ah, %edi
	movl	%eax, %r8d
	movl	%eax, %ecx
	andl	$3, %ebx
	movzbl	%al, %eax
	shrl	$16, %r8d
	movl	%edx, i.2(%rip)
	pushq	%rax
	.cfi_def_cfa_offset 80
	salq	$4, %rbx
	movl	%edi, %r9d
	shrl	$24, %ecx
	addq	%r13, %rbx
	movzbl	%r8b, %r8d
	movq	%r12, %rdx
	xorl	%eax, %eax
	movq	%rbx, %rdi
	call	snprintf@PLT
	popq	%rsi
	.cfi_def_cfa_offset 72
	popq	%rdi
	.cfi_def_cfa_offset 64
	jmp	.L761
	.cfi_endproc
.LFE89:
	.size	h_show_protocols, .-h_show_protocols
	.section	.rodata.str1.1
.LC82:
	.string	"!"
.LC83:
	.string	"hostname %s"
.LC84:
	.string	"enable secret %s"
.LC85:
	.string	"interface %s"
.LC86:
	.string	" description %s"
.LC87:
	.string	" ip address %s %s"
.LC88:
	.string	" no ip address"
.LC89:
	.string	" clock rate %ld"
.LC90:
	.string	" shutdown"
.LC91:
	.string	" no shutdown"
.LC92:
	.string	"router rip"
.LC93:
	.string	" version %d"
.LC94:
	.string	" network %s"
.LC95:
	.string	" no auto-summary"
.LC96:
	.string	"router ospf %d"
.LC97:
	.string	" router-id %s"
.LC98:
	.string	" network %s %s area %llu"
.LC99:
	.string	" %d"
.LC100:
	.string	"ip route %s %s %s%s"
.LC101:
	.string	"end"
	.text
	.p2align 4
	.type	gen_config, @function
gen_config:
.LFB46:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	xorl	%eax, %eax
	leaq	.LC82(%rip), %rsi
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	movq	%rdi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$40, %rsp
	.cfi_def_cfa_offset 96
	call	addf
	xorl	%eax, %eax
	leaq	cfg(%rip), %rdx
	movq	%rbp, %rdi
	leaq	.LC83(%rip), %rsi
	call	addf
	xorl	%eax, %eax
	leaq	.LC82(%rip), %rsi
	movq	%rbp, %rdi
	call	addf
	cmpb	$0, 64+cfg(%rip)
	jne	.L828
.L776:
	movq	640+cfg(%rip), %r15
	leaq	.LC85(%rip), %r13
	leaq	b.1(%rip), %r12
	testq	%r15, %r15
	jne	.L777
	jmp	.L786
	.p2align 4,,10
	.p2align 3
.L831:
	movl	144(%r15), %eax
	movl	i.2(%rip), %r14d
	subq	$8, %rsp
	.cfi_def_cfa_offset 104
	leal	1(%r14), %edx
	movzbl	%ah, %esi
	movl	%eax, %r8d
	movl	%eax, %ecx
	andl	$3, %r14d
	movzbl	%al, %eax
	shrl	$16, %r8d
	movl	%esi, %r9d
	pushq	%rax
	.cfi_def_cfa_offset 112
	salq	$4, %r14
	shrl	$24, %ecx
	movzbl	%r8b, %r8d
	addq	%r12, %r14
	movl	%edx, i.2(%rip)
	movl	$16, %esi
	xorl	%eax, %eax
	leaq	.LC58(%rip), %rdx
	movq	%r14, %rdi
	call	snprintf@PLT
	movl	i.2(%rip), %ebx
	movl	140(%r15), %eax
	leal	1(%rbx), %edx
	andl	$3, %ebx
	movl	%eax, %r8d
	movzbl	%ah, %esi
	salq	$4, %rbx
	movl	%eax, %ecx
	shrl	$16, %r8d
	movzbl	%al, %eax
	addq	%r12, %rbx
	movl	%eax, (%rsp)
	movl	%esi, %r9d
	movzbl	%r8b, %r8d
	movl	%edx, i.2(%rip)
	shrl	$24, %ecx
	movl	$16, %esi
	xorl	%eax, %eax
	leaq	.LC58(%rip), %rdx
	movq	%rbx, %rdi
	call	snprintf@PLT
	movq	%rbx, %rdx
	movq	%r14, %rcx
	movq	%rbp, %rdi
	leaq	.LC87(%rip), %rsi
	xorl	%eax, %eax
	call	addf
	movq	160(%r15), %rdx
	popq	%r8
	.cfi_def_cfa_offset 104
	popq	%r9
	.cfi_def_cfa_offset 96
	testq	%rdx, %rdx
	jne	.L829
.L783:
	movl	152(%r15), %edi
	leaq	.LC90(%rip), %rsi
	testl	%edi, %edi
	jne	.L826
	leaq	.LC91(%rip), %rsi
.L826:
	movq	%rbp, %rdi
	xorl	%eax, %eax
	call	addf
	leaq	.LC82(%rip), %rsi
	movq	%rbp, %rdi
	xorl	%eax, %eax
	call	addf
	movq	176(%r15), %r15
	testq	%r15, %r15
	je	.L786
.L777:
	xorl	%eax, %eax
	movq	%r15, %rdx
	movq	%r13, %rsi
	movq	%rbp, %rdi
	call	addf
	cmpb	$0, 40(%r15)
	jne	.L830
.L780:
	movl	148(%r15), %r10d
	testl	%r10d, %r10d
	jne	.L831
	leaq	.LC88(%rip), %rsi
	movq	%rbp, %rdi
	xorl	%eax, %eax
	call	addf
	movq	160(%r15), %rdx
	testq	%rdx, %rdx
	je	.L783
.L829:
	leaq	.LC89(%rip), %rsi
	movq	%rbp, %rdi
	xorl	%eax, %eax
	call	addf
	jmp	.L783
	.p2align 4,,10
	.p2align 3
.L830:
	leaq	40(%r15), %rdx
	leaq	.LC86(%rip), %rsi
	movq	%rbp, %rdi
	xorl	%eax, %eax
	call	addf
	jmp	.L780
	.p2align 4,,10
	.p2align 3
.L786:
	movl	680+cfg(%rip), %r11d
	testl	%r11d, %r11d
	jne	.L832
.L779:
	movl	712+cfg(%rip), %r12d
	testl	%r12d, %r12d
	jne	.L833
.L791:
	movl	672+cfg(%rip), %eax
	testl	%eax, %eax
	jle	.L795
	leaq	16(%rsp), %rax
	xorl	%r15d, %r15d
	leaq	b.1(%rip), %r14
	movq	%rax, (%rsp)
	leaq	.LC58(%rip), %r13
	jmp	.L799
	.p2align 4,,10
	.p2align 3
.L834:
	movl	8(%r12), %eax
	subq	$8, %rsp
	.cfi_def_cfa_offset 104
	movl	$16, %esi
	movq	%rbx, %rdi
	movl	%edx, i.2(%rip)
	movq	%r13, %rdx
	movzbl	%ah, %ecx
	movl	%eax, %r8d
	movl	%ecx, %r9d
	movl	%eax, %ecx
	movzbl	%al, %eax
	shrl	$16, %r8d
	pushq	%rax
	.cfi_def_cfa_offset 112
	shrl	$24, %ecx
	movzbl	%r8b, %r8d
	xorl	%eax, %eax
	call	snprintf@PLT
	movl	4(%r12), %eax
	movl	$16, %esi
	movl	i.2(%rip), %r10d
	leal	1(%r10), %edx
	andl	$3, %r10d
	movl	%eax, %r8d
	movzbl	%ah, %edi
	salq	$4, %r10
	movl	%eax, %ecx
	shrl	$16, %r8d
	movzbl	%al, %eax
	addq	%r14, %r10
	movl	%eax, (%rsp)
	movl	%edi, %r9d
	shrl	$24, %ecx
	movq	%r10, %rdi
	movl	%edx, i.2(%rip)
	movzbl	%r8b, %r8d
	movq	%r13, %rdx
	xorl	%eax, %eax
	movq	%r10, 24(%rsp)
	call	snprintf@PLT
	movl	(%r12), %eax
	movl	i.2(%rip), %r12d
	leal	1(%r12), %edx
	andl	$3, %r12d
	movl	%eax, %r8d
	movzbl	%ah, %esi
	salq	$4, %r12
	movl	%eax, %ecx
	shrl	$16, %r8d
	movzbl	%al, %eax
	addq	%r14, %r12
	movl	%esi, %r9d
	movl	%edx, i.2(%rip)
	shrl	$24, %ecx
	movl	%eax, (%rsp)
	movzbl	%r8b, %r8d
	movq	%r13, %rdx
	movl	$16, %esi
	movq	%r12, %rdi
	xorl	%eax, %eax
	call	snprintf@PLT
	movq	16(%rsp), %r9
	movq	%rbx, %r8
	movq	%r12, %rdx
	movq	24(%rsp), %rcx
.L827:
	xorl	%eax, %eax
	leaq	.LC100(%rip), %rsi
	movq	%rbp, %rdi
	addq	$1, %r15
	call	addf
	movl	672+cfg(%rip), %eax
	popq	%rdx
	.cfi_def_cfa_offset 104
	popq	%rcx
	.cfi_def_cfa_offset 96
	cmpl	%r15d, %eax
	jle	.L795
.L799:
	movq	%r15, %rax
	movq	664+cfg(%rip), %rdx
	pxor	%xmm0, %xmm0
	salq	$4, %rax
	movaps	%xmm0, 16(%rsp)
	subq	%r15, %rax
	leaq	(%rdx,%rax,4), %r12
	movl	56(%r12), %ecx
	cmpl	$1, %ecx
	je	.L796
	movq	(%rsp), %rdi
	leaq	.LC99(%rip), %rdx
	movl	$16, %esi
	xorl	%eax, %eax
	call	snprintf@PLT
.L796:
	movl	i.2(%rip), %ebx
	movl	52(%r12), %esi
	leal	1(%rbx), %edx
	andl	$3, %ebx
	salq	$4, %rbx
	addq	%r14, %rbx
	testl	%esi, %esi
	jne	.L834
	movl	4(%r12), %eax
	subq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 104
	movl	$16, %esi
	movq	%rbx, %rdi
	movl	%edx, i.2(%rip)
	movq	%r13, %rdx
	movzbl	%ah, %ecx
	movl	%eax, %r8d
	movl	%ecx, %r9d
	movl	%eax, %ecx
	movzbl	%al, %eax
	shrl	$16, %r8d
	pushq	%rax
	.cfi_def_cfa_offset 112
	shrl	$24, %ecx
	movzbl	%r8b, %r8d
	xorl	%eax, %eax
	call	snprintf@PLT
	movl	(%r12), %eax
	movl	i.2(%rip), %edi
	movl	%eax, %r8d
	leal	1(%rdi), %edx
	andl	$3, %edi
	movzbl	%ah, %esi
	movl	%eax, %ecx
	salq	$4, %rdi
	movzbl	%al, %eax
	movl	%esi, %r9d
	shrl	$16, %r8d
	movl	%edx, i.2(%rip)
	addq	%r14, %rdi
	shrl	$24, %ecx
	movl	%eax, (%rsp)
	movzbl	%r8b, %r8d
	movq	%r13, %rdx
	movl	$16, %esi
	xorl	%eax, %eax
	movq	%rdi, 24(%rsp)
	call	snprintf@PLT
	movq	16(%rsp), %r9
	movq	24(%rsp), %rdx
	movq	%rbx, %rcx
	leaq	12(%r12), %r8
	jmp	.L827
	.p2align 4,,10
	.p2align 3
.L795:
	.cfi_restore_state
	testl	%eax, %eax
	jne	.L835
.L800:
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movq	%rbp, %rdi
	leaq	.LC101(%rip), %rsi
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	jmp	addf
	.p2align 4,,10
	.p2align 3
.L828:
	.cfi_restore_state
	movq	%rbp, %rdi
	xorl	%eax, %eax
	leaq	64+cfg(%rip), %rdx
	leaq	.LC84(%rip), %rsi
	call	addf
	leaq	.LC82(%rip), %rsi
	movq	%rbp, %rdi
	xorl	%eax, %eax
	call	addf
	jmp	.L776
	.p2align 4,,10
	.p2align 3
.L835:
	leaq	.LC82(%rip), %rsi
	movq	%rbp, %rdi
	xorl	%eax, %eax
	call	addf
	jmp	.L800
	.p2align 4,,10
	.p2align 3
.L833:
	movl	716+cfg(%rip), %edx
	leaq	.LC96(%rip), %rsi
	movq	%rbp, %rdi
	xorl	%eax, %eax
	call	addf
	movl	720+cfg(%rip), %ebx
	testl	%ebx, %ebx
	jne	.L836
.L792:
	movl	736+cfg(%rip), %r9d
	xorl	%r15d, %r15d
	leaq	b.1(%rip), %r14
	leaq	.LC58(%rip), %r13
	testl	%r9d, %r9d
	jle	.L794
	movq	%rbp, (%rsp)
	movq	%r15, %rbp
	.p2align 4
	.p2align 3
.L793:
	movq	728+cfg(%rip), %rax
	movq	%rbp, %rbx
	subq	$8, %rsp
	.cfi_def_cfa_offset 104
	movl	$16, %esi
	salq	$4, %rbx
	movl	i.2(%rip), %r12d
	addq	$1, %rbp
	addq	%rbx, %rax
	movq	8(%rax), %r15
	movl	4(%rax), %eax
	leal	1(%r12), %edx
	andl	$3, %r12d
	salq	$4, %r12
	movl	%edx, i.2(%rip)
	movq	%r13, %rdx
	movzbl	%ah, %edi
	movl	%eax, %r8d
	movl	%eax, %ecx
	movzbl	%al, %eax
	pushq	%rax
	.cfi_def_cfa_offset 112
	addq	%r14, %r12
	shrl	$16, %r8d
	movl	%edi, %r9d
	shrl	$24, %ecx
	movzbl	%r8b, %r8d
	movq	%r12, %rdi
	xorl	%eax, %eax
	call	snprintf@PLT
	movq	728+cfg(%rip), %rax
	movl	$16, %esi
	movl	(%rax,%rbx), %eax
	movl	i.2(%rip), %ebx
	leal	1(%rbx), %edx
	andl	$3, %ebx
	movzbl	%ah, %ecx
	movl	%eax, %r8d
	salq	$4, %rbx
	movl	%ecx, %r9d
	shrl	$16, %r8d
	movl	%eax, %ecx
	addq	%r14, %rbx
	movzbl	%al, %eax
	shrl	$24, %ecx
	movl	%edx, i.2(%rip)
	movl	%eax, (%rsp)
	movzbl	%r8b, %r8d
	movq	%r13, %rdx
	movq	%rbx, %rdi
	xorl	%eax, %eax
	call	snprintf@PLT
	movq	16(%rsp), %rdi
	movq	%r15, %r8
	xorl	%eax, %eax
	movq	%r12, %rcx
	movq	%rbx, %rdx
	leaq	.LC98(%rip), %rsi
	call	addf
	cmpl	%ebp, 736+cfg(%rip)
	popq	%rdi
	.cfi_def_cfa_offset 104
	popq	%r8
	.cfi_def_cfa_offset 96
	jg	.L793
	movq	(%rsp), %rbp
.L794:
	leaq	.LC82(%rip), %rsi
	movq	%rbp, %rdi
	xorl	%eax, %eax
	call	addf
	jmp	.L791
	.p2align 4,,10
	.p2align 3
.L832:
	leaq	.LC92(%rip), %rsi
	movq	%rbp, %rdi
	xorl	%eax, %eax
	xorl	%r15d, %r15d
	call	addf
	movl	684+cfg(%rip), %edx
	movq	%rbp, %rdi
	xorl	%eax, %eax
	leaq	.LC93(%rip), %rsi
	leaq	b.1(%rip), %r14
	call	addf
	movl	704+cfg(%rip), %esi
	leaq	.LC58(%rip), %r13
	leaq	.LC94(%rip), %r12
	testl	%esi, %esi
	jle	.L790
	.p2align 4
	.p2align 3
.L787:
	movq	696+cfg(%rip), %rax
	movl	i.2(%rip), %ebx
	subq	$8, %rsp
	.cfi_def_cfa_offset 104
	movl	$16, %esi
	movl	(%rax,%r15,4), %eax
	leal	1(%rbx), %edx
	andl	$3, %ebx
	addq	$1, %r15
	salq	$4, %rbx
	movl	%edx, i.2(%rip)
	movq	%r13, %rdx
	movzbl	%ah, %edi
	movl	%eax, %r8d
	movl	%eax, %ecx
	movzbl	%al, %eax
	pushq	%rax
	.cfi_def_cfa_offset 112
	addq	%r14, %rbx
	shrl	$16, %r8d
	movl	%edi, %r9d
	shrl	$24, %ecx
	movzbl	%r8b, %r8d
	movq	%rbx, %rdi
	xorl	%eax, %eax
	call	snprintf@PLT
	xorl	%eax, %eax
	movq	%rbx, %rdx
	movq	%r12, %rsi
	movq	%rbp, %rdi
	call	addf
	cmpl	%r15d, 704+cfg(%rip)
	popq	%rax
	.cfi_def_cfa_offset 104
	popq	%rdx
	.cfi_def_cfa_offset 96
	jg	.L787
.L790:
	movl	688+cfg(%rip), %ecx
	testl	%ecx, %ecx
	je	.L837
.L789:
	leaq	.LC82(%rip), %rsi
	movq	%rbp, %rdi
	xorl	%eax, %eax
	call	addf
	jmp	.L779
	.p2align 4,,10
	.p2align 3
.L836:
	movl	724+cfg(%rip), %eax
	movl	i.2(%rip), %ebx
	subq	$8, %rsp
	.cfi_def_cfa_offset 104
	leaq	b.1(%rip), %r14
	leaq	.LC58(%rip), %r13
	leal	1(%rbx), %edx
	movzbl	%ah, %esi
	movl	%eax, %r8d
	movl	%eax, %ecx
	andl	$3, %ebx
	movzbl	%al, %eax
	shrl	$16, %r8d
	movl	%esi, %r9d
	pushq	%rax
	.cfi_def_cfa_offset 112
	salq	$4, %rbx
	shrl	$24, %ecx
	movzbl	%r8b, %r8d
	addq	%r14, %rbx
	movl	%edx, i.2(%rip)
	movl	$16, %esi
	xorl	%eax, %eax
	movq	%r13, %rdx
	movq	%rbx, %rdi
	call	snprintf@PLT
	movq	%rbx, %rdx
	movq	%rbp, %rdi
	xorl	%eax, %eax
	leaq	.LC97(%rip), %rsi
	call	addf
	popq	%r10
	.cfi_def_cfa_offset 104
	popq	%r11
	.cfi_def_cfa_offset 96
	jmp	.L792
	.p2align 4,,10
	.p2align 3
.L837:
	leaq	.LC95(%rip), %rsi
	movq	%rbp, %rdi
	xorl	%eax, %eax
	call	addf
	jmp	.L789
	.cfi_endproc
.LFE46:
	.size	gen_config, .-gen_config
	.section	.rodata.str1.8
	.align 8
.LC102:
	.string	"Building configuration...\n\nCurrent configuration : %lu bytes\n"
	.text
	.p2align 4
	.type	h_show_run, @function
h_show_run:
.LFB83:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pxor	%xmm0, %xmm0
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	subq	$16, %rsp
	.cfi_def_cfa_offset 64
	movq	%rsp, %rdi
	movaps	%xmm0, (%rsp)
	call	gen_config
	movslq	8(%rsp), %rax
	movq	(%rsp), %r14
	testl	%eax, %eax
	jle	.L839
	movq	%r14, %rbp
	leaq	(%r14,%rax,8), %r12
	movq	%r14, %rbx
	xorl	%r13d, %r13d
	.p2align 4
	.p2align 3
.L840:
	movq	(%rbx), %rdi
	addq	$8, %rbx
	call	strlen@PLT
	leaq	1(%r13,%rax), %r13
	cmpq	%rbx, %r12
	jne	.L840
	movq	%r13, %rsi
	leaq	.LC102(%rip), %rdi
	xorl	%eax, %eax
	movq	%r14, %rbx
	call	printf@PLT
	.p2align 4
	.p2align 3
.L843:
	movq	(%rbx), %rdi
	addq	$8, %rbx
	call	puts@PLT
	cmpq	%rbx, %r12
	jne	.L843
	.p2align 4
	.p2align 3
.L844:
	movq	0(%rbp), %rdi
	addq	$8, %rbp
	call	free@PLT
	cmpq	%rbp, %r12
	jne	.L844
.L842:
	movq	%r14, %rdi
	call	free@PLT
	addq	$16, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 48
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L839:
	.cfi_restore_state
	xorl	%esi, %esi
	leaq	.LC102(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
	jmp	.L842
	.cfi_endproc
.LFE83:
	.size	h_show_run, .-h_show_run
	.p2align 4
	.globl	rc_ieq
	.type	rc_ieq, @function
rc_ieq:
.LFB17:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	movq	%rsi, %r13
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	movq	%rdi, %r12
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$8, %rsp
	.cfi_def_cfa_offset 48
	movzbl	(%rdi), %ebx
	testb	%bl, %bl
	jne	.L851
	jmp	.L860
	.p2align 4,,10
	.p2align 3
.L854:
	call	__ctype_tolower_loc@PLT
	movq	(%rax), %rax
	movl	(%rax,%rbx,4), %edx
	cmpl	%edx, (%rax,%rbp,4)
	jne	.L855
	movzbl	1(%r12), %ebx
	addq	$1, %r12
	leaq	1(%r13), %rax
	testb	%bl, %bl
	je	.L861
	movq	%rax, %r13
.L851:
	movzbl	0(%r13), %ebp
	testb	%bpl, %bpl
	jne	.L854
.L852:
	xorl	%eax, %eax
	cmpb	%bpl, %bl
	sete	%al
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L855:
	.cfi_restore_state
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L861:
	.cfi_restore_state
	movzbl	1(%r13), %ebp
	jmp	.L852
.L860:
	movzbl	(%rsi), %ebp
	jmp	.L852
	.cfi_endproc
.LFE17:
	.size	rc_ieq, .-rc_ieq
	.p2align 4
	.globl	rc_is_prefix_ci
	.type	rc_is_prefix_ci, @function
rc_is_prefix_ci:
.LFB18:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	movq	%rsi, %r13
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	movq	%rdi, %r12
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$8, %rsp
	.cfi_def_cfa_offset 48
	movzbl	(%rdi), %ebx
	testb	%bl, %bl
	jne	.L864
	jmp	.L868
	.p2align 4,,10
	.p2align 3
.L866:
	call	__ctype_tolower_loc@PLT
	movq	(%rax), %rax
	movl	(%rax,%rbp,4), %edx
	cmpl	%edx, (%rax,%rbx,4)
	jne	.L868
	movzbl	1(%r12), %ebx
	addq	$1, %r12
	addq	$1, %r13
	testb	%bl, %bl
	je	.L869
.L864:
	movzbl	0(%r13), %ebp
	testb	%bpl, %bpl
	jne	.L866
.L868:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L869:
	.cfi_restore_state
	addq	$8, %rsp
	.cfi_def_cfa_offset 40
	movl	$1, %eax
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE18:
	.size	rc_is_prefix_ci, .-rc_is_prefix_ci
	.p2align 4
	.globl	rc_ipstr
	.type	rc_ipstr, @function
rc_ipstr:
.LFB20:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movl	i.2(%rip), %ebx
	movl	%edi, %eax
	movl	%edi, %r8d
	movzbl	%ah, %esi
	movzbl	%dil, %eax
	movl	%edi, %ecx
	shrl	$16, %r8d
	leal	1(%rbx), %edx
	andl	$3, %ebx
	movl	%esi, %r9d
	shrl	$24, %ecx
	subq	$8, %rsp
	.cfi_def_cfa_offset 24
	movl	%edx, i.2(%rip)
	salq	$4, %rbx
	leaq	b.1(%rip), %rdx
	pushq	%rax
	.cfi_def_cfa_offset 32
	addq	%rdx, %rbx
	movzbl	%r8b, %r8d
	leaq	.LC58(%rip), %rdx
	movq	%rbx, %rdi
	movl	$16, %esi
	xorl	%eax, %eax
	call	snprintf@PLT
	popq	%rax
	.cfi_def_cfa_offset 24
	movq	%rbx, %rax
	popq	%rdx
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE20:
	.size	rc_ipstr, .-rc_ipstr
	.p2align 4
	.globl	rc_parse_ip
	.type	rc_parse_ip, @function
rc_parse_ip:
.LFB21:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rdi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movq	%rsi, %rbx
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	call	__ctype_b_loc@PLT
	movzbl	0(%rbp), %edx
	movq	(%rax), %rcx
	testb	$8, 1(%rcx,%rdx,2)
	je	.L902
	movzbl	1(%rbp), %esi
	movsbl	%dl, %eax
	subl	$48, %eax
	movq	%rsi, %rdx
	testb	$8, 1(%rcx,%rsi,2)
	je	.L877
	movsbl	%sil, %edx
	movzbl	2(%rbp), %esi
	leal	(%rax,%rax,4), %eax
	leal	-48(%rdx,%rax,2), %eax
	movq	%rsi, %rdx
	testb	$8, 1(%rcx,%rsi,2)
	je	.L878
	movzbl	3(%rbp), %edi
	xorl	%r8d, %r8d
	testb	$8, 1(%rcx,%rdi,2)
	je	.L908
.L875:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	movl	%r8d, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L902:
	.cfi_restore_state
	xorl	%r8d, %r8d
	jmp	.L875
	.p2align 4,,10
	.p2align 3
.L877:
	addq	$1, %rbp
.L879:
	cmpl	$255, %eax
	ja	.L902
	cmpb	$46, %dl
	jne	.L902
	movzbl	1(%rbp), %esi
	testb	$8, 1(%rcx,%rsi,2)
	je	.L902
	movzbl	2(%rbp), %edi
	movsbl	%sil, %edx
	leal	-48(%rdx), %esi
	movq	%rdi, %rdx
	testb	$8, 1(%rcx,%rdi,2)
	je	.L880
	movsbl	%dil, %edx
	movzbl	3(%rbp), %edi
	leal	(%rsi,%rsi,4), %esi
	leal	-48(%rdx,%rsi,2), %esi
	movq	%rdi, %rdx
	testb	$8, 1(%rcx,%rdi,2)
	je	.L881
	movzbl	4(%rbp), %r9d
	xorl	%r8d, %r8d
	testb	$8, 1(%rcx,%r9,2)
	jne	.L875
	movsbl	%dl, %edx
	leal	(%rsi,%rsi,4), %esi
	addq	$4, %rbp
	leal	-48(%rdx,%rsi,2), %esi
	movl	%r9d, %edx
.L882:
	cmpl	$255, %esi
	ja	.L902
	cmpb	$46, %dl
	jne	.L902
	movzbl	1(%rbp), %r8d
	testb	$8, 1(%rcx,%r8,2)
	je	.L902
	movzbl	2(%rbp), %edx
	movsbl	%r8b, %edi
	subl	$48, %edi
	movq	%rdx, %r9
	testb	$8, 1(%rcx,%rdx,2)
	je	.L883
	movzbl	3(%rbp), %r8d
	movsbl	%r9b, %r9d
	leal	(%rdi,%rdi,4), %edx
	leal	-48(%r9,%rdx,2), %edi
	movq	%r8, %r9
	testb	$8, 1(%rcx,%r8,2)
	je	.L884
	movzbl	4(%rbp), %edx
	xorl	%r8d, %r8d
	movq	%rdx, %r10
	testb	$8, 1(%rcx,%rdx,2)
	jne	.L875
	leal	(%rdi,%rdi,4), %edx
	movsbl	%r9b, %r9d
	leal	-48(%r9,%rdx,2), %edi
	leaq	4(%rbp), %rdx
	movl	%r10d, %r9d
.L885:
	cmpl	$255, %edi
	ja	.L902
	sall	$8, %eax
	orl	%esi, %eax
	sall	$8, %eax
	orl	%edi, %eax
	cmpb	$46, %r9b
	jne	.L902
	movzbl	1(%rdx), %edi
	testb	$8, 1(%rcx,%rdi,2)
	je	.L902
	movzbl	2(%rdx), %r8d
	movsbl	%dil, %esi
	subl	$48, %esi
	testb	$8, 1(%rcx,%r8,2)
	je	.L888
	movsbl	%r8b, %edi
	movzbl	3(%rdx), %r8d
	leal	(%rsi,%rsi,4), %esi
	leal	-48(%rdi,%rsi,2), %esi
	movq	%r8, %rdi
	testb	$8, 1(%rcx,%r8,2)
	je	.L909
	movzbl	4(%rdx), %r9d
	xorl	%r8d, %r8d
	testb	$8, 1(%rcx,%r9,2)
	jne	.L875
	imull	$10, %esi, %esi
	movsbl	%dil, %edi
	addq	$4, %rdx
	leal	-48(%rsi,%rdi), %esi
.L890:
	xorl	%r8d, %r8d
	cmpl	$255, %esi
	ja	.L875
	cmpb	$0, (%rdx)
	jne	.L875
	sall	$8, %eax
	movl	$1, %r8d
	orl	%esi, %eax
	movl	%eax, (%rbx)
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	movl	%r8d, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L878:
	.cfi_restore_state
	addq	$2, %rbp
	jmp	.L879
	.p2align 4,,10
	.p2align 3
.L908:
	movsbl	%dl, %edx
	leal	(%rax,%rax,4), %eax
	addq	$3, %rbp
	leal	-48(%rdx,%rax,2), %eax
	movl	%edi, %edx
	jmp	.L879
.L880:
	addq	$2, %rbp
	jmp	.L882
.L881:
	addq	$3, %rbp
	jmp	.L882
.L884:
	leaq	3(%rbp), %rdx
	jmp	.L885
.L883:
	leaq	2(%rbp), %rdx
	jmp	.L885
.L909:
	addq	$3, %rdx
	jmp	.L890
.L888:
	addq	$2, %rdx
	jmp	.L890
	.cfi_endproc
.LFE21:
	.size	rc_parse_ip, .-rc_parse_ip
	.section	.rodata.str1.8
	.align 8
.LC103:
	.string	"Router-id must be a valid non-zero IPv4 address."
	.text
	.p2align 4
	.type	h_router_id, @function
h_router_id:
.LFB77:
	.cfi_startproc
	movq	%rsi, %rax
	subq	$24, %rsp
	.cfi_def_cfa_offset 32
	movq	(%rax), %rdi
	leaq	12(%rsp), %rsi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L911
	movl	12(%rsp), %edx
	testl	%edx, %edx
	je	.L911
	movl	720+cfg(%rip), %ecx
	testl	%ecx, %ecx
	jne	.L919
.L914:
	movl	%edx, 724+cfg(%rip)
	xorl	%eax, %eax
	movl	$1, 720+cfg(%rip)
.L910:
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L919:
	.cfi_restore_state
	cmpl	724+cfg(%rip), %edx
	jne	.L914
	jmp	.L910
	.p2align 4,,10
	.p2align 3
.L911:
	leaq	.LC103(%rip), %rsi
	xorl	%edi, %edi
	xorl	%eax, %eax
	call	bad_arg
	movl	$-1, %eax
	addq	$24, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE77:
	.size	h_router_id, .-h_router_id
	.section	.rodata.str1.1
.LC104:
	.string	"Invalid IP address."
	.section	.rodata.str1.8
	.align 8
.LC105:
	.string	"Success rate is %d percent (%d/5)\n"
	.align 8
.LC106:
	.string	"(simulation: result is based on this router's own routing table only)"
	.section	.rodata.str1.1
.LC107:
	.string	"!!!!!"
	.section	.rodata.str1.8
	.align 8
.LC108:
	.string	"Type escape sequence to abort.\nSending 5, 100-byte ICMP Echos to %s, timeout is 2 seconds:\n%s\n"
	.section	.rodata.str1.1
.LC109:
	.string	"UUUUU"
	.text
	.p2align 4
	.type	h_ping, @function
h_ping:
.LFB91:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	movq	%rsi, %rax
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	subq	$48, %rsp
	.cfi_def_cfa_offset 80
	movq	(%rax), %rdi
	leaq	12(%rsp), %rsi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L935
	movq	640+cfg(%rip), %rax
	movl	12(%rsp), %ebx
	testq	%rax, %rax
	je	.L923
	xorl	%edx, %edx
	.p2align 4
	.p2align 3
.L925:
	movl	148(%rax), %r8d
	testl	%r8d, %r8d
	je	.L924
	movl	152(%rax), %edi
	testl	%edi, %edi
	jne	.L924
	xorl	%ecx, %ecx
	cmpl	%ebx, 140(%rax)
	sete	%cl
	orl	%ecx, %edx
.L924:
	movq	176(%rax), %rax
	testq	%rax, %rax
	jne	.L925
	testl	%edx, %edx
	je	.L923
.L926:
	movl	i.2(%rip), %ebp
	subq	$8, %rsp
	.cfi_def_cfa_offset 88
	movl	%ebx, %r8d
	movl	%ebx, %ecx
	shrl	$16, %r8d
	shrl	$24, %ecx
	movl	$16, %esi
	leaq	.LC58(%rip), %rdx
	leal	1(%rbp), %eax
	andl	$3, %ebp
	movzbl	%r8b, %r8d
	movl	%eax, i.2(%rip)
	salq	$4, %rbp
	leaq	b.1(%rip), %rax
	addq	%rax, %rbp
	movzbl	%bh, %eax
	movzbl	%bl, %ebx
	pushq	%rbx
	.cfi_def_cfa_offset 96
	movl	%eax, %r9d
	movq	%rbp, %rdi
	xorl	%eax, %eax
	call	snprintf@PLT
	movq	%rbp, %rsi
	leaq	.LC107(%rip), %rdx
	xorl	%eax, %eax
	leaq	.LC108(%rip), %rdi
	movl	$100, %ebp
	call	printf@PLT
	popq	%rcx
	.cfi_def_cfa_offset 88
	movl	$5, %edx
	popq	%rsi
	.cfi_def_cfa_offset 80
.L928:
	movl	%ebp, %esi
	leaq	.LC105(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
	leaq	.LC106(%rip), %rdi
	call	puts@PLT
	xorl	%eax, %eax
.L920:
	addq	$48, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L923:
	.cfi_restore_state
	leaq	16(%rsp), %rsi
	movl	%ebx, %edi
	call	lookup
	movl	%eax, %ebp
	testl	%eax, %eax
	jne	.L926
	movl	i.2(%rip), %eax
	subq	$8, %rsp
	.cfi_def_cfa_offset 88
	movl	%ebx, %r8d
	movl	%ebx, %ecx
	leaq	b.1(%rip), %rdx
	shrl	$16, %r8d
	shrl	$24, %ecx
	movl	$16, %esi
	movl	%eax, %r12d
	addl	$1, %eax
	movzbl	%r8b, %r8d
	movl	%eax, i.2(%rip)
	andl	$3, %r12d
	movzbl	%bh, %eax
	movzbl	%bl, %ebx
	pushq	%rbx
	.cfi_def_cfa_offset 96
	salq	$4, %r12
	movl	%eax, %r9d
	xorl	%eax, %eax
	addq	%rdx, %r12
	leaq	.LC58(%rip), %rdx
	movq	%r12, %rdi
	call	snprintf@PLT
	leaq	.LC109(%rip), %rdx
	movq	%r12, %rsi
	xorl	%eax, %eax
	leaq	.LC108(%rip), %rdi
	call	printf@PLT
	popq	%rax
	.cfi_def_cfa_offset 88
	popq	%rdx
	.cfi_def_cfa_offset 80
	xorl	%edx, %edx
	jmp	.L928
.L935:
	leaq	.LC104(%rip), %rsi
	xorl	%edi, %edi
	call	bad_arg
	movl	$-1, %eax
	jmp	.L920
	.cfi_endproc
.LFE91:
	.size	h_ping, .-h_ping
	.section	.rodata.str1.1
.LC110:
	.string	"connected"
.LC111:
	.string	"static"
.LC112:
	.string	"Network not in table."
	.section	.rodata.str1.8
	.align 8
.LC113:
	.string	"Routing entry for %s/%d\n  Known via \"%s\", distance %d\n"
	.section	.rodata.str1.1
.LC114:
	.string	"  Directly connected, via %s\n"
.LC115:
	.string	"  Via next hop %s\n"
	.section	.rodata.str1.8
	.align 8
.LC116:
	.string	"Codes: C - connected, S - static, R - RIP, O - OSPF\n"
	.align 8
.LC117:
	.string	"Gateway of last resort is %s to network 0.0.0.0\n\n"
	.align 8
.LC118:
	.string	"Gateway of last resort is not set\n"
	.align 8
.LC119:
	.string	"C    %s/%d is directly connected, %s\n"
	.align 8
.LC120:
	.string	"(routing table is empty - no up interface with an IP address)"
	.section	.rodata.str1.1
.LC121:
	.string	"S    %s/%d [%d/0] via %s\n"
	.section	.rodata.str1.8
	.align 8
.LC122:
	.string	"S    %s/%d is directly connected, %s\n"
	.align 8
.LC123:
	.string	"\n(RIP/OSPF are configured but there are no neighbours in this simulator, so they learn no routes.)"
	.text
	.p2align 4
	.type	h_show_route, @function
h_show_route:
.LFB88:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$72, %rsp
	.cfi_def_cfa_offset 128
	testl	%edi, %edi
	jne	.L937
	movslq	672+cfg(%rip), %rax
	testl	%eax, %eax
	jle	.L1007
	movq	%rax, %rdx
	movq	664+cfg(%rip), %rbx
	salq	$4, %rdx
	subq	%rax, %rdx
	leaq	(%rbx,%rdx,4), %rbp
	jmp	.L953
	.p2align 4
	.p2align 4,,10
	.p2align 3
.L951:
	addq	$60, %rbx
	cmpq	%rbp, %rbx
	je	.L1007
.L953:
	movl	(%rbx), %esi
	testl	%esi, %esi
	jne	.L951
	movl	4(%rbx), %ecx
	testl	%ecx, %ecx
	jne	.L951
	movq	%rbx, %rdi
	call	route_installed
	testl	%eax, %eax
	je	.L951
	leaq	.LC116(%rip), %rdi
	call	puts@PLT
	movl	52(%rbx), %eax
	testl	%eax, %eax
	jne	.L1011
	addq	$12, %rbx
.L956:
	movq	%rbx, %rsi
	leaq	.LC117(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
.L957:
	movq	640+cfg(%rip), %rbx
	xorl	%r15d, %r15d
	testq	%rbx, %rbx
	je	.L958
	leaq	b.1(%rip), %r14
	leaq	.LC58(%rip), %r13
	leaq	.LC119(%rip), %r12
	jmp	.L962
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L959:
	movq	176(%rbx), %rbx
	testq	%rbx, %rbx
	je	.L1012
.L962:
	movl	148(%rbx), %eax
	testl	%eax, %eax
	je	.L959
	movl	152(%rbx), %ebp
	testl	%ebp, %ebp
	jne	.L959
	movl	144(%rbx), %ecx
	testl	%ecx, %ecx
	je	.L960
	movl	%ecx, %eax
	.p2align 4
	.p2align 4
	.p2align 3
.L961:
	movl	%eax, %edx
	andl	$1, %edx
	addl	%edx, %ebp
	shrl	%eax
	jne	.L961
.L960:
	movl	140(%rbx), %eax
	movl	i.2(%rip), %r15d
	subq	$8, %rsp
	.cfi_def_cfa_offset 136
	andl	%ecx, %eax
	leal	1(%r15), %edx
	andl	$3, %r15d
	movzbl	%ah, %esi
	movl	%eax, %r8d
	movl	%eax, %ecx
	movzbl	%al, %eax
	pushq	%rax
	.cfi_def_cfa_offset 144
	salq	$4, %r15
	shrl	$16, %r8d
	movl	%esi, %r9d
	addq	%r14, %r15
	movl	%edx, i.2(%rip)
	shrl	$24, %ecx
	movzbl	%r8b, %r8d
	movq	%r15, %rdi
	movq	%r13, %rdx
	movl	$16, %esi
	xorl	%eax, %eax
	call	snprintf@PLT
	movq	%rbx, %rcx
	movl	%ebp, %edx
	movq	%r15, %rsi
	movq	%r12, %rdi
	xorl	%eax, %eax
	call	printf@PLT
	movq	176(%rbx), %rbx
	popq	%rbp
	.cfi_def_cfa_offset 136
	popq	%r15
	.cfi_def_cfa_offset 128
	movl	$1, %r15d
	testq	%rbx, %rbx
	jne	.L962
	.p2align 4
	.p2align 3
.L1012:
	movl	672+cfg(%rip), %r10d
	testl	%r10d, %r10d
	jle	.L966
.L964:
	xorl	%r13d, %r13d
	xorl	%r12d, %r12d
	movl	%r15d, %ebx
	.p2align 4
	.p2align 3
.L974:
	movq	664+cfg(%rip), %r15
	addq	%r12, %r15
	movq	%r15, %rdi
	call	route_installed
	movl	%eax, %r10d
	testl	%eax, %eax
	je	.L967
	movl	i.2(%rip), %ebp
	movl	52(%r15), %ebx
	leaq	b.1(%rip), %rax
	leal	1(%rbp), %ecx
	andl	$3, %ebp
	salq	$4, %rbp
	addq	%rax, %rbp
	testl	%ebx, %ebx
	jne	.L1013
	movl	4(%r15), %eax
	leaq	12(%r15), %r14
	testl	%eax, %eax
	je	.L972
	.p2align 4
	.p2align 4
	.p2align 3
.L973:
	movl	%eax, %edx
	andl	$1, %edx
	addl	%edx, %ebx
	shrl	%eax
	jne	.L973
.L972:
	movl	(%r15), %eax
	movl	%r10d, 12(%rsp)
	subq	$8, %rsp
	.cfi_def_cfa_offset 136
	movq	%rbp, %rdi
	movl	%ecx, i.2(%rip)
	leaq	.LC58(%rip), %rdx
	movzbl	%ah, %esi
	movl	%eax, %r8d
	movl	%eax, %ecx
	movzbl	%al, %eax
	pushq	%rax
	.cfi_def_cfa_offset 144
	shrl	$16, %r8d
	movl	%esi, %r9d
	shrl	$24, %ecx
	movzbl	%r8b, %r8d
	movl	$16, %esi
	xorl	%eax, %eax
	call	snprintf@PLT
	movq	%r14, %rcx
	movl	%ebx, %edx
	movq	%rbp, %rsi
	leaq	.LC122(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
	popq	%rdx
	.cfi_def_cfa_offset 136
	popq	%rcx
	.cfi_def_cfa_offset 128
	movl	12(%rsp), %r10d
.L971:
	movl	%r10d, %ebx
.L967:
	addl	$1, %r13d
	addq	$60, %r12
	cmpl	%r13d, 672+cfg(%rip)
	jg	.L974
	movl	%ebx, %r15d
.L966:
	testl	%r15d, %r15d
	je	.L975
.L965:
	movl	680+cfg(%rip), %eax
	orl	712+cfg(%rip), %eax
	je	.L977
	leaq	.LC123(%rip), %rdi
	call	puts@PLT
.L977:
	addq	$72, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1013:
	.cfi_restore_state
	movl	8(%r15), %eax
	movl	%r10d, 12(%rsp)
	subq	$8, %rsp
	.cfi_def_cfa_offset 136
	movq	%rbp, %rdi
	movl	%ecx, i.2(%rip)
	leaq	.LC58(%rip), %rdx
	xorl	%r14d, %r14d
	movzbl	%ah, %esi
	movl	%eax, %r8d
	movl	%eax, %ecx
	movzbl	%al, %eax
	pushq	%rax
	.cfi_def_cfa_offset 144
	shrl	$16, %r8d
	movl	%esi, %r9d
	shrl	$24, %ecx
	movzbl	%r8b, %r8d
	xorl	%eax, %eax
	movl	$16, %esi
	call	snprintf@PLT
	movl	4(%r15), %eax
	popq	%r8
	.cfi_def_cfa_offset 136
	movl	56(%r15), %ebx
	popq	%r9
	.cfi_def_cfa_offset 128
	testl	%eax, %eax
	movl	12(%rsp), %r10d
	je	.L969
	.p2align 4
	.p2align 4
	.p2align 3
.L970:
	movl	%eax, %edx
	andl	$1, %edx
	addl	%edx, %r14d
	shrl	%eax
	jne	.L970
.L969:
	movl	(%r15), %eax
	movl	i.2(%rip), %r15d
	leaq	b.1(%rip), %rsi
	subq	$8, %rsp
	.cfi_def_cfa_offset 136
	movl	%r10d, 20(%rsp)
	leal	1(%r15), %edx
	andl	$3, %r15d
	movl	%eax, %r8d
	movl	%eax, %ecx
	salq	$4, %r15
	shrl	$16, %r8d
	movl	%edx, i.2(%rip)
	leaq	.LC58(%rip), %rdx
	addq	%rsi, %r15
	movzbl	%ah, %esi
	movzbl	%al, %eax
	shrl	$24, %ecx
	pushq	%rax
	.cfi_def_cfa_offset 144
	movl	%esi, %r9d
	movzbl	%r8b, %r8d
	movl	$16, %esi
	movq	%r15, %rdi
	xorl	%eax, %eax
	call	snprintf@PLT
	movq	%r15, %rsi
	movq	%rbp, %r8
	movl	%ebx, %ecx
	leaq	.LC121(%rip), %rdi
	movl	%r14d, %edx
	xorl	%eax, %eax
	call	printf@PLT
	popq	%rsi
	.cfi_def_cfa_offset 136
	popq	%rdi
	.cfi_def_cfa_offset 128
	movl	12(%rsp), %r10d
	jmp	.L971
	.p2align 4,,10
	.p2align 3
.L937:
	movq	(%rsi), %rdi
	leaq	28(%rsp), %rax
	movq	%rax, %rsi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L1014
	movl	28(%rsp), %edi
	leaq	32(%rsp), %rsi
	call	lookup
	testl	%eax, %eax
	je	.L1015
	movl	56(%rsp), %eax
	movzbl	32(%rsp), %r14d
	leaq	.LC111(%rip), %r12
	cmpb	$67, %r14b
	movl	%eax, 12(%rsp)
	leaq	.LC110(%rip), %rax
	cmove	%rax, %r12
	movl	40(%rsp), %eax
	xorl	%ebx, %ebx
	testl	%eax, %eax
	je	.L945
	.p2align 4
	.p2align 4
	.p2align 3
.L946:
	movl	%eax, %edx
	andl	$1, %edx
	addl	%edx, %ebx
	shrl	%eax
	jne	.L946
.L945:
	movl	i.2(%rip), %edx
	movl	36(%rsp), %eax
	subq	$8, %rsp
	.cfi_def_cfa_offset 136
	leaq	b.1(%rip), %r13
	leaq	.LC58(%rip), %r15
	leal	1(%rdx), %ecx
	movzbl	%ah, %esi
	movl	%eax, %r8d
	andl	$3, %edx
	movl	%ecx, i.2(%rip)
	movl	%eax, %ecx
	movzbl	%al, %eax
	salq	$4, %rdx
	pushq	%rax
	.cfi_def_cfa_offset 144
	leaq	(%rdx,%r13), %rbp
	shrl	$16, %r8d
	movl	%esi, %r9d
	shrl	$24, %ecx
	movzbl	%r8b, %r8d
	movq	%r15, %rdx
	movl	$16, %esi
	movq	%rbp, %rdi
	xorl	%eax, %eax
	call	snprintf@PLT
	movl	28(%rsp), %r8d
	movq	%r12, %rcx
	movl	%ebx, %edx
	movq	%rbp, %rsi
	leaq	.LC113(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
	popq	%r10
	.cfi_def_cfa_offset 136
	popq	%r11
	.cfi_def_cfa_offset 128
	cmpb	$67, %r14b
	je	.L947
	movl	60(%rsp), %r9d
	testl	%r9d, %r9d
	jne	.L948
.L947:
	movq	48(%rsp), %rsi
	leaq	.LC114(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
	jmp	.L977
.L958:
	movl	672+cfg(%rip), %r11d
	testl	%r11d, %r11d
	jg	.L964
.L975:
	leaq	.LC120(%rip), %rdi
	call	puts@PLT
	jmp	.L965
.L1011:
	movl	8(%rbx), %eax
	movl	i.2(%rip), %ebx
	subq	$8, %rsp
	.cfi_def_cfa_offset 136
	leal	1(%rbx), %edx
	movzbl	%ah, %esi
	movl	%eax, %r8d
	movl	%eax, %ecx
	andl	$3, %ebx
	movzbl	%al, %eax
	movl	%edx, i.2(%rip)
	shrl	$16, %r8d
	pushq	%rax
	.cfi_def_cfa_offset 144
	leaq	b.1(%rip), %rdx
	salq	$4, %rbx
	movl	%esi, %r9d
	addq	%rdx, %rbx
	shrl	$24, %ecx
	leaq	.LC58(%rip), %rdx
	xorl	%eax, %eax
	movzbl	%r8b, %r8d
	movl	$16, %esi
	movq	%rbx, %rdi
	call	snprintf@PLT
	popq	%rax
	.cfi_def_cfa_offset 136
	popq	%rdx
	.cfi_def_cfa_offset 128
	jmp	.L956
.L1015:
	leaq	.LC112(%rip), %rdi
	call	err
.L941:
	addq	$72, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movl	$-1, %eax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1007:
	.cfi_restore_state
	leaq	.LC116(%rip), %rdi
	call	puts@PLT
	leaq	.LC118(%rip), %rdi
	call	puts@PLT
	jmp	.L957
.L1014:
	leaq	.LC104(%rip), %rsi
	xorl	%edi, %edi
	call	bad_arg
	jmp	.L941
.L948:
	movl	i.2(%rip), %eax
	movl	44(%rsp), %edx
	subq	$8, %rsp
	.cfi_def_cfa_offset 136
	movl	$16, %esi
	leal	1(%rax), %ecx
	movl	%eax, %ebx
	movl	%edx, %r8d
	movzbl	%dh, %eax
	movl	%ecx, i.2(%rip)
	andl	$3, %ebx
	movl	%edx, %ecx
	movzbl	%dl, %edx
	pushq	%rdx
	.cfi_def_cfa_offset 144
	salq	$4, %rbx
	shrl	$16, %r8d
	movl	%eax, %r9d
	addq	%r13, %rbx
	movzbl	%r8b, %r8d
	shrl	$24, %ecx
	movq	%r15, %rdx
	movq	%rbx, %rdi
	xorl	%eax, %eax
	call	snprintf@PLT
	leaq	.LC115(%rip), %rdi
	movq	%rbx, %rsi
	xorl	%eax, %eax
	call	printf@PLT
	popq	%rdi
	.cfi_def_cfa_offset 136
	popq	%r8
	.cfi_def_cfa_offset 128
	jmp	.L977
	.cfi_endproc
.LFE88:
	.size	h_show_route, .-h_show_route
	.section	.rodata.str1.1
.LC124:
	.string	"Loopback"
	.section	.rodata.str1.8
	.align 8
.LC125:
	.string	"Invalid IP address \"%s\" (must be a unicast host address)."
	.align 8
.LC126:
	.string	"Invalid subnet mask \"%s\" (1-bits must be contiguous, e.g. 255.255.255.0)."
	.align 8
.LC127:
	.string	"Bad mask /32 for address %s (allowed only on loopbacks)."
	.align 8
.LC128:
	.string	"Bad mask /%d for address %s (it is the network or broadcast address)."
	.align 8
.LC129:
	.string	"%s/%d overlaps with %s (%s/%d)."
	.section	.rodata.str1.1
.LC130:
	.string	"%s ip = %s/%d"
	.text
	.p2align 4
	.type	h_ip_address, @function
h_ip_address:
.LFB59:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movl	$8, %edx
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rsi, %rbx
	leaq	.LC124(%rip), %rsi
	subq	$40, %rsp
	.cfi_def_cfa_offset 96
	movq	cur_if(%rip), %r14
	movq	%r14, %rdi
	call	strncmp@PLT
	movq	(%rbx), %r15
	leaq	24(%rsp), %rsi
	movl	%eax, %r13d
	movq	%r15, %rdi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L1017
	movl	24(%rsp), %r12d
	testl	%r12d, %r12d
	je	.L1017
	movl	%r12d, %ecx
	shrl	$24, %ecx
	cmpl	$-536870913, %r12d
	ja	.L1017
	cmpl	$127, %ecx
	je	.L1017
	movq	8(%rbx), %rbx
	leaq	28(%rsp), %rsi
	movl	%ecx, 12(%rsp)
	movq	%rbx, %rdi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L1021
	movl	28(%rsp), %ebp
	testl	%ebp, %ebp
	je	.L1021
	movl	%ebp, %r8d
	movl	%ebp, %edx
	movl	12(%rsp), %ecx
	notl	%r8d
	negl	%edx
	testl	%r8d, %edx
	jne	.L1021
	movl	%r12d, %r10d
	movl	%ebp, %edx
	xorl	%esi, %esi
	andl	%ebp, %r10d
	.p2align 4
	.p2align 4
	.p2align 3
.L1024:
	movl	%edx, %edi
	andl	$1, %edi
	addl	%edi, %esi
	shrl	%edx
	jne	.L1024
	cmpl	$32, %esi
	jne	.L1037
	testl	%r13d, %r13d
	je	.L1037
	movq	%r15, %rdx
	leaq	.LC127(%rip), %rsi
	movl	$1, %edi
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L1020
	.p2align 4,,10
	.p2align 3
.L1017:
	movq	%r15, %rdx
	leaq	.LC125(%rip), %rsi
	xorl	%edi, %edi
	xorl	%eax, %eax
	call	bad_arg
.L1020:
	movl	$-1, %eax
.L1016:
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1021:
	.cfi_restore_state
	movq	%rbx, %rdx
	leaq	.LC126(%rip), %rsi
	movl	$1, %edi
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L1020
	.p2align 4,,10
	.p2align 3
.L1037:
	movl	%ebp, %edx
	xorl	%esi, %esi
	.p2align 4
	.p2align 4
	.p2align 3
.L1025:
	movl	%edx, %edi
	andl	$1, %edi
	addl	%edi, %esi
	shrl	%edx
	jne	.L1025
	cmpl	$30, %esi
	jle	.L1072
.L1026:
	movq	640+cfg(%rip), %rbx
	testq	%rbx, %rbx
	je	.L1029
	.p2align 4
	.p2align 3
.L1034:
	cmpq	%rbx, %r14
	je	.L1030
	movl	148(%rbx), %r11d
	testl	%r11d, %r11d
	je	.L1030
	movl	144(%rbx), %edx
	movl	140(%rbx), %esi
	movl	%r12d, %r8d
	movl	%ebp, %edi
	xorl	%esi, %r8d
	andl	%edx, %edi
	testl	%edi, %r8d
	je	.L1073
.L1030:
	movq	176(%rbx), %rbx
	testq	%rbx, %rbx
	jne	.L1034
.L1029:
	movl	148(%r14), %esi
	testl	%esi, %esi
	je	.L1035
	cmpl	140(%r14), %r12d
	je	.L1074
.L1035:
	movd	%r12d, %xmm0
	movd	%ebp, %xmm1
	xorl	%ebx, %ebx
	movl	$1, 148(%r14)
	punpckldq	%xmm1, %xmm0
	movq	%xmm0, 140(%r14)
	.p2align 4
	.p2align 4
	.p2align 3
.L1036:
	movl	%ebp, %eax
	andl	$1, %eax
	addl	%eax, %ebx
	shrl	%ebp
	jne	.L1036
	movl	i.2(%rip), %ebp
	subq	$8, %rsp
	.cfi_def_cfa_offset 104
	movl	%r12d, %r8d
	leaq	.LC58(%rip), %rdx
	shrl	$16, %r8d
	movl	$16, %esi
	leal	1(%rbp), %eax
	andl	$3, %ebp
	movzbl	%r8b, %r8d
	movl	%eax, i.2(%rip)
	salq	$4, %rbp
	leaq	b.1(%rip), %rax
	addq	%rax, %rbp
	movl	%r12d, %eax
	movzbl	%r12b, %r12d
	pushq	%r12
	.cfi_def_cfa_offset 112
	movzbl	%ah, %eax
	movq	%rbp, %rdi
	movl	%eax, %r9d
	xorl	%eax, %eax
	call	snprintf@PLT
	xorl	%eax, %eax
	movl	%ebx, %r9d
	movq	%rbp, %r8
	movq	cur_if(%rip), %rcx
	leaq	.LC130(%rip), %rdx
	movl	$1, %edi
	leaq	.LC2(%rip), %rsi
	call	rlog_log@PLT
	popq	%rax
	.cfi_def_cfa_offset 104
	xorl	%eax, %eax
	popq	%rdx
	.cfi_def_cfa_offset 96
	jmp	.L1016
	.p2align 4,,10
	.p2align 3
.L1072:
	movl	%r12d, %edx
	notl	%edx
	testl	%r8d, %edx
	je	.L1039
	cmpl	%r10d, %r12d
	jne	.L1026
.L1039:
	xorl	%edx, %edx
	.p2align 4
	.p2align 4
	.p2align 3
.L1028:
	movl	%ebp, %eax
	andl	$1, %eax
	addl	%eax, %edx
	shrl	%ebp
	jne	.L1028
	movq	%r15, %rcx
	leaq	.LC128(%rip), %rsi
	xorl	%edi, %edi
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L1020
	.p2align 4,,10
	.p2align 3
.L1073:
	testl	%edx, %edx
	je	.L1038
	movl	%edx, %eax
	xorl	%r13d, %r13d
	.p2align 4
	.p2align 4
	.p2align 3
.L1032:
	movl	%eax, %ecx
	andl	$1, %ecx
	addl	%ecx, %r13d
	shrl	%eax
	jne	.L1032
.L1031:
	movl	i.2(%rip), %r12d
	andl	%esi, %edx
	subq	$8, %rsp
	.cfi_def_cfa_offset 104
	xorl	%r15d, %r15d
	movl	%edx, %r8d
	movl	%edx, %ecx
	movl	%r10d, 20(%rsp)
	movl	$16, %esi
	leal	1(%r12), %eax
	shrl	$16, %r8d
	andl	$3, %r12d
	shrl	$24, %ecx
	movl	%eax, i.2(%rip)
	movzbl	%dh, %eax
	movzbl	%dl, %edx
	salq	$4, %r12
	pushq	%rdx
	.cfi_def_cfa_offset 112
	leaq	b.1(%rip), %r14
	movl	%eax, %r9d
	movzbl	%r8b, %r8d
	addq	%r14, %r12
	leaq	.LC58(%rip), %rdx
	xorl	%eax, %eax
	movq	%r12, %rdi
	call	snprintf@PLT
	popq	%r9
	.cfi_def_cfa_offset 104
	popq	%r10
	.cfi_def_cfa_offset 96
	leaq	.LC58(%rip), %rdx
	movl	12(%rsp), %r10d
	.p2align 4
	.p2align 4
	.p2align 3
.L1033:
	movl	%ebp, %eax
	andl	$1, %eax
	addl	%eax, %r15d
	shrl	%ebp
	jne	.L1033
	movl	i.2(%rip), %ebp
	subq	$8, %rsp
	.cfi_def_cfa_offset 104
	movl	%r10d, %r8d
	movl	%r10d, %ecx
	shrl	$16, %r8d
	shrl	$24, %ecx
	movl	$16, %esi
	leal	1(%rbp), %eax
	andl	$3, %ebp
	movzbl	%r8b, %r8d
	movl	%eax, i.2(%rip)
	movl	%r10d, %eax
	movzbl	%r10b, %r10d
	salq	$4, %rbp
	pushq	%r10
	.cfi_def_cfa_offset 112
	addq	%r14, %rbp
	movzbl	%ah, %eax
	movl	%eax, %r9d
	movq	%rbp, %rdi
	xorl	%eax, %eax
	call	snprintf@PLT
	movq	%r12, %r8
	movl	%r13d, %r9d
	movq	%rbx, %rcx
	leaq	.LC129(%rip), %rdi
	movl	%r15d, %edx
	movq	%rbp, %rsi
	xorl	%eax, %eax
	call	err
	popq	%rdi
	.cfi_def_cfa_offset 104
	popq	%r8
	.cfi_def_cfa_offset 96
	jmp	.L1020
.L1074:
	cmpl	144(%r14), %ebp
	jne	.L1035
	jmp	.L1016
.L1038:
	xorl	%r13d, %r13d
	jmp	.L1031
	.cfi_endproc
.LFE59:
	.size	h_ip_address, .-h_ip_address
	.section	.rodata.str1.1
.LC131:
	.string	"area"
	.section	.rodata.str1.8
	.align 8
.LC132:
	.string	"RIP syntax: network <classful-network>"
	.section	.rodata.str1.1
.LC133:
	.string	"Invalid network address \"%s\"."
	.section	.rodata.str1.8
	.align 8
.LC134:
	.string	"Not a valid class A/B/C network."
	.align 8
.LC135:
	.string	"Incomplete command. OSPF syntax: network <ip> <wildcard> area <n>"
	.section	.rodata.str1.1
.LC136:
	.string	"Unexpected extra argument."
	.section	.rodata.str1.8
	.align 8
.LC137:
	.string	"Invalid wildcard mask \"%s\" (e.g. 0.0.0.255)."
	.section	.rodata.str1.1
.LC138:
	.string	"Expected keyword 'area'."
	.section	.rodata.str1.8
	.align 8
.LC139:
	.string	"Area must be a number 0-4294967295."
	.text
	.p2align 4
	.type	h_network, @function
h_network:
.LFB80:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rsi, %rbx
	subq	$40, %rsp
	.cfi_def_cfa_offset 96
	cmpl	$4, mode(%rip)
	je	.L1193
	cmpl	$3, %edi
	jle	.L1194
	cmpl	$4, %edi
	je	.L1095
	leaq	.LC136(%rip), %rsi
	movl	$4, %edi
	xorl	%eax, %eax
	call	bad_arg
.L1094:
	movl	$-1, %ebp
.L1075:
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movl	%ebp, %eax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1095:
	.cfi_restore_state
	movq	(%rsi), %rbp
	leaq	24(%rsp), %rsi
	movq	%rbp, %rdi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L1195
	movq	8(%rbx), %r12
	leaq	28(%rsp), %rsi
	movq	%r12, %rdi
	call	rc_parse_ip
	movl	%eax, %ebp
	testl	%eax, %eax
	je	.L1097
	movl	28(%rsp), %edx
	leal	1(%rdx), %eax
	movl	%edx, 12(%rsp)
	testl	%eax, %edx
	jne	.L1097
	movq	16(%rbx), %r15
	leaq	.LC131(%rip), %r14
	movzbl	(%r15), %r12d
	testb	%r12b, %r12b
	jne	.L1100
	jmp	.L1099
	.p2align 4,,10
	.p2align 3
.L1102:
	call	__ctype_tolower_loc@PLT
	movq	(%rax), %rax
	movl	(%rax,%r13,4), %ecx
	cmpl	%ecx, (%rax,%r12,4)
	jne	.L1099
	movzbl	1(%r15), %r12d
	addq	$1, %r15
	addq	$1, %r14
	testb	%r12b, %r12b
	je	.L1101
.L1100:
	movzbl	(%r14), %r13d
	testb	%r13b, %r13b
	jne	.L1102
.L1099:
	leaq	.LC138(%rip), %rsi
	movl	$2, %edi
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L1094
	.p2align 4,,10
	.p2align 3
.L1193:
	cmpl	$1, %edi
	jne	.L1196
	movq	(%rsi), %rbx
	leaq	20(%rsp), %rsi
	movq	%rbx, %rdi
	call	rc_parse_ip
	movl	%eax, %ebp
	testl	%eax, %eax
	je	.L1197
	movl	20(%rsp), %ebx
	movl	%ebx, %eax
	shrl	$24, %eax
	leal	-1(%rax), %edx
	cmpl	$125, %edx
	jbe	.L1198
	leal	-128(%rax), %edx
	cmpl	$63, %edx
	jbe	.L1199
	subl	$192, %eax
	xorb	%bl, %bl
	cmpl	$31, %eax
	jbe	.L1085
	leaq	.LC134(%rip), %rsi
	xorl	%edi, %edi
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L1094
	.p2align 4,,10
	.p2align 3
.L1196:
	leaq	.LC132(%rip), %rsi
	movl	$1, %edi
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L1094
	.p2align 4,,10
	.p2align 3
.L1195:
	movq	%rbp, %rdx
	leaq	.LC133(%rip), %rsi
	xorl	%edi, %edi
	call	bad_arg
	jmp	.L1094
	.p2align 4,,10
	.p2align 3
.L1198:
	andl	$-16777216, %ebx
.L1085:
	movq	696+cfg(%rip), %rdi
	movslq	704+cfg(%rip), %rsi
	xorl	%ecx, %ecx
	movq	%rdi, %rdx
	testl	%esi, %esi
	jg	.L1088
	jmp	.L1083
	.p2align 4
	.p2align 4,,10
	.p2align 3
.L1200:
	addl	$1, %ecx
	addq	$4, %rdx
	cmpl	%esi, %ecx
	je	.L1083
.L1088:
	cmpl	%ebx, (%rdx)
	jne	.L1200
	cmpl	%ecx, %esi
	jg	.L1075
.L1083:
	movl	708+cfg(%rip), %eax
	cmpl	%esi, %eax
	jg	.L1089
	testl	%eax, %eax
	je	.L1116
	addl	%eax, %eax
	movslq	%eax, %rsi
	salq	$2, %rsi
.L1090:
	movl	%eax, 708+cfg(%rip)
	call	realloc@PLT
	movq	%rax, %rdi
	testq	%rax, %rax
	je	.L1113
	movq	%rax, 696+cfg(%rip)
	movslq	704+cfg(%rip), %rsi
.L1089:
	leal	1(%rsi), %eax
	xorl	%ebp, %ebp
	movl	%eax, 704+cfg(%rip)
	movl	%ebx, (%rdi,%rsi,4)
	jmp	.L1075
	.p2align 4,,10
	.p2align 3
.L1194:
	leaq	.LC135(%rip), %rdi
	xorl	%eax, %eax
	call	err
	jmp	.L1094
	.p2align 4,,10
	.p2align 3
.L1097:
	movq	%r12, %rdx
	leaq	.LC137(%rip), %rsi
	movl	$1, %edi
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L1094
	.p2align 4,,10
	.p2align 3
.L1101:
	movq	24(%rbx), %r12
	movzbl	(%r12), %ebx
	testb	%bl, %bl
	je	.L1103
	call	__ctype_b_loc@PLT
	movq	(%rax), %rdx
	movzbl	%bl, %eax
	testb	$8, 1(%rdx,%rax,2)
	je	.L1103
	movsbl	%bl, %ebx
	movzbl	1(%r12), %eax
	subl	$48, %ebx
	movslq	%ebx, %rbx
	testb	%al, %al
	je	.L1104
	movzbl	%al, %ecx
	testb	$8, 1(%rdx,%rcx,2)
	je	.L1103
	movsbl	%al, %eax
	leaq	(%rbx,%rbx,4), %rcx
	subl	$48, %eax
	cltq
	leaq	(%rax,%rcx,2), %rbx
	movzbl	2(%r12), %eax
	testb	%al, %al
	je	.L1104
	movzbl	%al, %ecx
	testb	$8, 1(%rdx,%rcx,2)
	je	.L1103
	movsbl	%al, %eax
	leaq	(%rbx,%rbx,4), %rcx
	subl	$48, %eax
	cltq
	leaq	(%rax,%rcx,2), %rbx
	movzbl	3(%r12), %eax
	testb	%al, %al
	je	.L1104
	movzbl	%al, %ecx
	testb	$8, 1(%rdx,%rcx,2)
	je	.L1103
	movsbl	%al, %eax
	leaq	(%rbx,%rbx,4), %rcx
	subl	$48, %eax
	cltq
	leaq	(%rax,%rcx,2), %rbx
	movzbl	4(%r12), %eax
	testb	%al, %al
	je	.L1104
	movzbl	%al, %ecx
	testb	$8, 1(%rdx,%rcx,2)
	je	.L1103
	movsbl	%al, %eax
	leaq	(%rbx,%rbx,4), %rcx
	subl	$48, %eax
	cltq
	leaq	(%rax,%rcx,2), %rbx
	movzbl	5(%r12), %eax
	testb	%al, %al
	je	.L1104
	movzbl	%al, %ecx
	testb	$8, 1(%rdx,%rcx,2)
	je	.L1103
	movsbl	%al, %eax
	leaq	(%rbx,%rbx,4), %rcx
	subl	$48, %eax
	cltq
	leaq	(%rax,%rcx,2), %rbx
	movzbl	6(%r12), %eax
	testb	%al, %al
	je	.L1104
	movzbl	%al, %ecx
	testb	$8, 1(%rdx,%rcx,2)
	je	.L1103
	movsbl	%al, %eax
	leaq	(%rbx,%rbx,4), %rcx
	subl	$48, %eax
	cltq
	leaq	(%rax,%rcx,2), %rbx
	movzbl	7(%r12), %eax
	testb	%al, %al
	je	.L1104
	movzbl	%al, %ecx
	testb	$8, 1(%rdx,%rcx,2)
	je	.L1103
	movsbl	%al, %eax
	leaq	(%rbx,%rbx,4), %rcx
	subl	$48, %eax
	cltq
	leaq	(%rax,%rcx,2), %rbx
	movzbl	8(%r12), %eax
	testb	%al, %al
	je	.L1104
	movzbl	%al, %ecx
	testb	$8, 1(%rdx,%rcx,2)
	je	.L1103
	movsbl	%al, %eax
	leaq	(%rbx,%rbx,4), %rcx
	subl	$48, %eax
	cltq
	leaq	(%rax,%rcx,2), %rbx
	movzbl	9(%r12), %eax
	testb	%al, %al
	je	.L1104
	movzbl	%al, %ecx
	testb	$8, 1(%rdx,%rcx,2)
	je	.L1103
	cmpb	$0, 10(%r12)
	je	.L1201
.L1103:
	leaq	.LC139(%rip), %rsi
	movl	$3, %edi
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L1094
	.p2align 4,,10
	.p2align 3
.L1197:
	movq	%rbx, %rdx
	leaq	.LC133(%rip), %rsi
	xorl	%edi, %edi
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L1094
	.p2align 4,,10
	.p2align 3
.L1199:
	xorw	%bx, %bx
	jmp	.L1085
	.p2align 4,,10
	.p2align 3
.L1116:
	movl	$32, %esi
	movl	$8, %eax
	jmp	.L1090
.L1201:
	imulq	$10, %rbx, %rbx
	movsbl	%al, %eax
	subl	$48, %eax
	cltq
	addq	%rax, %rbx
.L1104:
	movq	%rbx, %rax
	shrq	$32, %rax
	jne	.L1103
	movl	12(%rsp), %r12d
	movq	728+cfg(%rip), %rdi
	xorl	%edx, %edx
	movslq	736+cfg(%rip), %rcx
	notl	%r12d
	movq	%rdi, %rax
	andl	24(%rsp), %r12d
	testl	%ecx, %ecx
	jg	.L1109
	jmp	.L1106
	.p2align 4
	.p2align 4,,10
	.p2align 3
.L1107:
	addl	$1, %edx
	addq	$16, %rax
	cmpl	%edx, %ecx
	je	.L1106
.L1109:
	cmpl	(%rax), %r12d
	jne	.L1107
	movl	12(%rsp), %esi
	cmpl	4(%rax), %esi
	jne	.L1107
	cmpl	%edx, %ecx
	jle	.L1106
	movslq	%edx, %rdx
	salq	$4, %rdx
	leaq	(%rdi,%rdx), %rax
	cmpq	%rbx, 8(%rax)
	je	.L1075
	movq	%rbx, 8(%rax)
	xorl	%ebp, %ebp
	jmp	.L1075
	.p2align 4,,10
	.p2align 3
.L1106:
	movl	740+cfg(%rip), %eax
	cmpl	%eax, %ecx
	jl	.L1111
	testl	%eax, %eax
	je	.L1117
	addl	%eax, %eax
	movslq	%eax, %rsi
	salq	$4, %rsi
.L1112:
	movl	%eax, 740+cfg(%rip)
	call	realloc@PLT
	movq	%rax, %rdi
	testq	%rax, %rax
	je	.L1113
	movq	%rax, 728+cfg(%rip)
	movslq	736+cfg(%rip), %rcx
.L1111:
	movd	12(%rsp), %xmm1
	leal	1(%rcx), %eax
	movd	%r12d, %xmm0
	xorl	%ebp, %ebp
	salq	$4, %rcx
	movl	%eax, 736+cfg(%rip)
	addq	%rcx, %rdi
	punpckldq	%xmm1, %xmm0
	movq	%rbx, 8(%rdi)
	movq	%xmm0, (%rdi)
	jmp	.L1075
.L1117:
	movl	$128, %esi
	movl	$8, %eax
	jmp	.L1112
.L1113:
	call	xrealloc.part.0
	.cfi_endproc
.LFE80:
	.size	h_network, .-h_network
	.section	.rodata.str1.1
.LC140:
	.string	"Network not configured."
	.section	.rodata.str1.8
	.align 8
.LC141:
	.string	"Network statement not configured."
	.text
	.p2align 4
	.type	h_no_network, @function
h_no_network:
.LFB81:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	movq	%rsi, %r12
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	cmpl	$4, mode(%rip)
	je	.L1311
	cmpl	$3, %edi
	jle	.L1312
	cmpl	$4, %edi
	je	.L1220
	leaq	.LC136(%rip), %rsi
	movl	$4, %edi
	xorl	%eax, %eax
	call	bad_arg
.L1219:
	movl	$-1, %eax
.L1202:
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1220:
	.cfi_restore_state
	movq	(%rsi), %rbx
	leaq	8(%rsp), %rsi
	movq	%rbx, %rdi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L1310
	movq	8(%r12), %rbx
	leaq	12(%rsp), %rsi
	movq	%rbx, %rdi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L1223
	movl	12(%rsp), %r13d
	leal	1(%r13), %eax
	testl	%r13d, %eax
	jne	.L1223
	movq	16(%r12), %r14
	leaq	.LC131(%rip), %r15
	movzbl	(%r14), %ebx
	testb	%bl, %bl
	jne	.L1226
	jmp	.L1225
	.p2align 4,,10
	.p2align 3
.L1228:
	call	__ctype_tolower_loc@PLT
	movq	(%rax), %rax
	movl	(%rax,%rbp,4), %ecx
	cmpl	%ecx, (%rax,%rbx,4)
	jne	.L1225
	movzbl	1(%r14), %ebx
	addq	$1, %r14
	addq	$1, %r15
	testb	%bl, %bl
	je	.L1227
.L1226:
	movzbl	(%r15), %ebp
	testb	%bpl, %bpl
	jne	.L1228
.L1225:
	leaq	.LC138(%rip), %rsi
	movl	$2, %edi
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L1219
	.p2align 4,,10
	.p2align 3
.L1311:
	cmpl	$1, %edi
	jne	.L1313
	movq	(%rsi), %rbx
	leaq	12(%rsp), %rsi
	movq	%rbx, %rdi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L1310
	movl	12(%rsp), %esi
	movl	%esi, %eax
	shrl	$24, %eax
	leal	-1(%rax), %edx
	cmpl	$125, %edx
	jbe	.L1314
	leal	-128(%rax), %edx
	cmpl	$63, %edx
	jbe	.L1315
	subl	$192, %eax
	xorb	%sil, %sil
	cmpl	$31, %eax
	jbe	.L1212
	leaq	.LC134(%rip), %rsi
	xorl	%edi, %edi
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L1219
	.p2align 4,,10
	.p2align 3
.L1313:
	leaq	.LC132(%rip), %rsi
	movl	$1, %edi
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L1219
	.p2align 4,,10
	.p2align 3
.L1310:
	movq	%rbx, %rdx
	leaq	.LC133(%rip), %rsi
	xorl	%edi, %edi
	call	bad_arg
	jmp	.L1219
	.p2align 4,,10
	.p2align 3
.L1314:
	andl	$-16777216, %esi
.L1212:
	movl	704+cfg(%rip), %ecx
	movq	696+cfg(%rip), %rdx
	xorl	%eax, %eax
	testl	%ecx, %ecx
	jg	.L1214
	jmp	.L1210
	.p2align 4
	.p2align 4,,10
	.p2align 3
.L1316:
	addl	$1, %eax
	addq	$4, %rdx
	cmpl	%ecx, %eax
	je	.L1215
.L1214:
	cmpl	%esi, (%rdx)
	jne	.L1316
.L1210:
	cmpl	%ecx, %eax
	je	.L1215
	leal	1(%rax), %esi
	movq	696+cfg(%rip), %rdi
	subl	%eax, %ecx
	movslq	%esi, %rsi
	leal	-1(%rcx), %edx
	salq	$2, %rsi
	movslq	%edx, %rdx
	leaq	(%rdi,%rsi), %rax
	salq	$2, %rdx
	leaq	-4(%rdi,%rsi), %rdi
	movq	%rax, %rsi
	call	memmove@PLT
	subl	$1, 704+cfg(%rip)
	xorl	%eax, %eax
	jmp	.L1202
	.p2align 4,,10
	.p2align 3
.L1312:
	leaq	.LC135(%rip), %rdi
	xorl	%eax, %eax
	call	err
	jmp	.L1219
	.p2align 4,,10
	.p2align 3
.L1223:
	movq	%rbx, %rdx
	leaq	.LC137(%rip), %rsi
	movl	$1, %edi
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L1219
	.p2align 4,,10
	.p2align 3
.L1227:
	movq	24(%r12), %rbp
	movzbl	0(%rbp), %ebx
	testb	%bl, %bl
	je	.L1229
	call	__ctype_b_loc@PLT
	movq	(%rax), %rcx
	movzbl	%bl, %eax
	testb	$8, 1(%rcx,%rax,2)
	je	.L1229
	movsbl	%bl, %eax
	movzbl	1(%rbp), %edx
	subl	$48, %eax
	cltq
	testb	%dl, %dl
	je	.L1230
	movzbl	%dl, %esi
	testb	$8, 1(%rcx,%rsi,2)
	je	.L1229
	movsbl	%dl, %edx
	leaq	(%rax,%rax,4), %rax
	subl	$48, %edx
	movslq	%edx, %rdx
	leaq	(%rdx,%rax,2), %rax
	movzbl	2(%rbp), %edx
	testb	%dl, %dl
	je	.L1230
	movzbl	%dl, %esi
	testb	$8, 1(%rcx,%rsi,2)
	je	.L1229
	leaq	(%rax,%rax,4), %rsi
	movsbl	%dl, %eax
	movzbl	3(%rbp), %edx
	subl	$48, %eax
	cltq
	leaq	(%rax,%rsi,2), %rax
	testb	%dl, %dl
	je	.L1230
	movzbl	%dl, %esi
	testb	$8, 1(%rcx,%rsi,2)
	je	.L1229
	leaq	(%rax,%rax,4), %rsi
	movsbl	%dl, %eax
	movzbl	4(%rbp), %edx
	subl	$48, %eax
	cltq
	leaq	(%rax,%rsi,2), %rax
	testb	%dl, %dl
	je	.L1230
	movzbl	%dl, %esi
	testb	$8, 1(%rcx,%rsi,2)
	je	.L1229
	leaq	(%rax,%rax,4), %rsi
	movsbl	%dl, %eax
	movzbl	5(%rbp), %edx
	subl	$48, %eax
	cltq
	leaq	(%rax,%rsi,2), %rax
	testb	%dl, %dl
	je	.L1230
	movzbl	%dl, %esi
	testb	$8, 1(%rcx,%rsi,2)
	je	.L1229
	leaq	(%rax,%rax,4), %rsi
	movsbl	%dl, %eax
	movzbl	6(%rbp), %edx
	subl	$48, %eax
	cltq
	leaq	(%rax,%rsi,2), %rax
	testb	%dl, %dl
	je	.L1230
	movzbl	%dl, %esi
	testb	$8, 1(%rcx,%rsi,2)
	je	.L1229
	leaq	(%rax,%rax,4), %rsi
	movsbl	%dl, %eax
	movzbl	7(%rbp), %edx
	subl	$48, %eax
	cltq
	leaq	(%rax,%rsi,2), %rax
	testb	%dl, %dl
	je	.L1230
	movzbl	%dl, %esi
	testb	$8, 1(%rcx,%rsi,2)
	je	.L1229
	leaq	(%rax,%rax,4), %rsi
	movsbl	%dl, %eax
	movzbl	8(%rbp), %edx
	subl	$48, %eax
	cltq
	leaq	(%rax,%rsi,2), %rax
	testb	%dl, %dl
	je	.L1230
	movzbl	%dl, %esi
	testb	$8, 1(%rcx,%rsi,2)
	je	.L1229
	leaq	(%rax,%rax,4), %rsi
	movsbl	%dl, %eax
	movzbl	9(%rbp), %edx
	subl	$48, %eax
	cltq
	leaq	(%rax,%rsi,2), %rax
	testb	%dl, %dl
	je	.L1230
	movzbl	%dl, %esi
	testb	$8, 1(%rcx,%rsi,2)
	je	.L1229
	cmpb	$0, 10(%rbp)
	je	.L1317
.L1229:
	leaq	.LC139(%rip), %rsi
	movl	$3, %edi
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L1219
	.p2align 4,,10
	.p2align 3
.L1215:
	leaq	.LC140(%rip), %rdi
	xorl	%eax, %eax
	call	err
	jmp	.L1219
	.p2align 4,,10
	.p2align 3
.L1315:
	xorw	%si, %si
	jmp	.L1212
.L1317:
	imulq	$10, %rax, %rax
	movsbl	%dl, %edx
	subl	$48, %edx
	movslq	%edx, %rdx
	addq	%rdx, %rax
.L1230:
	shrq	$32, %rax
	jne	.L1229
	movl	736+cfg(%rip), %ecx
	movl	%r13d, %esi
	movq	728+cfg(%rip), %rax
	xorl	%edx, %edx
	notl	%esi
	andl	8(%rsp), %esi
	testl	%ecx, %ecx
	jg	.L1234
	jmp	.L1232
	.p2align 4
	.p2align 4,,10
	.p2align 3
.L1233:
	addl	$1, %edx
	addq	$16, %rax
	cmpl	%edx, %ecx
	je	.L1235
.L1234:
	cmpl	(%rax), %esi
	jne	.L1233
	cmpl	4(%rax), %r13d
	jne	.L1233
.L1232:
	cmpl	%edx, %ecx
	je	.L1235
	leal	1(%rdx), %eax
	movq	728+cfg(%rip), %rsi
	subl	%edx, %ecx
	cltq
	leal	-1(%rcx), %edx
	salq	$4, %rax
	movslq	%edx, %rdx
	leaq	(%rsi,%rax), %rcx
	leaq	-16(%rsi,%rax), %rdi
	salq	$4, %rdx
	movq	%rcx, %rsi
	call	memmove@PLT
	subl	$1, 736+cfg(%rip)
	xorl	%eax, %eax
	jmp	.L1202
	.p2align 4,,10
	.p2align 3
.L1235:
	leaq	.LC141(%rip), %rdi
	xorl	%eax, %eax
	call	err
	jmp	.L1219
	.cfi_endproc
.LFE81:
	.size	h_no_network, .-h_no_network
	.p2align 4
	.globl	rc_parse_uint
	.type	rc_parse_uint, @function
rc_parse_uint:
.LFB22:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	xorl	%r15d, %r15d
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$8, %rsp
	.cfi_def_cfa_offset 64
	movzbl	(%rdi), %r13d
	testb	%r13b, %r13b
	je	.L1318
	movq	%rcx, %r12
	movq	%rdi, %r14
	movq	%rsi, %rbx
	movq	%rdx, %rbp
	call	__ctype_b_loc@PLT
	movq	(%rax), %rcx
	movzbl	%r13b, %eax
	testb	$8, 1(%rcx,%rax,2)
	je	.L1318
	movsbl	%r13b, %eax
	movzbl	1(%r14), %edx
	subl	$48, %eax
	cltq
	testb	%dl, %dl
	je	.L1320
	movzbl	%dl, %esi
	testb	$8, 1(%rcx,%rsi,2)
	je	.L1318
	movsbl	%dl, %edx
	leaq	(%rax,%rax,4), %rax
	subl	$48, %edx
	movslq	%edx, %rdx
	leaq	(%rdx,%rax,2), %rax
	movzbl	2(%r14), %edx
	testb	%dl, %dl
	je	.L1320
	movzbl	%dl, %esi
	testb	$8, 1(%rcx,%rsi,2)
	je	.L1318
	movsbl	%dl, %edx
	leaq	(%rax,%rax,4), %rax
	subl	$48, %edx
	movslq	%edx, %rdx
	leaq	(%rdx,%rax,2), %rax
	movzbl	3(%r14), %edx
	testb	%dl, %dl
	je	.L1320
	movzbl	%dl, %esi
	testb	$8, 1(%rcx,%rsi,2)
	je	.L1318
	movsbl	%dl, %edx
	leaq	(%rax,%rax,4), %rax
	subl	$48, %edx
	movslq	%edx, %rdx
	leaq	(%rdx,%rax,2), %rax
	movzbl	4(%r14), %edx
	testb	%dl, %dl
	je	.L1320
	movzbl	%dl, %esi
	testb	$8, 1(%rcx,%rsi,2)
	je	.L1333
	movsbl	%dl, %edx
	leaq	(%rax,%rax,4), %rax
	subl	$48, %edx
	movslq	%edx, %rdx
	leaq	(%rdx,%rax,2), %rax
	movzbl	5(%r14), %edx
	testb	%dl, %dl
	je	.L1320
	movzbl	%dl, %esi
	testb	$8, 1(%rcx,%rsi,2)
	je	.L1333
	movsbl	%dl, %edx
	leaq	(%rax,%rax,4), %rax
	subl	$48, %edx
	movslq	%edx, %rdx
	leaq	(%rdx,%rax,2), %rax
	movzbl	6(%r14), %edx
	testb	%dl, %dl
	je	.L1320
	movzbl	%dl, %esi
	testb	$8, 1(%rcx,%rsi,2)
	je	.L1333
	movsbl	%dl, %edx
	leaq	(%rax,%rax,4), %rax
	subl	$48, %edx
	movslq	%edx, %rdx
	leaq	(%rdx,%rax,2), %rax
	movzbl	7(%r14), %edx
	testb	%dl, %dl
	je	.L1320
	movzbl	%dl, %esi
	testb	$8, 1(%rcx,%rsi,2)
	je	.L1333
	movsbl	%dl, %edx
	leaq	(%rax,%rax,4), %rax
	subl	$48, %edx
	movslq	%edx, %rdx
	leaq	(%rdx,%rax,2), %rax
	movzbl	8(%r14), %edx
	testb	%dl, %dl
	je	.L1320
	movzbl	%dl, %esi
	testb	$8, 1(%rcx,%rsi,2)
	je	.L1333
	movsbl	%dl, %edx
	leaq	(%rax,%rax,4), %rax
	subl	$48, %edx
	movslq	%edx, %rdx
	leaq	(%rdx,%rax,2), %rax
	movzbl	9(%r14), %edx
	testb	%dl, %dl
	je	.L1320
	movzbl	%dl, %esi
	testb	$8, 1(%rcx,%rsi,2)
	je	.L1333
	cmpb	$0, 10(%r14)
	je	.L1363
.L1318:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movl	%r15d, %eax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L1363:
	.cfi_restore_state
	leaq	(%rax,%rax,4), %rcx
	movsbl	%dl, %eax
	subl	$48, %eax
	cltq
	leaq	(%rax,%rcx,2), %rax
	.p2align 4
	.p2align 3
.L1320:
	cmpq	%rbx, %rax
	jb	.L1333
	cmpq	%rax, %rbp
	jb	.L1333
	movq	%rax, (%r12)
	movl	$1, %r15d
	jmp	.L1318
	.p2align 4,,10
	.p2align 3
.L1333:
	xorl	%r15d, %r15d
	jmp	.L1318
	.cfi_endproc
.LFE22:
	.size	rc_parse_uint, .-rc_parse_uint
	.p2align 4
	.globl	rc_mask_ok
	.type	rc_mask_ok, @function
rc_mask_ok:
.LFB23:
	.cfi_startproc
	movl	%edi, %eax
	notl	%edi
	negl	%eax
	testl	%eax, %edi
	sete	%al
	movzbl	%al, %eax
	ret
	.cfi_endproc
.LFE23:
	.size	rc_mask_ok, .-rc_mask_ok
	.p2align 4
	.globl	rc_plen
	.type	rc_plen, @function
rc_plen:
.LFB24:
	.cfi_startproc
	xorl	%eax, %eax
	testl	%edi, %edi
	je	.L1368
	.p2align 4
	.p2align 4
	.p2align 3
.L1367:
	movl	%edi, %edx
	andl	$1, %edx
	addl	%edx, %eax
	shrl	%edi
	jne	.L1367
	ret
	.p2align 4,,10
	.p2align 3
.L1368:
	ret
	.cfi_endproc
.LFE24:
	.size	rc_plen, .-rc_plen
	.p2align 4
	.globl	rc_classful
	.type	rc_classful, @function
rc_classful:
.LFB25:
	.cfi_startproc
	movl	%edi, %eax
	shrl	$24, %eax
	leal	-1(%rax), %edx
	cmpl	$125, %edx
	jbe	.L1376
	leal	-128(%rax), %edx
	cmpl	$63, %edx
	jbe	.L1377
	subl	$192, %eax
	xorl	%edx, %edx
	cmpl	$31, %eax
	jbe	.L1378
	movl	%edx, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L1377:
	xorw	%di, %di
	movl	%edi, (%rsi)
.L1372:
	movl	$1, %edx
	movl	%edx, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L1376:
	andl	$-16777216, %edi
	movl	%edi, (%rsi)
	jmp	.L1372
	.p2align 4,,10
	.p2align 3
.L1378:
	xorb	%dil, %dil
	movl	%edi, (%rsi)
	jmp	.L1372
	.cfi_endproc
.LFE25:
	.size	rc_classful, .-rc_classful
	.section	.rodata.str1.1
.LC142:
	.string	"GigabitEthernet"
.LC143:
	.string	"%s%s"
	.text
	.p2align 4
	.globl	rc_canon_iface
	.type	rc_canon_iface, @function
rc_canon_iface:
.LFB36:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	movq	%rdi, %r14
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	movq	%rdx, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$88, %rsp
	.cfi_def_cfa_offset 144
	movq	%rsi, (%rsp)
	call	__ctype_b_loc@PLT
	movzbl	(%r14), %edx
	movq	(%rax), %rsi
	testb	$4, 1(%rsi,%rdx,2)
	je	.L1380
	movq	%rdx, %rax
	xorl	%edx, %edx
	jmp	.L1382
	.p2align 6
	.p2align 4,,10
	.p2align 3
.L1432:
	addq	$1, %r14
	movb	%al, 48(%rsp,%rdx)
	leaq	1(%rdx), %rdi
	movzbl	(%r14), %edx
	movzwl	(%rsi,%rdx,2), %ecx
	movq	%rdx, %rax
	movq	%rdi, %rdx
	testb	$4, %ch
	je	.L1383
.L1382:
	cmpq	$23, %rdx
	jne	.L1432
	.p2align 5
	.p2align 4
	.p2align 3
.L1381:
	movzbl	1(%r14), %ecx
	addq	$1, %r14
	movq	%rcx, %rax
	movzwl	(%rsi,%rcx,2), %ecx
	testb	$4, %ch
	jne	.L1381
.L1383:
	movb	$0, 48(%rsp,%rdx)
	testb	%al, %al
	jne	.L1433
.L1380:
	xorl	%eax, %eax
.L1379:
	addq	$88, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1433:
	.cfi_restore_state
	movl	$0, 12(%rsp)
	movq	%r14, %rdx
	andb	$8, %ch
	je	.L1380
.L1384:
	movzbl	1(%rdx), %ecx
	movq	%rcx, %rax
	testb	$8, 1(%rsi,%rcx,2)
	je	.L1434
	movzbl	2(%rdx), %ecx
	movq	%rcx, %rax
	testb	$8, 1(%rsi,%rcx,2)
	je	.L1435
	movzbl	3(%rdx), %ecx
	movq	%rcx, %rax
	testb	$8, 1(%rsi,%rcx,2)
	je	.L1436
	movzbl	4(%rdx), %ecx
	movq	%rcx, %rax
	testb	$8, 1(%rsi,%rcx,2)
	je	.L1437
	movzbl	5(%rdx), %ecx
	movq	%rcx, %rax
	testb	$8, 1(%rsi,%rcx,2)
	je	.L1438
	movzbl	6(%rdx), %ecx
	movq	%rcx, %rax
	testb	$8, 1(%rsi,%rcx,2)
	jne	.L1380
	leaq	6(%rdx), %rcx
	.p2align 4
	.p2align 3
.L1387:
	addl	$1, 12(%rsp)
	cmpb	$47, %al
	je	.L1439
	testb	%al, %al
	jne	.L1380
	cmpl	$3, 12(%rsp)
	jg	.L1380
	movzbl	48(%rsp), %eax
	leaq	.LC142(%rip), %rbx
	movq	$0, 16(%rsp)
	movq	%rbx, 24(%rsp)
	movb	%al, 43(%rsp)
	testb	%al, %al
	je	.L1393
	leaq	48(%rsp), %rax
	movl	$0, 44(%rsp)
	movq	%rax, 32(%rsp)
.L1394:
	movq	24(%rsp), %r12
	movzbl	43(%rsp), %r13d
	movq	32(%rsp), %r15
	jmp	.L1395
	.p2align 4,,10
	.p2align 3
.L1398:
	call	__ctype_tolower_loc@PLT
	movzbl	%bl, %edx
	movzbl	%r13b, %ecx
	movq	(%rax), %rax
	movl	(%rax,%rdx,4), %ebx
	cmpl	%ebx, (%rax,%rcx,4)
	jne	.L1396
	movzbl	1(%r15), %r13d
	addq	$1, %r15
	addq	$1, %r12
	testb	%r13b, %r13b
	je	.L1397
.L1395:
	movzbl	(%r12), %ebx
	testb	%bl, %bl
	jne	.L1398
	addq	$1, 16(%rsp)
	movq	16(%rsp), %rax
	cmpq	$4, %rax
	je	.L1380
	movq	%rax, %rbx
.L1431:
	leaq	IFTYPES(%rip), %rax
	movl	%ebx, 44(%rsp)
	movq	(%rax,%rbx,8), %rax
	movq	%rax, 24(%rsp)
	jmp	.L1394
.L1393:
	addq	$1, 16(%rsp)
	movq	16(%rsp), %rax
	cmpq	$4, %rax
	jne	.L1393
	jmp	.L1380
.L1396:
	addq	$1, 16(%rsp)
	movq	16(%rsp), %rbx
	cmpq	$4, %rbx
	jne	.L1431
	jmp	.L1380
.L1439:
	movzbl	1(%rcx), %eax
	leaq	1(%rcx), %rdx
	testb	$8, 1(%rsi,%rax,2)
	jne	.L1384
	jmp	.L1380
	.p2align 4,,10
	.p2align 3
.L1434:
	leaq	1(%rdx), %rcx
	jmp	.L1387
.L1435:
	leaq	2(%rdx), %rcx
	jmp	.L1387
.L1436:
	leaq	3(%rdx), %rcx
	jmp	.L1387
.L1437:
	leaq	4(%rdx), %rcx
	jmp	.L1387
.L1438:
	leaq	5(%rdx), %rcx
	jmp	.L1387
.L1397:
	cmpl	$3, 44(%rsp)
	jne	.L1403
	cmpl	$1, 12(%rsp)
	jne	.L1380
.L1403:
	movq	24(%rsp), %rcx
	movq	(%rsp), %rdi
	movq	%r14, %r8
	movq	%rbp, %rsi
	leaq	.LC143(%rip), %rdx
	xorl	%eax, %eax
	call	snprintf@PLT
	movl	$1, %eax
	jmp	.L1379
	.cfi_endproc
.LFE36:
	.size	rc_canon_iface, .-rc_canon_iface
	.section	.rodata.str1.1
.LC144:
	.string	"Matches for \"%s\":\n"
.LC145:
	.string	"  [%s] %s\n"
.LC146:
	.string	"  %s\n"
	.section	.rodata.str1.8
	.align 8
.LC147:
	.string	"No configuration line contains \"%s\".\n"
	.section	.rodata.str1.1
.LC148:
	.string	"%d match(es).\n"
	.section	.rodata.str1.8
	.align 8
.LC149:
	.string	"Interface found by hash lookup:"
	.text
	.p2align 4
	.type	h_search, @function
h_search:
.LFB96:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pxor	%xmm0, %xmm0
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	leaq	.LC33(%rip), %rbx
	subq	$248, %rsp
	.cfi_def_cfa_offset 304
	movslq	708+C(%rip), %rax
	cmpl	%eax, 704+C(%rip)
	movq	$0, 224(%rsp)
	movaps	%xmm0, 48(%rsp)
	movaps	%xmm0, 112(%rsp)
	movaps	%xmm0, 128(%rsp)
	movaps	%xmm0, 144(%rsp)
	movaps	%xmm0, 160(%rsp)
	movaps	%xmm0, 176(%rsp)
	movaps	%xmm0, 192(%rsp)
	movaps	%xmm0, 208(%rsp)
	jle	.L1441
	leaq	C(%rip), %rdx
	movslq	640(%rdx,%rax,4), %rbx
	addq	%rdx, %rbx
.L1441:
	leaq	64(%rsp), %rbp
	movl	$40, %edx
	movq	%rbx, %rdi
	movq	%rbp, %rsi
	call	rc_canon_iface
	testl	%eax, %eax
	jne	.L1507
.L1442:
	leaq	48(%rsp), %rdi
	call	gen_config
	movslq	56(%rsp), %rax
	movq	48(%rsp), %r13
	testl	%eax, %eax
	jle	.L1450
	xorl	%r8d, %r8d
	movq	%r13, 32(%rsp)
	leaq	0(%r13,%rax,8), %r12
	movq	%r13, %rbp
	movl	%r8d, 28(%rsp)
	movq	%r13, 40(%rsp)
	.p2align 4
	.p2align 3
.L1464:
	movq	0(%rbp), %r13
	movzbl	0(%r13), %eax
	subl	$32, %eax
	cmpb	$1, %al
	ja	.L1451
	movq	%rbx, %rdi
	call	strlen@PLT
	movq	%rax, %r15
	testq	%rax, %rax
	je	.L1455
.L1452:
	movq	%r13, 16(%rsp)
	movq	%rbp, 8(%rsp)
	.p2align 4
	.p2align 3
.L1457:
	xorl	%ebp, %ebp
	movq	%r13, %r14
	.p2align 4
	.p2align 3
.L1460:
	movzbl	(%r14,%rbp), %r13d
	testb	%r13b, %r13b
	je	.L1458
	call	__ctype_tolower_loc@PLT
	movzbl	(%rbx,%rbp), %ecx
	movq	(%rax), %rax
	movl	(%rax,%rcx,4), %esi
	cmpl	%esi, (%rax,%r13,4)
	jne	.L1458
	addq	$1, %rbp
	cmpq	%r15, %rbp
	jne	.L1460
.L1502:
	movq	16(%rsp), %r13
	movq	8(%rsp), %rbp
.L1455:
	movl	28(%rsp), %eax
	testl	%eax, %eax
	je	.L1508
.L1454:
	cmpb	$32, 0(%r13)
	je	.L1509
	movq	%r13, %rsi
	leaq	.LC146(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
.L1463:
	addl	$1, 28(%rsp)
.L1461:
	addq	$8, %rbp
	cmpq	%r12, %rbp
	jne	.L1464
	movl	28(%rsp), %r8d
	movq	32(%rsp), %r13
	movq	40(%rsp), %r14
	testl	%r8d, %r8d
	je	.L1510
	movl	%r8d, %esi
	leaq	.LC148(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
	.p2align 4
	.p2align 3
.L1469:
	movq	(%r14), %rdi
	addq	$8, %r14
	call	free@PLT
	cmpq	%r12, %r14
	jne	.L1469
.L1466:
	movq	%r13, %rdi
	call	free@PLT
	addq	$248, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1458:
	.cfi_restore_state
	movq	%r14, %r13
	cmpq	%r15, %rbp
	je	.L1502
	addq	$1, %r13
	cmpb	$0, 0(%r13)
	jne	.L1457
	movq	8(%rsp), %rbp
	jmp	.L1461
.L1451:
	leaq	112(%rsp), %rdi
	movq	%r13, %rcx
	movl	$120, %esi
	xorl	%eax, %eax
	leaq	.LC24(%rip), %rdx
	call	snprintf@PLT
	movq	%rbx, %rdi
	call	strlen@PLT
	movq	%rax, %r15
	testq	%rax, %rax
	je	.L1455
	cmpb	$0, 0(%r13)
	jne	.L1452
	jmp	.L1461
.L1509:
	leaq	1(%r13), %rdx
	leaq	112(%rsp), %rsi
	xorl	%eax, %eax
	leaq	.LC145(%rip), %rdi
	call	printf@PLT
	jmp	.L1463
.L1508:
	movq	%rbx, %rsi
	leaq	.LC144(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
	jmp	.L1454
.L1510:
	movq	%rbx, %rsi
	leaq	.LC147(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
	jmp	.L1469
.L1507:
	movzbl	64(%rsp), %r12d
	testb	%r12b, %r12b
	je	.L1473
	call	__ctype_tolower_loc@PLT
	movq	%rbp, %rcx
	movq	(%rax), %rsi
	movl	$5381, %eax
.L1444:
	movl	%eax, %edx
	addq	$1, %rcx
	sall	$5, %edx
	addl	%edx, %eax
	movzbl	(%rsi,%r12,4), %edx
	movzbl	(%rcx), %r12d
	addl	%edx, %eax
	testb	%r12b, %r12b
	jne	.L1444
	andl	$63, %eax
.L1443:
	leaq	cfg(%rip), %r12
	movq	128(%r12,%rax,8), %r13
	testq	%r13, %r13
	jne	.L1446
	jmp	.L1442
	.p2align 4,,10
	.p2align 3
.L1511:
	movq	168(%r13), %r13
	testq	%r13, %r13
	je	.L1442
.L1446:
	movq	%rbp, %rsi
	movq	%r13, %rdi
	call	strcmp@PLT
	testl	%eax, %eax
	jne	.L1511
	leaq	.LC149(%rip), %rdi
	call	puts@PLT
	movzbl	64(%rsp), %r13d
	movl	$5, %eax
	testb	%r13b, %r13b
	je	.L1471
	call	__ctype_tolower_loc@PLT
	movq	%rbp, %rcx
	movq	(%rax), %rsi
	movl	$5381, %eax
.L1447:
	movl	%eax, %edx
	addq	$1, %rcx
	sall	$5, %edx
	addl	%edx, %eax
	movzbl	(%rsi,%r13,4), %edx
	movzbl	(%rcx), %r13d
	addl	%edx, %eax
	testb	%r13b, %r13b
	jne	.L1447
	andl	$63, %eax
.L1471:
	movq	128(%r12,%rax,8), %r12
	testq	%r12, %r12
	jne	.L1449
	jmp	.L1448
	.p2align 4,,10
	.p2align 3
.L1512:
	movq	168(%r12), %r12
	testq	%r12, %r12
	je	.L1448
.L1449:
	movq	%rbp, %rsi
	movq	%r12, %rdi
	call	strcmp@PLT
	testl	%eax, %eax
	jne	.L1512
.L1448:
	movq	%r12, %rdi
	call	print_if_detail
	leaq	.LC33(%rip), %rdi
	call	puts@PLT
	jmp	.L1442
.L1450:
	movq	%rbx, %rsi
	leaq	.LC147(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
	jmp	.L1466
.L1473:
	movl	$5, %eax
	jmp	.L1443
	.cfi_endproc
.LFE96:
	.size	h_search, .-h_search
	.section	.rodata.str1.1
.LC150:
	.string	"Invalid network address."
.LC151:
	.string	"Invalid subnet mask."
.LC152:
	.string	"Invalid next hop / interface."
.LC153:
	.string	"No matching route to delete."
	.text
	.p2align 4
	.type	h_no_ip_route, @function
h_no_ip_route:
.LFB69:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	subq	$80, %rsp
	.cfi_def_cfa_offset 128
	cmpl	$1, %edi
	jle	.L1538
	movq	%rsi, %rbx
	movl	%edi, %r12d
	leaq	4(%rsp), %rsi
	movq	(%rbx), %rdi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L1539
	movq	8(%rbx), %rdi
	leaq	8(%rsp), %rsi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L1518
	movl	8(%rsp), %ebp
	movl	%ebp, %eax
	movl	%ebp, %edx
	negl	%eax
	notl	%edx
	testl	%eax, %edx
	jne	.L1518
	cmpl	$2, %r12d
	jne	.L1540
	movl	672+cfg(%rip), %edx
	movl	%edx, %r12d
	subl	$1, %r12d
	js	.L1529
	movslq	%r12d, %rax
	movl	4(%rsp), %r13d
	xorl	%r14d, %r14d
	movq	%rax, %rbx
	salq	$4, %rbx
	subq	%rax, %rbx
	salq	$2, %rbx
	jmp	.L1528
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L1527:
	subl	$1, %r12d
	subq	$60, %rbx
	cmpl	$-1, %r12d
	je	.L1541
.L1528:
	movq	664+cfg(%rip), %rax
	leaq	(%rax,%rbx), %rdi
	cmpl	%r13d, (%rdi)
	jne	.L1527
	cmpl	4(%rdi), %ebp
	jne	.L1527
	subl	%r12d, %edx
	leaq	60(%rax,%rbx), %rsi
	subl	$1, %r12d
	addl	$1, %r14d
	leal	-1(%rdx), %ecx
	subq	$60, %rbx
	movslq	%ecx, %rcx
	movq	%rcx, %rdx
	salq	$4, %rdx
	subq	%rcx, %rdx
	salq	$2, %rdx
	call	memmove@PLT
	movl	672+cfg(%rip), %edx
	subl	$1, %edx
	movl	%edx, 672+cfg(%rip)
	cmpl	$-1, %r12d
	jne	.L1528
	.p2align 4
	.p2align 3
.L1541:
	testl	%r14d, %r14d
	je	.L1529
	addq	$80, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 48
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1540:
	.cfi_restore_state
	pxor	%xmm0, %xmm0
	movq	16(%rbx), %rbx
	movd	%ebp, %xmm1
	leaq	24(%rsp), %rsi
	movups	%xmm0, 24(%rsp)
	movups	%xmm0, 40(%rsp)
	movq	%rbx, %rdi
	movups	%xmm0, 56(%rsp)
	movd	4(%rsp), %xmm0
	movl	$0, 72(%rsp)
	punpckldq	%xmm1, %xmm0
	movq	%xmm0, 16(%rsp)
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L1521
	movl	$1, 68(%rsp)
.L1522:
	leaq	12(%rsp), %rsi
	leaq	16(%rsp), %rdi
	call	route_find
	testl	%eax, %eax
	jne	.L1524
	leaq	.LC153(%rip), %rdi
	call	err
.L1523:
	addq	$80, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 48
	movl	$-1, %eax
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1524:
	.cfi_restore_state
	movslq	12(%rsp), %rdx
	movq	664+cfg(%rip), %rsi
	movq	%rdx, %rax
	addq	$1, %rdx
	movq	%rdx, %rcx
	notl	%eax
	addl	672+cfg(%rip), %eax
	cltq
	salq	$4, %rcx
	subq	%rdx, %rcx
	movq	%rax, %rdx
	salq	$2, %rcx
	salq	$4, %rdx
	subq	%rax, %rdx
	leaq	(%rsi,%rcx), %rax
	leaq	-60(%rsi,%rcx), %rdi
	salq	$2, %rdx
	movq	%rax, %rsi
	call	memmove@PLT
	subl	$1, 672+cfg(%rip)
	addq	$80, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 48
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1521:
	.cfi_restore_state
	leaq	28(%rsp), %rsi
	movl	$40, %edx
	movq	%rbx, %rdi
	call	rc_canon_iface
	testl	%eax, %eax
	jne	.L1522
	leaq	.LC152(%rip), %rsi
	movl	$2, %edi
	call	bad_arg
	jmp	.L1523
	.p2align 4,,10
	.p2align 3
.L1529:
	leaq	.LC153(%rip), %rdi
	xorl	%eax, %eax
	call	err
	jmp	.L1523
.L1518:
	leaq	.LC151(%rip), %rsi
	movl	$1, %edi
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L1523
.L1539:
	leaq	.LC150(%rip), %rsi
	xorl	%edi, %edi
	call	bad_arg
	jmp	.L1523
.L1538:
	leaq	.LC66(%rip), %rdi
	xorl	%eax, %eax
	call	err
	jmp	.L1523
	.cfi_endproc
.LFE69:
	.size	h_no_ip_route, .-h_no_ip_route
	.section	.rodata.str1.1
.LC154:
	.string	"Invalid subnet mask \"%s\"."
	.section	.rodata.str1.8
	.align 8
.LC155:
	.string	"Inconsistent address and mask: host bits set (did you mean %s?)."
	.section	.rodata.str1.1
.LC156:
	.string	"Invalid next-hop address."
	.section	.rodata.str1.8
	.align 8
.LC157:
	.string	"Invalid next hop %s (it is this router's own interface address)."
	.align 8
.LC158:
	.string	"Next hop must be an IP address or an exit interface."
	.align 8
.LC159:
	.string	"Exit interface %s does not exist (create it with 'interface' first)."
	.align 8
.LC160:
	.string	"Administrative distance must be 1-255."
	.section	.rodata.str1.1
.LC161:
	.string	"route added %s/%d ad=%d"
	.section	.rodata.str1.8
	.align 8
.LC162:
	.string	"%% Warning: next hop %s is not on a connected, up network - route not installed yet.\n"
	.text
	.p2align 4
	.type	h_ip_route, @function
h_ip_route:
.LFB68:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pxor	%xmm0, %xmm0
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$152, %rsp
	.cfi_def_cfa_offset 208
	movaps	%xmm0, 112(%rsp)
	movaps	%xmm0, 80(%rsp)
	movaps	%xmm0, 96(%rsp)
	movups	%xmm0, 124(%rsp)
	cmpl	$2, %edi
	jle	.L1666
	movq	(%rsi), %r12
	movl	%edi, %ebp
	movq	%rsi, %rbx
	leaq	24(%rsp), %rsi
	movq	%r12, %rdi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L1667
	movq	8(%rbx), %r13
	leaq	28(%rsp), %rsi
	movq	%r13, %rdi
	call	rc_parse_ip
	movl	%eax, %r12d
	testl	%eax, %eax
	je	.L1546
	movl	28(%rsp), %r14d
	movl	%r14d, %eax
	movl	%r14d, %edx
	negl	%eax
	notl	%edx
	testl	%eax, %edx
	jne	.L1546
	movl	24(%rsp), %r13d
	movl	%r14d, %eax
	andl	%r13d, %eax
	cmpl	%eax, %r13d
	jne	.L1668
	movq	16(%rbx), %r15
	leaq	88(%rsp), %rsi
	movq	%r15, %rdi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L1549
	movl	88(%rsp), %edx
	testl	%edx, %edx
	je	.L1550
	cmpl	$-536870913, %edx
	ja	.L1550
	movq	640+cfg(%rip), %rax
	testq	%rax, %rax
	je	.L1552
	.p2align 4
	.p2align 3
.L1554:
	movl	148(%rax), %r11d
	testl	%r11d, %r11d
	je	.L1553
	cmpl	140(%rax), %edx
	je	.L1669
.L1553:
	movq	176(%rax), %rax
	testq	%rax, %rax
	jne	.L1554
.L1552:
	movl	$1, 132(%rsp)
.L1555:
	cmpl	$4, %ebp
	jne	.L1564
	movq	24(%rbx), %rbp
	movzbl	0(%rbp), %r12d
	testb	%r12b, %r12b
	je	.L1565
	call	__ctype_b_loc@PLT
	movq	(%rax), %rdx
	movzbl	%r12b, %eax
	testb	$8, 1(%rdx,%rax,2)
	je	.L1565
	movsbl	%r12b, %r12d
	movzbl	1(%rbp), %eax
	subl	$48, %r12d
	movslq	%r12d, %r12
	testb	%al, %al
	je	.L1566
	movzbl	%al, %ecx
	testb	$8, 1(%rdx,%rcx,2)
	je	.L1565
	movsbl	%al, %eax
	leaq	(%r12,%r12,4), %rcx
	subl	$48, %eax
	cltq
	leaq	(%rax,%rcx,2), %r12
	movzbl	2(%rbp), %eax
	testb	%al, %al
	je	.L1566
	movzbl	%al, %ecx
	testb	$8, 1(%rdx,%rcx,2)
	je	.L1565
	movsbl	%al, %eax
	leaq	(%r12,%r12,4), %rcx
	subl	$48, %eax
	cltq
	leaq	(%rax,%rcx,2), %r12
	movzbl	3(%rbp), %eax
	testb	%al, %al
	je	.L1566
	movzbl	%al, %ecx
	testb	$8, 1(%rdx,%rcx,2)
	je	.L1565
	movsbl	%al, %eax
	leaq	(%r12,%r12,4), %rcx
	subl	$48, %eax
	cltq
	leaq	(%rax,%rcx,2), %r12
	movzbl	4(%rbp), %eax
	testb	%al, %al
	je	.L1566
	movzbl	%al, %ecx
	testb	$8, 1(%rdx,%rcx,2)
	je	.L1565
	movsbl	%al, %eax
	leaq	(%r12,%r12,4), %rcx
	subl	$48, %eax
	cltq
	leaq	(%rax,%rcx,2), %r12
	movzbl	5(%rbp), %eax
	testb	%al, %al
	je	.L1566
	movzbl	%al, %ecx
	testb	$8, 1(%rdx,%rcx,2)
	je	.L1565
	movsbl	%al, %eax
	leaq	(%r12,%r12,4), %rcx
	subl	$48, %eax
	cltq
	leaq	(%rax,%rcx,2), %r12
	movzbl	6(%rbp), %eax
	testb	%al, %al
	je	.L1566
	movzbl	%al, %ecx
	testb	$8, 1(%rdx,%rcx,2)
	je	.L1565
	movsbl	%al, %eax
	leaq	(%r12,%r12,4), %rcx
	subl	$48, %eax
	cltq
	leaq	(%rax,%rcx,2), %r12
	movzbl	7(%rbp), %eax
	testb	%al, %al
	je	.L1566
	movzbl	%al, %ecx
	testb	$8, 1(%rdx,%rcx,2)
	je	.L1565
	movsbl	%al, %eax
	leaq	(%r12,%r12,4), %rcx
	subl	$48, %eax
	cltq
	leaq	(%rax,%rcx,2), %r12
	movzbl	8(%rbp), %eax
	testb	%al, %al
	je	.L1566
	movzbl	%al, %ecx
	testb	$8, 1(%rdx,%rcx,2)
	je	.L1565
	movsbl	%al, %eax
	leaq	(%r12,%r12,4), %rcx
	subl	$48, %eax
	cltq
	leaq	(%rax,%rcx,2), %r12
	movzbl	9(%rbp), %eax
	testb	%al, %al
	je	.L1566
	movzbl	%al, %ecx
	testb	$8, 1(%rdx,%rcx,2)
	je	.L1565
	cmpb	$0, 10(%rbp)
	je	.L1670
.L1565:
	leaq	.LC160(%rip), %rsi
	movl	$3, %edi
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L1544
	.p2align 4,,10
	.p2align 3
.L1667:
	movq	%r12, %rdx
	leaq	.LC133(%rip), %rsi
	xorl	%edi, %edi
	call	bad_arg
.L1544:
	movl	$-1, %ebx
.L1542:
	addq	$152, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movl	%ebx, %eax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1666:
	.cfi_restore_state
	leaq	.LC66(%rip), %rdi
	xorl	%eax, %eax
	call	err
	jmp	.L1544
	.p2align 4,,10
	.p2align 3
.L1546:
	movq	%r13, %rdx
	leaq	.LC154(%rip), %rsi
	movl	$1, %edi
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L1544
	.p2align 4,,10
	.p2align 3
.L1668:
	movl	i.2(%rip), %ebx
	movzbl	%ah, %ecx
	subq	$8, %rsp
	.cfi_def_cfa_offset 216
	movl	%eax, %r8d
	movl	%ecx, %r9d
	movl	%eax, %ecx
	movzbl	%al, %eax
	shrl	$16, %r8d
	leal	1(%rbx), %edx
	andl	$3, %ebx
	pushq	%rax
	.cfi_def_cfa_offset 224
	shrl	$24, %ecx
	movl	%edx, i.2(%rip)
	salq	$4, %rbx
	movzbl	%r8b, %r8d
	xorl	%eax, %eax
	leaq	b.1(%rip), %rdx
	movl	$16, %esi
	addq	%rdx, %rbx
	leaq	.LC58(%rip), %rdx
	movq	%rbx, %rdi
	call	snprintf@PLT
	movq	%rbx, %rdx
	xorl	%edi, %edi
	xorl	%eax, %eax
	leaq	.LC155(%rip), %rsi
	call	bad_arg
	popq	%rbx
	.cfi_def_cfa_offset 216
	popq	%rbp
	.cfi_def_cfa_offset 208
	jmp	.L1544
	.p2align 4,,10
	.p2align 3
.L1550:
	leaq	.LC156(%rip), %rsi
	movl	$2, %edi
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L1544
	.p2align 4,,10
	.p2align 3
.L1549:
	leaq	32(%rsp), %rax
	movl	$40, %edx
	movq	%r15, %rdi
	movq	%rax, %rsi
	movq	%rax, 8(%rsp)
	call	rc_canon_iface
	testl	%eax, %eax
	je	.L1556
	movzbl	32(%rsp), %r15d
	movl	$5, %eax
	testb	%r15b, %r15b
	je	.L1558
	call	__ctype_tolower_loc@PLT
	movq	8(%rsp), %rdx
	movq	(%rax), %rsi
	movl	$5381, %eax
	.p2align 5
	.p2align 4
	.p2align 3
.L1560:
	movl	%eax, %ecx
	addq	$1, %rdx
	sall	$5, %ecx
	addl	%ecx, %eax
	movzbl	(%rsi,%r15,4), %ecx
	movzbl	(%rdx), %r15d
	addl	%ecx, %eax
	testb	%r15b, %r15b
	jne	.L1560
	andl	$63, %eax
.L1558:
	leaq	cfg(%rip), %rdx
	movq	128(%rdx,%rax,8), %r15
	testq	%r15, %r15
	jne	.L1563
	jmp	.L1561
	.p2align 4,,10
	.p2align 3
.L1671:
	movq	168(%r15), %r15
	testq	%r15, %r15
	je	.L1561
.L1563:
	movq	8(%rsp), %rsi
	movq	%r15, %rdi
	call	strcmp@PLT
	testl	%eax, %eax
	jne	.L1671
	movq	8(%rsp), %rcx
	leaq	92(%rsp), %rdi
	leaq	.LC24(%rip), %rdx
	xorl	%eax, %eax
	movl	$40, %esi
	call	snprintf@PLT
	jmp	.L1555
.L1670:
	imulq	$10, %r12, %r12
	movsbl	%al, %eax
	subl	$48, %eax
	cltq
	addq	%rax, %r12
.L1566:
	leaq	-1(%r12), %rax
	cmpq	$254, %rax
	ja	.L1565
	.p2align 4
	.p2align 3
.L1564:
	movd	%r14d, %xmm1
	movd	%r13d, %xmm0
	leaq	80(%rsp), %rdi
	movl	%r12d, 136(%rsp)
	punpckldq	%xmm1, %xmm0
	leaq	32(%rsp), %rsi
	movq	%xmm0, 80(%rsp)
	call	route_find
	movslq	32(%rsp), %rbp
	movq	664+cfg(%rip), %rdi
	movl	%eax, %ebx
	testl	%eax, %eax
	je	.L1567
	movq	%rbp, %rax
	salq	$4, %rax
	subq	%rbp, %rax
	leaq	(%rdi,%rax,4), %rax
	cmpl	%r12d, 56(%rax)
	je	.L1542
	movl	%r12d, 56(%rax)
.L1569:
	xorl	%ebx, %ebx
	jmp	.L1542
	.p2align 4,,10
	.p2align 3
.L1669:
	movq	%r15, %rdx
	leaq	.LC157(%rip), %rsi
	movl	$2, %edi
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L1544
	.p2align 4,,10
	.p2align 3
.L1556:
	leaq	.LC158(%rip), %rsi
	movl	$2, %edi
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L1544
	.p2align 4,,10
	.p2align 3
.L1567:
	movl	672+cfg(%rip), %eax
	movl	676+cfg(%rip), %edx
	cmpl	%edx, %eax
	jl	.L1570
	testl	%edx, %edx
	je	.L1579
	addl	%edx, %edx
	movslq	%edx, %rax
	movq	%rax, %rsi
	salq	$4, %rsi
	subq	%rax, %rsi
	salq	$2, %rsi
.L1571:
	movl	%edx, 676+cfg(%rip)
	call	realloc@PLT
	movq	%rax, %rdi
	testq	%rax, %rax
	je	.L1672
	movq	%rax, 664+cfg(%rip)
	movl	672+cfg(%rip), %eax
.L1570:
	movslq	%ebp, %rdx
	subl	%ebp, %eax
	movq	%rdx, %rcx
	cltq
	salq	$4, %rcx
	subq	%rdx, %rcx
	movq	%rax, %rdx
	salq	$4, %rdx
	leaq	0(,%rcx,4), %r15
	subq	%rax, %rdx
	leaq	(%rdi,%r15), %rsi
	leaq	60(%rdi,%r15), %rdi
	salq	$2, %rdx
	call	memmove@PLT
	movdqa	80(%rsp), %xmm0
	movq	664+cfg(%rip), %rax
	movups	%xmm0, (%rax,%r15)
	movdqa	96(%rsp), %xmm0
	movups	%xmm0, 16(%rax,%r15)
	movdqa	112(%rsp), %xmm0
	movups	%xmm0, 32(%rax,%r15)
	movdqu	124(%rsp), %xmm0
	movups	%xmm0, 44(%rax,%r15)
	addl	$1, 672+cfg(%rip)
	testl	%r14d, %r14d
	je	.L1573
	.p2align 4
	.p2align 4
	.p2align 3
.L1574:
	movl	%r14d, %eax
	andl	$1, %eax
	addl	%eax, %ebx
	shrl	%r14d
	jne	.L1574
.L1573:
	movl	i.2(%rip), %ebp
	subq	$8, %rsp
	.cfi_def_cfa_offset 216
	movl	%r13d, %r8d
	movl	%r13d, %ecx
	shrl	$16, %r8d
	shrl	$24, %ecx
	movl	$16, %esi
	leaq	.LC58(%rip), %rdx
	leal	1(%rbp), %eax
	andl	$3, %ebp
	movzbl	%r8b, %r8d
	movl	%eax, i.2(%rip)
	salq	$4, %rbp
	leaq	b.1(%rip), %rax
	addq	%rax, %rbp
	movl	%r13d, %eax
	movzbl	%r13b, %r13d
	pushq	%r13
	.cfi_def_cfa_offset 224
	movzbl	%ah, %eax
	movq	%rbp, %rdi
	movl	%eax, %r9d
	xorl	%eax, %eax
	call	snprintf@PLT
	movl	%r12d, %r9d
	movl	%ebx, %r8d
	movq	%rbp, %rcx
	leaq	.LC161(%rip), %rdx
	leaq	.LC2(%rip), %rsi
	movl	$1, %edi
	xorl	%eax, %eax
	call	rlog_log@PLT
	movl	loading(%rip), %r10d
	popq	%r8
	.cfi_def_cfa_offset 216
	popq	%r9
	.cfi_def_cfa_offset 208
	testl	%r10d, %r10d
	jne	.L1569
	movl	132(%rsp), %edi
	testl	%edi, %edi
	je	.L1569
	movq	640+cfg(%rip), %rax
	movl	88(%rsp), %edi
	testq	%rax, %rax
	je	.L1576
	xorl	%edx, %edx
	.p2align 4
	.p2align 3
.L1578:
	movl	148(%rax), %esi
	testl	%esi, %esi
	je	.L1577
	movl	152(%rax), %ecx
	testl	%ecx, %ecx
	jne	.L1577
	movl	140(%rax), %esi
	movl	144(%rax), %ecx
	xorl	%edi, %esi
	testl	%ecx, %esi
	jne	.L1577
	testq	%rdx, %rdx
	je	.L1580
	cmpl	%ecx, 144(%rdx)
	cmovb	%rax, %rdx
	.p2align 4
	.p2align 3
.L1577:
	movq	176(%rax), %rax
	testq	%rax, %rax
	jne	.L1578
	testq	%rdx, %rdx
	jne	.L1569
.L1576:
	call	rc_ipstr
	leaq	.LC162(%rip), %rdi
	xorl	%ebx, %ebx
	movq	%rax, %rsi
	xorl	%eax, %eax
	call	printf@PLT
	jmp	.L1542
	.p2align 4,,10
	.p2align 3
.L1561:
	movq	8(%rsp), %rdx
	leaq	.LC159(%rip), %rsi
	movl	$2, %edi
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L1544
.L1579:
	movl	$480, %esi
	movl	$8, %edx
	jmp	.L1571
.L1580:
	movq	%rax, %rdx
	jmp	.L1577
.L1672:
	call	xrealloc.part.0
	.cfi_endproc
.LFE68:
	.size	h_ip_route, .-h_ip_route
	.section	.rodata.str1.8
	.align 8
.LC163:
	.string	"Invalid interface. Examples: g0/0, fa0/1, s0/0/0, loopback0."
	.section	.rodata.str1.1
.LC164:
	.string	"created interface %s"
	.text
	.p2align 4
	.type	h_interface, @function
h_interface:
.LFB57:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$136, %rsp
	.cfi_def_cfa_offset 176
	movq	(%rsi), %rcx
	leaq	48(%rsp), %rbp
	cmpl	$2, %edi
	je	.L1702
	leaq	.LC24(%rip), %rdx
	movl	$80, %esi
	movq	%rbp, %rdi
	xorl	%eax, %eax
	call	snprintf@PLT
.L1675:
	movl	$40, %edx
	movq	%rsp, %rsi
	movq	%rbp, %rdi
	movq	%rsp, %rbx
	call	rc_canon_iface
	testl	%eax, %eax
	je	.L1676
	movzbl	(%rsp), %ebp
	movl	$5, %eax
	testb	%bpl, %bpl
	je	.L1678
	call	__ctype_tolower_loc@PLT
	movzbl	%bpl, %edx
	movq	%rsp, %rcx
	movq	(%rax), %rdi
	movl	$5381, %eax
	.p2align 5
	.p2align 4
	.p2align 3
.L1680:
	movl	%eax, %esi
	movzbl	(%rdi,%rdx,4), %edx
	addq	$1, %rcx
	sall	$5, %esi
	addl	%esi, %eax
	addl	%edx, %eax
	movzbl	(%rcx), %edx
	testb	%dl, %dl
	jne	.L1680
	andl	$63, %eax
.L1678:
	leaq	cfg(%rip), %r13
	movq	128(%r13,%rax,8), %r12
	testq	%r12, %r12
	jne	.L1683
	jmp	.L1681
	.p2align 4,,10
	.p2align 3
.L1703:
	movq	168(%r12), %r12
	testq	%r12, %r12
	je	.L1681
.L1683:
	movq	%rbx, %rsi
	movq	%r12, %rdi
	call	strcmp@PLT
	testl	%eax, %eax
	jne	.L1703
.L1682:
	movq	%r12, cur_if(%rip)
	xorl	%eax, %eax
	movl	$3, mode(%rip)
.L1673:
	addq	$136, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1702:
	.cfi_restore_state
	movq	8(%rsi), %r8
	leaq	.LC143(%rip), %rdx
	movq	%rbp, %rdi
	xorl	%eax, %eax
	movl	$80, %esi
	call	snprintf@PLT
	jmp	.L1675
	.p2align 4,,10
	.p2align 3
.L1681:
	movl	$1, %esi
	movl	$184, %edi
	call	calloc@PLT
	movq	%rax, %r12
	testq	%rax, %rax
	je	.L1684
	testb	%bpl, %bpl
	je	.L1704
	call	__ctype_tolower_loc@PLT
	movq	%rbx, %rdx
	movq	(%rax), %rsi
	movl	$5381, %eax
	.p2align 5
	.p2align 4
	.p2align 3
.L1687:
	movl	%eax, %ecx
	addq	$1, %rdx
	sall	$5, %ecx
	addl	%ecx, %eax
	movzbl	(%rsi,%rbp,4), %ecx
	movzbl	(%rdx), %ebp
	addl	%ecx, %eax
	testb	%bpl, %bpl
	jne	.L1687
	andl	$63, %eax
	movl	%eax, %ebp
.L1686:
	leaq	.LC24(%rip), %rdx
	xorl	%eax, %eax
	movq	%rbx, %rcx
	movq	%r12, %rdi
	movl	$40, %esi
	call	snprintf@PLT
	movabsq	$7738135660173684556, %rax
	cmpq	%rax, (%rsp)
	setne	%al
	movzbl	%al, %eax
	movl	%eax, 152(%r12)
	movl	%ebp, %eax
	addq	$16, %rax
	movq	0(%r13,%rax,8), %rdx
	movq	%r12, 0(%r13,%rax,8)
	movq	648+cfg(%rip), %rax
	movq	%rdx, 168(%r12)
	testq	%rax, %rax
	je	.L1690
	movq	%r12, 176(%rax)
.L1691:
	movq	%rbx, %rcx
	leaq	.LC164(%rip), %rdx
	xorl	%edi, %edi
	xorl	%eax, %eax
	leaq	.LC2(%rip), %rsi
	addl	$1, 656+cfg(%rip)
	movq	%r12, 648+cfg(%rip)
	call	rlog_log@PLT
	jmp	.L1682
.L1690:
	movq	%r12, 640+cfg(%rip)
	jmp	.L1691
.L1704:
	movl	$5, %ebp
	jmp	.L1686
.L1676:
	leaq	.LC163(%rip), %rsi
	xorl	%edi, %edi
	xorl	%eax, %eax
	call	bad_arg
	movl	$-1, %eax
	jmp	.L1673
.L1684:
	movq	stderr(%rip), %rcx
	movl	$14, %edx
	movl	$1, %esi
	leaq	.LC19(%rip), %rdi
	call	fwrite@PLT
	movl	$1, %edi
	call	exit@PLT
	.cfi_endproc
.LFE57:
	.size	h_interface, .-h_interface
	.section	.rodata.str1.1
.LC165:
	.string	"Invalid interface name."
	.section	.rodata.str1.8
	.align 8
.LC166:
	.string	"Cannot delete physical interface %s (only loopbacks can be removed)."
	.section	.rodata.str1.1
.LC167:
	.string	"Interface %s does not exist."
.LC168:
	.string	"deleted interface %s"
	.text
	.p2align 4
	.type	h_no_interface, @function
h_no_interface:
.LFB58:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$152, %rsp
	.cfi_def_cfa_offset 208
	movq	(%rsi), %rcx
	leaq	64(%rsp), %rbx
	cmpl	$2, %edi
	je	.L1770
	leaq	.LC24(%rip), %rdx
	movl	$80, %esi
	movq	%rbx, %rdi
	xorl	%eax, %eax
	call	snprintf@PLT
.L1707:
	leaq	16(%rsp), %r12
	movl	$40, %edx
	movq	%rbx, %rdi
	movq	%r12, %rsi
	call	rc_canon_iface
	testl	%eax, %eax
	je	.L1771
	movabsq	$7738135660173684556, %rax
	cmpq	%rax, 16(%rsp)
	je	.L1772
	movq	%r12, %rsi
	leaq	.LC166(%rip), %rdi
	xorl	%eax, %eax
	call	err
.L1709:
	movl	$-1, %r13d
.L1705:
	addq	$152, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movl	%r13d, %eax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1770:
	.cfi_restore_state
	movq	8(%rsi), %r8
	leaq	.LC143(%rip), %rdx
	movq	%rbx, %rdi
	xorl	%eax, %eax
	movl	$80, %esi
	call	snprintf@PLT
	jmp	.L1707
	.p2align 4,,10
	.p2align 3
.L1772:
	movzbl	16(%rsp), %ebx
	testb	%bl, %bl
	je	.L1773
	call	__ctype_tolower_loc@PLT
	movq	%r12, %rdx
	movq	(%rax), %rsi
	movl	$5381, %eax
	.p2align 5
	.p2align 4
	.p2align 3
.L1715:
	movl	%eax, %ecx
	addq	$1, %rdx
	sall	$5, %ecx
	addl	%ecx, %eax
	movzbl	(%rsi,%rbx,4), %ecx
	movzbl	(%rdx), %ebx
	addl	%ecx, %eax
	testb	%bl, %bl
	jne	.L1715
	andl	$63, %eax
.L1714:
	leaq	cfg(%rip), %rdi
	movq	128(%rdi,%rax,8), %rbx
	testq	%rbx, %rbx
	jne	.L1718
	jmp	.L1716
	.p2align 4,,10
	.p2align 3
.L1774:
	movq	168(%rbx), %rbx
	testq	%rbx, %rbx
	je	.L1716
.L1718:
	movq	%r12, %rsi
	movq	%rbx, %rdi
	call	strcmp@PLT
	movl	%eax, %r13d
	testl	%eax, %eax
	jne	.L1774
	movl	672+cfg(%rip), %r15d
	movl	%r15d, %ebp
	subl	$1, %ebp
	js	.L1723
	movslq	%ebp, %rax
	movq	%rax, %r14
	salq	$4, %r14
	subq	%rax, %r14
	salq	$2, %r14
	jmp	.L1722
	.p2align 6
	.p2align 4,,10
	.p2align 3
.L1721:
	subl	$1, %ebp
	subq	$60, %r14
	cmpl	$-1, %ebp
	je	.L1723
.L1722:
	movq	664+cfg(%rip), %r9
	leaq	(%r9,%r14), %r8
	movq	%r9, (%rsp)
	movl	52(%r8), %eax
	testl	%eax, %eax
	jne	.L1721
	leaq	12(%r8), %rdi
	movq	%r12, %rsi
	movq	%r8, 8(%rsp)
	call	strcmp@PLT
	movq	8(%rsp), %r8
	movq	(%rsp), %r9
	testl	%eax, %eax
	jne	.L1721
	subl	%ebp, %r15d
	leaq	60(%r9,%r14), %rsi
	movq	%r8, %rdi
	subl	$1, %ebp
	subl	$1, %r15d
	subq	$60, %r14
	movslq	%r15d, %r15
	movq	%r15, %rdx
	salq	$4, %rdx
	subq	%r15, %rdx
	salq	$2, %rdx
	call	memmove@PLT
	movl	672+cfg(%rip), %r15d
	subl	$1, %r15d
	movl	%r15d, 672+cfg(%rip)
	cmpl	$-1, %ebp
	jne	.L1722
	.p2align 4
	.p2align 3
.L1723:
	cmpq	%rbx, cur_if(%rip)
	je	.L1775
	movzbl	(%rbx), %r12d
	testb	%r12b, %r12b
	je	.L1742
.L1777:
	call	__ctype_tolower_loc@PLT
	movq	%rbx, %rdx
	movq	(%rax), %rsi
	movl	$5381, %eax
	.p2align 5
	.p2align 4
	.p2align 3
.L1725:
	movl	%eax, %ecx
	addq	$1, %rdx
	sall	$5, %ecx
	addl	%ecx, %eax
	movzbl	(%rsi,%r12,4), %ecx
	movzbl	(%rdx), %r12d
	addl	%ecx, %eax
	testb	%r12b, %r12b
	jne	.L1725
	andl	$63, %eax
	leal	16(%rax), %edx
	salq	$3, %rdx
.L1724:
	leaq	cfg(%rip), %rdi
	addq	%rdi, %rdx
	cmpq	$0, 128(%rdi,%rax,8)
	je	.L1726
	movq	(%rdx), %rax
	jmp	.L1727
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L1728:
	leaq	168(%rax), %rdx
	movq	168(%rax), %rax
	testq	%rax, %rax
	je	.L1726
.L1727:
	cmpq	%rax, %rbx
	jne	.L1728
	movq	168(%rbx), %rax
	movq	%rax, (%rdx)
.L1726:
	movq	640+cfg(%rip), %rax
	cmpq	%rbx, %rax
	je	.L1730
	testq	%rax, %rax
	je	.L1735
	.p2align 5
	.p2align 4
	.p2align 3
.L1731:
	movq	%rax, %rdx
	movq	176(%rax), %rax
	testq	%rax, %rax
	je	.L1735
	cmpq	%rbx, %rax
	jne	.L1731
	testq	%rax, %rax
	je	.L1735
	movq	176(%rbx), %rax
	movq	%rax, 176(%rdx)
.L1737:
	cmpq	%rbx, 648+cfg(%rip)
	je	.L1776
.L1735:
	xorl	%edi, %edi
	xorl	%eax, %eax
	movq	%rbx, %rcx
	subl	$1, 656+cfg(%rip)
	leaq	.LC168(%rip), %rdx
	leaq	.LC2(%rip), %rsi
	call	rlog_log@PLT
	movq	%rbx, %rdi
	call	free@PLT
	cmpl	$3, mode(%rip)
	jne	.L1705
	movl	$2, mode(%rip)
	jmp	.L1705
	.p2align 4,,10
	.p2align 3
.L1775:
	movq	$0, cur_if(%rip)
	movzbl	(%rbx), %r12d
	testb	%r12b, %r12b
	jne	.L1777
.L1742:
	movl	$168, %edx
	movl	$5, %eax
	jmp	.L1724
	.p2align 4,,10
	.p2align 3
.L1776:
	movq	%rdx, 648+cfg(%rip)
	jmp	.L1735
.L1773:
	movl	$5, %eax
	jmp	.L1714
.L1730:
	testq	%rax, %rax
	je	.L1735
	movq	176(%rbx), %rax
	xorl	%edx, %edx
	movq	%rax, 640+cfg(%rip)
	jmp	.L1737
.L1771:
	leaq	.LC165(%rip), %rsi
	xorl	%edi, %edi
	call	bad_arg
	jmp	.L1709
	.p2align 4,,10
	.p2align 3
.L1716:
	movq	%r12, %rsi
	leaq	.LC167(%rip), %rdi
	xorl	%eax, %eax
	call	err
	jmp	.L1709
	.cfi_endproc
.LFE58:
	.size	h_no_interface, .-h_no_interface
	.section	.rodata.str1.8
	.align 8
.LC169:
	.string	"Interface %s is not configured."
	.text
	.p2align 4
	.type	h_show_if, @function
h_show_if:
.LFB87:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$152, %rsp
	.cfi_def_cfa_offset 176
	testl	%edi, %edi
	jne	.L1804
	movq	640+cfg(%rip), %rbx
	testq	%rbx, %rbx
	je	.L1793
	.p2align 4
	.p2align 3
.L1791:
	movq	%rbx, %rdi
	call	print_if_detail
	movq	176(%rbx), %rbx
	testq	%rbx, %rbx
	jne	.L1791
.L1793:
	movl	656+cfg(%rip), %eax
	testl	%eax, %eax
	je	.L1792
.L1794:
	addq	$152, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1792:
	.cfi_restore_state
	leaq	.LC63(%rip), %rdi
	call	puts@PLT
	jmp	.L1794
	.p2align 4,,10
	.p2align 3
.L1804:
	movq	(%rsi), %rcx
	leaq	64(%rsp), %rbx
	cmpl	$2, %edi
	je	.L1805
	leaq	.LC24(%rip), %rdx
	movl	$80, %esi
	movq	%rbx, %rdi
	xorl	%eax, %eax
	call	snprintf@PLT
.L1781:
	leaq	16(%rsp), %rbp
	movl	$40, %edx
	movq	%rbx, %rdi
	movq	%rbp, %rsi
	call	rc_canon_iface
	testl	%eax, %eax
	je	.L1782
	movzbl	16(%rsp), %ebx
	movl	$5, %eax
	testb	%bl, %bl
	je	.L1784
	call	__ctype_tolower_loc@PLT
	movq	%rbp, %rdx
	movq	(%rax), %rsi
	movl	$5381, %eax
	.p2align 5
	.p2align 4
	.p2align 3
.L1786:
	movl	%eax, %ecx
	addq	$1, %rdx
	sall	$5, %ecx
	addl	%ecx, %eax
	movzbl	(%rsi,%rbx,4), %ecx
	movzbl	(%rdx), %ebx
	addl	%ecx, %eax
	testb	%bl, %bl
	jne	.L1786
	andl	$63, %eax
.L1784:
	leaq	cfg(%rip), %rdx
	movq	128(%rdx,%rax,8), %rbx
	testq	%rbx, %rbx
	jne	.L1789
	jmp	.L1787
	.p2align 4,,10
	.p2align 3
.L1806:
	movq	168(%rbx), %rbx
	testq	%rbx, %rbx
	je	.L1787
.L1789:
	movq	%rbp, %rsi
	movq	%rbx, %rdi
	call	strcmp@PLT
	testl	%eax, %eax
	jne	.L1806
	movq	%rbx, %rdi
	movl	%eax, 12(%rsp)
	call	print_if_detail
	movl	12(%rsp), %eax
	addq	$152, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1782:
	.cfi_restore_state
	leaq	.LC165(%rip), %rsi
	xorl	%edi, %edi
	xorl	%eax, %eax
	call	bad_arg
.L1785:
	addq	$152, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	movl	$-1, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1805:
	.cfi_restore_state
	movq	8(%rsi), %r8
	leaq	.LC143(%rip), %rdx
	movq	%rbx, %rdi
	xorl	%eax, %eax
	movl	$80, %esi
	call	snprintf@PLT
	jmp	.L1781
	.p2align 4,,10
	.p2align 3
.L1787:
	movq	%rbp, %rsi
	leaq	.LC169(%rip), %rdi
	xorl	%eax, %eax
	call	err
	jmp	.L1785
	.cfi_endproc
.LFE87:
	.size	h_show_if, .-h_show_if
	.p2align 4
	.globl	rc_join_iface
	.type	rc_join_iface, @function
rc_join_iface:
.LFB37:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	movq	%rcx, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movq	%rdx, %rbx
	subq	$80, %rsp
	.cfi_def_cfa_offset 112
	movq	(%rsi), %rcx
	movq	%rsp, %r12
	cmpl	$2, %edi
	je	.L1811
	leaq	.LC24(%rip), %rdx
	movl	$80, %esi
	movq	%rsp, %rdi
	xorl	%eax, %eax
	call	snprintf@PLT
.L1809:
	movq	%rbp, %rdx
	movq	%rbx, %rsi
	movq	%r12, %rdi
	call	rc_canon_iface
	addq	$80, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1811:
	.cfi_restore_state
	movq	8(%rsi), %r8
	leaq	.LC143(%rip), %rdx
	movq	%rsp, %rdi
	xorl	%eax, %eax
	movl	$80, %esi
	call	snprintf@PLT
	jmp	.L1809
	.cfi_endproc
.LFE37:
	.size	rc_join_iface, .-rc_join_iface
	.section	.rodata.str1.1
.LC170:
	.string	"reset to default"
	.text
	.p2align 4
	.globl	rc_reset_config
	.type	rc_reset_config, @function
rc_reset_config:
.LFB42:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movq	640+cfg(%rip), %rbx
	testq	%rbx, %rbx
	je	.L1813
	.p2align 4
	.p2align 3
.L1814:
	movq	%rbx, %rdi
	movq	176(%rbx), %rbx
	call	free@PLT
	testq	%rbx, %rbx
	jne	.L1814
.L1813:
	movq	664+cfg(%rip), %rdi
	leaq	cfg(%rip), %rbx
	call	free@PLT
	movq	696+cfg(%rip), %rdi
	call	free@PLT
	movq	728+cfg(%rip), %rdi
	call	free@PLT
	xorl	%eax, %eax
	movq	%rbx, %rdi
	movl	$93, %ecx
	rep stosq
	movl	$1, %edi
	leaq	.LC33(%rip), %rax
	leaq	.LC170(%rip), %rdx
	movq	%rax, load_name(%rip)
	xorl	%eax, %eax
	leaq	.LC2(%rip), %rsi
	movl	$1953853266, cfg(%rip)
	popq	%rbx
	.cfi_def_cfa_offset 8
	movl	$7497076, 3+cfg(%rip)
	movl	$0, mode(%rip)
	movq	$0, cur_if(%rip)
	movl	$0, quit_flag(%rip)
	movl	$0, loading(%rip)
	movl	$0, load_line(%rip)
	jmp	rlog_log@PLT
	.cfi_endproc
.LFE42:
	.size	rc_reset_config, .-rc_reset_config
	.section	.rodata.str1.8
	.align 8
.LC171:
	.string	"--- Validating configuration of %s ---\n"
	.align 8
.LC172:
	.string	"  [warn ] hostname is still the default 'Router'."
	.align 8
.LC173:
	.string	"  [warn ] %s is up but has no IP address.\n"
	.align 8
.LC174:
	.string	"  [warn ] %s has an IP address but is administratively down.\n"
	.align 8
.LC175:
	.string	"  [warn ] %s has a clock rate but is down.\n"
	.align 8
.LC176:
	.string	"  [warn ] static route %s/%d via %s is NOT installed (next hop unreachable).\n"
	.align 8
.LC177:
	.string	"  [warn ] static route %s/%d via %s is NOT installed (interface down).\n"
	.align 8
.LC178:
	.string	"  [warn ] RIP is enabled but has no network statements."
	.align 8
.LC179:
	.string	"  [warn ] RIP network %s matches no interface.\n"
	.align 8
.LC180:
	.string	"  [warn ] OSPF is enabled but has no network statements."
	.align 8
.LC181:
	.string	"  [error] OSPF has no router-id and no up interface with an IP to derive one from."
	.align 8
.LC182:
	.string	"  [warn ] OSPF network %s %s matches no interface.\n"
	.align 8
.LC183:
	.string	"  [error] %s and %s share IP %s.\n"
	.align 8
.LC184:
	.string	"--- Result: %d error(s), %d warning(s) ---\n"
	.text
	.p2align 4
	.globl	rc_validate
	.type	rc_validate, @function
rc_validate:
.LFB92:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	xorl	%eax, %eax
	leaq	cfg(%rip), %rsi
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movq	%rdi, 8(%rsp)
	leaq	.LC171(%rip), %rdi
	call	printf@PLT
	cmpl	$1953853266, cfg(%rip)
	je	.L1958
.L1821:
	movl	$0, 4(%rsp)
.L1823:
	movq	640+cfg(%rip), %r14
	testq	%r14, %r14
	je	.L1824
	movl	4(%rsp), %r13d
	leaq	.LC175(%rip), %r12
	leaq	.LC174(%rip), %rbp
	leaq	.LC124(%rip), %rbx
	jmp	.L1829
	.p2align 4,,10
	.p2align 3
.L1961:
	movl	$8, %edx
	movq	%rbx, %rsi
	movq	%r14, %rdi
	call	strncmp@PLT
	movl	148(%r14), %edx
	testl	%edx, %edx
	jne	.L1828
	testl	%eax, %eax
	jne	.L1959
.L1828:
	movq	176(%r14), %r14
	testq	%r14, %r14
	je	.L1960
.L1829:
	movl	152(%r14), %ecx
	testl	%ecx, %ecx
	je	.L1961
.L1825:
	movl	148(%r14), %eax
	testl	%eax, %eax
	jne	.L1962
	cmpq	$0, 160(%r14)
	je	.L1828
.L1882:
	movq	%r14, %rsi
	movq	%r12, %rdi
	xorl	%eax, %eax
	addl	$1, %r13d
	call	printf@PLT
	movq	176(%r14), %r14
	testq	%r14, %r14
	jne	.L1829
	.p2align 4
	.p2align 3
.L1960:
	movl	%r13d, 4(%rsp)
.L1824:
	movl	672+cfg(%rip), %eax
	movl	%eax, (%rsp)
	testl	%eax, %eax
	jle	.L1830
	xorl	%r12d, %r12d
	xorl	%ebp, %ebp
	.p2align 4
	.p2align 3
.L1846:
	movq	664+cfg(%rip), %r14
	addq	%r12, %r14
	movl	52(%r14), %r15d
	testl	%r15d, %r15d
	jne	.L1963
	movzbl	12(%r14), %r13d
	leaq	12(%r14), %rbx
	testb	%r13b, %r13b
	je	.L1887
	call	__ctype_tolower_loc@PLT
	movq	%rbx, %rsi
	movq	(%rax), %rdi
	movl	$5381, %eax
	.p2align 5
	.p2align 4
	.p2align 3
.L1837:
	movl	%eax, %edx
	addq	$1, %rsi
	sall	$5, %edx
	addl	%edx, %eax
	movzbl	(%rdi,%r13,4), %edx
	movzbl	(%rsi), %r13d
	addl	%edx, %eax
	testb	%r13b, %r13b
	jne	.L1837
	andl	$63, %eax
.L1836:
	leaq	cfg(%rip), %rdi
	movq	128(%rdi,%rax,8), %r13
	testq	%r13, %r13
	jne	.L1840
	jmp	.L1838
	.p2align 4,,10
	.p2align 3
.L1964:
	movq	168(%r13), %r13
	testq	%r13, %r13
	je	.L1838
.L1840:
	movq	%rbx, %rsi
	movq	%r13, %rdi
	call	strcmp@PLT
	testl	%eax, %eax
	jne	.L1964
	movl	152(%r13), %eax
	testl	%eax, %eax
	je	.L1835
.L1838:
	movl	4(%r14), %eax
	testl	%eax, %eax
	je	.L1844
	.p2align 4
	.p2align 4
	.p2align 3
.L1845:
	movl	%eax, %edx
	andl	$1, %edx
	addl	%edx, %r15d
	shrl	%eax
	jne	.L1845
.L1844:
	movl	(%r14), %eax
	subq	$8, %rsp
	.cfi_def_cfa_offset 88
	movl	i.2(%rip), %r13d
	leaq	b.1(%rip), %rdi
	movl	$16, %esi
	movzbl	%ah, %ecx
	leal	1(%r13), %edx
	movl	%eax, %r8d
	andl	$3, %r13d
	movl	%ecx, %r9d
	movl	%eax, %ecx
	movzbl	%al, %eax
	salq	$4, %r13
	pushq	%rax
	.cfi_def_cfa_offset 96
	addq	%rdi, %r13
	shrl	$16, %r8d
	xorl	%eax, %eax
	movl	%edx, i.2(%rip)
	shrl	$24, %ecx
	movzbl	%r8b, %r8d
	movq	%r13, %rdi
	leaq	.LC58(%rip), %rdx
	call	snprintf@PLT
	movq	%r13, %rsi
	movq	%rbx, %rcx
	movl	%r15d, %edx
	leaq	.LC177(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
	popq	%rsi
	.cfi_def_cfa_offset 88
	popq	%rdi
	.cfi_def_cfa_offset 80
.L1843:
	movl	672+cfg(%rip), %eax
	addl	$1, 4(%rsp)
	movl	%eax, (%rsp)
.L1835:
	movl	(%rsp), %eax
	addl	$1, %ebp
	addq	$60, %r12
	cmpl	%eax, %ebp
	jl	.L1846
.L1830:
	movl	680+cfg(%rip), %ecx
	testl	%ecx, %ecx
	je	.L1847
	movl	704+cfg(%rip), %r9d
	testl	%r9d, %r9d
	je	.L1965
.L1848:
	movl	4(%rsp), %r13d
	xorl	%r14d, %r14d
	leaq	b.1(%rip), %r12
	leaq	.LC58(%rip), %rbp
	leaq	.LC179(%rip), %rbx
	testl	%r9d, %r9d
	jle	.L1847
	.p2align 4
	.p2align 3
.L1856:
	movq	696+cfg(%rip), %rdx
	movq	640+cfg(%rip), %rax
	leaq	(%rdx,%r14,4), %r8
	testq	%rax, %rax
	je	.L1849
	xorl	%edi, %edi
	jmp	.L1854
	.p2align 4,,10
	.p2align 3
.L1851:
	leal	-128(%rcx), %esi
	cmpl	$63, %esi
	jbe	.L1966
	subl	$192, %ecx
	xorb	%dl, %dl
	cmpl	$31, %ecx
	jbe	.L1853
.L1850:
	movq	176(%rax), %rax
	testq	%rax, %rax
	je	.L1967
.L1854:
	movl	148(%rax), %edx
	testl	%edx, %edx
	je	.L1850
	movl	140(%rax), %edx
	movl	%edx, %ecx
	shrl	$24, %ecx
	leal	-1(%rcx), %esi
	cmpl	$125, %esi
	ja	.L1851
	andl	$-16777216, %edx
.L1853:
	cmpl	%edx, (%r8)
	movq	176(%rax), %rax
	sete	%dl
	movzbl	%dl, %edx
	orl	%edx, %edi
	testq	%rax, %rax
	jne	.L1854
.L1967:
	testl	%edi, %edi
	je	.L1849
.L1855:
	addq	$1, %r14
	cmpl	%r14d, %r9d
	jg	.L1856
	movl	%r13d, 4(%rsp)
.L1847:
	movl	712+cfg(%rip), %ebp
	testl	%ebp, %ebp
	je	.L1857
	movl	736+cfg(%rip), %r14d
	testl	%r14d, %r14d
	je	.L1968
	movq	640+cfg(%rip), %rbx
	testq	%rbx, %rbx
	je	.L1859
.L1970:
	movq	%rbx, %rax
	xorl	%edx, %edx
	.p2align 6
	.p2align 4
	.p2align 3
.L1861:
	movl	148(%rax), %r13d
	testl	%r13d, %r13d
	je	.L1860
	movl	152(%rax), %r12d
	xorl	%ecx, %ecx
	testl	%r12d, %r12d
	sete	%cl
	orl	%ecx, %edx
.L1860:
	movq	176(%rax), %rax
	testq	%rax, %rax
	jne	.L1861
	orl	720+cfg(%rip), %edx
	je	.L1863
	movl	736+cfg(%rip), %edi
	xorl	%ebp, %ebp
	testl	%edi, %edi
	jle	.L1883
.L1864:
	movl	%ebp, (%rsp)
	xorl	%r15d, %r15d
	movq	%rbx, %r8
	leaq	b.1(%rip), %r14
	leaq	.LC58(%rip), %r12
	leaq	.LC182(%rip), %r13
	movq	%r15, %rbx
.L1872:
	movq	728+cfg(%rip), %r9
	movq	%rbx, %rbp
	salq	$4, %rbp
	leaq	(%r9,%rbp), %rsi
	testq	%r8, %r8
	je	.L1868
.L1871:
	movq	%r8, %rax
	xorl	%ecx, %ecx
	.p2align 6
	.p2align 4
	.p2align 3
.L1870:
	movl	148(%rax), %r11d
	testl	%r11d, %r11d
	je	.L1869
	movl	4(%rsi), %edx
	notl	%edx
	andl	140(%rax), %edx
	cmpl	(%rsi), %edx
	sete	%dl
	movzbl	%dl, %edx
	orl	%edx, %ecx
.L1869:
	movq	176(%rax), %rax
	testq	%rax, %rax
	jne	.L1870
	testl	%ecx, %ecx
	je	.L1868
	addq	$1, %rbx
	cmpl	%ebx, %edi
	jle	.L1954
	movq	%rbx, %rbp
	salq	$4, %rbp
	leaq	(%r9,%rbp), %rsi
	jmp	.L1871
	.p2align 4,,10
	.p2align 3
.L1962:
	xorl	%eax, %eax
	movq	%r14, %rsi
	movq	%rbp, %rdi
	addl	$1, %r13d
	call	printf@PLT
	cmpq	$0, 160(%r14)
	je	.L1828
	movl	152(%r14), %r15d
	testl	%r15d, %r15d
	je	.L1828
	jmp	.L1882
	.p2align 4,,10
	.p2align 3
.L1966:
	xorw	%dx, %dx
	jmp	.L1853
	.p2align 4,,10
	.p2align 3
.L1963:
	movq	640+cfg(%rip), %rax
	movl	8(%r14), %edx
	testq	%rax, %rax
	je	.L1832
	xorl	%ecx, %ecx
	.p2align 4
	.p2align 3
.L1834:
	movl	148(%rax), %r13d
	testl	%r13d, %r13d
	je	.L1833
	movl	152(%rax), %ebx
	testl	%ebx, %ebx
	jne	.L1833
	movl	140(%rax), %edi
	movl	144(%rax), %esi
	xorl	%edx, %edi
	testl	%esi, %edi
	jne	.L1833
	testq	%rcx, %rcx
	je	.L1885
	cmpl	%esi, 144(%rcx)
	cmovb	%rax, %rcx
	.p2align 4
	.p2align 3
.L1833:
	movq	176(%rax), %rax
	testq	%rax, %rax
	jne	.L1834
	testq	%rcx, %rcx
	jne	.L1835
.L1832:
	movl	i.2(%rip), %ebx
	subq	$8, %rsp
	.cfi_def_cfa_offset 88
	movl	%edx, %r8d
	movl	%edx, %ecx
	shrl	$16, %r8d
	shrl	$24, %ecx
	movl	$16, %esi
	xorl	%r13d, %r13d
	leal	1(%rbx), %eax
	andl	$3, %ebx
	movzbl	%r8b, %r8d
	movl	%eax, i.2(%rip)
	salq	$4, %rbx
	leaq	b.1(%rip), %rax
	addq	%rax, %rbx
	movzbl	%dh, %eax
	movzbl	%dl, %edx
	pushq	%rdx
	.cfi_def_cfa_offset 96
	movl	%eax, %r9d
	leaq	.LC58(%rip), %rdx
	movq	%rbx, %rdi
	xorl	%eax, %eax
	call	snprintf@PLT
	movl	4(%r14), %eax
	popq	%r10
	.cfi_def_cfa_offset 88
	popq	%r11
	.cfi_def_cfa_offset 80
	testl	%eax, %eax
	je	.L1841
	.p2align 4
	.p2align 4
	.p2align 3
.L1842:
	movl	%eax, %edx
	andl	$1, %edx
	addl	%edx, %r13d
	shrl	%eax
	jne	.L1842
.L1841:
	movl	(%r14), %eax
	subq	$8, %rsp
	.cfi_def_cfa_offset 88
	movl	i.2(%rip), %r15d
	leaq	b.1(%rip), %rdi
	movl	$16, %esi
	movzbl	%ah, %ecx
	leal	1(%r15), %edx
	movl	%eax, %r8d
	andl	$3, %r15d
	movl	%ecx, %r9d
	movl	%eax, %ecx
	movzbl	%al, %eax
	salq	$4, %r15
	pushq	%rax
	.cfi_def_cfa_offset 96
	addq	%rdi, %r15
	shrl	$16, %r8d
	xorl	%eax, %eax
	movzbl	%r8b, %r8d
	movl	%edx, i.2(%rip)
	shrl	$24, %ecx
	movq	%r15, %rdi
	leaq	.LC58(%rip), %rdx
	call	snprintf@PLT
	movq	%rbx, %rcx
	movl	%r13d, %edx
	movq	%r15, %rsi
	leaq	.LC176(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
	popq	%r8
	.cfi_def_cfa_offset 88
	popq	%r9
	.cfi_def_cfa_offset 80
	jmp	.L1843
	.p2align 4,,10
	.p2align 3
.L1849:
	movl	(%r8), %eax
	subq	$8, %rsp
	.cfi_def_cfa_offset 88
	movl	$16, %esi
	addl	$1, %r13d
	movl	i.2(%rip), %r15d
	movzbl	%ah, %ecx
	movl	%eax, %r8d
	movl	%ecx, %r9d
	leal	1(%r15), %edx
	movl	%eax, %ecx
	andl	$3, %r15d
	salq	$4, %r15
	movzbl	%al, %eax
	movl	%edx, i.2(%rip)
	shrl	$24, %ecx
	pushq	%rax
	.cfi_def_cfa_offset 96
	addq	%r12, %r15
	shrl	$16, %r8d
	movq	%rbp, %rdx
	movq	%r15, %rdi
	movzbl	%r8b, %r8d
	xorl	%eax, %eax
	call	snprintf@PLT
	movq	%r15, %rsi
	movq	%rbx, %rdi
	xorl	%eax, %eax
	call	printf@PLT
	popq	%r15
	.cfi_def_cfa_offset 88
	movl	704+cfg(%rip), %r9d
	popq	%rax
	.cfi_def_cfa_offset 80
	jmp	.L1855
	.p2align 4,,10
	.p2align 3
.L1885:
	movq	%rax, %rcx
	jmp	.L1833
.L1959:
	movq	%r14, %rsi
	leaq	.LC173(%rip), %rdi
	xorl	%eax, %eax
	addl	$1, %r13d
	call	printf@PLT
	movl	152(%r14), %eax
	testl	%eax, %eax
	je	.L1828
	jmp	.L1825
	.p2align 4,,10
	.p2align 3
.L1887:
	movl	$5, %eax
	jmp	.L1836
.L1857:
	movq	640+cfg(%rip), %rbx
.L1867:
	testq	%rbx, %rbx
	je	.L1865
.L1883:
	leaq	b.1(%rip), %r15
	leaq	.LC58(%rip), %r14
	.p2align 4
	.p2align 3
.L1880:
	movq	176(%rbx), %r12
	testq	%r12, %r12
	je	.L1865
.L1879:
	movl	148(%rbx), %edi
	testl	%edi, %edi
	jne	.L1873
	movq	176(%r12), %rax
	testq	%rax, %rax
	je	.L1875
.L1874:
	movq	176(%rax), %rax
	testq	%rax, %rax
	jne	.L1874
.L1875:
	movq	176(%rbx), %rbx
	testq	%rbx, %rbx
	jne	.L1880
	.p2align 4
	.p2align 3
.L1865:
	movl	4(%rsp), %ebx
	movl	%ebp, %esi
	leaq	.LC184(%rip), %rdi
	xorl	%eax, %eax
	movl	%ebx, %edx
	call	printf@PLT
	movq	8(%rsp), %rax
	testq	%rax, %rax
	je	.L1820
	movl	%ebx, (%rax)
.L1820:
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movl	%ebp, %eax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1873:
	.cfi_restore_state
	movl	148(%r12), %esi
	testl	%esi, %esi
	je	.L1878
	movl	140(%rbx), %eax
	cmpl	140(%r12), %eax
	je	.L1969
.L1878:
	movq	176(%r12), %r12
	testq	%r12, %r12
	jne	.L1879
	movq	176(%rbx), %rbx
	testq	%rbx, %rbx
	jne	.L1880
	jmp	.L1865
	.p2align 4,,10
	.p2align 3
.L1969:
	movl	i.2(%rip), %r13d
	movzbl	%ah, %ecx
	movl	%eax, %r8d
	addl	$1, %ebp
	subq	$8, %rsp
	.cfi_def_cfa_offset 88
	movl	%ecx, %r9d
	movl	%eax, %ecx
	movzbl	%al, %eax
	leal	1(%r13), %edx
	andl	$3, %r13d
	pushq	%rax
	.cfi_def_cfa_offset 96
	shrl	$16, %r8d
	salq	$4, %r13
	movl	%edx, i.2(%rip)
	shrl	$24, %ecx
	movq	%r14, %rdx
	addq	%r15, %r13
	movzbl	%r8b, %r8d
	movl	$16, %esi
	xorl	%eax, %eax
	movq	%r13, %rdi
	call	snprintf@PLT
	movq	%r13, %rcx
	movq	%r12, %rdx
	movq	%rbx, %rsi
	leaq	.LC183(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
	popq	%rdx
	.cfi_def_cfa_offset 88
	popq	%rcx
	.cfi_def_cfa_offset 80
	jmp	.L1878
	.p2align 4,,10
	.p2align 3
.L1868:
	movl	4(%rsi), %eax
	movl	i.2(%rip), %r11d
	subq	$8, %rsp
	.cfi_def_cfa_offset 88
	addq	$1, %rbx
	movl	$16, %esi
	movzbl	%ah, %ecx
	leal	1(%r11), %edx
	movl	%eax, %r8d
	andl	$3, %r11d
	movl	%ecx, %r9d
	movl	%eax, %ecx
	movzbl	%al, %eax
	salq	$4, %r11
	pushq	%rax
	.cfi_def_cfa_offset 96
	leaq	(%r11,%r14), %r15
	shrl	$16, %r8d
	shrl	$24, %ecx
	movl	%edx, i.2(%rip)
	movzbl	%r8b, %r8d
	movq	%r12, %rdx
	movq	%r15, %rdi
	xorl	%eax, %eax
	call	snprintf@PLT
	movl	i.2(%rip), %edi
	movl	$16, %esi
	movq	728+cfg(%rip), %rax
	movl	(%rax,%rbp), %eax
	leal	1(%rdi), %edx
	andl	$3, %edi
	salq	$4, %rdi
	movl	%edx, i.2(%rip)
	movq	%r12, %rdx
	movzbl	%ah, %ecx
	movl	%eax, %r8d
	leaq	(%rdi,%r14), %rbp
	movl	%ecx, %r9d
	shrl	$16, %r8d
	movl	%eax, %ecx
	movzbl	%al, %eax
	movl	%eax, (%rsp)
	movzbl	%r8b, %r8d
	shrl	$24, %ecx
	movq	%rbp, %rdi
	xorl	%eax, %eax
	call	snprintf@PLT
	movq	%r13, %rdi
	movq	%r15, %rdx
	movq	%rbp, %rsi
	xorl	%eax, %eax
	call	printf@PLT
	movl	736+cfg(%rip), %edi
	addl	$1, 20(%rsp)
	movq	640+cfg(%rip), %r8
	popq	%r9
	.cfi_def_cfa_offset 88
	popq	%r10
	.cfi_def_cfa_offset 80
	cmpl	%ebx, %edi
	jg	.L1872
.L1954:
	movl	(%rsp), %ebp
	movq	%r8, %rbx
	jmp	.L1867
.L1958:
	cmpl	$7497076, 3+cfg(%rip)
	jne	.L1821
	leaq	.LC172(%rip), %rdi
	call	puts@PLT
	movl	$1, 4(%rsp)
	jmp	.L1823
.L1968:
	leaq	.LC180(%rip), %rdi
	call	puts@PLT
	movq	640+cfg(%rip), %rbx
	addl	$1, 4(%rsp)
	testq	%rbx, %rbx
	jne	.L1970
	jmp	.L1859
.L1965:
	leaq	.LC178(%rip), %rdi
	call	puts@PLT
	addl	$1, 4(%rsp)
	movl	704+cfg(%rip), %r9d
	jmp	.L1848
.L1859:
	movl	720+cfg(%rip), %ebp
	testl	%ebp, %ebp
	je	.L1863
	movl	736+cfg(%rip), %edi
	xorl	%ebp, %ebp
	testl	%edi, %edi
	jg	.L1864
	jmp	.L1865
	.p2align 4,,10
	.p2align 3
.L1863:
	leaq	.LC181(%rip), %rdi
	movl	$1, %ebp
	call	puts@PLT
	movl	736+cfg(%rip), %edi
	movq	640+cfg(%rip), %rbx
	testl	%edi, %edi
	jg	.L1864
	jmp	.L1867
	.cfi_endproc
.LFE92:
	.size	rc_validate, .-rc_validate
	.section	.rodata.str1.1
.LC185:
	.string	"ON"
.LC186:
	.string	"OFF"
	.section	.rodata.str1.8
	.align 8
.LC187:
	.string	"Compilation aborted: %d configuration error(s)."
	.section	.rodata.str1.1
.LC188:
	.string	"%s.rcx"
.LC189:
	.string	"w"
.LC190:
	.string	"Cannot write %s"
	.section	.rodata.str1.8
	.align 8
.LC191:
	.string	"\n--- Generated executable instructions ---"
	.align 8
.LC192:
	.string	"; RCC executable configuration for %s\n"
	.section	.rodata.str1.1
.LC193:
	.string	"SET_HOST"
.LC194:
	.string	"SET_SECRET"
.LC195:
	.string	"IF_SELECT"
.LC196:
	.string	"\"%s\""
.LC197:
	.string	"IF_DESC"
.LC198:
	.string	"%s %s"
.LC199:
	.string	"IF_IPV4"
.LC200:
	.string	"%ld"
.LC201:
	.string	"IF_CLOCK"
.LC202:
	.string	"-"
.LC203:
	.string	"IF_ADMIN_DN"
.LC204:
	.string	"IF_ADMIN_UP"
.LC205:
	.string	"%s %s VIA %s AD %d"
.LC206:
	.string	"ROUTE_ADD"
.LC207:
	.string	"%s %s OUT %s AD %d"
.LC208:
	.string	"v%d"
.LC209:
	.string	"RIP_ENABLE"
.LC210:
	.string	"RIP_NET"
.LC211:
	.string	"RIP_AUTOSUM"
.LC212:
	.string	"%d"
.LC213:
	.string	"OSPF_ENABLE"
.LC214:
	.string	"OSPF_RID"
.LC215:
	.string	"%s %s AREA %llu"
.LC216:
	.string	"OSPF_NET"
.LC217:
	.string	"checksum=0x%08lX"
.LC218:
	.string	"COMMIT"
	.section	.rodata.str1.8
	.align 8
.LC219:
	.string	"compiled %d instructions -> %s"
	.section	.rodata.str1.1
.LC220:
	.string	"codegen"
	.section	.rodata.str1.8
	.align 8
.LC221:
	.string	"\nCompiled %d instruction(s) -> %s\n"
	.align 8
.LC222:
	.string	"Optimisation report: %d config command(s) accepted, %d duplicate/no-op command(s) skipped,\n  %d default-state interface(s) pruned, routes emitted in sorted order, final state only (no history).\n"
	.section	.rodata.str1.1
.LC223:
	.string	"Compiled with %d warning(s).\n"
	.text
	.p2align 4
	.type	h_compile, @function
h_compile:
.LFB95:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	movq	%rsi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movl	%edi, %ebx
	subq	$264, %rsp
	.cfi_def_cfa_offset 320
	leaq	60(%rsp), %rdi
	call	rc_validate
	movl	%eax, 44(%rsp)
	testl	%eax, %eax
	jne	.L2015
	testl	%ebx, %ebx
	jne	.L2016
	leaq	96(%rsp), %rdi
	leaq	cfg(%rip), %rcx
	movl	$160, %esi
	xorl	%eax, %eax
	leaq	.LC188(%rip), %rdx
	movq	%rdi, 32(%rsp)
	call	snprintf@PLT
.L1975:
	movq	32(%rsp), %rdi
	pxor	%xmm0, %xmm0
	leaq	.LC189(%rip), %rsi
	movq	$0, 80(%rsp)
	movaps	%xmm0, 64(%rsp)
	leaq	64(%rsp), %r12
	call	fopen@PLT
	movq	%rax, %rbx
	testq	%rax, %rax
	je	.L2017
	leaq	.LC191(%rip), %rdi
	leaq	cfg(%rip), %rbp
	call	puts@PLT
	movq	%rbp, %rdx
	movq	%rbx, %rdi
	xorl	%eax, %eax
	leaq	.LC192(%rip), %rsi
	call	fprintf@PLT
	xorl	%eax, %eax
	movq	%rbp, %r8
	movl	$1, %esi
	leaq	.LC24(%rip), %rcx
	leaq	.LC193(%rip), %rdx
	movq	%r12, %rdi
	movq	%rbx, 72(%rsp)
	call	emit
	cmpb	$0, 64+cfg(%rip)
	jne	.L1977
.L2012:
	movq	640+cfg(%rip), %rbx
	movl	$0, 40(%rsp)
	movq	72(%rsp), %r14
	testq	%rbx, %rbx
	je	.L1979
	leaq	.LC195(%rip), %r13
	leaq	.LC202(%rip), %rbp
	jmp	.L1987
	.p2align 4,,10
	.p2align 3
.L2021:
	leaq	.LC203(%rip), %rdx
	movl	$21, %esi
	movq	%r12, %rdi
	xorl	%eax, %eax
	call	emit
	movq	72(%rsp), %r14
.L1981:
	movq	176(%rbx), %rbx
	testq	%rbx, %rbx
	je	.L1979
.L1987:
	movl	152(%rbx), %edi
	testl	%edi, %edi
	je	.L1980
	movl	148(%rbx), %esi
	testl	%esi, %esi
	jne	.L1980
	cmpb	$0, 40(%rbx)
	jne	.L1980
	cmpq	$0, 160(%rbx)
	je	.L2018
	.p2align 4
	.p2align 3
.L1980:
	xorl	%eax, %eax
	movq	%rbx, %r8
	leaq	.LC24(%rip), %rcx
	movq	%r13, %rdx
	movl	$16, %esi
	movq	%r12, %rdi
	movq	%r14, 72(%rsp)
	call	emit
	cmpb	$0, 40(%rbx)
	jne	.L1982
.L2013:
	movl	148(%rbx), %ecx
	movq	72(%rsp), %r14
	testl	%ecx, %ecx
	jne	.L2019
.L1984:
	movq	160(%rbx), %r8
	testq	%r8, %r8
	jne	.L2020
.L1985:
	movl	152(%rbx), %eax
	movq	%r14, 72(%rsp)
	movq	%rbp, %rcx
	testl	%eax, %eax
	jne	.L2021
	leaq	.LC204(%rip), %rdx
	movl	$20, %esi
	movq	%r12, %rdi
	xorl	%eax, %eax
	call	emit
	movq	176(%rbx), %rbx
	movq	72(%rsp), %r14
	testq	%rbx, %rbx
	jne	.L1987
.L1979:
	movl	672+cfg(%rip), %eax
	testl	%eax, %eax
	jle	.L1988
	leaq	.LC58(%rip), %rax
	xorl	%r11d, %r11d
	movq	%r12, 16(%rsp)
	xorl	%r10d, %r10d
	movq	%rax, (%rsp)
	leaq	b.1(%rip), %r15
	movq	%r15, %r12
	movl	%r11d, %r15d
	.p2align 4
	.p2align 3
.L1991:
	movq	664+cfg(%rip), %rbp
	movl	i.2(%rip), %ebx
	movq	%r10, 24(%rsp)
	addq	%r10, %rbp
	leal	1(%rbx), %edx
	andl	$3, %ebx
	movl	56(%rbp), %eax
	salq	$4, %rbx
	addq	%r12, %rbx
	movl	%eax, 8(%rsp)
	movl	52(%rbp), %eax
	testl	%eax, %eax
	je	.L1989
	movl	8(%rbp), %eax
	subq	$8, %rsp
	.cfi_def_cfa_offset 328
	movl	$16, %esi
	addl	$1, %r15d
	movl	%edx, i.2(%rip)
	movzbl	%ah, %edi
	movl	%eax, %r8d
	movl	%eax, %ecx
	movzbl	%al, %eax
	pushq	%rax
	.cfi_def_cfa_offset 336
	shrl	$16, %r8d
	movq	16(%rsp), %rdx
	movl	%edi, %r9d
	shrl	$24, %ecx
	movzbl	%r8b, %r8d
	movq	%rbx, %rdi
	xorl	%eax, %eax
	call	snprintf@PLT
	movl	i.2(%rip), %r13d
	movl	4(%rbp), %eax
	leal	1(%r13), %edx
	andl	$3, %r13d
	movl	%eax, %r8d
	movzbl	%ah, %esi
	salq	$4, %r13
	movl	%edx, i.2(%rip)
	shrl	$16, %r8d
	movl	%eax, %ecx
	movq	16(%rsp), %rdx
	addq	%r12, %r13
	movzbl	%al, %eax
	movl	%esi, %r9d
	movl	%eax, (%rsp)
	shrl	$24, %ecx
	movzbl	%r8b, %r8d
	movl	$16, %esi
	movq	%r13, %rdi
	xorl	%eax, %eax
	call	snprintf@PLT
	movl	0(%rbp), %eax
	movl	i.2(%rip), %ebp
	movl	$16, %esi
	leal	1(%rbp), %edx
	andl	$3, %ebp
	movl	%eax, %r8d
	movzbl	%ah, %edi
	salq	$4, %rbp
	movl	%edx, i.2(%rip)
	shrl	$16, %r8d
	movl	%eax, %ecx
	movq	16(%rsp), %rdx
	addq	%r12, %rbp
	movzbl	%al, %eax
	movl	%edi, %r9d
	movl	%eax, (%rsp)
	shrl	$24, %ecx
	movzbl	%r8b, %r8d
	movq	%rbp, %rdi
	xorl	%eax, %eax
	call	snprintf@PLT
	movl	24(%rsp), %eax
	movq	%r13, %r9
	movq	%rbp, %r8
	movq	%r14, 88(%rsp)
	leaq	.LC205(%rip), %rcx
	movl	$32, %esi
	leaq	.LC206(%rip), %rdx
	pushq	%rax
	.cfi_def_cfa_offset 344
	xorl	%eax, %eax
	pushq	%rbx
	.cfi_def_cfa_offset 352
	movq	48(%rsp), %rdi
	call	emit
	movq	56(%rsp), %r10
	movq	104(%rsp), %r14
	addq	$32, %rsp
	.cfi_def_cfa_offset 320
	addq	$60, %r10
	cmpl	672+cfg(%rip), %r15d
	jl	.L1991
.L2014:
	movq	16(%rsp), %r12
.L1988:
	movl	680+cfg(%rip), %eax
	testl	%eax, %eax
	jne	.L2022
.L1992:
	movl	712+cfg(%rip), %r9d
	testl	%r9d, %r9d
	jne	.L2023
.L1996:
	movl	80(%rsp), %r8d
	movl	$255, %esi
	movq	%r12, %rdi
	xorl	%eax, %eax
	leaq	.LC217(%rip), %rcx
	leaq	.LC218(%rip), %rdx
	movq	%r14, 72(%rsp)
	call	emit
	movq	72(%rsp), %rdi
	call	fclose@PLT
	movl	64(%rsp), %ebx
	movq	32(%rsp), %r15
	xorl	%eax, %eax
	leaq	.LC219(%rip), %rdx
	leaq	.LC220(%rip), %rsi
	movl	$1, %edi
	movq	%r15, %r8
	movl	%ebx, %ecx
	call	rlog_log@PLT
	movq	%r15, %rdx
	movl	%ebx, %esi
	xorl	%eax, %eax
	leaq	.LC221(%rip), %rdi
	call	printf@PLT
	movl	4+st(%rip), %esi
	movl	40(%rsp), %ecx
	xorl	%eax, %eax
	movl	8+st(%rip), %edx
	leaq	.LC222(%rip), %rdi
	call	printf@PLT
	movl	60(%rsp), %esi
	testl	%esi, %esi
	jne	.L2024
.L1971:
	movl	44(%rsp), %eax
	addq	$264, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L2016:
	.cfi_restore_state
	movq	0(%rbp), %rcx
	leaq	96(%rsp), %rdi
	movl	$160, %esi
	xorl	%eax, %eax
	leaq	.LC24(%rip), %rdx
	movq	%rdi, 32(%rsp)
	call	snprintf@PLT
	jmp	.L1975
	.p2align 4,,10
	.p2align 3
.L2020:
	movl	$19, %esi
	movq	%r12, %rdi
	xorl	%eax, %eax
	movq	%r14, 72(%rsp)
	leaq	.LC200(%rip), %rcx
	leaq	.LC201(%rip), %rdx
	call	emit
	movq	72(%rsp), %r14
	jmp	.L1985
	.p2align 4,,10
	.p2align 3
.L2019:
	movl	144(%rbx), %eax
	movl	i.2(%rip), %r10d
	subq	$8, %rsp
	.cfi_def_cfa_offset 328
	leaq	b.1(%rip), %r15
	leal	1(%r10), %edx
	movzbl	%ah, %esi
	movl	%eax, %r8d
	movl	%eax, %ecx
	andl	$3, %r10d
	movzbl	%al, %eax
	shrl	$16, %r8d
	movl	%esi, %r9d
	pushq	%rax
	.cfi_def_cfa_offset 336
	salq	$4, %r10
	shrl	$24, %ecx
	movzbl	%r8b, %r8d
	addq	%r15, %r10
	movl	%edx, i.2(%rip)
	movl	$16, %esi
	xorl	%eax, %eax
	movq	%r10, %rdi
	leaq	.LC58(%rip), %rdx
	movq	%r10, 16(%rsp)
	movq	%rdx, 24(%rsp)
	call	snprintf@PLT
	movl	i.2(%rip), %ecx
	movl	140(%rbx), %eax
	movq	24(%rsp), %rdx
	leal	1(%rcx), %esi
	andl	$3, %ecx
	movl	%eax, %r8d
	movzbl	%ah, %edi
	salq	$4, %rcx
	shrl	$16, %r8d
	movl	%edi, %r9d
	movl	%esi, i.2(%rip)
	addq	%rcx, %r15
	movl	%eax, %ecx
	movzbl	%al, %eax
	movzbl	%r8b, %r8d
	movl	%eax, (%rsp)
	shrl	$24, %ecx
	movl	$16, %esi
	movq	%r15, %rdi
	xorl	%eax, %eax
	call	snprintf@PLT
	movq	16(%rsp), %r9
	xorl	%eax, %eax
	movq	%r15, %r8
	leaq	.LC199(%rip), %rdx
	movl	$18, %esi
	movq	%r12, %rdi
	movq	%r14, 88(%rsp)
	leaq	.LC198(%rip), %rcx
	call	emit
	movq	88(%rsp), %r14
	popq	%rax
	.cfi_def_cfa_offset 328
	popq	%rdx
	.cfi_def_cfa_offset 320
	jmp	.L1984
	.p2align 4,,10
	.p2align 3
.L1982:
	leaq	40(%rbx), %r8
	leaq	.LC196(%rip), %rcx
	movq	%r12, %rdi
	xorl	%eax, %eax
	leaq	.LC197(%rip), %rdx
	movl	$17, %esi
	call	emit
	jmp	.L2013
	.p2align 4,,10
	.p2align 3
.L1989:
	movl	4(%rbp), %eax
	subq	$8, %rsp
	.cfi_def_cfa_offset 328
	movl	%edx, i.2(%rip)
	movq	%rbx, %rdi
	addq	$12, %rbp
	addl	$1, %r15d
	movzbl	%ah, %esi
	movl	%eax, %r8d
	movl	%eax, %ecx
	movzbl	%al, %eax
	pushq	%rax
	.cfi_def_cfa_offset 336
	shrl	$16, %r8d
	movq	16(%rsp), %rdx
	movl	%esi, %r9d
	shrl	$24, %ecx
	movzbl	%r8b, %r8d
	movl	$16, %esi
	xorl	%eax, %eax
	call	snprintf@PLT
	movl	i.2(%rip), %r13d
	movl	-12(%rbp), %eax
	movl	$16, %esi
	leal	1(%r13), %edx
	andl	$3, %r13d
	movl	%eax, %r8d
	movzbl	%ah, %edi
	salq	$4, %r13
	movl	%edx, i.2(%rip)
	shrl	$16, %r8d
	movl	%eax, %ecx
	movq	16(%rsp), %rdx
	addq	%r12, %r13
	movzbl	%al, %eax
	movl	%edi, %r9d
	movl	%eax, (%rsp)
	shrl	$24, %ecx
	movzbl	%r8b, %r8d
	movq	%r13, %rdi
	xorl	%eax, %eax
	call	snprintf@PLT
	movl	24(%rsp), %eax
	movq	%rbx, %r9
	movq	%r13, %r8
	movq	%r14, 88(%rsp)
	leaq	.LC207(%rip), %rcx
	movl	$32, %esi
	leaq	.LC206(%rip), %rdx
	pushq	%rax
	.cfi_def_cfa_offset 344
	xorl	%eax, %eax
	pushq	%rbp
	.cfi_def_cfa_offset 352
	movq	48(%rsp), %rdi
	call	emit
	movq	56(%rsp), %r10
	movq	104(%rsp), %r14
	addq	$32, %rsp
	.cfi_def_cfa_offset 320
	addq	$60, %r10
	cmpl	%r15d, 672+cfg(%rip)
	jg	.L1991
	jmp	.L2014
	.p2align 4,,10
	.p2align 3
.L2018:
	addl	$1, 40(%rsp)
	jmp	.L1981
	.p2align 4,,10
	.p2align 3
.L1977:
	leaq	64+cfg(%rip), %r8
	movl	$2, %esi
	movq	%r12, %rdi
	xorl	%eax, %eax
	leaq	.LC24(%rip), %rcx
	leaq	.LC194(%rip), %rdx
	call	emit
	jmp	.L2012
	.p2align 4,,10
	.p2align 3
.L2024:
	leaq	.LC223(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
	jmp	.L1971
	.p2align 4,,10
	.p2align 3
.L2023:
	movl	$64, %esi
	movq	%r12, %rdi
	xorl	%eax, %eax
	movq	%r14, 72(%rsp)
	movl	716+cfg(%rip), %r8d
	leaq	.LC212(%rip), %rcx
	leaq	.LC213(%rip), %rdx
	call	emit
	movl	720+cfg(%rip), %r8d
	testl	%r8d, %r8d
	jne	.L1997
	movq	72(%rsp), %r14
.L1998:
	movl	736+cfg(%rip), %ecx
	testl	%ecx, %ecx
	jle	.L1996
	leaq	.LC58(%rip), %rax
	leaq	b.1(%rip), %r15
	movq	%r12, 8(%rsp)
	xorl	%ebp, %ebp
	movq	%rax, (%rsp)
	movq	%r15, %r12
	.p2align 4
	.p2align 3
.L1999:
	movq	728+cfg(%rip), %rax
	movq	%rbp, %rbx
	subq	$8, %rsp
	.cfi_def_cfa_offset 328
	addq	$1, %rbp
	salq	$4, %rbx
	movl	i.2(%rip), %r13d
	addq	%rbx, %rax
	movq	8(%rax), %r15
	movl	4(%rax), %eax
	leal	1(%r13), %edx
	andl	$3, %r13d
	salq	$4, %r13
	movl	%edx, i.2(%rip)
	movzbl	%ah, %esi
	movl	%eax, %r8d
	movl	%eax, %ecx
	movzbl	%al, %eax
	pushq	%rax
	.cfi_def_cfa_offset 336
	addq	%r12, %r13
	movq	16(%rsp), %rdx
	shrl	$16, %r8d
	movl	%esi, %r9d
	shrl	$24, %ecx
	movzbl	%r8b, %r8d
	movl	$16, %esi
	movq	%r13, %rdi
	xorl	%eax, %eax
	call	snprintf@PLT
	movq	728+cfg(%rip), %rax
	movl	$16, %esi
	movl	(%rax,%rbx), %eax
	movl	i.2(%rip), %ebx
	leal	1(%rbx), %edx
	andl	$3, %ebx
	movl	%eax, %r8d
	movzbl	%ah, %edi
	salq	$4, %rbx
	movl	%edx, i.2(%rip)
	shrl	$16, %r8d
	movl	%eax, %ecx
	movq	16(%rsp), %rdx
	addq	%r12, %rbx
	movzbl	%al, %eax
	movl	%edi, %r9d
	movl	%eax, (%rsp)
	shrl	$24, %ecx
	movzbl	%r8b, %r8d
	movq	%rbx, %rdi
	xorl	%eax, %eax
	call	snprintf@PLT
	movq	24(%rsp), %rdi
	xorl	%eax, %eax
	movq	%r13, %r9
	leaq	.LC216(%rip), %rdx
	movq	%rbx, %r8
	movl	$66, %esi
	movq	%r14, 88(%rsp)
	leaq	.LC215(%rip), %rcx
	movq	%r15, (%rsp)
	call	emit
	cmpl	%ebp, 736+cfg(%rip)
	movq	88(%rsp), %r14
	popq	%rax
	.cfi_def_cfa_offset 328
	popq	%rdx
	.cfi_def_cfa_offset 320
	jg	.L1999
	movq	8(%rsp), %r12
	jmp	.L1996
	.p2align 4,,10
	.p2align 3
.L2022:
	movl	$48, %esi
	movq	%r12, %rdi
	xorl	%eax, %eax
	movq	%r14, 72(%rsp)
	movl	684+cfg(%rip), %r8d
	leaq	.LC208(%rip), %rcx
	leaq	.LC209(%rip), %rdx
	call	emit
	movl	704+cfg(%rip), %r15d
	movq	72(%rsp), %r13
	testl	%r15d, %r15d
	jle	.L1993
	xorl	%ebp, %ebp
	leaq	.LC58(%rip), %rax
	leaq	b.1(%rip), %r15
	movq	%rax, (%rsp)
	movq	%rbp, %rax
	leaq	.LC210(%rip), %rbx
	movq	%r13, %rbp
	movq	%rax, %r13
	.p2align 4
	.p2align 3
.L1994:
	movq	696+cfg(%rip), %rax
	movl	i.2(%rip), %r14d
	subq	$8, %rsp
	.cfi_def_cfa_offset 328
	movl	(%rax,%r13,4), %eax
	leal	1(%r14), %edx
	andl	$3, %r14d
	addq	$1, %r13
	salq	$4, %r14
	movl	%edx, i.2(%rip)
	movzbl	%ah, %esi
	movl	%eax, %r8d
	movl	%eax, %ecx
	movzbl	%al, %eax
	pushq	%rax
	.cfi_def_cfa_offset 336
	addq	%r15, %r14
	movq	16(%rsp), %rdx
	shrl	$16, %r8d
	movl	%esi, %r9d
	shrl	$24, %ecx
	movq	%r14, %rdi
	movzbl	%r8b, %r8d
	movl	$16, %esi
	xorl	%eax, %eax
	call	snprintf@PLT
	movq	%r14, %r8
	xorl	%eax, %eax
	movq	%rbx, %rdx
	leaq	.LC24(%rip), %rcx
	movl	$49, %esi
	movq	%r12, %rdi
	movq	%rbp, 88(%rsp)
	call	emit
	cmpl	%r13d, 704+cfg(%rip)
	movq	88(%rsp), %rbp
	popq	%r11
	.cfi_def_cfa_offset 328
	popq	%r14
	.cfi_def_cfa_offset 320
	jg	.L1994
	movq	%rbp, %r13
.L1993:
	movl	688+cfg(%rip), %r10d
	leaq	.LC186(%rip), %rax
	leaq	.LC185(%rip), %r8
	movl	$50, %esi
	leaq	.LC24(%rip), %rcx
	leaq	.LC211(%rip), %rdx
	movq	%r12, %rdi
	movq	%r13, 72(%rsp)
	testl	%r10d, %r10d
	cmove	%rax, %r8
	xorl	%eax, %eax
	call	emit
	movq	72(%rsp), %r14
	jmp	.L1992
	.p2align 4,,10
	.p2align 3
.L1997:
	movl	724+cfg(%rip), %eax
	movl	i.2(%rip), %ebx
	subq	$8, %rsp
	.cfi_def_cfa_offset 328
	leaq	b.1(%rip), %r15
	leal	1(%rbx), %edx
	movzbl	%ah, %esi
	movl	%eax, %r8d
	movl	%eax, %ecx
	andl	$3, %ebx
	movzbl	%al, %eax
	shrl	$16, %r8d
	movl	%esi, %r9d
	pushq	%rax
	.cfi_def_cfa_offset 336
	salq	$4, %rbx
	leaq	.LC58(%rip), %rax
	shrl	$24, %ecx
	addq	%r15, %rbx
	movl	%edx, i.2(%rip)
	movzbl	%r8b, %r8d
	movq	%rax, %rdx
	movl	$16, %esi
	movq	%rbx, %rdi
	xorl	%eax, %eax
	call	snprintf@PLT
	movl	$65, %esi
	movq	%r12, %rdi
	movq	%rbx, %r8
	leaq	.LC24(%rip), %rcx
	leaq	.LC214(%rip), %rdx
	xorl	%eax, %eax
	call	emit
	movq	88(%rsp), %r14
	popq	%rsi
	.cfi_def_cfa_offset 328
	popq	%rdi
	.cfi_def_cfa_offset 320
	jmp	.L1998
.L2015:
	movl	%eax, %esi
	leaq	.LC187(%rip), %rdi
	xorl	%eax, %eax
	call	err
.L1973:
	movl	$-1, 44(%rsp)
	jmp	.L1971
.L2017:
	movq	32(%rsp), %rsi
	leaq	.LC190(%rip), %rdi
	xorl	%eax, %eax
	call	err
	jmp	.L1973
	.cfi_endproc
.LFE95:
	.size	h_compile, .-h_compile
	.p2align 4
	.type	h_validate, @function
h_validate:
.LFB93:
	.cfi_startproc
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	xorl	%edi, %edi
	call	rc_validate
	xorl	%eax, %eax
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE93:
	.size	h_validate, .-h_validate
	.section	.rodata.str1.1
.LC224:
	.string	"Cannot open %s for writing."
	.text
	.p2align 4
	.globl	rc_save_file
	.type	rc_save_file, @function
rc_save_file:
.LFB97:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pxor	%xmm0, %xmm0
	leaq	.LC189(%rip), %rsi
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rdi, %rbx
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movaps	%xmm0, (%rsp)
	call	fopen@PLT
	testq	%rax, %rax
	je	.L2037
	movq	%rsp, %rdi
	movq	%rax, %r13
	call	gen_config
	movslq	8(%rsp), %rax
	movq	(%rsp), %r15
	testl	%eax, %eax
	jle	.L2033
	movq	%r15, %rbp
	leaq	(%r15,%rax,8), %r12
	movq	%r15, %rbx
	leaq	.LC7(%rip), %r14
	.p2align 4
	.p2align 3
.L2031:
	movq	(%rbx), %rdx
	movq	%r14, %rsi
	movq	%r13, %rdi
	xorl	%eax, %eax
	addq	$8, %rbx
	call	fprintf@PLT
	cmpq	%r12, %rbx
	jne	.L2031
	.p2align 4
	.p2align 3
.L2032:
	movq	0(%rbp), %rdi
	addq	$8, %rbp
	call	free@PLT
	cmpq	%r12, %rbp
	jne	.L2032
.L2033:
	movq	%r15, %rdi
	call	free@PLT
	movq	%r13, %rdi
	call	fclose@PLT
	xorl	%eax, %eax
.L2027:
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L2037:
	.cfi_restore_state
	movq	%rbx, %rsi
	leaq	.LC224(%rip), %rdi
	xorl	%eax, %eax
	call	err
	orl	$-1, %eax
	jmp	.L2027
	.cfi_endproc
.LFE97:
	.size	rc_save_file, .-rc_save_file
	.section	.rodata.str1.8
	.align 8
.LC225:
	.string	"[OK] configuration saved to %s\n"
	.text
	.p2align 4
	.type	h_save, @function
h_save:
.LFB102:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movq	(%rsi), %rdi
	call	rc_save_file
	testl	%eax, %eax
	jne	.L2040
	movq	0(%rbp), %rsi
	movl	%eax, %ebx
	leaq	.LC225(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
.L2038:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	movl	%ebx, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L2040:
	.cfi_restore_state
	movl	$-1, %ebx
	jmp	.L2038
	.cfi_endproc
.LFE102:
	.size	h_save, .-h_save
	.section	.rodata.str1.1
.LC226:
	.string	"memory"
.LC227:
	.string	"Did you mean 'write memory'?"
.LC228:
	.string	"Building configuration..."
	.section	.rodata.str1.8
	.align 8
.LC229:
	.string	"[OK] saved to startup-config.cfg"
	.text
	.p2align 4
	.type	h_write, @function
h_write:
.LFB99:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$8, %rsp
	.cfi_def_cfa_offset 48
	testl	%edi, %edi
	je	.L2043
	movq	(%rsi), %r12
	leaq	.LC226(%rip), %r13
	movzbl	(%r12), %ebx
	testb	%bl, %bl
	jne	.L2045
.L2044:
	leaq	.LC227(%rip), %rsi
	xorl	%edi, %edi
	xorl	%eax, %eax
	call	bad_arg
.L2047:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	movl	$-1, %ebx
	movl	%ebx, %eax
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L2046:
	.cfi_restore_state
	call	__ctype_tolower_loc@PLT
	movq	(%rax), %rax
	movl	(%rax,%rbp,4), %edx
	cmpl	%edx, (%rax,%rbx,4)
	jne	.L2044
	movzbl	1(%r12), %ebx
	addq	$1, %r12
	addq	$1, %r13
	testb	%bl, %bl
	je	.L2043
.L2045:
	movzbl	0(%r13), %ebp
	testb	%bpl, %bpl
	jne	.L2046
	jmp	.L2044
	.p2align 4,,10
	.p2align 3
.L2043:
	leaq	.LC228(%rip), %rdi
	call	puts@PLT
	leaq	.LC9(%rip), %rdi
	call	rc_save_file
	movl	%eax, %ebx
	testl	%eax, %eax
	jne	.L2047
	leaq	.LC229(%rip), %rdi
	call	puts@PLT
	addq	$8, %rsp
	.cfi_def_cfa_offset 40
	movl	%ebx, %eax
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE99:
	.size	h_write, .-h_write
	.p2align 4
	.type	h_copy, @function
h_copy:
.LFB100:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	leaq	.LC228(%rip), %rdi
	call	puts@PLT
	leaq	.LC9(%rip), %rdi
	call	rc_save_file
	testl	%eax, %eax
	jne	.L2062
	leaq	.LC229(%rip), %rdi
	movl	%eax, %ebx
	call	puts@PLT
.L2060:
	movl	%ebx, %eax
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L2062:
	.cfi_restore_state
	movl	$-1, %ebx
	jmp	.L2060
	.cfi_endproc
.LFE100:
	.size	h_copy, .-h_copy
	.section	.rodata.str1.1
.LC230:
	.string	"Cannot open file \"%s\"."
	.section	.rodata.str1.8
	.align 8
.LC231:
	.string	"loaded %d line(s) from %s (%d error(s))"
	.section	.rodata.str1.1
.LC232:
	.string	"loader"
	.section	.rodata.str1.8
	.align 8
.LC233:
	.string	"Loaded %d line(s) from %s (%d error(s)).\n"
	.text
	.p2align 4
	.globl	rc_load_file
	.type	rc_load_file, @function
rc_load_file:
.LFB98:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	leaq	.LC8(%rip), %rsi
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rdi, %rbx
	subq	$264, %rsp
	.cfi_def_cfa_offset 320
	call	fopen@PLT
	movl	mode(%rip), %r15d
	movl	nerr(%rip), %r14d
	testq	%rax, %rax
	je	.L2071
	movq	%rbx, %rdi
	movq	%rax, %r12
	call	strlen@PLT
	leaq	1(%rax), %rbp
	movq	%rbp, %rdi
	call	malloc@PLT
	movq	%rax, %r13
	testq	%rax, %rax
	je	.L2072
	movq	%rbp, %rdx
	movq	%rbx, %rsi
	movq	%rax, %rdi
	xorl	%ebx, %ebx
	call	memcpy@PLT
	movq	%rsp, %rbp
	call	rc_reset_config
	movq	%r13, load_name(%rip)
	movl	$2, mode(%rip)
	movl	$1, loading(%rip)
	jmp	.L2068
	.p2align 4,,10
	.p2align 3
.L2069:
	addl	$1, %ebx
	movq	%rbp, %rdi
	movl	%ebx, load_line(%rip)
	call	execute_line_impl
.L2068:
	movq	%r12, %rdx
	movl	$256, %esi
	movq	%rbp, %rdi
	call	fgets@PLT
	testq	%rax, %rax
	jne	.L2069
	leaq	.LC33(%rip), %rax
	movq	%r12, %rdi
	movl	$0, loading(%rip)
	movq	%rax, load_name(%rip)
	movl	%r15d, mode(%rip)
	movq	$0, cur_if(%rip)
	call	fclose@PLT
	movl	nerr(%rip), %r9d
	xorl	%eax, %eax
	movl	%ebx, %ecx
	movq	%r13, %r8
	leaq	.LC231(%rip), %rdx
	movl	$1, %edi
	subl	%r14d, %r9d
	leaq	.LC232(%rip), %rsi
	call	rlog_log@PLT
	movl	nerr(%rip), %ecx
	movq	%r13, %rdx
	movl	%ebx, %esi
	leaq	.LC233(%rip), %rdi
	xorl	%eax, %eax
	subl	%r14d, %ecx
	call	printf@PLT
	movq	%r13, %rdi
	call	free@PLT
	xorl	%eax, %eax
	cmpl	%r14d, nerr(%rip)
	setne	%al
	negl	%eax
.L2064:
	addq	$264, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L2071:
	.cfi_restore_state
	movq	%rbx, %rsi
	leaq	.LC230(%rip), %rdi
	xorl	%eax, %eax
	call	err
	orl	$-1, %eax
	jmp	.L2064
.L2072:
	movq	stderr(%rip), %rcx
	movl	$14, %edx
	movl	$1, %esi
	leaq	.LC19(%rip), %rdi
	call	fwrite@PLT
	movl	$1, %edi
	call	exit@PLT
	.cfi_endproc
.LFE98:
	.size	rc_load_file, .-rc_load_file
	.section	.rodata.str1.8
	.align 8
.LC234:
	.string	"Proceed with reload? [confirm]"
	.section	.rodata.str1.1
.LC235:
	.string	"Restarting system..."
.LC236:
	.string	"reload requested"
	.text
	.p2align 4
	.type	h_reload, @function
h_reload:
.LFB104:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	leaq	.LC234(%rip), %rdi
	xorl	%eax, %eax
	subq	$16, %rsp
	.cfi_def_cfa_offset 32
	call	printf@PLT
	movq	stdout(%rip), %rdi
	call	fflush@PLT
	movq	stdin(%rip), %rdx
	movq	%rsp, %rdi
	movl	$16, %esi
	call	fgets@PLT
	testq	%rax, %rax
	je	.L2077
	movzbl	(%rsp), %eax
	andl	$-33, %eax
	cmpb	$78, %al
	jne	.L2085
.L2075:
	xorl	%eax, %eax
.L2073:
	addq	$16, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L2085:
	.cfi_restore_state
	call	rc_reset_config
	leaq	.LC9(%rip), %rbx
	leaq	.LC235(%rip), %rdi
	movl	$0, mode(%rip)
	call	puts@PLT
	movq	%rbx, %rdi
	leaq	.LC8(%rip), %rsi
	call	fopen@PLT
	movq	%rax, %rdi
	testq	%rax, %rax
	je	.L2076
	call	fclose@PLT
	movq	%rbx, %rdi
	call	rc_load_file
	movl	$0, mode(%rip)
.L2076:
	leaq	.LC236(%rip), %rdx
	leaq	.LC5(%rip), %rsi
	movl	$1, %edi
	xorl	%eax, %eax
	call	rlog_log@PLT
	jmp	.L2075
.L2077:
	movl	$-1, %eax
	jmp	.L2073
	.cfi_endproc
.LFE104:
	.size	h_reload, .-h_reload
	.p2align 4
	.type	h_load, @function
h_load:
.LFB103:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	leaq	.LC24(%rip), %rdx
	xorl	%eax, %eax
	subq	$208, %rsp
	.cfi_def_cfa_offset 224
	movq	(%rsi), %rcx
	movl	$200, %esi
	movq	%rsp, %rdi
	call	snprintf@PLT
	movq	%rsp, %rdi
	call	rc_load_file
	addq	$208, %rsp
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE103:
	.size	h_load, .-h_load
	.p2align 4
	.globl	rc_execute_line
	.type	rc_execute_line, @function
rc_execute_line:
.LFB113:
	.cfi_startproc
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	call	execute_line_impl
	movl	nerr(%rip), %eax
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE113:
	.size	rc_execute_line, .-rc_execute_line
	.p2align 4
	.globl	rc_set_quit_flag
	.type	rc_set_quit_flag, @function
rc_set_quit_flag:
.LFB114:
	.cfi_startproc
	movl	%edi, quit_flag(%rip)
	ret
	.cfi_endproc
.LFE114:
	.size	rc_set_quit_flag, .-rc_set_quit_flag
	.p2align 4
	.globl	rc_get_quit_flag
	.type	rc_get_quit_flag, @function
rc_get_quit_flag:
.LFB115:
	.cfi_startproc
	movl	quit_flag(%rip), %eax
	ret
	.cfi_endproc
.LFE115:
	.size	rc_get_quit_flag, .-rc_get_quit_flag
	.p2align 4
	.globl	rc_gen_config_lines
	.type	rc_gen_config_lines, @function
rc_gen_config_lines:
.LFB116:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pxor	%xmm0, %xmm0
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	movq	%rsi, %r14
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	movq	%rdi, %r13
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movq	%rsp, %rdi
	movaps	%xmm0, (%rsp)
	call	gen_config
	movslq	8(%rsp), %rax
	movq	(%rsp), %r15
	testl	%eax, %eax
	jle	.L2096
	movq	%r15, %rbp
	leaq	(%r15,%rax,8), %r12
	movq	%r15, %rbx
	.p2align 4
	.p2align 3
.L2094:
	movq	(%rbx), %rdi
	addq	$8, %rbx
	movq	%r14, %rsi
	call	*%r13
	cmpq	%r12, %rbx
	jne	.L2094
	.p2align 4
	.p2align 3
.L2095:
	movq	0(%rbp), %rdi
	addq	$8, %rbp
	call	free@PLT
	cmpq	%r12, %rbp
	jne	.L2095
.L2096:
	addq	$24, %rsp
	.cfi_def_cfa_offset 56
	movq	%r15, %rdi
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	jmp	free@PLT
	.cfi_endproc
.LFE116:
	.size	rc_gen_config_lines, .-rc_gen_config_lines
	.section	.rodata.str1.1
.LC237:
	.string	"reports/router_compiler.log"
	.section	.rodata.str1.8
	.align 8
.LC238:
	.string	"warning: could not open %s for logging\n"
	.align 8
.LC239:
	.string	"router compiler start (Linux POC)"
	.section	.rodata.str1.1
.LC240:
	.string	"main"
	.section	.rodata.str1.8
	.align 8
.LC241:
	.string	"===================================================================="
	.align 8
.LC242:
	.string	"  Network Router Configuration Compiler  (Cisco IOS style CLI)"
	.align 8
.LC243:
	.string	"  Type '?' or 'help' for commands, 'exit' in user mode to quit."
	.align 8
.LC244:
	.string	"Restoring saved startup-config..."
	.section	.rodata.str1.1
.LC245:
	.string	"\nBye."
.LC246:
	.string	"router compiler exit"
	.text
	.p2align 4
	.globl	rc_run_cli
	.type	rc_run_cli, @function
rc_run_cli:
.LFB117:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	leaq	.LC237(%rip), %rbx
	subq	$376, %rsp
	.cfi_def_cfa_offset 432
	call	rc_reset_config
	movl	$1, %esi
	movq	%rbx, %rdi
	call	rlog_init@PLT
	testl	%eax, %eax
	jne	.L2116
.L2101:
	leaq	.LC239(%rip), %rdx
	leaq	.LC240(%rip), %rsi
	movl	$1, %edi
	xorl	%eax, %eax
	call	rlog_log@PLT
	leaq	.LC241(%rip), %rbx
	movq	%rbx, %rdi
	call	puts@PLT
	leaq	.LC242(%rip), %rdi
	call	puts@PLT
	leaq	.LC243(%rip), %rdi
	call	puts@PLT
	movq	%rbx, %rdi
	leaq	.LC9(%rip), %rbx
	call	puts@PLT
	movq	%rbx, %rdi
	leaq	.LC8(%rip), %rsi
	call	fopen@PLT
	movq	%rax, %rdi
	testq	%rax, %rax
	je	.L2102
	call	fclose@PLT
	leaq	.LC244(%rip), %rdi
	call	puts@PLT
	movq	%rbx, %rdi
	call	rc_load_file
	movl	$0, mode(%rip)
.L2102:
	movl	quit_flag(%rip), %edx
	testl	%edx, %edx
	jne	.L2103
	leaq	suffix.0(%rip), %r15
	movq	%rsp, %rbx
	leaq	cfg(%rip), %r14
	leaq	.LC143(%rip), %r13
	leaq	.LC24(%rip), %r12
	leaq	112(%rsp), %rbp
	jmp	.L2104
	.p2align 4,,10
	.p2align 3
.L2117:
	movq	%rbp, %rdi
	call	execute_line_impl
	movl	quit_flag(%rip), %eax
	testl	%eax, %eax
	jne	.L2103
.L2104:
	movl	mode(%rip), %eax
	movq	%r13, %rdx
	movq	%r14, %rcx
	movq	%rbx, %rdi
	movl	$100, %esi
	movq	(%r15,%rax,8), %r8
	xorl	%eax, %eax
	call	snprintf@PLT
	movq	%rbx, %rdi
	call	strlen@PLT
	movq	%rbx, %rsi
	movq	%r12, %rdi
	movl	%eax, prompt_len(%rip)
	xorl	%eax, %eax
	call	printf@PLT
	movq	stdout(%rip), %rdi
	call	fflush@PLT
	movq	stdin(%rip), %rdx
	movl	$256, %esi
	movq	%rbp, %rdi
	call	fgets@PLT
	testq	%rax, %rax
	jne	.L2117
.L2103:
	leaq	.LC245(%rip), %rdi
	call	puts@PLT
	xorl	%eax, %eax
	movl	$1, %edi
	leaq	.LC246(%rip), %rdx
	leaq	.LC240(%rip), %rsi
	call	rlog_log@PLT
	call	rc_reset_config
	movq	errlog(%rip), %rdi
	call	free@PLT
	movq	$0, errlog(%rip)
	movl	$0, cerr(%rip)
	movl	$0, nerr(%rip)
	call	rlog_close@PLT
	addq	$376, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L2116:
	.cfi_restore_state
	movq	stderr(%rip), %rdi
	movq	%rbx, %rdx
	leaq	.LC238(%rip), %rsi
	xorl	%eax, %eax
	call	fprintf@PLT
	jmp	.L2101
	.cfi_endproc
.LFE117:
	.size	rc_run_cli, .-rc_run_cli
	.section	.rodata.str1.1
.LC247:
	.string	">"
.LC248:
	.string	"#"
.LC249:
	.string	"(config)#"
.LC250:
	.string	"(config-if)#"
.LC251:
	.string	"(config-router)#"
	.section	.data.rel.ro.local,"aw"
	.align 32
	.type	suffix.0, @object
	.size	suffix.0, 48
suffix.0:
	.quad	.LC247
	.quad	.LC248
	.quad	.LC249
	.quad	.LC250
	.quad	.LC251
	.quad	.LC251
	.local	b.1
	.comm	b.1,64,32
	.local	i.2
	.comm	i.2,4,4
	.section	.rodata.str1.1
.LC252:
	.string	"enable"
.LC253:
	.string	"Enter privileged EXEC mode"
.LC254:
	.string	"disable"
.LC255:
	.string	"Return to user EXEC mode"
.LC256:
	.string	"configure terminal"
	.section	.rodata.str1.8
	.align 8
.LC257:
	.string	"Enter global configuration mode"
	.section	.rodata.str1.1
.LC258:
	.string	"exit"
	.section	.rodata.str1.8
	.align 8
.LC259:
	.string	"Go back one level (in user mode: quit program)"
	.section	.rodata.str1.1
.LC260:
	.string	"quit"
.LC261:
	.string	"Quit the program"
.LC262:
	.string	"help"
	.section	.rodata.str1.8
	.align 8
.LC263:
	.string	"List commands for the current mode"
	.align 8
.LC264:
	.string	"Return to privileged EXEC mode"
	.section	.rodata.str1.1
.LC265:
	.string	"hostname"
.LC266:
	.string	"<name>"
.LC267:
	.string	"Set the router name"
.LC268:
	.string	"no hostname"
.LC269:
	.string	"Reset hostname to 'Router'"
.LC270:
	.string	"enable secret"
.LC271:
	.string	"<password>"
.LC272:
	.string	"Set privileged-mode password"
.LC273:
	.string	"no enable secret"
	.section	.rodata.str1.8
	.align 8
.LC274:
	.string	"Remove privileged-mode password"
	.section	.rodata.str1.1
.LC275:
	.string	"interface"
.LC276:
	.string	"<type> <number>"
	.section	.rodata.str1.8
	.align 8
.LC277:
	.string	"Select/create an interface (g0/0, fa0/1, s0/0/0, lo0)"
	.section	.rodata.str1.1
.LC278:
	.string	"no interface"
.LC279:
	.string	"<loopback>"
.LC280:
	.string	"Delete a loopback interface"
.LC281:
	.string	"ip route"
.LC282:
	.string	"<net> <mask> <nh|if> [ad]"
.LC283:
	.string	"Add a static route"
.LC284:
	.string	"no ip route"
.LC285:
	.string	"<net> <mask> [nh|if]"
.LC286:
	.string	"Remove a static route"
	.section	.rodata.str1.8
	.align 8
.LC287:
	.string	"Enable RIP and enter router mode"
	.section	.rodata.str1.1
.LC288:
	.string	"no router rip"
.LC289:
	.string	"Disable RIP"
.LC290:
	.string	"router ospf"
.LC291:
	.string	"<process-id>"
	.section	.rodata.str1.8
	.align 8
.LC292:
	.string	"Enable OSPF and enter router mode"
	.section	.rodata.str1.1
.LC293:
	.string	"no router ospf"
.LC294:
	.string	"Disable OSPF"
.LC295:
	.string	"ip address"
.LC296:
	.string	"<ip> <mask>"
	.section	.rodata.str1.8
	.align 8
.LC297:
	.string	"Assign IPv4 address to the interface"
	.section	.rodata.str1.1
.LC298:
	.string	"no ip address"
.LC299:
	.string	"Remove IPv4 address"
.LC300:
	.string	"shutdown"
	.section	.rodata.str1.8
	.align 8
.LC301:
	.string	"Administratively disable the interface"
	.section	.rodata.str1.1
.LC302:
	.string	"no shutdown"
.LC303:
	.string	"Enable the interface"
.LC304:
	.string	"description"
.LC305:
	.string	"<text>"
.LC306:
	.string	"Set interface description"
.LC307:
	.string	"no description"
.LC308:
	.string	"Remove interface description"
.LC309:
	.string	"clock rate"
.LC310:
	.string	"<bits/sec>"
	.section	.rodata.str1.8
	.align 8
.LC311:
	.string	"Set DCE clock rate (Serial only)"
	.section	.rodata.str1.1
.LC312:
	.string	"no clock rate"
.LC313:
	.string	"Remove clock rate"
.LC314:
	.string	"version"
.LC315:
	.string	"<1|2>"
.LC316:
	.string	"Set RIP version"
.LC317:
	.string	"auto-summary"
	.section	.rodata.str1.8
	.align 8
.LC318:
	.string	"Enable automatic summarisation"
	.section	.rodata.str1.1
.LC319:
	.string	"no auto-summary"
	.section	.rodata.str1.8
	.align 8
.LC320:
	.string	"Disable automatic summarisation"
	.section	.rodata.str1.1
.LC321:
	.string	"router-id"
.LC322:
	.string	"<a.b.c.d>"
.LC323:
	.string	"Set OSPF router-id"
.LC324:
	.string	"no router-id"
.LC325:
	.string	"Remove OSPF router-id"
.LC326:
	.string	"network"
.LC327:
	.string	"<net> | <net> <wild> area <n>"
	.section	.rodata.str1.8
	.align 8
.LC328:
	.string	"Advertise a network (RIP: classful; OSPF: wildcard+area)"
	.section	.rodata.str1.1
.LC329:
	.string	"no network"
.LC330:
	.string	"<same as network>"
.LC331:
	.string	"Remove a network statement"
.LC332:
	.string	"show ip interface brief"
	.section	.rodata.str1.8
	.align 8
.LC333:
	.string	"One-line status of every interface"
	.section	.rodata.str1.1
.LC334:
	.string	"show ip route"
.LC335:
	.string	"[ip]"
	.section	.rodata.str1.8
	.align 8
.LC336:
	.string	"Routing table (or lookup of one address)"
	.section	.rodata.str1.1
.LC337:
	.string	"show ip protocols"
.LC338:
	.string	"RIP / OSPF settings"
.LC339:
	.string	"show interfaces"
.LC340:
	.string	"[type number]"
	.section	.rodata.str1.8
	.align 8
.LC341:
	.string	"Detailed interface information"
	.section	.rodata.str1.1
.LC342:
	.string	"show errors"
	.section	.rodata.str1.8
	.align 8
.LC343:
	.string	"All configuration errors seen this session"
	.section	.rodata.str1.1
.LC344:
	.string	"show running-config"
.LC345:
	.string	"Display current configuration"
.LC346:
	.string	"show startup-config"
.LC347:
	.string	"Display saved configuration"
.LC348:
	.string	"ping"
.LC349:
	.string	"<ip>"
	.section	.rodata.str1.8
	.align 8
.LC350:
	.string	"Simulated ping using the routing table"
	.section	.rodata.str1.1
.LC351:
	.string	"write"
.LC352:
	.string	"[memory]"
	.section	.rodata.str1.8
	.align 8
.LC353:
	.string	"Save running-config to startup-config"
	.align 8
.LC354:
	.string	"copy running-config startup-config"
	.section	.rodata.str1.1
.LC355:
	.string	"erase startup-config"
	.section	.rodata.str1.8
	.align 8
.LC356:
	.string	"Delete the saved startup-config"
	.section	.rodata.str1.1
.LC357:
	.string	"save"
.LC358:
	.string	"<file>"
	.section	.rodata.str1.8
	.align 8
.LC359:
	.string	"Save running-config to any file"
	.section	.rodata.str1.1
.LC360:
	.string	"load"
	.section	.rodata.str1.8
	.align 8
.LC361:
	.string	"Load a config file (replaces running-config)"
	.section	.rodata.str1.1
.LC362:
	.string	"reload"
	.section	.rodata.str1.8
	.align 8
.LC363:
	.string	"Restart: clear running-config, reload startup-config"
	.section	.rodata.str1.1
.LC364:
	.string	"validate"
	.section	.rodata.str1.8
	.align 8
.LC365:
	.string	"Semantic check of the whole configuration"
	.section	.rodata.str1.1
.LC366:
	.string	"compile"
.LC367:
	.string	"[file.rcx]"
	.section	.rodata.str1.8
	.align 8
.LC368:
	.string	"Validate + generate executable instructions"
	.section	.rodata.str1.1
.LC369:
	.string	"search"
.LC370:
	.string	"<keyword>"
	.section	.rodata.str1.8
	.align 8
.LC371:
	.string	"Search configuration text / interface name"
	.section	.data.rel.ro.local
	.align 32
	.type	CMDS, @object
	.size	CMDS, 2448
CMDS:
	.long	1
	.zero	4
	.quad	.LC252
	.quad	.LC33
	.long	0
	.long	0
	.quad	h_enable
	.quad	.LC253
	.long	2
	.zero	4
	.quad	.LC254
	.quad	.LC33
	.long	0
	.long	0
	.quad	h_disable
	.quad	.LC255
	.long	2
	.zero	4
	.quad	.LC256
	.quad	.LC33
	.long	0
	.long	0
	.quad	h_configure
	.quad	.LC257
	.long	63
	.zero	4
	.quad	.LC258
	.quad	.LC33
	.long	0
	.long	0
	.quad	h_exit
	.quad	.LC259
	.long	63
	.zero	4
	.quad	.LC260
	.quad	.LC33
	.long	0
	.long	0
	.quad	h_quit
	.quad	.LC261
	.long	63
	.zero	4
	.quad	.LC262
	.quad	.LC33
	.long	0
	.long	0
	.quad	h_help
	.quad	.LC263
	.long	60
	.zero	4
	.quad	.LC101
	.quad	.LC33
	.long	0
	.long	0
	.quad	h_end
	.quad	.LC264
	.long	60
	.zero	4
	.quad	.LC265
	.quad	.LC266
	.long	1
	.long	1
	.quad	h_hostname
	.quad	.LC267
	.long	60
	.zero	4
	.quad	.LC268
	.quad	.LC33
	.long	0
	.long	0
	.quad	h_no_hostname
	.quad	.LC269
	.long	60
	.zero	4
	.quad	.LC270
	.quad	.LC271
	.long	1
	.long	1
	.quad	h_secret
	.quad	.LC272
	.long	60
	.zero	4
	.quad	.LC273
	.quad	.LC33
	.long	0
	.long	0
	.quad	h_no_secret
	.quad	.LC274
	.long	60
	.zero	4
	.quad	.LC275
	.quad	.LC276
	.long	1
	.long	2
	.quad	h_interface
	.quad	.LC277
	.long	60
	.zero	4
	.quad	.LC278
	.quad	.LC279
	.long	1
	.long	2
	.quad	h_no_interface
	.quad	.LC280
	.long	60
	.zero	4
	.quad	.LC281
	.quad	.LC282
	.long	3
	.long	4
	.quad	h_ip_route
	.quad	.LC283
	.long	60
	.zero	4
	.quad	.LC284
	.quad	.LC285
	.long	2
	.long	4
	.quad	h_no_ip_route
	.quad	.LC286
	.long	60
	.zero	4
	.quad	.LC92
	.quad	.LC33
	.long	0
	.long	0
	.quad	h_router_rip
	.quad	.LC287
	.long	60
	.zero	4
	.quad	.LC288
	.quad	.LC33
	.long	0
	.long	0
	.quad	h_no_router_rip
	.quad	.LC289
	.long	60
	.zero	4
	.quad	.LC290
	.quad	.LC291
	.long	1
	.long	1
	.quad	h_router_ospf
	.quad	.LC292
	.long	60
	.zero	4
	.quad	.LC293
	.quad	.LC291
	.long	1
	.long	1
	.quad	h_no_router_ospf
	.quad	.LC294
	.long	8
	.zero	4
	.quad	.LC295
	.quad	.LC296
	.long	2
	.long	2
	.quad	h_ip_address
	.quad	.LC297
	.long	8
	.zero	4
	.quad	.LC298
	.quad	.LC33
	.long	0
	.long	0
	.quad	h_no_ip_address
	.quad	.LC299
	.long	8
	.zero	4
	.quad	.LC300
	.quad	.LC33
	.long	0
	.long	0
	.quad	h_shutdown
	.quad	.LC301
	.long	8
	.zero	4
	.quad	.LC302
	.quad	.LC33
	.long	0
	.long	0
	.quad	h_no_shutdown
	.quad	.LC303
	.long	8
	.zero	4
	.quad	.LC304
	.quad	.LC305
	.long	1
	.long	12
	.quad	h_description
	.quad	.LC306
	.long	8
	.zero	4
	.quad	.LC307
	.quad	.LC33
	.long	0
	.long	12
	.quad	h_no_description
	.quad	.LC308
	.long	8
	.zero	4
	.quad	.LC309
	.quad	.LC310
	.long	1
	.long	1
	.quad	h_clock
	.quad	.LC311
	.long	8
	.zero	4
	.quad	.LC312
	.quad	.LC33
	.long	0
	.long	1
	.quad	h_no_clock
	.quad	.LC313
	.long	16
	.zero	4
	.quad	.LC314
	.quad	.LC315
	.long	1
	.long	1
	.quad	h_rip_version
	.quad	.LC316
	.long	16
	.zero	4
	.quad	.LC317
	.quad	.LC33
	.long	0
	.long	0
	.quad	h_autosum
	.quad	.LC318
	.long	16
	.zero	4
	.quad	.LC319
	.quad	.LC33
	.long	0
	.long	0
	.quad	h_no_autosum
	.quad	.LC320
	.long	32
	.zero	4
	.quad	.LC321
	.quad	.LC322
	.long	1
	.long	1
	.quad	h_router_id
	.quad	.LC323
	.long	32
	.zero	4
	.quad	.LC324
	.quad	.LC33
	.long	0
	.long	1
	.quad	h_no_router_id
	.quad	.LC325
	.long	48
	.zero	4
	.quad	.LC326
	.quad	.LC327
	.long	1
	.long	4
	.quad	h_network
	.quad	.LC328
	.long	48
	.zero	4
	.quad	.LC329
	.quad	.LC330
	.long	1
	.long	4
	.quad	h_no_network
	.quad	.LC331
	.long	3
	.zero	4
	.quad	.LC332
	.quad	.LC33
	.long	0
	.long	0
	.quad	h_show_ipbrief
	.quad	.LC333
	.long	3
	.zero	4
	.quad	.LC334
	.quad	.LC335
	.long	0
	.long	1
	.quad	h_show_route
	.quad	.LC336
	.long	3
	.zero	4
	.quad	.LC337
	.quad	.LC33
	.long	0
	.long	0
	.quad	h_show_protocols
	.quad	.LC338
	.long	3
	.zero	4
	.quad	.LC339
	.quad	.LC340
	.long	0
	.long	2
	.quad	h_show_if
	.quad	.LC341
	.long	3
	.zero	4
	.quad	.LC342
	.quad	.LC33
	.long	0
	.long	0
	.quad	h_show_errors
	.quad	.LC343
	.long	2
	.zero	4
	.quad	.LC344
	.quad	.LC33
	.long	0
	.long	0
	.quad	h_show_run
	.quad	.LC345
	.long	2
	.zero	4
	.quad	.LC346
	.quad	.LC33
	.long	0
	.long	0
	.quad	h_show_startup
	.quad	.LC347
	.long	3
	.zero	4
	.quad	.LC348
	.quad	.LC349
	.long	1
	.long	1
	.quad	h_ping
	.quad	.LC350
	.long	2
	.zero	4
	.quad	.LC351
	.quad	.LC352
	.long	0
	.long	1
	.quad	h_write
	.quad	.LC353
	.long	2
	.zero	4
	.quad	.LC354
	.quad	.LC33
	.long	0
	.long	0
	.quad	h_copy
	.quad	.LC353
	.long	2
	.zero	4
	.quad	.LC355
	.quad	.LC33
	.long	0
	.long	0
	.quad	h_erase
	.quad	.LC356
	.long	2
	.zero	4
	.quad	.LC357
	.quad	.LC358
	.long	1
	.long	1
	.quad	h_save
	.quad	.LC359
	.long	2
	.zero	4
	.quad	.LC360
	.quad	.LC358
	.long	1
	.long	1
	.quad	h_load
	.quad	.LC361
	.long	2
	.zero	4
	.quad	.LC362
	.quad	.LC33
	.long	0
	.long	0
	.quad	h_reload
	.quad	.LC363
	.long	2
	.zero	4
	.quad	.LC364
	.quad	.LC33
	.long	0
	.long	0
	.quad	h_validate
	.quad	.LC365
	.long	2
	.zero	4
	.quad	.LC366
	.quad	.LC367
	.long	0
	.long	1
	.quad	h_compile
	.quad	.LC368
	.long	2
	.zero	4
	.quad	.LC369
	.quad	.LC370
	.long	1
	.long	8
	.quad	h_search
	.quad	.LC371
	.section	.rodata.str1.1
.LC372:
	.string	"FastEthernet"
	.section	.data.rel.ro.local
	.align 32
	.type	IFTYPES, @object
	.size	IFTYPES, 32
IFTYPES:
	.quad	.LC142
	.quad	.LC372
	.quad	.LC48
	.quad	.LC124
	.local	st
	.comm	st,12,8
	.local	cerr
	.comm	cerr,4,4
	.local	nerr
	.comm	nerr,4,4
	.local	errlog
	.comm	errlog,8,8
	.section	.data.rel.local,"aw"
	.align 8
	.type	load_name, @object
	.size	load_name, 8
load_name:
	.quad	.LC33
	.local	load_line
	.comm	load_line,4,4
	.local	loading
	.comm	loading,4,4
	.local	quit_flag
	.comm	quit_flag,4,4
	.local	prompt_len
	.comm	prompt_len,4,4
	.local	C
	.comm	C,712,32
	.local	cur_if
	.comm	cur_if,8,8
	.local	mode
	.comm	mode,4,4
	.local	cfg
	.comm	cfg,744,32
	.section	.rodata.cst8,"aM",@progbits,8
	.align 8
.LC0:
	.long	1
	.long	1
	.ident	"GCC: (Debian 14.2.0-19) 14.2.0"
	.section	.note.GNU-stack,"",@progbits
