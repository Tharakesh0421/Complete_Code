	.file	"router_compiler.c"
	.text
	.p2align 4
	.type	connected_if, @function
connected_if:
.LFB43:
	.cfi_startproc
	movq	640+cfg(%rip), %rax
	xorl	%edx, %edx
	testq	%rax, %rax
	je	.L1
	.p2align 4
	.p2align 3
.L4:
	movl	148(%rax), %esi
	testl	%esi, %esi
	je	.L3
	movl	152(%rax), %ecx
	testl	%ecx, %ecx
	jne	.L3
	movl	140(%rax), %esi
	movl	144(%rax), %ecx
	xorl	%edi, %esi
	testl	%ecx, %esi
	jne	.L3
	testq	%rdx, %rdx
	je	.L6
	cmpl	%ecx, 144(%rdx)
	cmovb	%rax, %rdx
	.p2align 4
	.p2align 3
.L3:
	movq	176(%rax), %rax
	testq	%rax, %rax
	jne	.L4
.L1:
	movq	%rdx, %rax
	ret
	.p2align 4,,10
	.p2align 3
.L6:
	movq	%rax, %rdx
	jmp	.L3
	.cfi_endproc
.LFE43:
	.size	connected_if, .-connected_if
	.p2align 4
	.type	h_disable, @function
h_disable:
.LFB48:
	.cfi_startproc
	movl	$0, mode(%rip)
	xorl	%eax, %eax
	ret
	.cfi_endproc
.LFE48:
	.size	h_disable, .-h_disable
	.p2align 4
	.type	h_exit, @function
h_exit:
.LFB50:
	.cfi_startproc
	movl	mode(%rip), %eax
	cmpl	$2, %eax
	je	.L12
	ja	.L13
	testl	%eax, %eax
	je	.L21
	movl	$0, mode(%rip)
	xorl	%eax, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L13:
	subl	$3, %eax
	cmpl	$2, %eax
	ja	.L22
	movl	$2, mode(%rip)
	xorl	%eax, %eax
	movq	$0, cur_if(%rip)
	ret
	.p2align 4,,10
	.p2align 3
.L22:
	movl	$0, mode(%rip)
.L21:
	movl	$1, quit_flag(%rip)
	xorl	%eax, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L12:
	movl	$1, mode(%rip)
	xorl	%eax, %eax
	ret
	.cfi_endproc
.LFE50:
	.size	h_exit, .-h_exit
	.p2align 4
	.type	h_quit, @function
h_quit:
.LFB51:
	.cfi_startproc
	movl	$1, quit_flag(%rip)
	xorl	%eax, %eax
	ret
	.cfi_endproc
.LFE51:
	.size	h_quit, .-h_quit
	.p2align 4
	.type	h_end, @function
h_end:
.LFB52:
	.cfi_startproc
	movl	$1, mode(%rip)
	xorl	%eax, %eax
	movq	$0, cur_if(%rip)
	ret
	.cfi_endproc
.LFE52:
	.size	h_end, .-h_end
	.p2align 4
	.type	h_no_secret, @function
h_no_secret:
.LFB56:
	.cfi_startproc
	cmpb	$0, 64+cfg(%rip)
	movl	$1, %eax
	je	.L25
	movb	$0, 64+cfg(%rip)
	xorl	%eax, %eax
.L25:
	ret
	.cfi_endproc
.LFE56:
	.size	h_no_secret, .-h_no_secret
	.p2align 4
	.type	h_no_ip_address, @function
h_no_ip_address:
.LFB60:
	.cfi_startproc
	movq	cur_if(%rip), %rax
	movl	$1, %edx
	movl	148(%rax), %ecx
	testl	%ecx, %ecx
	je	.L28
	movl	$0, 148(%rax)
	xorl	%edx, %edx
	movq	$0, 140(%rax)
.L28:
	movl	%edx, %eax
	ret
	.cfi_endproc
.LFE60:
	.size	h_no_ip_address, .-h_no_ip_address
	.p2align 4
	.type	h_no_description, @function
h_no_description:
.LFB65:
	.cfi_startproc
	movq	cur_if(%rip), %rdx
	movl	$1, %eax
	cmpb	$0, 40(%rdx)
	je	.L31
	movb	$0, 40(%rdx)
	xorl	%eax, %eax
.L31:
	ret
	.cfi_endproc
.LFE65:
	.size	h_no_description, .-h_no_description
	.p2align 4
	.type	h_no_clock, @function
h_no_clock:
.LFB67:
	.cfi_startproc
	movq	cur_if(%rip), %rdx
	movl	$1, %eax
	cmpq	$0, 160(%rdx)
	je	.L34
	movq	$0, 160(%rdx)
	xorl	%eax, %eax
.L34:
	ret
	.cfi_endproc
.LFE67:
	.size	h_no_clock, .-h_no_clock
	.p2align 4
	.type	h_autosum, @function
h_autosum:
.LFB75:
	.cfi_startproc
	movl	688+cfg(%rip), %eax
	testl	%eax, %eax
	jne	.L39
	movl	$1, 688+cfg(%rip)
	ret
	.p2align 4,,10
	.p2align 3
.L39:
	movl	$1, %eax
	ret
	.cfi_endproc
.LFE75:
	.size	h_autosum, .-h_autosum
	.p2align 4
	.type	h_no_autosum, @function
h_no_autosum:
.LFB76:
	.cfi_startproc
	movl	688+cfg(%rip), %edx
	movl	$1, %eax
	testl	%edx, %edx
	je	.L40
	movl	$0, 688+cfg(%rip)
	xorl	%eax, %eax
.L40:
	ret
	.cfi_endproc
.LFE76:
	.size	h_no_autosum, .-h_no_autosum
	.p2align 4
	.type	h_no_router_id, @function
h_no_router_id:
.LFB78:
	.cfi_startproc
	movl	720+cfg(%rip), %edx
	movl	$1, %eax
	testl	%edx, %edx
	je	.L43
	movl	$0, 720+cfg(%rip)
	xorl	%eax, %eax
.L43:
	ret
	.cfi_endproc
.LFE78:
	.size	h_no_router_id, .-h_no_router_id
	.p2align 4
	.type	pat_split, @function
pat_split:
.LFB106:
	.cfi_startproc
	movzbl	(%rdi), %eax
	xorl	%r8d, %r8d
	testb	%al, %al
	je	.L46
	.p2align 4
	.p2align 3
.L70:
	cmpb	$32, %al
	jne	.L48
	.p2align 4
	.p2align 4
	.p2align 3
.L49:
	movzbl	1(%rdi), %eax
	addq	$1, %rdi
	cmpb	$32, %al
	je	.L49
	testb	%al, %al
	je	.L46
.L48:
	movzbl	(%rdi), %edx
	movq	%rdi, %rcx
	testb	$-33, %dl
	je	.L57
	movl	$1, %eax
	jmp	.L52
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L72:
	addq	$1, %rax
	cmpq	$24, %rax
	je	.L71
.L52:
	movb	%dl, -1(%rsi,%rax)
	movzbl	(%rcx,%rax), %edx
	leaq	(%rcx,%rax), %rdi
	testb	$-33, %dl
	jne	.L72
.L50:
	cltq
	addl	$1, %r8d
	addq	$24, %rsi
	movb	$0, -24(%rsi,%rax)
	movzbl	(%rdi), %eax
	testb	%al, %al
	jne	.L70
.L46:
	movl	%r8d, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L71:
	movl	$23, %eax
	jmp	.L50
.L57:
	xorl	%eax, %eax
	jmp	.L50
	.cfi_endproc
.LFE106:
	.size	pat_split, .-pat_split
	.section	.rodata.str1.1,"aMS",@progbits,1
.LC1:
	.string	"RIP enabled"
.LC2:
	.string	"config"
	.text
	.p2align 4
	.type	h_router_rip, @function
h_router_rip:
.LFB70:
	.cfi_startproc
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	movl	680+cfg(%rip), %eax
	testl	%eax, %eax
	jne	.L74
	movq	.LC0(%rip), %rax
	movl	$1, 688+cfg(%rip)
	movq	%rax, 680+cfg(%rip)
.L74:
	xorl	%eax, %eax
	leaq	.LC1(%rip), %rdx
	movl	$1, %edi
	movl	$4, mode(%rip)
	leaq	.LC2(%rip), %rsi
	call	rlog_log@PLT
	xorl	%eax, %eax
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE70:
	.size	h_router_rip, .-h_router_rip
	.p2align 4
	.type	route_find, @function
route_find:
.LFB39:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movq	%rsi, %rdx
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movl	672+cfg(%rip), %ebp
	subl	$1, %ebp
	js	.L88
	movq	664+cfg(%rip), %r15
	movl	(%rdi), %r14d
	movq	%rdi, %r13
	xorl	%r12d, %r12d
	jmp	.L87
	.p2align 4,,10
	.p2align 3
.L78:
	movl	4(%r13), %eax
	cmpl	%eax, 4(%rdi)
	jne	.L93
	movl	52(%rdi), %eax
	movl	52(%r13), %ecx
	cmpl	%ecx, %eax
	je	.L82
	subl	%ecx, %eax
.L83:
	testl	%eax, %eax
	js	.L79
.L80:
	leal	-1(%rbx), %ebp
	cmpl	%r12d, %ebp
	jl	.L77
.L87:
	leal	(%r12,%rbp), %eax
	movl	%eax, %ebx
	shrl	$31, %ebx
	addl	%eax, %ebx
	sarl	%ebx
	movslq	%ebx, %rcx
	movq	%rcx, %rax
	salq	$4, %rax
	subq	%rcx, %rax
	leaq	(%r15,%rax,4), %rdi
	cmpl	%r14d, (%rdi)
	je	.L78
.L93:
	jnb	.L80
.L79:
	leal	1(%rbx), %r12d
	cmpl	%r12d, %ebp
	jge	.L87
.L77:
	xorl	%eax, %eax
.L85:
	movl	%r12d, (%rdx)
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L82:
	.cfi_restore_state
	testl	%eax, %eax
	jne	.L95
	addq	$12, %rdi
	leaq	12(%r13), %rsi
	movq	%rdx, 8(%rsp)
	call	strcmp@PLT
	movq	8(%rsp), %rdx
	testl	%eax, %eax
	jne	.L83
	movl	%ebx, %r12d
	movl	$1, %eax
	jmp	.L85
	.p2align 4,,10
	.p2align 3
.L95:
	movl	8(%r13), %eax
	cmpl	%eax, 8(%rdi)
	jne	.L93
	movl	%ebx, %r12d
	movl	$1, %eax
	jmp	.L85
.L88:
	xorl	%r12d, %r12d
	jmp	.L77
	.cfi_endproc
.LFE39:
	.size	route_find, .-route_find
	.section	.rodata.str1.8,"aMS",@progbits,1
	.align 8
.LC3:
	.string	"Enter configuration commands, one per line.  End with 'end'."
	.section	.rodata.str1.1
.LC4:
	.string	"entered config mode"
.LC5:
	.string	"cli"
	.text
	.p2align 4
	.type	h_configure, @function
h_configure:
.LFB49:
	.cfi_startproc
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	movl	loading(%rip), %eax
	movl	$2, mode(%rip)
	testl	%eax, %eax
	je	.L99
.L97:
	xorl	%eax, %eax
	leaq	.LC4(%rip), %rdx
	leaq	.LC5(%rip), %rsi
	xorl	%edi, %edi
	call	rlog_log@PLT
	xorl	%eax, %eax
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L99:
	.cfi_restore_state
	leaq	.LC3(%rip), %rdi
	call	puts@PLT
	jmp	.L97
	.cfi_endproc
.LFE49:
	.size	h_configure, .-h_configure
	.section	.rodata.str1.1
.LC6:
	.string	"%04d  0x%02X  %-11s %s"
.LC7:
	.string	"%s\n"
	.text
	.p2align 4
	.type	emit, @function
emit:
.LFB94:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	movq	%rdx, %r13
	movq	%rcx, %rdx
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	movl	%esi, %r12d
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	movq	%rdi, %rbx
	subq	$688, %rsp
	.cfi_def_cfa_offset 736
	movq	%r8, 544(%rsp)
	movq	%r9, 552(%rsp)
	testb	%al, %al
	je	.L105
	movaps	%xmm0, 560(%rsp)
	movaps	%xmm1, 576(%rsp)
	movaps	%xmm2, 592(%rsp)
	movaps	%xmm3, 608(%rsp)
	movaps	%xmm4, 624(%rsp)
	movaps	%xmm5, 640(%rsp)
	movaps	%xmm6, 656(%rsp)
	movaps	%xmm7, 672(%rsp)
.L105:
	leaq	32(%rsp), %rbp
	leaq	8(%rsp), %rcx
	movl	$200, %esi
	movl	$32, 8(%rsp)
	leaq	736(%rsp), %rax
	movq	%rbp, %rdi
	movl	$48, 12(%rsp)
	leaq	240(%rsp), %r14
	movq	%rax, 16(%rsp)
	leaq	512(%rsp), %rax
	movq	%rax, 24(%rsp)
	call	vsnprintf@PLT
	movl	(%rbx), %ecx
	subq	$8, %rsp
	.cfi_def_cfa_offset 744
	movq	%r13, %r9
	leaq	.LC6(%rip), %rdx
	movl	%r12d, %r8d
	movl	$260, %esi
	movq	%r14, %rdi
	leal	1(%rcx), %eax
	movl	%eax, (%rbx)
	xorl	%eax, %eax
	pushq	%rbp
	.cfi_def_cfa_offset 752
	call	snprintf@PLT
	movq	%r14, %rdi
	call	puts@PLT
	movq	8(%rbx), %rdi
	popq	%rax
	.cfi_def_cfa_offset 744
	popq	%rdx
	.cfi_def_cfa_offset 736
	testq	%rdi, %rdi
	je	.L102
	movq	%r14, %rdx
	leaq	.LC7(%rip), %rsi
	xorl	%eax, %eax
	call	fprintf@PLT
.L102:
	movq	16(%rbx), %rax
	movq	%rax, %rdx
	salq	$6, %rdx
	addq	%rax, %rdx
	leaq	(%rax,%rdx,2), %rax
	movzbl	32(%rsp), %edx
	addq	%r12, %rax
	movq	%rax, 16(%rbx)
	testb	%dl, %dl
	je	.L100
	movq	%rbp, %rsi
	.p2align 5
	.p2align 4
	.p2align 3
.L104:
	movq	%rax, %rcx
	addq	$1, %rsi
	salq	$6, %rcx
	addq	%rax, %rcx
	leaq	(%rax,%rcx,2), %rax
	addq	%rdx, %rax
	movzbl	(%rsi), %edx
	testb	%dl, %dl
	jne	.L104
	movq	%rax, 16(%rbx)
.L100:
	addq	$688, %rsp
	.cfi_def_cfa_offset 48
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE94:
	.size	emit, .-emit
	.section	.rodata.str1.1
.LC8:
	.string	"r"
.LC9:
	.string	"startup-config.cfg"
.LC10:
	.string	"startup-config is not present"
	.text
	.p2align 4
	.type	h_show_startup, @function
h_show_startup:
.LFB84:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	leaq	.LC8(%rip), %rsi
	leaq	.LC9(%rip), %rdi
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$312, %rsp
	.cfi_def_cfa_offset 336
	call	fopen@PLT
	testq	%rax, %rax
	je	.L119
	movq	%rax, %rbp
	movq	%rsp, %rbx
	jmp	.L115
	.p2align 4,,10
	.p2align 3
.L117:
	movq	stdout(%rip), %rsi
	movq	%rbx, %rdi
	call	fputs@PLT
.L115:
	movq	%rbp, %rdx
	movl	$300, %esi
	movq	%rbx, %rdi
	call	fgets@PLT
	testq	%rax, %rax
	jne	.L117
	movq	%rbp, %rdi
	call	fclose@PLT
.L116:
	addq	$312, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L119:
	.cfi_restore_state
	leaq	.LC10(%rip), %rdi
	call	puts@PLT
	jmp	.L116
	.cfi_endproc
.LFE84:
	.size	h_show_startup, .-h_show_startup
	.p2align 4
	.type	route_remove, @function
route_remove:
.LFB41:
	.cfi_startproc
	movslq	%edi, %rax
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	notl	%edi
	addl	672+cfg(%rip), %edi
	addq	$1, %rax
	movq	664+cfg(%rip), %rsi
	movq	%rax, %rcx
	salq	$4, %rcx
	subq	%rax, %rcx
	movslq	%edi, %rax
	movq	%rax, %rdx
	salq	$2, %rcx
	salq	$4, %rdx
	leaq	-60(%rsi,%rcx), %rdi
	subq	%rax, %rdx
	leaq	(%rsi,%rcx), %rax
	salq	$2, %rdx
	movq	%rax, %rsi
	call	memmove@PLT
	subl	$1, 672+cfg(%rip)
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE41:
	.size	route_remove, .-route_remove
	.p2align 4
	.type	h_no_router_rip, @function
h_no_router_rip:
.LFB71:
	.cfi_startproc
	movl	680+cfg(%rip), %eax
	testl	%eax, %eax
	jne	.L131
	movl	$1, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L131:
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	movq	696+cfg(%rip), %rdi
	call	free@PLT
	xorl	%eax, %eax
	movq	$0, 696+cfg(%rip)
	movq	$0, 704+cfg(%rip)
	movl	$0, 680+cfg(%rip)
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE71:
	.size	h_no_router_rip, .-h_no_router_rip
	.section	.rodata.str1.1
.LC11:
	.string	"administratively down"
	.section	.rodata.str1.8
	.align 8
.LC12:
	.string	"%%LINK-5-CHANGED: Interface %s, changed state to %s\n"
	.section	.rodata.str1.1
.LC13:
	.string	"down"
	.section	.rodata.str1.8
	.align 8
.LC14:
	.string	"%%LINEPROTO-5-UPDOWN: Line protocol on Interface %s, changed state to %s\n"
	.text
	.p2align 4
	.type	h_shutdown, @function
h_shutdown:
.LFB62:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movq	cur_if(%rip), %rbx
	movl	152(%rbx), %ebp
	testl	%ebp, %ebp
	jne	.L136
	movl	$1, 152(%rbx)
	movl	loading(%rip), %eax
	testl	%eax, %eax
	jne	.L132
	leaq	.LC11(%rip), %rdx
	movq	%rbx, %rsi
	leaq	.LC12(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
	leaq	.LC13(%rip), %rdx
	movq	%rbx, %rsi
	xorl	%eax, %eax
	leaq	.LC14(%rip), %rdi
	call	printf@PLT
.L132:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	movl	%ebp, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L136:
	.cfi_restore_state
	movl	$1, %ebp
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	movl	%ebp, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE62:
	.size	h_shutdown, .-h_shutdown
	.section	.rodata.str1.1
.LC15:
	.string	"Router"
	.text
	.p2align 4
	.type	h_no_hostname, @function
h_no_hostname:
.LFB54:
	.cfi_startproc
	cmpl	$1953853266, cfg(%rip)
	je	.L143
.L139:
	movl	$1953853266, cfg(%rip)
	xorl	%eax, %eax
	movl	$7497076, 3+cfg(%rip)
	ret
	.p2align 4,,10
	.p2align 3
.L143:
	cmpl	$7497076, 3+cfg(%rip)
	jne	.L139
	movl	$1, %eax
	ret
	.cfi_endproc
.LFE54:
	.size	h_no_hostname, .-h_no_hostname
	.section	.rodata.str1.8
	.align 8
.LC16:
	.string	"No errors recorded in this session."
	.section	.rodata.str1.1
.LC17:
	.string	"%d error(s) recorded:\n"
.LC18:
	.string	"%3d. [%s] \"%s\"\n       -> %s\n"
	.text
	.p2align 4
	.type	h_show_errors, @function
h_show_errors:
.LFB90:
	.cfi_startproc
	movl	nerr(%rip), %esi
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	testl	%esi, %esi
	je	.L151
	leaq	.LC17(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
	movl	nerr(%rip), %eax
	testl	%eax, %eax
	jle	.L146
	xorl	%ebp, %ebp
	xorl	%ebx, %ebx
	leaq	.LC18(%rip), %r12
	.p2align 4
	.p2align 3
.L148:
	movq	errlog(%rip), %rdx
	addl	$1, %ebx
	xorl	%eax, %eax
	movq	%r12, %rdi
	movl	%ebx, %esi
	addq	%rbp, %rdx
	addq	$520, %rbp
	leaq	64(%rdx), %rcx
	leaq	320(%rdx), %r8
	call	printf@PLT
	cmpl	nerr(%rip), %ebx
	jl	.L148
.L146:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	xorl	%eax, %eax
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L151:
	.cfi_restore_state
	leaq	.LC16(%rip), %rdi
	call	puts@PLT
	popq	%rbx
	.cfi_def_cfa_offset 24
	xorl	%eax, %eax
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE90:
	.size	h_show_errors, .-h_show_errors
	.section	.rodata.str1.1
.LC19:
	.string	"out of memory\n"
	.text
	.p2align 4
	.type	xrealloc.part.0, @function
xrealloc.part.0:
.LFB123:
	.cfi_startproc
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	movl	$14, %edx
	movl	$1, %esi
	movq	stderr(%rip), %rcx
	leaq	.LC19(%rip), %rdi
	call	fwrite@PLT
	movl	$1, %edi
	call	exit@PLT
	.cfi_endproc
.LFE123:
	.size	xrealloc.part.0, .-xrealloc.part.0
	.p2align 4
	.type	rc_is_prefix_ci.part.0, @function
rc_is_prefix_ci.part.0:
.LFB127:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	movq	%rsi, %r13
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	movq	%rdi, %r12
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$8, %rsp
	.cfi_def_cfa_offset 48
	movzbl	(%rdi), %ebx
	testb	%bl, %bl
	jne	.L155
	jmp	.L160
	.p2align 4,,10
	.p2align 3
.L158:
	call	__ctype_tolower_loc@PLT
	movq	(%rax), %rax
	movl	(%rax,%rbp,4), %edx
	cmpl	%edx, (%rax,%rbx,4)
	jne	.L159
	movzbl	1(%r12), %ebx
	addq	$1, %r12
	addq	$1, %r13
	testb	%bl, %bl
	je	.L160
.L155:
	movzbl	0(%r13), %ebp
	testb	%bpl, %bpl
	jne	.L158
.L159:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L160:
	.cfi_restore_state
	addq	$8, %rsp
	.cfi_def_cfa_offset 40
	movl	$1, %eax
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE127:
	.size	rc_is_prefix_ci.part.0, .-rc_is_prefix_ci.part.0
	.section	.rodata.str1.1
.LC20:
	.string	"  %-34s %-26s %s\n"
.LC21:
	.string	"% Unrecognized command"
	.section	.rodata.str1.8
	.align 8
.LC22:
	.string	"  (abbreviations work: conf t, int g0/0, sh ip int br, no sh ...)"
	.text
	.p2align 4
	.type	show_help, @function
show_help:
.LFB108:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	leaq	CMDS(%rip), %r15
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	leaq	2448(%r15), %rbx
	subq	$152, %rsp
	.cfi_def_cfa_offset 208
	movl	%edi, 8(%rsp)
	movl	$0, 12(%rsp)
	jmp	.L169
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L168:
	addq	$48, %r15
	cmpq	%rbx, %r15
	je	.L181
.L169:
	movl	(%r15), %edx
	movl	mode(%rip), %eax
	btl	%eax, %edx
	jnc	.L168
	movq	8(%r15), %r12
	leaq	16(%rsp), %r13
	movq	%r13, %rsi
	movq	%r12, %rdi
	call	pat_split
	movl	8(%rsp), %ecx
	cmpl	%ecx, %eax
	cmovg	%ecx, %eax
	testl	%eax, %eax
	jle	.L166
	leaq	C(%rip), %r14
	cltq
	leaq	(%r14,%rax,8), %rbp
.L167:
	movq	512(%r14), %rdi
	cmpb	$0, (%rdi)
	je	.L168
	movq	%r13, %rsi
	call	rc_is_prefix_ci.part.0
	testl	%eax, %eax
	je	.L168
	addq	$8, %r14
	addq	$24, %r13
	cmpq	%rbp, %r14
	jne	.L167
.L166:
	movq	40(%r15), %rcx
	movq	16(%r15), %rdx
	movq	%r12, %rsi
	xorl	%eax, %eax
	leaq	.LC20(%rip), %rdi
	addq	$48, %r15
	call	printf@PLT
	addl	$1, 12(%rsp)
	cmpq	%rbx, %r15
	jne	.L169
	.p2align 4
	.p2align 3
.L181:
	movl	12(%rsp), %eax
	leaq	.LC21(%rip), %rdi
	testl	%eax, %eax
	je	.L180
	leaq	.LC22(%rip), %rdi
.L180:
	addq	$152, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	jmp	puts@PLT
	.cfi_endproc
.LFE108:
	.size	show_help, .-show_help
	.p2align 4
	.type	h_help, @function
h_help:
.LFB109:
	.cfi_startproc
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	xorl	%edi, %edi
	movl	$0, 704+C(%rip)
	call	show_help
	xorl	%eax, %eax
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE109:
	.size	h_help, .-h_help
	.p2align 4
	.type	rc_parse_uint.part.0, @function
rc_parse_uint.part.0:
.LFB129:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	movq	%rcx, %r13
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	movq	%rsi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	movzbl	(%rdi), %ebx
	testb	%bl, %bl
	je	.L188
	movq	%rdi, %r14
	movq	%rdx, %r12
	call	__ctype_b_loc@PLT
	leaq	10(%r14), %rsi
	movq	(%rax), %rcx
	xorl	%eax, %eax
	jmp	.L187
	.p2align 4,,10
	.p2align 3
.L195:
	movsbl	%bl, %ebx
	leaq	(%rax,%rax,4), %rax
	addq	$1, %r14
	subl	$48, %ebx
	movslq	%ebx, %rbx
	leaq	(%rbx,%rax,2), %rax
	movzbl	(%r14), %ebx
	testb	%bl, %bl
	je	.L194
.L187:
	movzbl	%bl, %edx
	testb	$8, 1(%rcx,%rdx,2)
	je	.L191
	cmpq	%r14, %rsi
	jne	.L195
.L191:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	xorl	%eax, %eax
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L194:
	.cfi_restore_state
	cmpq	%rax, %r12
	setb	%dl
.L185:
	cmpq	%rbp, %rax
	jb	.L191
	testb	%dl, %dl
	jne	.L191
	movq	%rax, 0(%r13)
	movl	$1, %eax
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
.L188:
	.cfi_restore_state
	xorl	%edx, %edx
	xorl	%eax, %eax
	jmp	.L185
	.cfi_endproc
.LFE129:
	.size	rc_parse_uint.part.0, .-rc_parse_uint.part.0
	.section	.rodata.str1.1
.LC23:
	.string	"up"
	.text
	.p2align 4
	.type	h_no_shutdown, @function
h_no_shutdown:
.LFB63:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movl	$1, %eax
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movq	cur_if(%rip), %rbx
	movl	152(%rbx), %edx
	testl	%edx, %edx
	je	.L196
	movl	$0, 152(%rbx)
	movl	loading(%rip), %eax
	testl	%eax, %eax
	jne	.L199
	leaq	.LC23(%rip), %rbp
	movq	%rbx, %rsi
	leaq	.LC12(%rip), %rdi
	xorl	%eax, %eax
	movq	%rbp, %rdx
	call	printf@PLT
	movq	%rbp, %rdx
	movq	%rbx, %rsi
	xorl	%eax, %eax
	leaq	.LC14(%rip), %rdi
	call	printf@PLT
.L199:
	xorl	%eax, %eax
.L196:
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE63:
	.size	h_no_shutdown, .-h_no_shutdown
	.p2align 4
	.type	addf, @function
addf:
.LFB26:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	movq	%rdi, %rbx
	subq	$520, %rsp
	.cfi_def_cfa_offset 560
	movq	%rdx, 352(%rsp)
	movq	%rcx, 360(%rsp)
	movq	%r8, 368(%rsp)
	movq	%r9, 376(%rsp)
	testb	%al, %al
	je	.L214
	movaps	%xmm0, 384(%rsp)
	movaps	%xmm1, 400(%rsp)
	movaps	%xmm2, 416(%rsp)
	movaps	%xmm3, 432(%rsp)
	movaps	%xmm4, 448(%rsp)
	movaps	%xmm5, 464(%rsp)
	movaps	%xmm6, 480(%rsp)
	movaps	%xmm7, 496(%rsp)
.L214:
	leaq	560(%rsp), %rax
	leaq	32(%rsp), %rbp
	movq	%rsi, %rdx
	movl	$300, %esi
	movq	%rax, 16(%rsp)
	movq	%rbp, %rdi
	leaq	336(%rsp), %rax
	leaq	8(%rsp), %rcx
	movl	$16, 8(%rsp)
	movl	$48, 12(%rsp)
	movq	%rax, 24(%rsp)
	call	vsnprintf@PLT
	movslq	8(%rbx), %rdx
	movl	12(%rbx), %eax
	movq	(%rbx), %rdi
	cmpl	%eax, %edx
	jl	.L205
	testl	%eax, %eax
	jne	.L219
	movl	$64, %esi
	movl	$8, %eax
.L206:
	movl	%eax, 12(%rbx)
	call	realloc@PLT
	movq	%rax, %rdi
	testq	%rax, %rax
	je	.L220
	movq	%rax, (%rbx)
	movslq	8(%rbx), %rdx
.L205:
	leal	1(%rdx), %eax
	leaq	(%rdi,%rdx,8), %r13
	movq	%rbp, %rdi
	movl	%eax, 8(%rbx)
	call	strlen@PLT
	leaq	1(%rax), %r12
	movq	%rax, %rbx
	movq	%r12, %rdi
	call	malloc@PLT
	testq	%rax, %rax
	je	.L221
	cmpl	$8, %r12d
	jnb	.L209
	testb	$4, %r12b
	jne	.L222
	testl	%r12d, %r12d
	je	.L210
	movzbl	32(%rsp), %edx
	movb	%dl, (%rax)
	testb	$2, %r12b
	je	.L210
	movl	%r12d, %r12d
	movzwl	-2(%rbp,%r12), %edx
	movw	%dx, -2(%rax,%r12)
	jmp	.L210
	.p2align 4,,10
	.p2align 3
.L209:
	movl	%r12d, %r12d
	shrl	$3, %ebx
	movq	%rax, %rdi
	movq	%rbp, %rsi
	movq	-8(%rbp,%r12), %rdx
	movl	%ebx, %ecx
	movq	%rdx, -8(%rax,%r12)
	rep movsq
.L210:
	movq	%rax, 0(%r13)
	addq	$520, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L219:
	.cfi_restore_state
	addl	%eax, %eax
	movslq	%eax, %rsi
	salq	$3, %rsi
	jmp	.L206
	.p2align 4,,10
	.p2align 3
.L222:
	movl	32(%rsp), %edx
	movl	%r12d, %r12d
	movl	%edx, (%rax)
	movl	-4(%rbp,%r12), %edx
	movl	%edx, -4(%rax,%r12)
	jmp	.L210
.L221:
	movq	stderr(%rip), %rcx
	movl	$14, %edx
	movl	$1, %esi
	leaq	.LC19(%rip), %rdi
	call	fwrite@PLT
	movl	$1, %edi
	call	exit@PLT
.L220:
	call	xrealloc.part.0
	.cfi_endproc
.LFE26:
	.size	addf, .-addf
	.section	.rodata.str1.1
.LC24:
	.string	"  %s:%d: %% %s\n"
.LC25:
	.string	"%s:%d %s"
.LC26:
	.string	"parser"
.LC27:
	.string	"%% %s\n"
.LC28:
	.string	"%s"
.LC29:
	.string	"%s:%d"
.LC30:
	.string	"cmd #%d"
	.text
	.p2align 4
	.type	err, @function
err:
.LFB28:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	subq	$416, %rsp
	.cfi_def_cfa_offset 448
	movq	%rsi, 248(%rsp)
	movq	%rdx, 256(%rsp)
	movq	%rcx, 264(%rsp)
	movq	%r8, 272(%rsp)
	movq	%r9, 280(%rsp)
	testb	%al, %al
	je	.L233
	movaps	%xmm0, 288(%rsp)
	movaps	%xmm1, 304(%rsp)
	movaps	%xmm2, 320(%rsp)
	movaps	%xmm3, 336(%rsp)
	movaps	%xmm4, 352(%rsp)
	movaps	%xmm5, 368(%rsp)
	movaps	%xmm6, 384(%rsp)
	movaps	%xmm7, 400(%rsp)
.L233:
	leaq	448(%rsp), %rax
	leaq	32(%rsp), %rbp
	movq	%rdi, %rdx
	movl	$200, %esi
	movq	%rax, 16(%rsp)
	leaq	8(%rsp), %rcx
	leaq	240(%rsp), %rax
	movq	%rbp, %rdi
	movl	$8, 8(%rsp)
	movl	$48, 12(%rsp)
	movq	%rax, 24(%rsp)
	call	vsnprintf@PLT
	movl	loading(%rip), %edx
	testl	%edx, %edx
	je	.L225
	movl	load_line(%rip), %edx
	movq	load_name(%rip), %rsi
	movq	%rbp, %rcx
	xorl	%eax, %eax
	leaq	.LC24(%rip), %rdi
	call	printf@PLT
	movl	load_line(%rip), %r8d
	movq	%rbp, %r9
	xorl	%eax, %eax
	movq	load_name(%rip), %rcx
	leaq	.LC25(%rip), %rdx
	movl	$2, %edi
	leaq	.LC26(%rip), %rsi
	call	rlog_log@PLT
.L226:
	movslq	nerr(%rip), %rbx
	movl	cerr(%rip), %eax
	movq	errlog(%rip), %rdi
	cmpl	%eax, %ebx
	jl	.L227
	testl	%eax, %eax
	jne	.L235
	movl	$4160, %esi
	movl	$8, %eax
.L228:
	movl	%eax, cerr(%rip)
	call	realloc@PLT
	movq	%rax, %rdi
	testq	%rax, %rax
	je	.L236
	movq	%rax, errlog(%rip)
.L227:
	leal	1(%rbx), %eax
	movl	%eax, nerr(%rip)
	movq	%rbx, %rax
	salq	$6, %rax
	addq	%rbx, %rax
	leaq	(%rdi,%rax,8), %rbx
	movl	loading(%rip), %eax
	testl	%eax, %eax
	je	.L230
	movl	load_line(%rip), %r8d
	movl	$64, %esi
	movq	%rbx, %rdi
	xorl	%eax, %eax
	movq	load_name(%rip), %rcx
	leaq	.LC29(%rip), %rdx
	call	snprintf@PLT
.L231:
	leaq	.LC28(%rip), %r12
	leaq	64(%rbx), %rdi
	movl	$256, %esi
	xorl	%eax, %eax
	movq	%r12, %rdx
	leaq	C(%rip), %rcx
	call	snprintf@PLT
	movq	%rbp, %rcx
	movq	%r12, %rdx
	movl	$200, %esi
	leaq	320(%rbx), %rdi
	xorl	%eax, %eax
	call	snprintf@PLT
	addq	$416, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 32
	movl	$-1, %eax
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L225:
	.cfi_restore_state
	movq	%rbp, %rsi
	leaq	.LC27(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
	movq	%rbp, %rcx
	movl	$2, %edi
	xorl	%eax, %eax
	leaq	.LC28(%rip), %rdx
	leaq	.LC26(%rip), %rsi
	call	rlog_log@PLT
	jmp	.L226
	.p2align 4,,10
	.p2align 3
.L230:
	movl	st(%rip), %ecx
	movl	$64, %esi
	movq	%rbx, %rdi
	xorl	%eax, %eax
	leaq	.LC30(%rip), %rdx
	call	snprintf@PLT
	jmp	.L231
	.p2align 4,,10
	.p2align 3
.L235:
	addl	%eax, %eax
	movslq	%eax, %rdx
	movq	%rdx, %rsi
	salq	$6, %rsi
	addq	%rdx, %rsi
	salq	$3, %rsi
	jmp	.L228
.L236:
	call	xrealloc.part.0
	.cfi_endproc
.LFE28:
	.size	err, .-err
	.section	.rodata.str1.1
.LC31:
	.string	"Password: "
.LC32:
	.string	"Access denied"
.LC33:
	.string	"entered privileged EXEC"
	.text
	.p2align 4
	.type	h_enable, @function
h_enable:
.LFB47:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	subq	$112, %rsp
	.cfi_def_cfa_offset 128
	cmpb	$0, 64+cfg(%rip)
	je	.L238
	movl	loading(%rip), %eax
	testl	%eax, %eax
	je	.L254
.L238:
	xorl	%eax, %eax
	leaq	.LC33(%rip), %rdx
	leaq	.LC5(%rip), %rsi
	xorl	%edi, %edi
	movl	$1, mode(%rip)
	call	rlog_log@PLT
	xorl	%eax, %eax
.L237:
	addq	$112, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L254:
	.cfi_restore_state
	leaq	.LC31(%rip), %rdi
	xorl	%eax, %eax
	movq	%rsp, %rbx
	call	printf@PLT
	movq	stdout(%rip), %rdi
	call	fflush@PLT
	movq	stdin(%rip), %rdx
	movl	$100, %esi
	movq	%rsp, %rdi
	call	fgets@PLT
	testq	%rax, %rax
	je	.L239
	movq	%rsp, %rdi
	call	strlen@PLT
	testq	%rax, %rax
	jne	.L240
	jmp	.L243
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L244:
	movb	$0, (%rbx,%rax)
	testq	%rax, %rax
	je	.L243
.L240:
	subq	$1, %rax
	movzbl	(%rbx,%rax), %edx
	cmpb	$10, %dl
	je	.L244
	cmpb	$13, %dl
	je	.L244
.L243:
	leaq	64+cfg(%rip), %rsi
	movq	%rbx, %rdi
	call	strcmp@PLT
	testl	%eax, %eax
	je	.L238
	leaq	.LC32(%rip), %rdi
	xorl	%eax, %eax
	call	err
.L239:
	movl	$-1, %eax
	jmp	.L237
	.cfi_endproc
.LFE47:
	.size	h_enable, .-h_enable
	.section	.rodata.str1.1
.LC34:
	.string	"No startup-config to erase."
.LC35:
	.string	"[OK] startup-config erased"
	.text
	.p2align 4
	.type	h_erase, @function
h_erase:
.LFB101:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	leaq	.LC9(%rip), %rdi
	call	remove@PLT
	testl	%eax, %eax
	jne	.L259
	leaq	.LC35(%rip), %rdi
	movl	%eax, %ebx
	call	puts@PLT
.L255:
	movl	%ebx, %eax
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L259:
	.cfi_restore_state
	leaq	.LC34(%rip), %rdi
	xorl	%eax, %eax
	movl	$-1, %ebx
	call	err
	jmp	.L255
	.cfi_endproc
.LFE101:
	.size	h_erase, .-h_erase
	.p2align 4
	.type	if_find, @function
if_find:
.LFB33:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rdi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movzbl	(%rdi), %ebx
	testb	%bl, %bl
	je	.L265
	call	__ctype_tolower_loc@PLT
	movq	%rbp, %rdx
	movq	(%rax), %rsi
	movl	$5381, %eax
	.p2align 5
	.p2align 4
	.p2align 3
.L262:
	movl	%eax, %ecx
	addq	$1, %rdx
	sall	$5, %ecx
	addl	%ecx, %eax
	movzbl	(%rsi,%rbx,4), %ecx
	movzbl	(%rdx), %ebx
	addl	%ecx, %eax
	testb	%bl, %bl
	jne	.L262
	andl	$63, %eax
.L261:
	leaq	cfg(%rip), %rdx
	movq	128(%rdx,%rax,8), %rbx
	testq	%rbx, %rbx
	jne	.L264
	jmp	.L260
	.p2align 4,,10
	.p2align 3
.L275:
	movq	168(%rbx), %rbx
	testq	%rbx, %rbx
	je	.L260
.L264:
	movq	%rbp, %rsi
	movq	%rbx, %rdi
	call	strcmp@PLT
	testl	%eax, %eax
	jne	.L275
.L260:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	movq	%rbx, %rax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L265:
	.cfi_restore_state
	movl	$5, %eax
	jmp	.L261
	.cfi_endproc
.LFE33:
	.size	if_find, .-if_find
	.section	.rodata.str1.1
.LC36:
	.string	""
.LC37:
	.string	"%*s^\n"
	.text
	.p2align 4
	.type	bad_arg, @function
bad_arg:
.LFB30:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movl	%edi, %ebx
	subq	$376, %rsp
	.cfi_def_cfa_offset 400
	movq	%rdx, 208(%rsp)
	movq	%rcx, 216(%rsp)
	movq	%r8, 224(%rsp)
	movq	%r9, 232(%rsp)
	testb	%al, %al
	je	.L281
	movaps	%xmm0, 240(%rsp)
	movaps	%xmm1, 256(%rsp)
	movaps	%xmm2, 272(%rsp)
	movaps	%xmm3, 288(%rsp)
	movaps	%xmm4, 304(%rsp)
	movaps	%xmm5, 320(%rsp)
	movaps	%xmm6, 336(%rsp)
	movaps	%xmm7, 352(%rsp)
.L281:
	leaq	400(%rsp), %rax
	leaq	32(%rsp), %rbp
	movq	%rsi, %rdx
	movl	$160, %esi
	movq	%rax, 16(%rsp)
	leaq	8(%rsp), %rcx
	leaq	192(%rsp), %rax
	movq	%rbp, %rdi
	movl	$16, 8(%rsp)
	movl	$48, 12(%rsp)
	movq	%rax, 24(%rsp)
	call	vsnprintf@PLT
	movl	loading(%rip), %eax
	testl	%eax, %eax
	jne	.L278
	addl	708+C(%rip), %ebx
	leaq	C(%rip), %rax
	movslq	%ebx, %rdi
	cmpl	704+C(%rip), %edi
	jl	.L283
	movq	%rax, %rdi
	call	strlen@PLT
	movl	%eax, %esi
.L280:
	addl	prompt_len(%rip), %esi
	leaq	.LC36(%rip), %rdx
	leaq	.LC37(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
.L278:
	movq	%rbp, %rsi
	leaq	.LC28(%rip), %rdi
	xorl	%eax, %eax
	call	err
	addq	$376, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	movl	$-1, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L283:
	.cfi_restore_state
	movl	640(%rax,%rdi,4), %esi
	jmp	.L280
	.cfi_endproc
.LFE30:
	.size	bad_arg, .-bad_arg
	.section	.rodata.str1.1
.LC38:
	.string	"RIP version must be 1 or 2."
	.text
	.p2align 4
	.type	h_rip_version, @function
h_rip_version:
.LFB74:
	.cfi_startproc
	movq	(%rsi), %rax
	movzbl	(%rax), %edx
	cmpl	$49, %edx
	jne	.L290
	cmpb	$0, 1(%rax)
	jne	.L290
.L286:
	movsbl	(%rax), %eax
	movl	$1, %edx
	subl	$48, %eax
	cmpl	%eax, 684+cfg(%rip)
	je	.L299
	movl	%eax, 684+cfg(%rip)
	xorl	%edx, %edx
.L299:
	movl	%edx, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L290:
	cmpl	$50, %edx
	je	.L301
.L291:
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	leaq	.LC38(%rip), %rsi
	xorl	%edi, %edi
	xorl	%eax, %eax
	call	bad_arg
	movl	$-1, %eax
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L301:
	cmpb	$0, 1(%rax)
	je	.L286
	jmp	.L291
	.cfi_endproc
.LFE74:
	.size	h_rip_version, .-h_rip_version
	.section	.rodata.str1.8
	.align 8
.LC39:
	.string	"Description too long (max 99 characters)."
	.text
	.p2align 4
	.type	h_description, @function
h_description:
.LFB64:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movslq	708+C(%rip), %rax
	cmpl	704+C(%rip), %eax
	jge	.L305
	leaq	C(%rip), %rdx
	movslq	640(%rdx,%rax,4), %rbx
	addq	%rdx, %rbx
	movq	%rbx, %rdi
	call	strlen@PLT
	cmpq	$99, %rax
	ja	.L309
.L303:
	movq	cur_if(%rip), %rax
	movq	%rbx, %rsi
	leaq	40(%rax), %rbp
	movq	%rbp, %rdi
	call	strcmp@PLT
	movl	%eax, %edx
	movl	$1, %eax
	testl	%edx, %edx
	jne	.L310
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L305:
	.cfi_restore_state
	leaq	.LC36(%rip), %rbx
	jmp	.L303
	.p2align 4,,10
	.p2align 3
.L310:
	movq	%rbx, %rcx
	movq	%rbp, %rdi
	leaq	.LC28(%rip), %rdx
	xorl	%eax, %eax
	movl	$100, %esi
	call	snprintf@PLT
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L309:
	.cfi_restore_state
	leaq	.LC39(%rip), %rsi
	xorl	%edi, %edi
	xorl	%eax, %eax
	call	bad_arg
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	movl	$-1, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE64:
	.size	h_description, .-h_description
	.section	.rodata.str1.1
.LC40:
	.string	"Password too long (max 63)."
	.text
	.p2align 4
	.type	h_secret, @function
h_secret:
.LFB55:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movq	(%rsi), %rbx
	movq	%rbx, %rdi
	call	strlen@PLT
	cmpq	$63, %rax
	ja	.L317
	leaq	64+cfg(%rip), %rbp
	movq	%rbx, %rsi
	movq	%rbp, %rdi
	call	strcmp@PLT
	movl	%eax, %edx
	movl	$1, %eax
	testl	%edx, %edx
	jne	.L318
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L318:
	.cfi_restore_state
	movq	%rbx, %rcx
	movq	%rbp, %rdi
	leaq	.LC28(%rip), %rdx
	xorl	%eax, %eax
	movl	$64, %esi
	call	snprintf@PLT
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L317:
	.cfi_restore_state
	leaq	.LC40(%rip), %rsi
	xorl	%edi, %edi
	xorl	%eax, %eax
	call	bad_arg
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	movl	$-1, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE55:
	.size	h_secret, .-h_secret
	.section	.rodata.str1.8
	.align 8
.LC41:
	.string	"Hostname must start with a letter and be at most 63 characters."
	.align 8
.LC42:
	.string	"Hostname may contain only letters, digits, '-' and '_'."
	.section	.rodata.str1.1
.LC43:
	.string	"hostname -> %s"
	.text
	.p2align 4
	.type	h_hostname, @function
h_hostname:
.LFB53:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$8, %rsp
	.cfi_def_cfa_offset 48
	movq	(%rsi), %rbp
	call	__ctype_b_loc@PLT
	movq	(%rax), %r13
	movzbl	0(%rbp), %eax
	movzwl	0(%r13,%rax,2), %r12d
	testw	$1024, %r12w
	je	.L320
	movq	%rbp, %rdi
	movq	%rax, %rbx
	call	strlen@PLT
	cmpq	$63, %rax
	ja	.L320
	testb	%bl, %bl
	je	.L321
	leaq	1(%rbp), %rax
	jmp	.L322
	.p2align 4,,10
	.p2align 3
.L345:
	movzbl	%bl, %edx
	movzwl	0(%r13,%rdx,2), %r12d
.L322:
	cmpb	$45, %bl
	setne	%cl
	cmpb	$95, %bl
	setne	%dl
	testb	%dl, %cl
	je	.L324
	andl	$8, %r12d
	je	.L344
.L324:
	movzbl	(%rax), %ebx
	addq	$1, %rax
	testb	%bl, %bl
	jne	.L345
.L321:
	leaq	cfg(%rip), %rbx
	movq	%rbp, %rsi
	movq	%rbx, %rdi
	call	strcmp@PLT
	movl	%eax, %edx
	movl	$1, %eax
	testl	%edx, %edx
	je	.L319
	movq	%rbp, %rcx
	leaq	.LC28(%rip), %rdx
	movq	%rbx, %rdi
	xorl	%eax, %eax
	movl	$64, %esi
	call	snprintf@PLT
	xorl	%eax, %eax
	movq	%rbp, %rcx
	movl	$1, %edi
	leaq	.LC43(%rip), %rdx
	leaq	.LC2(%rip), %rsi
	call	rlog_log@PLT
	xorl	%eax, %eax
.L319:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L320:
	.cfi_restore_state
	leaq	.LC41(%rip), %rsi
	xorl	%edi, %edi
	xorl	%eax, %eax
	call	bad_arg
.L323:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	movl	$-1, %eax
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L344:
	.cfi_restore_state
	leaq	.LC42(%rip), %rsi
	xorl	%edi, %edi
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L323
	.cfi_endproc
.LFE53:
	.size	h_hostname, .-h_hostname
	.section	.rodata.str1.1
.LC44:
	.string	"Serial"
	.section	.rodata.str1.8
	.align 8
.LC45:
	.string	"Clock rate can only be set on Serial interfaces."
	.align 8
.LC46:
	.string	"Clock rate must be 1200-8000000 (e.g. 64000)."
	.text
	.p2align 4
	.type	h_clock, @function
h_clock:
.LFB66:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	movl	$6, %edx
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	movq	%rsi, %rbp
	leaq	.LC44(%rip), %rsi
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	subq	$16, %rsp
	.cfi_def_cfa_offset 48
	movq	cur_if(%rip), %r12
	movq	%r12, %rdi
	call	strncmp@PLT
	testl	%eax, %eax
	jne	.L357
	movq	0(%rbp), %rdi
	cmpb	$0, (%rdi)
	je	.L351
	leaq	8(%rsp), %rcx
	movl	$8000000, %edx
	movl	$1200, %esi
	movl	%eax, %ebx
	call	rc_parse_uint.part.0
	testl	%eax, %eax
	je	.L351
	movq	8(%rsp), %rdx
	cmpq	%rdx, 160(%r12)
	je	.L352
	movq	%rdx, 160(%r12)
.L346:
	addq	$16, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 32
	movl	%ebx, %eax
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L351:
	.cfi_restore_state
	leaq	.LC46(%rip), %rsi
	xorl	%edi, %edi
	xorl	%eax, %eax
	call	bad_arg
.L348:
	addq	$16, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 32
	movl	$-1, %ebx
	movl	%ebx, %eax
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L357:
	.cfi_restore_state
	leaq	.LC45(%rip), %rdi
	xorl	%eax, %eax
	call	err
	jmp	.L348
	.p2align 4,,10
	.p2align 3
.L352:
	movl	%eax, %ebx
	jmp	.L346
	.cfi_endproc
.LFE66:
	.size	h_clock, .-h_clock
	.section	.rodata.str1.8
	.align 8
.LC47:
	.string	"OSPF process id must be 1-65535."
	.align 8
.LC48:
	.string	"OSPF process %llu is not configured."
	.text
	.p2align 4
	.type	h_no_router_ospf, @function
h_no_router_ospf:
.LFB73:
	.cfi_startproc
	subq	$24, %rsp
	.cfi_def_cfa_offset 32
	movq	(%rsi), %rdi
	cmpb	$0, (%rdi)
	je	.L361
	leaq	8(%rsp), %rcx
	movl	$65535, %edx
	movl	$1, %esi
	call	rc_parse_uint.part.0
	testl	%eax, %eax
	je	.L361
	movl	712+cfg(%rip), %eax
	movq	8(%rsp), %rsi
	testl	%eax, %eax
	je	.L362
	cmpl	%esi, 716+cfg(%rip)
	jne	.L362
	movq	728+cfg(%rip), %rdi
	call	free@PLT
	xorl	%eax, %eax
	movq	$0, 728+cfg(%rip)
	movq	$0, 736+cfg(%rip)
	movl	$0, 712+cfg(%rip)
	movl	$0, 720+cfg(%rip)
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L361:
	.cfi_restore_state
	leaq	.LC47(%rip), %rsi
	xorl	%edi, %edi
	xorl	%eax, %eax
	call	bad_arg
.L360:
	movl	$-1, %eax
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L362:
	.cfi_restore_state
	leaq	.LC48(%rip), %rdi
	xorl	%eax, %eax
	call	err
	jmp	.L360
	.cfi_endproc
.LFE73:
	.size	h_no_router_ospf, .-h_no_router_ospf
	.section	.rodata.str1.8
	.align 8
.LC49:
	.string	"OSPF process %d already exists (this compiler supports one OSPF process)."
	.section	.rodata.str1.1
.LC50:
	.string	"OSPF %d enabled"
	.text
	.p2align 4
	.type	h_router_ospf, @function
h_router_ospf:
.LFB72:
	.cfi_startproc
	subq	$24, %rsp
	.cfi_def_cfa_offset 32
	movq	(%rsi), %rdi
	cmpb	$0, (%rdi)
	je	.L372
	leaq	8(%rsp), %rcx
	movl	$65535, %edx
	movl	$1, %esi
	call	rc_parse_uint.part.0
	testl	%eax, %eax
	je	.L372
	movq	8(%rsp), %rax
	movl	712+cfg(%rip), %edx
	movl	%eax, %ecx
	testl	%edx, %edx
	je	.L373
	movl	716+cfg(%rip), %esi
	cmpl	%eax, %esi
	jne	.L380
.L374:
	xorl	%eax, %eax
	leaq	.LC50(%rip), %rdx
	movl	$1, %edi
	movl	$5, mode(%rip)
	leaq	.LC2(%rip), %rsi
	call	rlog_log@PLT
	xorl	%eax, %eax
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L373:
	.cfi_restore_state
	movl	$1, 712+cfg(%rip)
	movl	%eax, 716+cfg(%rip)
	jmp	.L374
	.p2align 4,,10
	.p2align 3
.L372:
	leaq	.LC47(%rip), %rsi
	xorl	%edi, %edi
	xorl	%eax, %eax
	call	bad_arg
.L371:
	movl	$-1, %eax
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L380:
	.cfi_restore_state
	leaq	.LC49(%rip), %rdi
	xorl	%eax, %eax
	call	err
	jmp	.L371
	.cfi_endproc
.LFE72:
	.size	h_router_ospf, .-h_router_ospf
	.p2align 4
	.type	lookup, @function
lookup:
.LFB45:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movl	$-1, %r15d
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	movl	%edi, %r13d
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$40, %rsp
	.cfi_def_cfa_offset 96
	movq	640+cfg(%rip), %rdx
	movl	$999, 4(%rsp)
	movl	$0, 24(%rsp)
	testq	%rdx, %rdx
	jne	.L391
	jmp	.L382
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L383:
	movq	176(%rdx), %rdx
	testq	%rdx, %rdx
	je	.L382
.L391:
	movl	148(%rdx), %r9d
	testl	%r9d, %r9d
	je	.L383
	movl	152(%rdx), %r8d
	testl	%r8d, %r8d
	jne	.L383
	movl	140(%rdx), %r10d
	movl	144(%rdx), %r9d
	movl	%r10d, %eax
	xorl	%r13d, %eax
	testl	%r9d, %eax
	jne	.L383
	testl	%r9d, %r9d
	je	.L384
	xorl	%edi, %edi
	movl	%r9d, %eax
	.p2align 4
	.p2align 4
	.p2align 3
.L385:
	movl	%eax, %r8d
	andl	$1, %r8d
	addl	%r8d, %edi
	shrl	%eax
	jne	.L385
	cmpl	%r15d, %edi
	jg	.L403
	xorl	%edi, %edi
	movl	%r9d, %eax
	.p2align 4
	.p2align 4
	.p2align 3
.L389:
	movl	%eax, %r8d
	andl	$1, %r8d
	addl	%r8d, %edi
	shrl	%eax
	jne	.L389
	cmpl	%r15d, %edi
	jne	.L383
	movl	4(%rsp), %ecx
	testl	%ecx, %ecx
	je	.L383
	.p2align 4
	.p2align 3
.L403:
	xorl	%r15d, %r15d
	movl	%r9d, %eax
	.p2align 4
	.p2align 4
	.p2align 3
.L390:
	movl	%eax, %edi
	andl	$1, %edi
	addl	%edi, %r15d
	shrl	%eax
	jne	.L390
.L387:
	andl	%r9d, %r10d
	movb	$67, (%rsi)
	movd	%r9d, %xmm3
	movq	%rdx, 16(%rsi)
	movd	%r10d, %xmm0
	movq	176(%rdx), %rdx
	punpckldq	%xmm3, %xmm0
	movq	$0, 24(%rsi)
	movl	$0, 12(%rsi)
	movl	$0, 4(%rsp)
	movl	$1, 24(%rsp)
	movq	%xmm0, 4(%rsi)
	testq	%rdx, %rdx
	jne	.L391
	.p2align 4
	.p2align 3
.L382:
	movslq	672+cfg(%rip), %rax
	testl	%eax, %eax
	jle	.L381
	movq	664+cfg(%rip), %rcx
	movq	%rax, %rdx
	salq	$4, %rdx
	leaq	12(%rcx), %rbp
	subq	%rax, %rdx
	leaq	0(%rbp,%rdx,4), %r12
	.p2align 4
	.p2align 3
.L400:
	movl	-8(%rbp), %r14d
	testl	%r14d, %r14d
	je	.L404
	movl	%r14d, %eax
	xorl	%ebx, %ebx
	.p2align 4
	.p2align 4
	.p2align 3
.L394:
	movl	%eax, %edx
	andl	$1, %edx
	addl	%edx, %ebx
	shrl	%eax
	jne	.L394
.L393:
	movl	%r14d, %eax
	movl	-12(%rbp), %edx
	andl	%r13d, %eax
	cmpl	%edx, %eax
	je	.L423
.L395:
	addq	$60, %rbp
	cmpq	%r12, %rbp
	jne	.L400
.L381:
	movl	24(%rsp), %eax
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L423:
	.cfi_restore_state
	movl	40(%rbp), %r9d
	testl	%r9d, %r9d
	jne	.L424
	movq	%rbp, %rdi
	movq	%rsi, 8(%rsp)
	movl	%r9d, 28(%rsp)
	movl	%edx, 16(%rsp)
	call	if_find
	movq	8(%rsp), %rsi
	testq	%rax, %rax
	je	.L395
	movl	152(%rax), %eax
	movl	16(%rsp), %edx
	movl	28(%rsp), %r9d
	testl	%eax, %eax
	jne	.L395
	cmpl	%ebx, %r15d
	jge	.L398
.L425:
	movl	44(%rbp), %eax
	movl	%eax, 4(%rsp)
.L399:
	movd	%edx, %xmm0
	movd	%r14d, %xmm1
	movb	$83, (%rsi)
	movl	%ebx, %r15d
	punpckldq	%xmm1, %xmm0
	movd	%r9d, %xmm2
	movl	$1, 24(%rsp)
	movq	%xmm0, 4(%rsi)
	movd	4(%rsp), %xmm0
	movl	-4(%rbp), %eax
	movq	%rbp, 16(%rsi)
	punpckldq	%xmm2, %xmm0
	movl	%eax, 12(%rsi)
	movq	%xmm0, 24(%rsi)
	jmp	.L395
	.p2align 4,,10
	.p2align 3
.L424:
	movl	-4(%rbp), %edi
	movq	%rsi, 16(%rsp)
	movl	%edx, 8(%rsp)
	call	connected_if
	movl	8(%rsp), %edx
	movq	16(%rsp), %rsi
	testq	%rax, %rax
	je	.L395
	cmpl	%ebx, %r15d
	jl	.L425
.L398:
	jne	.L395
	movl	44(%rbp), %eax
	movl	4(%rsp), %ecx
	cmpl	%ecx, %eax
	jge	.L395
	movl	%eax, 4(%rsp)
	jmp	.L399
	.p2align 4,,10
	.p2align 3
.L404:
	xorl	%ebx, %ebx
	jmp	.L393
.L384:
	testl	%r15d, %r15d
	js	.L402
	jne	.L383
	movl	4(%rsp), %edi
	testl	%edi, %edi
	je	.L383
	jmp	.L387
	.p2align 4,,10
	.p2align 3
.L402:
	xorl	%r15d, %r15d
	jmp	.L387
	.cfi_endproc
.LFE45:
	.size	lookup, .-lookup
	.p2align 4
	.globl	rc_ieq
	.type	rc_ieq, @function
rc_ieq:
.LFB17:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	movq	%rsi, %r13
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	movq	%rdi, %r12
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$8, %rsp
	.cfi_def_cfa_offset 48
	movzbl	(%rdi), %ebx
	testb	%bl, %bl
	jne	.L427
	jmp	.L436
	.p2align 4,,10
	.p2align 3
.L430:
	call	__ctype_tolower_loc@PLT
	movq	(%rax), %rax
	movl	(%rax,%rbx,4), %edx
	cmpl	%edx, (%rax,%rbp,4)
	jne	.L431
	movzbl	1(%r12), %ebx
	addq	$1, %r12
	leaq	1(%r13), %rax
	testb	%bl, %bl
	je	.L437
	movq	%rax, %r13
.L427:
	movzbl	0(%r13), %ebp
	testb	%bpl, %bpl
	jne	.L430
.L428:
	xorl	%eax, %eax
	cmpb	%bpl, %bl
	sete	%al
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L431:
	.cfi_restore_state
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L437:
	.cfi_restore_state
	movzbl	1(%r13), %ebp
	jmp	.L428
.L436:
	movzbl	(%rsi), %ebp
	jmp	.L428
	.cfi_endproc
.LFE17:
	.size	rc_ieq, .-rc_ieq
	.section	.rodata.str1.8
	.align 8
.LC51:
	.string	"Too many words on one line (max %d)."
	.section	.rodata.str1.1
.LC52:
	.string	"do"
.LC53:
	.string	"Incomplete command."
	.section	.rodata.str1.8
	.align 8
.LC54:
	.string	"Invalid input detected at '^' marker."
	.section	.rodata.str1.1
.LC55:
	.string	"Ambiguous command: \"%s\""
	.text
	.p2align 4
	.type	execute_line_impl, @function
execute_line_impl:
.LFB111:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movq	%rdi, %rax
	movl	$89, %ecx
	leaq	C(%rip), %rsi
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	leaq	.LC28(%rip), %rbx
	movq	%rbx, %rdx
	subq	$1176, %rsp
	.cfi_def_cfa_offset 1232
	addl	$1, st(%rip)
	leaq	192(%rsp), %r12
	leaq	448(%rsp), %rbp
	movq	%rbp, %rdi
	rep movsq
	movq	%rax, %rcx
	movl	$256, %esi
	movq	%r12, %rdi
	xorl	%eax, %eax
	call	snprintf@PLT
	movq	%rbx, %rdx
	xorl	%eax, %eax
	movq	%r12, %rcx
	leaq	C(%rip), %rbx
	movl	$256, %esi
	movq	%rbx, %rdi
	call	snprintf@PLT
	movq	%rbx, %rdi
	call	strlen@PLT
	testq	%rax, %rax
	je	.L442
	movq	%rax, %r12
	call	__ctype_b_loc@PLT
	movq	(%rax), %rdx
	jmp	.L441
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L443:
	movb	$0, (%rbx,%r12)
	testq	%r12, %r12
	je	.L442
.L441:
	subq	$1, %r12
	movzbl	(%rbx,%r12), %eax
	testb	$32, 1(%rdx,%rax,2)
	jne	.L443
.L442:
	movdqa	C(%rip), %xmm0
	xorl	%r15d, %r15d
	leaq	256+C(%rip), %r13
	movq	%r13, %r14
	movaps	%xmm0, 256+C(%rip)
	movdqa	16+C(%rip), %xmm0
	movaps	%xmm0, 272+C(%rip)
	movdqa	32+C(%rip), %xmm0
	movaps	%xmm0, 288+C(%rip)
	movdqa	48+C(%rip), %xmm0
	movaps	%xmm0, 304+C(%rip)
	movdqa	64+C(%rip), %xmm0
	movaps	%xmm0, 320+C(%rip)
	movdqa	80+C(%rip), %xmm0
	movaps	%xmm0, 336+C(%rip)
	movdqa	96+C(%rip), %xmm0
	movaps	%xmm0, 352+C(%rip)
	movdqa	112+C(%rip), %xmm0
	movaps	%xmm0, 368+C(%rip)
	movdqa	128+C(%rip), %xmm0
	movaps	%xmm0, 384+C(%rip)
	movdqa	144+C(%rip), %xmm0
	movaps	%xmm0, 400+C(%rip)
	movdqa	160+C(%rip), %xmm0
	movaps	%xmm0, 416+C(%rip)
	movdqa	176+C(%rip), %xmm0
	movaps	%xmm0, 432+C(%rip)
	movdqa	192+C(%rip), %xmm0
	movaps	%xmm0, 448+C(%rip)
	movdqa	208+C(%rip), %xmm0
	movaps	%xmm0, 464+C(%rip)
	movdqa	224+C(%rip), %xmm0
	movaps	%xmm0, 480+C(%rip)
	movdqa	240+C(%rip), %xmm0
	movaps	%xmm0, 496+C(%rip)
	movq	$0, 704+C(%rip)
	movq	%rbp, (%rsp)
	movl	%r15d, %ebp
.L440:
	movzbl	(%r14), %r12d
	movslq	%ebp, %r15
	testb	%r12b, %r12b
	je	.L518
	call	__ctype_b_loc@PLT
	movq	(%rax), %rdx
	jmp	.L453
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L445:
	movzbl	1(%r14), %r12d
	addq	$1, %r14
	testb	%r12b, %r12b
	je	.L518
.L453:
	testb	$32, 1(%rdx,%r12,2)
	jne	.L445
	cmpl	$15, %ebp
	jg	.L520
	leaq	512+C(%rip), %rax
	leaq	640+C(%rip), %rdi
	movq	%r14, (%rax,%r15,8)
	movq	%r14, %rax
	leal	1(%rbp), %r8d
	subq	%r13, %rax
	movl	%eax, (%rdi,%r15,4)
	movl	%r8d, 704+C(%rip)
	movzbl	(%r14), %eax
	testb	%al, %al
	jne	.L448
	jmp	.L450
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L451:
	testb	%al, %al
	je	.L450
.L448:
	movzbl	%al, %ecx
	movq	%r14, %rsi
	movzbl	1(%r14), %eax
	addq	$1, %r14
	testb	$32, 1(%rdx,%rcx,2)
	je	.L451
	movb	$0, (%rsi)
	movl	704+C(%rip), %ebp
	jmp	.L440
	.p2align 4,,10
	.p2align 3
.L450:
	movl	%r8d, %r15d
	movq	(%rsp), %rbp
	testl	%r15d, %r15d
	je	.L454
.L522:
	movq	512+C(%rip), %r14
	cmpb	$33, (%r14)
	je	.L454
	leal	-1(%r15), %r13d
	movslq	%r13d, %rax
	movq	512(%rbx,%rax,8), %r12
	movq	%r12, %rdi
	call	strlen@PLT
	leaq	-1(%r12,%rax), %rax
	cmpb	$63, (%rax)
	je	.L521
	leaq	.LC52(%rip), %rsi
	movq	%r14, %rdi
	call	rc_ieq
	movl	mode(%rip), %r12d
	testl	%eax, %eax
	je	.L458
	cmpl	$1, %r12d
	jbe	.L458
	cmpl	$1, %r15d
	je	.L471
	movslq	644+C(%rip), %rdi
	movq	cur_if(%rip), %r13
	movl	$1, mode(%rip)
	addq	%rbx, %rdi
	call	execute_line_impl
	movl	%r12d, mode(%rip)
	movq	%r13, cur_if(%rip)
	jmp	.L447
	.p2align 4,,10
	.p2align 3
.L518:
	movl	%ebp, %r15d
	movq	(%rsp), %rbp
	testl	%r15d, %r15d
	jne	.L522
.L454:
	subl	$1, st(%rip)
.L447:
	movq	%rbx, %rdi
	movq	%rbp, %rsi
	movl	$89, %ecx
	rep movsq
	addq	$1176, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L520:
	.cfi_restore_state
	movl	$16, %esi
	leaq	.LC51(%rip), %rdi
	xorl	%eax, %eax
	movq	(%rsp), %rbp
	call	err
	jmp	.L447
.L458:
	movl	$1, %r10d
	movl	%r12d, %ecx
	xorl	%r11d, %r11d
	xorl	%eax, %eax
	sall	%cl, %r10d
	leaq	64(%rsp), %r14
	movl	%r11d, %r15d
	movq	%rbp, 56(%rsp)
	movl	$-1, %r8d
	movl	%r10d, %r11d
	movl	$0, 48(%rsp)
	leaq	CMDS(%rip), %r9
	movl	$-1, 52(%rsp)
	movl	%eax, %r10d
	movl	$-1, 40(%rsp)
	movl	%r8d, 44(%rsp)
	movq	%r14, 32(%rsp)
	jmp	.L469
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L468:
	addl	$1, %r15d
	addq	$48, %r9
	cmpl	$51, %r15d
	je	.L523
.L469:
	movl	%r11d, %eax
	andl	(%r9), %eax
	je	.L468
	movq	32(%rsp), %r12
	movq	8(%r9), %rdi
	movq	%r12, %rsi
	call	pat_split
	testl	%eax, %eax
	je	.L480
	movl	704+C(%rip), %edi
	movl	%r15d, 12(%rsp)
	xorl	%r14d, %r14d
	movl	%eax, %r13d
	movl	$0, (%rsp)
	leaq	512+C(%rip), %rbp
	movl	%edi, 8(%rsp)
	movl	%r10d, 24(%rsp)
	movq	%r9, 16(%rsp)
	movl	%r11d, 28(%rsp)
.L462:
	cmpl	%r14d, 8(%rsp)
	jle	.L463
	movq	0(%rbp), %r15
	cmpb	$0, (%r15)
	je	.L463
	movq	%r12, %rsi
	movq	%r15, %rdi
	call	rc_is_prefix_ci.part.0
	testl	%eax, %eax
	je	.L463
	movq	%r12, %rsi
	movq	%r15, %rdi
	addl	$1, %r14d
	addq	$24, %r12
	call	rc_ieq
	addq	$8, %rbp
	addl	%eax, (%rsp)
	cmpl	%r14d, %r13d
	jne	.L462
	movl	24(%rsp), %r10d
	movl	12(%rsp), %r15d
	movl	%r13d, %eax
	movq	16(%rsp), %r9
	movl	28(%rsp), %r11d
	cmpl	%r13d, %r10d
	cmovl	%r13d, %r10d
.L461:
	movl	44(%rsp), %edi
	cmpl	%edi, %eax
	jg	.L481
.L527:
	movl	40(%rsp), %esi
	sete	%al
	cmpl	%esi, (%rsp)
	jle	.L483
	testb	%al, %al
	je	.L483
	movl	%r15d, 52(%rsp)
	movl	$0, 48(%rsp)
.L466:
	movl	(%rsp), %eax
	addl	$1, %r15d
	addq	$48, %r9
	movl	%eax, 40(%rsp)
	cmpl	$51, %r15d
	jne	.L469
.L523:
	movl	52(%rsp), %r9d
	movslq	44(%rsp), %r8
	movq	56(%rsp), %rbp
	testl	%r9d, %r9d
	js	.L524
	movl	48(%rsp), %esi
	testl	%esi, %esi
	jne	.L525
	movslq	52(%rsp), %rax
	movl	704+C(%rip), %edx
	leaq	CMDS(%rip), %rdi
	movl	%r8d, 708+C(%rip)
	leaq	(%rax,%rax,2), %rax
	salq	$4, %rax
	leaq	(%rdi,%rax), %r12
	movl	%edx, %edi
	subl	%r8d, %edi
	cmpl	24(%r12), %edi
	jl	.L471
	movl	28(%r12), %eax
	cmpl	%eax, %edi
	jg	.L526
	leaq	512+C(%rip), %rax
	leaq	(%rax,%r8,8), %rsi
	call	*32(%r12)
	movl	(%r12), %edx
	testl	%edx, %edx
	je	.L447
	andl	$-61, %edx
	jne	.L447
	testl	%eax, %eax
	jne	.L479
	addl	$1, 4+st(%rip)
	jmp	.L447
	.p2align 4,,10
	.p2align 3
.L463:
	movl	24(%rsp), %r10d
	movl	12(%rsp), %r15d
	movl	%r13d, %eax
	movq	16(%rsp), %r9
	movl	28(%rsp), %r11d
	cmpl	%r14d, %r10d
	cmovl	%r14d, %r10d
	cmpl	%r14d, %r13d
	jne	.L468
	movl	44(%rsp), %edi
	cmpl	%edi, %eax
	jle	.L527
.L481:
	movl	%eax, 44(%rsp)
	movl	%r15d, 52(%rsp)
	movl	$0, 48(%rsp)
	jmp	.L466
.L483:
	movl	40(%rsp), %edi
	xorl	%edx, %edx
	cmpl	%edi, (%rsp)
	sete	%dl
	andl	%edx, %eax
	movl	%edi, (%rsp)
	orl	%eax, 48(%rsp)
	jmp	.L466
.L521:
	movb	$0, (%rax)
	cmpb	$0, (%r12)
	cmovne	%r15d, %r13d
	movl	%r13d, %edi
	call	show_help
	jmp	.L447
.L524:
	cmpl	%r10d, 704+C(%rip)
	jg	.L528
.L471:
	leaq	.LC53(%rip), %rdi
	xorl	%eax, %eax
	call	err
	jmp	.L447
.L480:
	movl	$0, (%rsp)
	jmp	.L461
.L528:
	movl	loading(%rip), %edi
	testl	%edi, %edi
	jne	.L473
	movslq	%r10d, %r11
	movl	prompt_len(%rip), %esi
	leaq	.LC36(%rip), %rdx
	xorl	%eax, %eax
	addl	640(%rbx,%r11,4), %esi
	leaq	.LC37(%rip), %rdi
	call	printf@PLT
.L473:
	leaq	.LC54(%rip), %rdi
	xorl	%eax, %eax
	call	err
	jmp	.L447
.L526:
	movl	loading(%rip), %ecx
	testl	%ecx, %ecx
	jne	.L473
	addl	%r8d, %eax
	cmpl	%eax, %edx
	jle	.L477
	cltq
	movl	640(%rbx,%rax,4), %eax
.L478:
	addl	prompt_len(%rip), %eax
	leaq	.LC36(%rip), %rdx
	leaq	.LC37(%rip), %rdi
	movl	%eax, %esi
	xorl	%eax, %eax
	call	printf@PLT
	jmp	.L473
.L525:
	movq	512+C(%rip), %rsi
	leaq	.LC55(%rip), %rdi
	xorl	%eax, %eax
	call	err
	jmp	.L447
.L477:
	movq	%rbx, %rdi
	call	strlen@PLT
	jmp	.L478
.L479:
	jle	.L447
	addl	$1, 8+st(%rip)
	jmp	.L447
	.cfi_endproc
.LFE111:
	.size	execute_line_impl, .-execute_line_impl
	.p2align 4
	.globl	rc_is_prefix_ci
	.type	rc_is_prefix_ci, @function
rc_is_prefix_ci:
.LFB18:
	.cfi_startproc
	cmpb	$0, (%rdi)
	je	.L530
	jmp	rc_is_prefix_ci.part.0
	.p2align 4,,10
	.p2align 3
.L530:
	xorl	%eax, %eax
	ret
	.cfi_endproc
.LFE18:
	.size	rc_is_prefix_ci, .-rc_is_prefix_ci
	.section	.rodata.str1.1
.LC56:
	.string	"%u.%u.%u.%u"
	.text
	.p2align 4
	.globl	rc_ipstr
	.type	rc_ipstr, @function
rc_ipstr:
.LFB20:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movl	i.2(%rip), %ebx
	movl	%edi, %eax
	movl	%edi, %r8d
	movzbl	%ah, %esi
	movzbl	%dil, %eax
	movl	%edi, %ecx
	shrl	$16, %r8d
	leal	1(%rbx), %edx
	andl	$3, %ebx
	movl	%esi, %r9d
	shrl	$24, %ecx
	subq	$8, %rsp
	.cfi_def_cfa_offset 24
	movl	%edx, i.2(%rip)
	salq	$4, %rbx
	leaq	b.1(%rip), %rdx
	pushq	%rax
	.cfi_def_cfa_offset 32
	addq	%rdx, %rbx
	movzbl	%r8b, %r8d
	leaq	.LC56(%rip), %rdx
	movq	%rbx, %rdi
	movl	$16, %esi
	xorl	%eax, %eax
	call	snprintf@PLT
	popq	%rax
	.cfi_def_cfa_offset 24
	movq	%rbx, %rax
	popq	%rdx
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE20:
	.size	rc_ipstr, .-rc_ipstr
	.section	.rodata.str1.1
.LC57:
	.string	" shutdown"
.LC58:
	.string	" no shutdown"
.LC59:
	.string	"!"
.LC60:
	.string	"hostname %s"
.LC61:
	.string	"enable secret %s"
.LC62:
	.string	"interface %s"
.LC63:
	.string	" description %s"
.LC64:
	.string	" ip address %s %s"
.LC65:
	.string	" no ip address"
.LC66:
	.string	" clock rate %ld"
.LC67:
	.string	"router rip"
.LC68:
	.string	" version %d"
.LC69:
	.string	" network %s"
.LC70:
	.string	" no auto-summary"
.LC71:
	.string	"router ospf %d"
.LC72:
	.string	" router-id %s"
.LC73:
	.string	" network %s %s area %llu"
.LC74:
	.string	" %d"
.LC75:
	.string	"ip route %s %s %s%s"
.LC76:
	.string	"end"
	.text
	.p2align 4
	.type	gen_config, @function
gen_config:
.LFB46:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	xorl	%eax, %eax
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	leaq	.LC59(%rip), %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rbp, %rsi
	movq	%rdi, %rbx
	subq	$40, %rsp
	.cfi_def_cfa_offset 96
	call	addf
	xorl	%eax, %eax
	leaq	cfg(%rip), %rdx
	movq	%rbx, %rdi
	leaq	.LC60(%rip), %rsi
	call	addf
	xorl	%eax, %eax
	movq	%rbp, %rsi
	movq	%rbx, %rdi
	call	addf
	cmpb	$0, 64+cfg(%rip)
	jne	.L575
.L534:
	movq	640+cfg(%rip), %r15
	testq	%r15, %r15
	je	.L535
	leaq	.LC62(%rip), %r12
	leaq	.LC65(%rip), %r14
	jmp	.L541
	.p2align 4,,10
	.p2align 3
.L578:
	movl	144(%r15), %edi
	call	rc_ipstr
	movl	140(%r15), %edi
	movq	%rax, %r13
	call	rc_ipstr
	movq	%r13, %rcx
	leaq	.LC64(%rip), %rsi
	movq	%rbx, %rdi
	movq	%rax, %rdx
	xorl	%eax, %eax
	call	addf
	movq	160(%r15), %rdx
	testq	%rdx, %rdx
	jne	.L576
.L539:
	movl	152(%r15), %r10d
	leaq	.LC58(%rip), %rsi
	testl	%r10d, %r10d
	je	.L540
	leaq	.LC57(%rip), %rsi
.L540:
	movq	%rbx, %rdi
	xorl	%eax, %eax
	call	addf
	movq	%rbp, %rsi
	movq	%rbx, %rdi
	xorl	%eax, %eax
	call	addf
	movq	176(%r15), %r15
	testq	%r15, %r15
	je	.L535
.L541:
	xorl	%eax, %eax
	movq	%r15, %rdx
	movq	%r12, %rsi
	movq	%rbx, %rdi
	call	addf
	cmpb	$0, 40(%r15)
	jne	.L577
.L536:
	movl	148(%r15), %r11d
	testl	%r11d, %r11d
	jne	.L578
	movq	%r14, %rsi
	movq	%rbx, %rdi
	xorl	%eax, %eax
	call	addf
	movq	160(%r15), %rdx
	testq	%rdx, %rdx
	je	.L539
.L576:
	leaq	.LC66(%rip), %rsi
	movq	%rbx, %rdi
	xorl	%eax, %eax
	call	addf
	jmp	.L539
	.p2align 4,,10
	.p2align 3
.L577:
	leaq	40(%r15), %rdx
	leaq	.LC63(%rip), %rsi
	movq	%rbx, %rdi
	xorl	%eax, %eax
	call	addf
	jmp	.L536
	.p2align 4,,10
	.p2align 3
.L535:
	movl	680+cfg(%rip), %r9d
	testl	%r9d, %r9d
	jne	.L579
.L542:
	movl	712+cfg(%rip), %esi
	testl	%esi, %esi
	jne	.L580
.L546:
	movl	672+cfg(%rip), %eax
	testl	%eax, %eax
	jle	.L550
	xorl	%r15d, %r15d
	leaq	16(%rsp), %r13
	leaq	.LC75(%rip), %r14
	jmp	.L554
	.p2align 4,,10
	.p2align 3
.L581:
	movl	8(%r12), %edi
	call	rc_ipstr
	movl	4(%r12), %edi
	movq	%rax, 8(%rsp)
	call	rc_ipstr
	movl	(%r12), %edi
	movq	%rax, (%rsp)
	call	rc_ipstr
	movq	8(%rsp), %r8
	movq	%r13, %r9
	movq	%rax, %rdx
.L574:
	movq	(%rsp), %rcx
	xorl	%eax, %eax
	movq	%r14, %rsi
	movq	%rbx, %rdi
	addq	$1, %r15
	call	addf
	movl	672+cfg(%rip), %eax
	cmpl	%r15d, %eax
	jle	.L550
.L554:
	movq	%r15, %rax
	movq	664+cfg(%rip), %rdx
	pxor	%xmm0, %xmm0
	salq	$4, %rax
	movaps	%xmm0, 16(%rsp)
	subq	%r15, %rax
	leaq	(%rdx,%rax,4), %r12
	movl	56(%r12), %ecx
	cmpl	$1, %ecx
	je	.L551
	leaq	.LC74(%rip), %rdx
	movl	$16, %esi
	movq	%r13, %rdi
	xorl	%eax, %eax
	call	snprintf@PLT
.L551:
	movl	52(%r12), %eax
	testl	%eax, %eax
	jne	.L581
	movl	4(%r12), %edi
	call	rc_ipstr
	movl	(%r12), %edi
	movq	%rax, (%rsp)
	call	rc_ipstr
	movq	%r13, %r9
	leaq	12(%r12), %r8
	movq	%rax, %rdx
	jmp	.L574
	.p2align 4,,10
	.p2align 3
.L550:
	testl	%eax, %eax
	jne	.L582
.L555:
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movq	%rbx, %rdi
	leaq	.LC76(%rip), %rsi
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	jmp	addf
	.p2align 4,,10
	.p2align 3
.L575:
	.cfi_restore_state
	movq	%rbx, %rdi
	xorl	%eax, %eax
	leaq	64+cfg(%rip), %rdx
	leaq	.LC61(%rip), %rsi
	call	addf
	movq	%rbp, %rsi
	movq	%rbx, %rdi
	xorl	%eax, %eax
	call	addf
	jmp	.L534
	.p2align 4,,10
	.p2align 3
.L582:
	movq	%rbp, %rsi
	movq	%rbx, %rdi
	xorl	%eax, %eax
	call	addf
	jmp	.L555
	.p2align 4,,10
	.p2align 3
.L580:
	movl	716+cfg(%rip), %edx
	leaq	.LC71(%rip), %rsi
	movq	%rbx, %rdi
	xorl	%eax, %eax
	call	addf
	movl	720+cfg(%rip), %ecx
	testl	%ecx, %ecx
	jne	.L583
.L547:
	movl	736+cfg(%rip), %edx
	testl	%edx, %edx
	jle	.L548
	xorl	%r12d, %r12d
	.p2align 4
	.p2align 3
.L549:
	movq	728+cfg(%rip), %rax
	movq	%r12, %r14
	addq	$1, %r12
	salq	$4, %r14
	addq	%r14, %rax
	movl	4(%rax), %edi
	movq	8(%rax), %r15
	call	rc_ipstr
	movq	%rax, %r13
	movq	728+cfg(%rip), %rax
	movl	(%rax,%r14), %edi
	call	rc_ipstr
	movq	%r15, %r8
	movq	%r13, %rcx
	movq	%rbx, %rdi
	movq	%rax, %rdx
	leaq	.LC73(%rip), %rsi
	xorl	%eax, %eax
	call	addf
	cmpl	%r12d, 736+cfg(%rip)
	jg	.L549
.L548:
	movq	%rbp, %rsi
	movq	%rbx, %rdi
	xorl	%eax, %eax
	call	addf
	jmp	.L546
	.p2align 4,,10
	.p2align 3
.L579:
	leaq	.LC67(%rip), %rsi
	movq	%rbx, %rdi
	xorl	%eax, %eax
	call	addf
	movl	684+cfg(%rip), %edx
	movq	%rbx, %rdi
	xorl	%eax, %eax
	leaq	.LC68(%rip), %rsi
	call	addf
	movl	704+cfg(%rip), %r8d
	testl	%r8d, %r8d
	jle	.L543
	xorl	%r12d, %r12d
	leaq	.LC69(%rip), %r13
	.p2align 4
	.p2align 3
.L544:
	movq	696+cfg(%rip), %rax
	movl	(%rax,%r12,4), %edi
	addq	$1, %r12
	call	rc_ipstr
	movq	%r13, %rsi
	movq	%rbx, %rdi
	movq	%rax, %rdx
	xorl	%eax, %eax
	call	addf
	cmpl	%r12d, 704+cfg(%rip)
	jg	.L544
.L543:
	movl	688+cfg(%rip), %edi
	testl	%edi, %edi
	je	.L584
.L545:
	movq	%rbp, %rsi
	movq	%rbx, %rdi
	xorl	%eax, %eax
	call	addf
	jmp	.L542
	.p2align 4,,10
	.p2align 3
.L583:
	movl	724+cfg(%rip), %edi
	call	rc_ipstr
	leaq	.LC72(%rip), %rsi
	movq	%rbx, %rdi
	movq	%rax, %rdx
	xorl	%eax, %eax
	call	addf
	jmp	.L547
	.p2align 4,,10
	.p2align 3
.L584:
	leaq	.LC70(%rip), %rsi
	movq	%rbx, %rdi
	xorl	%eax, %eax
	call	addf
	jmp	.L545
	.cfi_endproc
.LFE46:
	.size	gen_config, .-gen_config
	.section	.rodata.str1.8
	.align 8
.LC77:
	.string	"Building configuration...\n\nCurrent configuration : %lu bytes\n"
	.text
	.p2align 4
	.type	h_show_run, @function
h_show_run:
.LFB83:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pxor	%xmm0, %xmm0
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	subq	$16, %rsp
	.cfi_def_cfa_offset 64
	movq	%rsp, %rdi
	movaps	%xmm0, (%rsp)
	call	gen_config
	movslq	8(%rsp), %rax
	movq	(%rsp), %r14
	testl	%eax, %eax
	jle	.L586
	movq	%r14, %rbp
	leaq	(%r14,%rax,8), %r12
	movq	%r14, %rbx
	xorl	%r13d, %r13d
	.p2align 4
	.p2align 3
.L587:
	movq	(%rbx), %rdi
	addq	$8, %rbx
	call	strlen@PLT
	leaq	1(%r13,%rax), %r13
	cmpq	%r12, %rbx
	jne	.L587
	movq	%r13, %rsi
	leaq	.LC77(%rip), %rdi
	xorl	%eax, %eax
	movq	%r14, %rbx
	call	printf@PLT
	.p2align 4
	.p2align 3
.L590:
	movq	(%rbx), %rdi
	addq	$8, %rbx
	call	puts@PLT
	cmpq	%r12, %rbx
	jne	.L590
	.p2align 4
	.p2align 3
.L591:
	movq	0(%rbp), %rdi
	addq	$8, %rbp
	call	free@PLT
	cmpq	%r12, %rbp
	jne	.L591
.L589:
	movq	%r14, %rdi
	call	free@PLT
	addq	$16, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 48
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L586:
	.cfi_restore_state
	xorl	%esi, %esi
	leaq	.LC77(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
	jmp	.L589
	.cfi_endproc
.LFE83:
	.size	h_show_run, .-h_show_run
	.section	.rodata.str1.1
.LC78:
	.string	"enabled"
.LC79:
	.string	"disabled"
.LC80:
	.string	"(not set)"
	.section	.rodata.str1.8
	.align 8
.LC81:
	.string	"No routing protocol is configured."
	.align 8
.LC82:
	.string	"Routing Protocol is \"rip\"\n  Version %d, automatic summarization %s\n  Routing for Networks:\n"
	.section	.rodata.str1.1
.LC83:
	.string	"    %s\n"
	.section	.rodata.str1.8
	.align 8
.LC84:
	.string	"Routing Protocol is \"ospf %d\"\n  Router ID %s\n  Routing for Networks:\n"
	.section	.rodata.str1.1
.LC85:
	.string	"    %s %s area %llu\n"
	.text
	.p2align 4
	.type	h_show_protocols, @function
h_show_protocols:
.LFB89:
	.cfi_startproc
	movl	680+cfg(%rip), %r9d
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	testl	%r9d, %r9d
	je	.L613
	movl	688+cfg(%rip), %ecx
	leaq	.LC78(%rip), %rax
	leaq	.LC79(%rip), %rdx
	movl	684+cfg(%rip), %esi
	leaq	.LC82(%rip), %rdi
	testl	%ecx, %ecx
	cmovne	%rax, %rdx
	xorl	%eax, %eax
	call	printf@PLT
	movl	704+cfg(%rip), %esi
	testl	%esi, %esi
	jle	.L604
	xorl	%ebx, %ebx
	leaq	.LC83(%rip), %rbp
	.p2align 4
	.p2align 3
.L605:
	movq	696+cfg(%rip), %rax
	movl	(%rax,%rbx,4), %edi
	addq	$1, %rbx
	call	rc_ipstr
	movq	%rbp, %rdi
	movq	%rax, %rsi
	xorl	%eax, %eax
	call	printf@PLT
	cmpl	%ebx, 704+cfg(%rip)
	jg	.L605
.L604:
	movl	712+cfg(%rip), %edx
	testl	%edx, %edx
	jne	.L606
.L602:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	xorl	%eax, %eax
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L613:
	.cfi_restore_state
	movl	712+cfg(%rip), %r8d
	testl	%r8d, %r8d
	je	.L599
.L606:
	movl	720+cfg(%rip), %edi
	leaq	.LC80(%rip), %rdx
	testl	%edi, %edi
	jne	.L614
.L601:
	movl	716+cfg(%rip), %esi
	leaq	.LC84(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
	movl	736+cfg(%rip), %eax
	testl	%eax, %eax
	jle	.L602
	xorl	%ebx, %ebx
	leaq	.LC85(%rip), %r13
	.p2align 4
	.p2align 3
.L608:
	movq	728+cfg(%rip), %rax
	movq	%rbx, %r12
	addq	$1, %rbx
	salq	$4, %r12
	addq	%r12, %rax
	movl	4(%rax), %edi
	movq	8(%rax), %r14
	call	rc_ipstr
	movq	%rax, %rbp
	movq	728+cfg(%rip), %rax
	movl	(%rax,%r12), %edi
	call	rc_ipstr
	movq	%r14, %rcx
	movq	%rbp, %rdx
	movq	%r13, %rdi
	movq	%rax, %rsi
	xorl	%eax, %eax
	call	printf@PLT
	cmpl	%ebx, 736+cfg(%rip)
	jg	.L608
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	xorl	%eax, %eax
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L599:
	.cfi_restore_state
	leaq	.LC81(%rip), %rdi
	call	puts@PLT
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	xorl	%eax, %eax
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L614:
	.cfi_restore_state
	movl	724+cfg(%rip), %edi
	call	rc_ipstr
	movq	%rax, %rdx
	jmp	.L601
	.cfi_endproc
.LFE89:
	.size	h_show_protocols, .-h_show_protocols
	.section	.rodata.str1.1
.LC86:
	.string	"manual"
.LC87:
	.string	"unset"
.LC88:
	.string	"unassigned"
.LC89:
	.string	"Status"
.LC90:
	.string	"Method"
.LC91:
	.string	"OK?"
.LC92:
	.string	"IP-Address"
.LC93:
	.string	"Interface"
	.section	.rodata.str1.8
	.align 8
.LC94:
	.string	"%-22s %-15s %-4s %-7s %-21s %s\n"
	.section	.rodata.str1.1
.LC95:
	.string	"Protocol"
.LC96:
	.string	"YES"
.LC97:
	.string	"(no interfaces configured)"
	.text
	.p2align 4
	.type	h_show_ipbrief, @function
h_show_ipbrief:
.LFB85:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	leaq	.LC95(%rip), %rax
	leaq	.LC89(%rip), %r9
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	leaq	.LC90(%rip), %r8
	leaq	.LC91(%rip), %rcx
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	leaq	.LC92(%rip), %rdx
	leaq	.LC93(%rip), %rsi
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	leaq	.LC94(%rip), %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rbp, %rdi
	subq	$32, %rsp
	.cfi_def_cfa_offset 88
	pushq	%rax
	.cfi_def_cfa_offset 96
	xorl	%eax, %eax
	call	printf@PLT
	movq	640+cfg(%rip), %r14
	popq	%r8
	.cfi_def_cfa_offset 88
	popq	%r9
	.cfi_def_cfa_offset 80
	testq	%r14, %r14
	je	.L616
	leaq	.LC96(%rip), %r13
	leaq	.LC23(%rip), %rbx
	leaq	.LC87(%rip), %r12
	.p2align 4
	.p2align 3
.L619:
	movl	152(%r14), %edi
	movq	%rbx, %r15
	movq	%rbx, %r9
	testl	%edi, %edi
	je	.L617
	leaq	.LC13(%rip), %r15
	leaq	.LC11(%rip), %r9
.L617:
	movl	148(%r14), %esi
	movq	%r12, %r8
	leaq	.LC88(%rip), %rdx
	testl	%esi, %esi
	je	.L618
	movl	140(%r14), %edi
	movq	%r9, 8(%rsp)
	call	rc_ipstr
	movq	8(%rsp), %r9
	leaq	.LC86(%rip), %r8
	movq	%rax, %rdx
.L618:
	subq	$8, %rsp
	.cfi_def_cfa_offset 88
	movq	%r13, %rcx
	movq	%r14, %rsi
	movq	%rbp, %rdi
	pushq	%r15
	.cfi_def_cfa_offset 96
	xorl	%eax, %eax
	call	printf@PLT
	movq	176(%r14), %r14
	popq	%rdx
	.cfi_def_cfa_offset 88
	popq	%rcx
	.cfi_def_cfa_offset 80
	testq	%r14, %r14
	jne	.L619
.L616:
	movl	656+cfg(%rip), %eax
	testl	%eax, %eax
	je	.L628
.L620:
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L628:
	.cfi_restore_state
	leaq	.LC97(%rip), %rdi
	call	puts@PLT
	jmp	.L620
	.cfi_endproc
.LFE85:
	.size	h_show_ipbrief, .-h_show_ipbrief
	.section	.rodata.str1.8
	.align 8
.LC98:
	.string	"%s is %s, line protocol is %s\n"
	.section	.rodata.str1.1
.LC99:
	.string	"  Description: %s\n"
.LC100:
	.string	"  Internet address is %s/%d\n"
	.section	.rodata.str1.8
	.align 8
.LC101:
	.string	"  Internet protocol processing disabled"
	.section	.rodata.str1.1
.LC102:
	.string	"  Clock rate %ld\n"
	.text
	.p2align 4
	.type	print_if_detail, @function
print_if_detail:
.LFB86:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rdi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movl	152(%rdi), %edx
	testl	%edx, %edx
	je	.L640
	leaq	.LC13(%rip), %rcx
	leaq	.LC11(%rip), %rdx
.L630:
	xorl	%eax, %eax
	movq	%rbp, %rsi
	leaq	.LC98(%rip), %rdi
	call	printf@PLT
	cmpb	$0, 40(%rbp)
	jne	.L642
	movl	148(%rbp), %eax
	testl	%eax, %eax
	je	.L632
.L644:
	movl	144(%rbp), %eax
	xorl	%ebx, %ebx
	testl	%eax, %eax
	je	.L633
	.p2align 4
	.p2align 4
	.p2align 3
.L634:
	movl	%eax, %edx
	andl	$1, %edx
	addl	%edx, %ebx
	shrl	%eax
	jne	.L634
.L633:
	movl	140(%rbp), %edi
	call	rc_ipstr
	movl	%ebx, %edx
	leaq	.LC100(%rip), %rdi
	movq	%rax, %rsi
	xorl	%eax, %eax
	call	printf@PLT
	movq	160(%rbp), %rsi
	testq	%rsi, %rsi
	jne	.L643
.L629:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L640:
	.cfi_restore_state
	leaq	.LC23(%rip), %rcx
	movq	%rcx, %rdx
	jmp	.L630
	.p2align 4,,10
	.p2align 3
.L642:
	leaq	40(%rbp), %rsi
	leaq	.LC99(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
	movl	148(%rbp), %eax
	testl	%eax, %eax
	jne	.L644
.L632:
	leaq	.LC101(%rip), %rdi
	call	puts@PLT
	movq	160(%rbp), %rsi
	testq	%rsi, %rsi
	je	.L629
.L643:
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	leaq	.LC102(%rip), %rdi
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	jmp	printf@PLT
	.cfi_endproc
.LFE86:
	.size	print_if_detail, .-print_if_detail
	.p2align 4
	.globl	rc_parse_ip
	.type	rc_parse_ip, @function
rc_parse_ip:
.LFB21:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movq	%rdi, %rbx
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	call	__ctype_b_loc@PLT
	movl	$4, %r9d
	xorl	%r8d, %r8d
	movq	(%rax), %rdi
.L646:
	xorl	%edx, %edx
	xorl	%ecx, %ecx
.L651:
	movsbl	(%rbx), %eax
	movzbl	%al, %esi
	testb	$8, 1(%rdi,%rsi,2)
	je	.L658
	leal	(%rdx,%rdx,4), %edx
	addl	$1, %ecx
	addq	$1, %rbx
	leal	-48(%rax,%rdx,2), %edx
	cmpl	$4, %ecx
	jne	.L651
.L655:
	xorl	%edx, %edx
.L645:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	movl	%edx, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L658:
	.cfi_restore_state
	testl	%ecx, %ecx
	je	.L655
	cmpl	$255, %edx
	ja	.L655
	sall	$8, %r8d
	orl	%edx, %r8d
	subl	$1, %r9d
	je	.L659
	cmpb	$46, %al
	jne	.L655
	addq	$1, %rbx
	jmp	.L646
	.p2align 4,,10
	.p2align 3
.L659:
	xorl	%edx, %edx
	testb	%al, %al
	jne	.L645
	movl	%r8d, 0(%rbp)
	movl	$1, %edx
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	movl	%edx, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE21:
	.size	rc_parse_ip, .-rc_parse_ip
	.section	.rodata.str1.8
	.align 8
.LC103:
	.string	"Router-id must be a valid non-zero IPv4 address."
	.text
	.p2align 4
	.type	h_router_id, @function
h_router_id:
.LFB77:
	.cfi_startproc
	movq	%rsi, %rax
	subq	$24, %rsp
	.cfi_def_cfa_offset 32
	movq	(%rax), %rdi
	leaq	12(%rsp), %rsi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L661
	movl	12(%rsp), %edx
	testl	%edx, %edx
	je	.L661
	movl	720+cfg(%rip), %ecx
	testl	%ecx, %ecx
	jne	.L669
.L664:
	movl	%edx, 724+cfg(%rip)
	xorl	%eax, %eax
	movl	$1, 720+cfg(%rip)
.L660:
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L669:
	.cfi_restore_state
	cmpl	724+cfg(%rip), %edx
	jne	.L664
	jmp	.L660
	.p2align 4,,10
	.p2align 3
.L661:
	leaq	.LC103(%rip), %rsi
	xorl	%edi, %edi
	xorl	%eax, %eax
	call	bad_arg
	movl	$-1, %eax
	addq	$24, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE77:
	.size	h_router_id, .-h_router_id
	.section	.rodata.str1.1
.LC104:
	.string	"Invalid IP address."
	.section	.rodata.str1.8
	.align 8
.LC105:
	.string	"Success rate is %d percent (%d/5)\n"
	.align 8
.LC106:
	.string	"(simulation: result is based on this router's own routing table only)"
	.section	.rodata.str1.1
.LC107:
	.string	"!!!!!"
	.section	.rodata.str1.8
	.align 8
.LC108:
	.string	"Type escape sequence to abort.\nSending 5, 100-byte ICMP Echos to %s, timeout is 2 seconds:\n%s\n"
	.section	.rodata.str1.1
.LC109:
	.string	"UUUUU"
	.text
	.p2align 4
	.type	h_ping, @function
h_ping:
.LFB91:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsi, %rax
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$56, %rsp
	.cfi_def_cfa_offset 80
	movq	(%rax), %rdi
	leaq	12(%rsp), %rsi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L685
	movq	640+cfg(%rip), %rax
	movl	12(%rsp), %ebx
	testq	%rax, %rax
	je	.L673
	xorl	%edx, %edx
	.p2align 4
	.p2align 3
.L675:
	movl	148(%rax), %esi
	testl	%esi, %esi
	je	.L674
	movl	152(%rax), %ecx
	testl	%ecx, %ecx
	jne	.L674
	xorl	%ecx, %ecx
	cmpl	%ebx, 140(%rax)
	sete	%cl
	orl	%ecx, %edx
.L674:
	movq	176(%rax), %rax
	testq	%rax, %rax
	jne	.L675
	testl	%edx, %edx
	je	.L673
.L676:
	movl	%ebx, %edi
	movl	$100, %ebp
	call	rc_ipstr
	leaq	.LC107(%rip), %rdx
	leaq	.LC108(%rip), %rdi
	movq	%rax, %rsi
	xorl	%eax, %eax
	call	printf@PLT
	movl	$5, %edx
.L678:
	movl	%ebp, %esi
	leaq	.LC105(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
	leaq	.LC106(%rip), %rdi
	call	puts@PLT
	xorl	%eax, %eax
.L670:
	addq	$56, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L673:
	.cfi_restore_state
	leaq	16(%rsp), %rsi
	movl	%ebx, %edi
	call	lookup
	movl	%eax, %ebp
	testl	%eax, %eax
	jne	.L676
	movl	%ebx, %edi
	call	rc_ipstr
	leaq	.LC109(%rip), %rdx
	leaq	.LC108(%rip), %rdi
	movq	%rax, %rsi
	xorl	%eax, %eax
	call	printf@PLT
	xorl	%edx, %edx
	jmp	.L678
.L685:
	leaq	.LC104(%rip), %rsi
	xorl	%edi, %edi
	call	bad_arg
	movl	$-1, %eax
	jmp	.L670
	.cfi_endproc
.LFE91:
	.size	h_ping, .-h_ping
	.section	.rodata.str1.1
.LC110:
	.string	"static"
.LC111:
	.string	"connected"
.LC112:
	.string	"Network not in table."
	.section	.rodata.str1.8
	.align 8
.LC113:
	.string	"Routing entry for %s/%d\n  Known via \"%s\", distance %d\n"
	.section	.rodata.str1.1
.LC114:
	.string	"  Directly connected, via %s\n"
.LC115:
	.string	"  Via next hop %s\n"
	.section	.rodata.str1.8
	.align 8
.LC116:
	.string	"Codes: C - connected, S - static, R - RIP, O - OSPF\n"
	.align 8
.LC117:
	.string	"Gateway of last resort is %s to network 0.0.0.0\n\n"
	.align 8
.LC118:
	.string	"Gateway of last resort is not set\n"
	.align 8
.LC119:
	.string	"C    %s/%d is directly connected, %s\n"
	.align 8
.LC120:
	.string	"(routing table is empty - no up interface with an IP address)"
	.section	.rodata.str1.1
.LC121:
	.string	"S    %s/%d [%d/0] via %s\n"
	.section	.rodata.str1.8
	.align 8
.LC122:
	.string	"S    %s/%d is directly connected, %s\n"
	.align 8
.LC123:
	.string	"\n(RIP/OSPF are configured but there are no neighbours in this simulator, so they learn no routes.)"
	.text
	.p2align 4
	.type	h_show_route, @function
h_show_route:
.LFB88:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$56, %rsp
	.cfi_def_cfa_offset 112
	testl	%edi, %edi
	jne	.L687
	movslq	672+cfg(%rip), %rax
	testl	%eax, %eax
	jle	.L770
	movq	%rax, %rdx
	movq	664+cfg(%rip), %rbx
	salq	$4, %rdx
	subq	%rax, %rdx
	leaq	(%rbx,%rdx,4), %rbp
	jmp	.L706
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L703:
	addq	$60, %rbx
	cmpq	%rbx, %rbp
	je	.L770
.L706:
	movl	(%rbx), %r11d
	testl	%r11d, %r11d
	jne	.L703
	movl	4(%rbx), %r10d
	testl	%r10d, %r10d
	jne	.L703
	movl	52(%rbx), %r9d
	testl	%r9d, %r9d
	jne	.L778
	leaq	12(%rbx), %rdi
	call	if_find
	testq	%rax, %rax
	je	.L703
	movl	152(%rax), %r8d
	testl	%r8d, %r8d
	jne	.L703
.L705:
	leaq	.LC116(%rip), %rdi
	call	puts@PLT
	movl	52(%rbx), %eax
	leaq	12(%rbx), %rsi
	testl	%eax, %eax
	jne	.L779
.L709:
	leaq	.LC117(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
.L710:
	movq	640+cfg(%rip), %rbx
	xorl	%r15d, %r15d
	testq	%rbx, %rbx
	je	.L711
	leaq	.LC119(%rip), %r12
	jmp	.L715
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L712:
	movq	176(%rbx), %rbx
	testq	%rbx, %rbx
	je	.L780
.L715:
	movl	148(%rbx), %edi
	testl	%edi, %edi
	je	.L712
	movl	152(%rbx), %ebp
	testl	%ebp, %ebp
	jne	.L712
	movl	144(%rbx), %edi
	testl	%edi, %edi
	je	.L713
	movl	%edi, %eax
	.p2align 4
	.p2align 4
	.p2align 3
.L714:
	movl	%eax, %edx
	andl	$1, %edx
	addl	%edx, %ebp
	shrl	%eax
	jne	.L714
.L713:
	andl	140(%rbx), %edi
	movl	$1, %r15d
	call	rc_ipstr
	movq	%rbx, %rcx
	movl	%ebp, %edx
	movq	%r12, %rdi
	movq	%rax, %rsi
	xorl	%eax, %eax
	call	printf@PLT
	movq	176(%rbx), %rbx
	testq	%rbx, %rbx
	jne	.L715
	.p2align 4
	.p2align 3
.L780:
	movl	672+cfg(%rip), %ecx
	testl	%ecx, %ecx
	jle	.L719
.L717:
	xorl	%ebp, %ebp
	xorl	%ebx, %ebx
	.p2align 4
	.p2align 3
.L729:
	movq	664+cfg(%rip), %r13
	addq	%rbx, %r13
	movl	52(%r13), %edx
	testl	%edx, %edx
	jne	.L781
	leaq	12(%r13), %r12
	movq	%r12, %rdi
	call	if_find
	testq	%rax, %rax
	je	.L721
	movl	152(%rax), %r14d
	testl	%r14d, %r14d
	jne	.L721
	movl	4(%r13), %eax
	testl	%eax, %eax
	je	.L727
	.p2align 4
	.p2align 4
	.p2align 3
.L728:
	movl	%eax, %ecx
	andl	$1, %ecx
	addl	%ecx, %r14d
	shrl	%eax
	jne	.L728
.L727:
	movl	0(%r13), %edi
	call	rc_ipstr
	movq	%r12, %rcx
	movl	%r14d, %edx
	leaq	.LC122(%rip), %rdi
	movq	%rax, %rsi
	xorl	%eax, %eax
	call	printf@PLT
.L726:
	movl	$1, %r15d
.L721:
	addl	$1, %ebp
	addq	$60, %rbx
	cmpl	%ebp, 672+cfg(%rip)
	jg	.L729
.L719:
	testl	%r15d, %r15d
	je	.L730
	movl	680+cfg(%rip), %eax
	orl	712+cfg(%rip), %eax
	jne	.L731
.L732:
	addq	$56, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L781:
	.cfi_restore_state
	movl	8(%r13), %edi
	call	connected_if
	testq	%rax, %rax
	je	.L721
	call	rc_ipstr
	xorl	%r14d, %r14d
	movl	56(%r13), %r15d
	movq	%rax, %r12
	movl	4(%r13), %eax
	testl	%eax, %eax
	je	.L724
	.p2align 4
	.p2align 4
	.p2align 3
.L725:
	movl	%eax, %ecx
	andl	$1, %ecx
	addl	%ecx, %r14d
	shrl	%eax
	jne	.L725
.L724:
	movl	0(%r13), %edi
	call	rc_ipstr
	movq	%r12, %r8
	movl	%r15d, %ecx
	movl	%r14d, %edx
	movq	%rax, %rsi
	leaq	.LC121(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
	jmp	.L726
	.p2align 4,,10
	.p2align 3
.L778:
	movl	8(%rbx), %edi
	call	connected_if
	testq	%rax, %rax
	jne	.L705
	addq	$60, %rbx
	cmpq	%rbx, %rbp
	jne	.L706
	.p2align 4
	.p2align 3
.L770:
	leaq	.LC116(%rip), %rdi
	call	puts@PLT
	leaq	.LC118(%rip), %rdi
	call	puts@PLT
	jmp	.L710
	.p2align 4,,10
	.p2align 3
.L731:
	leaq	.LC123(%rip), %rdi
	call	puts@PLT
	jmp	.L732
.L711:
	movl	672+cfg(%rip), %esi
	testl	%esi, %esi
	jg	.L717
.L730:
	leaq	.LC120(%rip), %rdi
	call	puts@PLT
	movl	680+cfg(%rip), %eax
	orl	712+cfg(%rip), %eax
	jne	.L731
	jmp	.L732
	.p2align 4,,10
	.p2align 3
.L687:
	movq	(%rsi), %rdi
	leaq	12(%rsp), %rax
	movq	%rax, %rsi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L782
	movl	12(%rsp), %edi
	leaq	16(%rsp), %rsi
	call	lookup
	testl	%eax, %eax
	je	.L783
	movzbl	16(%rsp), %r13d
	movl	40(%rsp), %ebp
	movl	24(%rsp), %eax
	movl	20(%rsp), %edi
	cmpb	$67, %r13b
	je	.L784
	leaq	.LC110(%rip), %r12
	testl	%eax, %eax
	je	.L785
.L733:
	xorl	%ebx, %ebx
	.p2align 4
	.p2align 4
	.p2align 3
.L696:
	movl	%eax, %edx
	andl	$1, %edx
	addl	%edx, %ebx
	shrl	%eax
	jne	.L696
	call	rc_ipstr
	movl	%ebp, %r8d
	movq	%r12, %rcx
	movl	%ebx, %edx
	movq	%rax, %rsi
	leaq	.LC113(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
	cmpb	$67, %r13b
	je	.L698
.L697:
	movl	44(%rsp), %ebx
	testl	%ebx, %ebx
	jne	.L769
.L698:
	movq	32(%rsp), %rsi
	leaq	.LC114(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
	jmp	.L732
.L779:
	movl	8(%rbx), %edi
	call	rc_ipstr
	movq	%rax, %rsi
	jmp	.L709
.L783:
	leaq	.LC112(%rip), %rdi
	call	err
.L691:
	addq	$56, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movl	$-1, %eax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L782:
	.cfi_restore_state
	leaq	.LC104(%rip), %rsi
	xorl	%edi, %edi
	call	bad_arg
	jmp	.L691
.L785:
	call	rc_ipstr
	movl	%ebp, %r8d
	movq	%r12, %rcx
	xorl	%edx, %edx
	movq	%rax, %rsi
	leaq	.LC113(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
	jmp	.L697
.L784:
	leaq	.LC111(%rip), %r12
	testl	%eax, %eax
	jne	.L733
	call	rc_ipstr
	movl	%ebp, %r8d
	movq	%r12, %rcx
	xorl	%edx, %edx
	movq	%rax, %rsi
	leaq	.LC113(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
	jmp	.L698
.L769:
	movl	28(%rsp), %edi
	call	rc_ipstr
	leaq	.LC115(%rip), %rdi
	movq	%rax, %rsi
	xorl	%eax, %eax
	call	printf@PLT
	jmp	.L732
	.cfi_endproc
.LFE88:
	.size	h_show_route, .-h_show_route
	.section	.rodata.str1.1
.LC124:
	.string	"Loopback"
	.section	.rodata.str1.8
	.align 8
.LC125:
	.string	"Invalid IP address \"%s\" (must be a unicast host address)."
	.align 8
.LC126:
	.string	"Invalid subnet mask \"%s\" (1-bits must be contiguous, e.g. 255.255.255.0)."
	.align 8
.LC127:
	.string	"Bad mask /32 for address %s (allowed only on loopbacks)."
	.align 8
.LC128:
	.string	"Bad mask /%d for address %s (it is the network or broadcast address)."
	.align 8
.LC129:
	.string	"%s/%d overlaps with %s (%s/%d)."
	.section	.rodata.str1.1
.LC130:
	.string	"%s ip = %s/%d"
	.text
	.p2align 4
	.type	h_ip_address, @function
h_ip_address:
.LFB59:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movl	$8, %edx
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rsi, %rbx
	leaq	.LC124(%rip), %rsi
	subq	$40, %rsp
	.cfi_def_cfa_offset 96
	movq	cur_if(%rip), %r14
	movq	%r14, %rdi
	call	strncmp@PLT
	movq	(%rbx), %r15
	leaq	24(%rsp), %rsi
	movl	%eax, %r13d
	movq	%r15, %rdi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L787
	movl	24(%rsp), %r12d
	testl	%r12d, %r12d
	je	.L787
	movl	%r12d, %eax
	shrl	$24, %eax
	cmpl	$-536870913, %r12d
	ja	.L787
	cmpl	$127, %eax
	je	.L787
	movq	8(%rbx), %rbx
	leaq	28(%rsp), %rsi
	movq	%rbx, %rdi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L791
	movl	28(%rsp), %ebp
	testl	%ebp, %ebp
	je	.L791
	movl	%ebp, %edi
	movl	%ebp, %edx
	notl	%edi
	negl	%edx
	testl	%edi, %edx
	jne	.L791
	movl	%r12d, %r10d
	movl	%ebp, %edx
	xorl	%ecx, %ecx
	andl	%ebp, %r10d
	.p2align 4
	.p2align 4
	.p2align 3
.L794:
	movl	%edx, %esi
	andl	$1, %esi
	addl	%esi, %ecx
	shrl	%edx
	jne	.L794
	cmpl	$32, %ecx
	jne	.L807
	testl	%r13d, %r13d
	je	.L807
	movq	%r15, %rdx
	leaq	.LC127(%rip), %rsi
	movl	$1, %edi
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L790
	.p2align 4,,10
	.p2align 3
.L787:
	movq	%r15, %rdx
	leaq	.LC125(%rip), %rsi
	xorl	%edi, %edi
	xorl	%eax, %eax
	call	bad_arg
.L790:
	movl	$-1, %eax
.L786:
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L791:
	.cfi_restore_state
	movq	%rbx, %rdx
	leaq	.LC126(%rip), %rsi
	movl	$1, %edi
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L790
	.p2align 4,,10
	.p2align 3
.L807:
	movl	%ebp, %edx
	xorl	%ecx, %ecx
	.p2align 4
	.p2align 4
	.p2align 3
.L795:
	movl	%edx, %esi
	andl	$1, %esi
	addl	%esi, %ecx
	shrl	%edx
	jne	.L795
	cmpl	$30, %ecx
	jle	.L842
.L796:
	movq	640+cfg(%rip), %rbx
	testq	%rbx, %rbx
	je	.L799
	.p2align 4
	.p2align 3
.L804:
	cmpq	%rbx, %r14
	je	.L800
	movl	148(%rbx), %ecx
	testl	%ecx, %ecx
	je	.L800
	movl	144(%rbx), %edi
	movl	140(%rbx), %edx
	movl	%r12d, %esi
	movl	%ebp, %ecx
	xorl	%edx, %esi
	andl	%edi, %ecx
	testl	%ecx, %esi
	je	.L843
.L800:
	movq	176(%rbx), %rbx
	testq	%rbx, %rbx
	jne	.L804
.L799:
	movl	148(%r14), %edx
	testl	%edx, %edx
	je	.L805
	cmpl	140(%r14), %r12d
	je	.L844
.L805:
	movd	%r12d, %xmm0
	movd	%ebp, %xmm1
	xorl	%ebx, %ebx
	movl	$1, 148(%r14)
	punpckldq	%xmm1, %xmm0
	movq	%xmm0, 140(%r14)
	.p2align 4
	.p2align 4
	.p2align 3
.L806:
	movl	%ebp, %eax
	andl	$1, %eax
	addl	%eax, %ebx
	shrl	%ebp
	jne	.L806
	movl	%r12d, %edi
	call	rc_ipstr
	movq	cur_if(%rip), %rcx
	movl	%ebx, %r9d
	leaq	.LC130(%rip), %rdx
	movq	%rax, %r8
	leaq	.LC2(%rip), %rsi
	xorl	%eax, %eax
	movl	$1, %edi
	call	rlog_log@PLT
	xorl	%eax, %eax
	jmp	.L786
	.p2align 4,,10
	.p2align 3
.L842:
	movl	%r12d, %edx
	notl	%edx
	testl	%edi, %edx
	je	.L809
	cmpl	%r10d, %r12d
	jne	.L796
.L809:
	xorl	%edx, %edx
	.p2align 4
	.p2align 4
	.p2align 3
.L798:
	movl	%ebp, %eax
	andl	$1, %eax
	addl	%eax, %edx
	shrl	%ebp
	jne	.L798
	movq	%r15, %rcx
	leaq	.LC128(%rip), %rsi
	xorl	%edi, %edi
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L790
	.p2align 4,,10
	.p2align 3
.L843:
	testl	%edi, %edi
	je	.L808
	movl	%edi, %eax
	xorl	%r13d, %r13d
	.p2align 4
	.p2align 4
	.p2align 3
.L802:
	movl	%eax, %ecx
	andl	$1, %ecx
	addl	%ecx, %r13d
	shrl	%eax
	jne	.L802
.L801:
	andl	%edx, %edi
	movl	%r10d, 12(%rsp)
	xorl	%r12d, %r12d
	call	rc_ipstr
	movl	12(%rsp), %r10d
	movq	%rax, %r14
	.p2align 4
	.p2align 4
	.p2align 3
.L803:
	movl	%ebp, %eax
	andl	$1, %eax
	addl	%eax, %r12d
	shrl	%ebp
	jne	.L803
	movl	%r10d, %edi
	call	rc_ipstr
	movl	%r13d, %r9d
	movq	%r14, %r8
	movq	%rbx, %rcx
	movq	%rax, %rsi
	movl	%r12d, %edx
	leaq	.LC129(%rip), %rdi
	xorl	%eax, %eax
	call	err
	jmp	.L790
.L844:
	cmpl	144(%r14), %ebp
	jne	.L805
	jmp	.L786
.L808:
	xorl	%r13d, %r13d
	jmp	.L801
	.cfi_endproc
.LFE59:
	.size	h_ip_address, .-h_ip_address
	.section	.rodata.str1.8
	.align 8
.LC131:
	.string	"RIP syntax: network <classful-network>"
	.section	.rodata.str1.1
.LC132:
	.string	"Invalid network address \"%s\"."
	.section	.rodata.str1.8
	.align 8
.LC133:
	.string	"Not a valid class A/B/C network."
	.section	.rodata.str1.1
.LC134:
	.string	"Network not configured."
	.section	.rodata.str1.8
	.align 8
.LC135:
	.string	"Incomplete command. OSPF syntax: network <ip> <wildcard> area <n>"
	.section	.rodata.str1.1
.LC136:
	.string	"Unexpected extra argument."
	.section	.rodata.str1.8
	.align 8
.LC137:
	.string	"Invalid wildcard mask \"%s\" (e.g. 0.0.0.255)."
	.section	.rodata.str1.1
.LC138:
	.string	"area"
.LC139:
	.string	"Expected keyword 'area'."
	.section	.rodata.str1.8
	.align 8
.LC140:
	.string	"Area must be a number 0-4294967295."
	.align 8
.LC141:
	.string	"Network statement not configured."
	.text
	.p2align 4
	.type	net_stmt, @function
net_stmt:
.LFB79:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	movl	%edx, %ebp
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	movq	%rsi, %rbx
	subq	$40, %rsp
	.cfi_def_cfa_offset 80
	cmpl	$4, mode(%rip)
	je	.L914
	cmpl	$3, %edi
	jle	.L915
	cmpl	$4, %edi
	je	.L870
	leaq	.LC136(%rip), %rsi
	movl	$4, %edi
	xorl	%eax, %eax
	call	bad_arg
.L869:
	movl	$-1, %eax
.L845:
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L870:
	.cfi_restore_state
	movq	(%rsi), %r12
	leaq	16(%rsp), %rsi
	movq	%r12, %rdi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L916
	movq	8(%rbx), %r13
	leaq	20(%rsp), %rsi
	movq	%r13, %rdi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L872
	movl	20(%rsp), %r12d
	leal	1(%r12), %eax
	testl	%r12d, %eax
	jne	.L872
	movq	16(%rbx), %rdi
	cmpb	$0, (%rdi)
	je	.L874
	leaq	.LC138(%rip), %rsi
	call	rc_is_prefix_ci.part.0
	testl	%eax, %eax
	je	.L874
	movq	24(%rbx), %rdi
	cmpb	$0, (%rdi)
	je	.L877
	xorl	%esi, %esi
	leaq	24(%rsp), %rcx
	movl	$4294967295, %edx
	call	rc_parse_uint.part.0
	testl	%eax, %eax
	je	.L877
	movl	736+cfg(%rip), %esi
	movl	%r12d, %r13d
	movq	24(%rsp), %rbx
	notl	%r13d
	andl	16(%rsp), %r13d
	testl	%esi, %esi
	jle	.L878
	movq	728+cfg(%rip), %rdi
	xorl	%ecx, %ecx
	movq	%rdi, %rdx
	jmp	.L881
	.p2align 4
	.p2align 4,,10
	.p2align 3
.L879:
	addl	$1, %ecx
	addq	$16, %rdx
	cmpl	%ecx, %esi
	je	.L917
.L881:
	cmpl	(%rdx), %r13d
	jne	.L879
	cmpl	4(%rdx), %r12d
	jne	.L879
	testl	%ebp, %ebp
	je	.L918
.L883:
	cmpl	%esi, %ecx
	je	.L894
	subl	%ecx, %esi
	leal	1(%rcx), %eax
	movq	728+cfg(%rip), %rdi
	leal	-1(%rsi), %edx
	cltq
	salq	$4, %rax
	movslq	%edx, %rdx
	leaq	(%rdi,%rax), %rsi
	salq	$4, %rdx
	leaq	-16(%rdi,%rax), %rdi
	call	memmove@PLT
	subl	$1, 736+cfg(%rip)
	xorl	%eax, %eax
	jmp	.L845
	.p2align 4,,10
	.p2align 3
.L914:
	cmpl	$1, %edi
	jne	.L919
	movq	(%rsi), %rbx
	leaq	12(%rsp), %rsi
	movq	%rbx, %rdi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L920
	movl	12(%rsp), %ebx
	movl	%ebx, %edx
	shrl	$24, %edx
	leal	-1(%rdx), %ecx
	cmpl	$125, %ecx
	jbe	.L921
	leal	-128(%rdx), %ecx
	cmpl	$63, %ecx
	jbe	.L922
	subl	$192, %edx
	xorb	%bl, %bl
	cmpl	$31, %edx
	jbe	.L852
	leaq	.LC133(%rip), %rsi
	xorl	%edi, %edi
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L869
	.p2align 4,,10
	.p2align 3
.L919:
	leaq	.LC131(%rip), %rsi
	movl	$1, %edi
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L869
	.p2align 4,,10
	.p2align 3
.L916:
	movq	%r12, %rdx
	leaq	.LC132(%rip), %rsi
	xorl	%edi, %edi
	call	bad_arg
	jmp	.L869
	.p2align 4,,10
	.p2align 3
.L874:
	leaq	.LC139(%rip), %rsi
	movl	$2, %edi
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L869
	.p2align 4,,10
	.p2align 3
.L915:
	leaq	.LC135(%rip), %rdi
	xorl	%eax, %eax
	call	err
	jmp	.L869
	.p2align 4,,10
	.p2align 3
.L872:
	movq	%r13, %rdx
	leaq	.LC137(%rip), %rsi
	movl	$1, %edi
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L869
	.p2align 4,,10
	.p2align 3
.L920:
	movq	%rbx, %rdx
	leaq	.LC132(%rip), %rsi
	xorl	%edi, %edi
	call	bad_arg
	jmp	.L869
	.p2align 4,,10
	.p2align 3
.L922:
	xorw	%bx, %bx
.L852:
	movslq	704+cfg(%rip), %rsi
	testl	%esi, %esi
	jle	.L855
	movq	696+cfg(%rip), %rdi
	xorl	%edx, %edx
	movq	%rdi, %rcx
	jmp	.L857
	.p2align 4
	.p2align 4,,10
	.p2align 3
.L924:
	addl	$1, %edx
	addq	$4, %rcx
	cmpl	%esi, %edx
	je	.L923
.L857:
	cmpl	%ebx, (%rcx)
	jne	.L924
	testl	%ebp, %ebp
	je	.L861
.L859:
	cmpl	%esi, %edx
	je	.L893
	leal	1(%rdx), %eax
	subl	%edx, %esi
	movq	696+cfg(%rip), %rcx
	leal	-1(%rsi), %edx
	cltq
	salq	$2, %rax
	movslq	%edx, %rdx
	salq	$2, %rdx
	leaq	(%rcx,%rax), %rsi
	leaq	-4(%rcx,%rax), %rdi
	call	memmove@PLT
	subl	$1, 704+cfg(%rip)
	xorl	%eax, %eax
	jmp	.L845
	.p2align 4,,10
	.p2align 3
.L923:
	testl	%ebp, %ebp
	je	.L860
.L893:
	leaq	.LC134(%rip), %rdi
	xorl	%eax, %eax
	call	err
	jmp	.L869
	.p2align 4,,10
	.p2align 3
.L921:
	andl	$-16777216, %ebx
	jmp	.L852
	.p2align 4,,10
	.p2align 3
.L877:
	leaq	.LC140(%rip), %rsi
	movl	$3, %edi
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L869
	.p2align 4,,10
	.p2align 3
.L861:
	cmpl	%edx, %esi
	jg	.L845
	.p2align 4
	.p2align 3
.L860:
	movl	708+cfg(%rip), %eax
	cmpl	%esi, %eax
	jg	.L864
	testl	%eax, %eax
	je	.L896
	addl	%eax, %eax
	movslq	%eax, %rsi
	salq	$2, %rsi
.L865:
	movl	%eax, 708+cfg(%rip)
	call	realloc@PLT
	movq	%rax, %rdi
	testq	%rax, %rax
	je	.L892
	movq	%rax, 696+cfg(%rip)
	movslq	704+cfg(%rip), %rsi
.L864:
	leal	1(%rsi), %eax
	movl	%eax, 704+cfg(%rip)
	xorl	%eax, %eax
	movl	%ebx, (%rdi,%rsi,4)
	jmp	.L845
	.p2align 4,,10
	.p2align 3
.L917:
	testl	%ebp, %ebp
	jne	.L894
.L888:
	movl	740+cfg(%rip), %edx
	cmpl	%edx, %esi
	jl	.L890
	testl	%edx, %edx
	leal	(%rdx,%rdx), %eax
	movl	$8, %edx
	cmove	%edx, %eax
	movl	%eax, 740+cfg(%rip)
	cltq
	salq	$4, %rax
	movq	%rax, %rsi
	call	realloc@PLT
	movq	%rax, %rdi
	testq	%rax, %rax
	je	.L892
	movq	%rax, 728+cfg(%rip)
	movl	736+cfg(%rip), %esi
.L890:
	leal	1(%rsi), %eax
	movd	%r13d, %xmm0
	movd	%r12d, %xmm1
	movl	%eax, 736+cfg(%rip)
	movslq	%esi, %rax
	punpckldq	%xmm1, %xmm0
	salq	$4, %rax
	addq	%rdi, %rax
	movq	%rbx, 8(%rax)
	movq	%xmm0, (%rax)
	xorl	%eax, %eax
	jmp	.L845
.L896:
	movl	$32, %esi
	movl	$8, %eax
	jmp	.L865
.L855:
	movq	696+cfg(%rip), %rdi
	testl	%ebp, %ebp
	je	.L860
	xorl	%edx, %edx
	jmp	.L859
.L894:
	leaq	.LC141(%rip), %rdi
	xorl	%eax, %eax
	call	err
	jmp	.L869
.L878:
	testl	%ebp, %ebp
	je	.L925
	xorl	%ecx, %ecx
	jmp	.L883
.L925:
	movq	728+cfg(%rip), %rdi
	jmp	.L888
.L918:
	cmpl	%ecx, %esi
	jle	.L888
	movslq	%ecx, %rdx
	salq	$4, %rdx
	addq	%rdi, %rdx
	cmpq	8(%rdx), %rbx
	je	.L845
	movq	%rbx, 8(%rdx)
	xorl	%eax, %eax
	jmp	.L845
.L892:
	call	xrealloc.part.0
	.cfi_endproc
.LFE79:
	.size	net_stmt, .-net_stmt
	.p2align 4
	.type	h_no_network, @function
h_no_network:
.LFB81:
	.cfi_startproc
	movl	$1, %edx
	jmp	net_stmt
	.cfi_endproc
.LFE81:
	.size	h_no_network, .-h_no_network
	.p2align 4
	.type	h_network, @function
h_network:
.LFB80:
	.cfi_startproc
	xorl	%edx, %edx
	jmp	net_stmt
	.cfi_endproc
.LFE80:
	.size	h_network, .-h_network
	.p2align 4
	.globl	rc_parse_uint
	.type	rc_parse_uint, @function
rc_parse_uint:
.LFB22:
	.cfi_startproc
	cmpb	$0, (%rdi)
	je	.L929
	jmp	rc_parse_uint.part.0
	.p2align 4,,10
	.p2align 3
.L929:
	xorl	%eax, %eax
	ret
	.cfi_endproc
.LFE22:
	.size	rc_parse_uint, .-rc_parse_uint
	.p2align 4
	.globl	rc_mask_ok
	.type	rc_mask_ok, @function
rc_mask_ok:
.LFB23:
	.cfi_startproc
	movl	%edi, %eax
	notl	%edi
	negl	%eax
	testl	%eax, %edi
	sete	%al
	movzbl	%al, %eax
	ret
	.cfi_endproc
.LFE23:
	.size	rc_mask_ok, .-rc_mask_ok
	.p2align 4
	.globl	rc_plen
	.type	rc_plen, @function
rc_plen:
.LFB24:
	.cfi_startproc
	xorl	%eax, %eax
	testl	%edi, %edi
	je	.L934
	.p2align 4
	.p2align 4
	.p2align 3
.L933:
	movl	%edi, %edx
	andl	$1, %edx
	addl	%edx, %eax
	shrl	%edi
	jne	.L933
	ret
	.p2align 4,,10
	.p2align 3
.L934:
	ret
	.cfi_endproc
.LFE24:
	.size	rc_plen, .-rc_plen
	.p2align 4
	.globl	rc_classful
	.type	rc_classful, @function
rc_classful:
.LFB25:
	.cfi_startproc
	movl	%edi, %eax
	shrl	$24, %eax
	leal	-1(%rax), %edx
	cmpl	$125, %edx
	jbe	.L942
	leal	-128(%rax), %edx
	cmpl	$63, %edx
	jbe	.L943
	subl	$192, %eax
	xorl	%edx, %edx
	cmpl	$31, %eax
	jbe	.L944
	movl	%edx, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L943:
	xorw	%di, %di
	movl	%edi, (%rsi)
.L938:
	movl	$1, %edx
	movl	%edx, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L942:
	andl	$-16777216, %edi
	movl	%edi, (%rsi)
	jmp	.L938
	.p2align 4,,10
	.p2align 3
.L944:
	xorb	%dil, %dil
	movl	%edi, (%rsi)
	jmp	.L938
	.cfi_endproc
.LFE25:
	.size	rc_classful, .-rc_classful
	.section	.rodata.str1.1
.LC142:
	.string	"%s%s"
	.text
	.p2align 4
	.globl	rc_canon_iface
	.type	rc_canon_iface, @function
rc_canon_iface:
.LFB36:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	movq	%rdx, %r12
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	movq	%rsi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rdi, %rbx
	subq	$56, %rsp
	.cfi_def_cfa_offset 112
	call	__ctype_b_loc@PLT
	movzbl	(%rbx), %edx
	movq	(%rax), %rsi
	testb	$4, 1(%rsi,%rdx,2)
	je	.L946
	movq	%rdx, %rax
	xorl	%edx, %edx
	.p2align 6
	.p2align 4
	.p2align 3
.L948:
	cmpq	$22, %rdx
	ja	.L947
	movb	%al, 16(%rsp,%rdx)
	addq	$1, %rdx
.L947:
	movzbl	1(%rbx), %ecx
	addq	$1, %rbx
	movq	%rcx, %rax
	movzwl	(%rsi,%rcx,2), %ecx
	testb	$4, %ch
	jne	.L948
	movb	$0, 16(%rsp,%rdx)
	testb	%al, %al
	jne	.L981
.L946:
	xorl	%r9d, %r9d
.L945:
	addq	$56, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movl	%r9d, %eax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L981:
	.cfi_restore_state
	movq	%rbx, %rax
	xorl	%r15d, %r15d
	andb	$8, %ch
	je	.L946
.L949:
	leaq	6(%rax), %rdi
.L951:
	movq	%rax, %r9
	movzbl	1(%rax), %ecx
	addq	$1, %rax
	testb	$8, 1(%rsi,%rcx,2)
	je	.L982
	cmpq	%rax, %rdi
	jne	.L951
	jmp	.L946
	.p2align 4,,10
	.p2align 3
.L982:
	addl	$1, %r15d
	cmpb	$47, %cl
	je	.L983
	testb	%cl, %cl
	jne	.L946
	cmpl	$3, %r15d
	jg	.L946
	xorl	%r13d, %r13d
	cmpb	$0, 16(%rsp)
	jne	.L984
.L954:
	addq	$1, %r13
	cmpq	$4, %r13
	jne	.L954
	jmp	.L946
.L984:
	leaq	16(%rsp), %rax
	leaq	IFTYPES(%rip), %r14
	movl	$0, 4(%rsp)
	movq	%rax, 8(%rsp)
	movq	(%r14,%r13,8), %rsi
.L956:
	movq	8(%rsp), %rdi
	call	rc_is_prefix_ci.part.0
	movl	%eax, %r9d
	testl	%eax, %eax
	jne	.L955
	addq	$1, %r13
	cmpq	$4, %r13
	je	.L946
	movl	%r13d, 4(%rsp)
	movq	(%r14,%r13,8), %rsi
	jmp	.L956
.L955:
	cmpl	$3, 4(%rsp)
	jne	.L959
	cmpl	$1, %r15d
	jne	.L946
.L959:
	movslq	4(%rsp), %r13
	movq	%rbx, %r8
	movq	%r12, %rsi
	movq	%rbp, %rdi
	leaq	.LC142(%rip), %rdx
	xorl	%eax, %eax
	movl	%r9d, 8(%rsp)
	movq	(%r14,%r13,8), %rcx
	call	snprintf@PLT
	movl	8(%rsp), %r9d
	jmp	.L945
.L983:
	movzbl	1(%rax), %eax
	addq	$2, %r9
	testb	$8, 1(%rsi,%rax,2)
	je	.L946
	movq	%r9, %rax
	jmp	.L949
	.cfi_endproc
.LFE36:
	.size	rc_canon_iface, .-rc_canon_iface
	.section	.rodata.str1.8
	.align 8
.LC143:
	.string	"Interface found by hash lookup:"
	.section	.rodata.str1.1
.LC144:
	.string	"Matches for \"%s\":\n"
.LC145:
	.string	"  [%s] %s\n"
.LC146:
	.string	"  %s\n"
	.section	.rodata.str1.8
	.align 8
.LC147:
	.string	"No configuration line contains \"%s\".\n"
	.section	.rodata.str1.1
.LC148:
	.string	"%d match(es).\n"
	.text
	.p2align 4
	.type	h_search, @function
h_search:
.LFB96:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pxor	%xmm0, %xmm0
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	leaq	.LC36(%rip), %rbx
	subq	$248, %rsp
	.cfi_def_cfa_offset 304
	movslq	708+C(%rip), %rax
	cmpl	%eax, 704+C(%rip)
	movq	$0, 224(%rsp)
	movaps	%xmm0, 48(%rsp)
	movaps	%xmm0, 112(%rsp)
	movaps	%xmm0, 128(%rsp)
	movaps	%xmm0, 144(%rsp)
	movaps	%xmm0, 160(%rsp)
	movaps	%xmm0, 176(%rsp)
	movaps	%xmm0, 192(%rsp)
	movaps	%xmm0, 208(%rsp)
	jle	.L986
	leaq	C(%rip), %rdx
	movslq	640(%rdx,%rax,4), %rbx
	addq	%rdx, %rbx
.L986:
	leaq	64(%rsp), %rbp
	movl	$40, %edx
	movq	%rbx, %rdi
	movq	%rbp, %rsi
	call	rc_canon_iface
	testl	%eax, %eax
	jne	.L1030
.L987:
	leaq	48(%rsp), %rdi
	call	gen_config
	movslq	56(%rsp), %rax
	movq	48(%rsp), %r13
	testl	%eax, %eax
	jle	.L988
	leaq	0(%r13,%rax,8), %rax
	movq	%r13, 32(%rsp)
	movq	%r13, %rbp
	xorl	%r15d, %r15d
	movq	%rax, 24(%rsp)
	movq	%r13, 40(%rsp)
	.p2align 4
	.p2align 3
.L1002:
	movq	0(%rbp), %rcx
	movzbl	(%rcx), %eax
	subl	$32, %eax
	cmpb	$1, %al
	ja	.L989
	movq	%rbx, %rdi
	movq	%rcx, 8(%rsp)
	call	strlen@PLT
	movq	8(%rsp), %rcx
	testq	%rax, %rax
	movq	%rax, %r14
	je	.L993
.L990:
	movq	%rbp, 8(%rsp)
	movq	%rcx, %r13
	movq	%rcx, 16(%rsp)
	.p2align 4
	.p2align 3
.L995:
	xorl	%ebp, %ebp
	.p2align 4
	.p2align 3
.L998:
	movzbl	0(%r13,%rbp), %r12d
	testb	%r12b, %r12b
	je	.L996
	call	__ctype_tolower_loc@PLT
	movzbl	(%rbx,%rbp), %esi
	movq	(%rax), %rcx
	movzbl	%r12b, %eax
	movl	(%rcx,%rsi,4), %edx
	cmpl	%edx, (%rcx,%rax,4)
	jne	.L996
	addq	$1, %rbp
	cmpq	%r14, %rbp
	jne	.L998
.L1025:
	movq	8(%rsp), %rbp
	movq	16(%rsp), %rcx
.L993:
	testl	%r15d, %r15d
	je	.L1031
.L992:
	cmpb	$32, (%rcx)
	je	.L1032
	movq	%rcx, %rsi
	leaq	.LC146(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
.L1001:
	addl	$1, %r15d
.L999:
	movq	24(%rsp), %rax
	addq	$8, %rbp
	cmpq	%rax, %rbp
	jne	.L1002
	movq	32(%rsp), %r13
	movq	40(%rsp), %r12
	testl	%r15d, %r15d
	je	.L1033
	movl	%r15d, %esi
	leaq	.LC148(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
	movq	24(%rsp), %rbx
	.p2align 4
	.p2align 3
.L1007:
	movq	(%r12), %rdi
	addq	$8, %r12
	call	free@PLT
	cmpq	%r12, %rbx
	jne	.L1007
.L1004:
	movq	%r13, %rdi
	call	free@PLT
	addq	$248, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L996:
	.cfi_restore_state
	cmpq	%r14, %rbp
	je	.L1025
	addq	$1, %r13
	cmpb	$0, 0(%r13)
	jne	.L995
	movq	8(%rsp), %rbp
	jmp	.L999
.L989:
	leaq	112(%rsp), %rdi
	leaq	.LC28(%rip), %rdx
	movl	$120, %esi
	xorl	%eax, %eax
	movq	%rcx, 8(%rsp)
	call	snprintf@PLT
	movq	%rbx, %rdi
	call	strlen@PLT
	movq	8(%rsp), %rcx
	testq	%rax, %rax
	movq	%rax, %r14
	je	.L993
	cmpb	$0, (%rcx)
	jne	.L990
	jmp	.L999
.L1032:
	leaq	1(%rcx), %rdx
	leaq	112(%rsp), %rsi
	xorl	%eax, %eax
	leaq	.LC145(%rip), %rdi
	call	printf@PLT
	jmp	.L1001
.L1031:
	movq	%rbx, %rsi
	leaq	.LC144(%rip), %rdi
	xorl	%eax, %eax
	movq	%rcx, 8(%rsp)
	call	printf@PLT
	movq	8(%rsp), %rcx
	jmp	.L992
.L1033:
	movq	%rbx, %rsi
	leaq	.LC147(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
	movq	24(%rsp), %rbx
	jmp	.L1007
.L1030:
	movq	%rbp, %rdi
	call	if_find
	testq	%rax, %rax
	je	.L987
	leaq	.LC143(%rip), %rdi
	call	puts@PLT
	movq	%rbp, %rdi
	call	if_find
	movq	%rax, %rdi
	call	print_if_detail
	leaq	.LC36(%rip), %rdi
	call	puts@PLT
	jmp	.L987
.L988:
	movq	%rbx, %rsi
	leaq	.LC147(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
	jmp	.L1004
	.cfi_endproc
.LFE96:
	.size	h_search, .-h_search
	.section	.rodata.str1.1
.LC149:
	.string	"Invalid network address."
.LC150:
	.string	"Invalid subnet mask."
.LC151:
	.string	"Invalid next hop / interface."
.LC152:
	.string	"No matching route to delete."
	.text
	.p2align 4
	.type	h_no_ip_route, @function
h_no_ip_route:
.LFB69:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	subq	$80, %rsp
	.cfi_def_cfa_offset 128
	cmpl	$1, %edi
	jle	.L1059
	movq	%rsi, %rbx
	movl	%edi, %ebp
	leaq	4(%rsp), %rsi
	movq	(%rbx), %rdi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L1060
	movq	8(%rbx), %rdi
	leaq	8(%rsp), %rsi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L1039
	movl	8(%rsp), %r12d
	movl	%r12d, %eax
	movl	%r12d, %edx
	negl	%eax
	notl	%edx
	testl	%eax, %edx
	jne	.L1039
	cmpl	$2, %ebp
	jne	.L1061
	movl	672+cfg(%rip), %ebx
	subl	$1, %ebx
	js	.L1050
	movslq	%ebx, %rax
	movl	4(%rsp), %r13d
	xorl	%r14d, %r14d
	movq	%rax, %rbp
	salq	$4, %rbp
	subq	%rax, %rbp
	salq	$2, %rbp
	jmp	.L1049
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L1048:
	subl	$1, %ebx
	subq	$60, %rbp
	cmpl	$-1, %ebx
	je	.L1062
.L1049:
	movq	664+cfg(%rip), %rax
	addq	%rbp, %rax
	cmpl	%r13d, (%rax)
	jne	.L1048
	cmpl	4(%rax), %r12d
	jne	.L1048
	movl	%ebx, %edi
	subl	$1, %ebx
	addl	$1, %r14d
	subq	$60, %rbp
	call	route_remove
	cmpl	$-1, %ebx
	jne	.L1049
	.p2align 4
	.p2align 3
.L1062:
	testl	%r14d, %r14d
	je	.L1050
	addq	$80, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 48
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1061:
	.cfi_restore_state
	pxor	%xmm0, %xmm0
	movq	16(%rbx), %rbx
	movd	%r12d, %xmm1
	leaq	24(%rsp), %rsi
	movups	%xmm0, 24(%rsp)
	movups	%xmm0, 40(%rsp)
	movq	%rbx, %rdi
	movups	%xmm0, 56(%rsp)
	movd	4(%rsp), %xmm0
	movl	$0, 72(%rsp)
	punpckldq	%xmm1, %xmm0
	movq	%xmm0, 16(%rsp)
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L1042
	movl	$1, 68(%rsp)
.L1043:
	leaq	12(%rsp), %rsi
	leaq	16(%rsp), %rdi
	call	route_find
	testl	%eax, %eax
	jne	.L1045
	leaq	.LC152(%rip), %rdi
	call	err
.L1044:
	addq	$80, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 48
	movl	$-1, %eax
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1045:
	.cfi_restore_state
	movl	12(%rsp), %edi
	call	route_remove
	addq	$80, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 48
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1042:
	.cfi_restore_state
	leaq	28(%rsp), %rsi
	movl	$40, %edx
	movq	%rbx, %rdi
	call	rc_canon_iface
	testl	%eax, %eax
	jne	.L1043
	leaq	.LC151(%rip), %rsi
	movl	$2, %edi
	call	bad_arg
	jmp	.L1044
	.p2align 4,,10
	.p2align 3
.L1050:
	leaq	.LC152(%rip), %rdi
	xorl	%eax, %eax
	call	err
	jmp	.L1044
.L1039:
	leaq	.LC150(%rip), %rsi
	movl	$1, %edi
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L1044
.L1060:
	leaq	.LC149(%rip), %rsi
	xorl	%edi, %edi
	call	bad_arg
	jmp	.L1044
.L1059:
	leaq	.LC53(%rip), %rdi
	xorl	%eax, %eax
	call	err
	jmp	.L1044
	.cfi_endproc
.LFE69:
	.size	h_no_ip_route, .-h_no_ip_route
	.section	.rodata.str1.1
.LC153:
	.string	"Invalid subnet mask \"%s\"."
	.section	.rodata.str1.8
	.align 8
.LC154:
	.string	"Inconsistent address and mask: host bits set (did you mean %s?)."
	.section	.rodata.str1.1
.LC155:
	.string	"Invalid next-hop address."
	.section	.rodata.str1.8
	.align 8
.LC156:
	.string	"Invalid next hop %s (it is this router's own interface address)."
	.align 8
.LC157:
	.string	"Next hop must be an IP address or an exit interface."
	.align 8
.LC158:
	.string	"Exit interface %s does not exist (create it with 'interface' first)."
	.align 8
.LC159:
	.string	"Administrative distance must be 1-255."
	.section	.rodata.str1.1
.LC160:
	.string	"route added %s/%d ad=%d"
	.section	.rodata.str1.8
	.align 8
.LC161:
	.string	"%% Warning: next hop %s is not on a connected, up network - route not installed yet.\n"
	.text
	.p2align 4
	.type	h_ip_route, @function
h_ip_route:
.LFB68:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pxor	%xmm0, %xmm0
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$152, %rsp
	.cfi_def_cfa_offset 208
	movaps	%xmm0, 112(%rsp)
	movq	$1, 24(%rsp)
	movaps	%xmm0, 80(%rsp)
	movaps	%xmm0, 96(%rsp)
	movups	%xmm0, 124(%rsp)
	cmpl	$2, %edi
	jle	.L1110
	movq	(%rsi), %r12
	movl	%edi, %ebp
	movq	%rsi, %rbx
	leaq	16(%rsp), %rsi
	movq	%r12, %rdi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L1111
	movq	8(%rbx), %r14
	leaq	20(%rsp), %rsi
	movq	%r14, %rdi
	call	rc_parse_ip
	movl	%eax, %r12d
	testl	%eax, %eax
	je	.L1067
	movl	20(%rsp), %r13d
	movl	%r13d, %eax
	movl	%r13d, %edx
	negl	%eax
	notl	%edx
	testl	%eax, %edx
	jne	.L1067
	movl	16(%rsp), %r15d
	movl	%r13d, %edi
	andl	%r15d, %edi
	cmpl	%edi, %r15d
	jne	.L1112
	movq	16(%rbx), %r14
	leaq	88(%rsp), %rsi
	movq	%r14, %rdi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L1070
	movl	88(%rsp), %edx
	testl	%edx, %edx
	je	.L1071
	cmpl	$-536870913, %edx
	ja	.L1071
	movq	640+cfg(%rip), %rax
	testq	%rax, %rax
	je	.L1073
	.p2align 4
	.p2align 3
.L1075:
	movl	148(%rax), %ecx
	testl	%ecx, %ecx
	je	.L1074
	cmpl	140(%rax), %edx
	je	.L1113
.L1074:
	movq	176(%rax), %rax
	testq	%rax, %rax
	jne	.L1075
.L1073:
	movl	$1, 132(%rsp)
.L1076:
	cmpl	$4, %ebp
	jne	.L1080
	movq	24(%rbx), %rdi
	cmpb	$0, (%rdi)
	je	.L1081
	leaq	24(%rsp), %rcx
	movl	$255, %edx
	movl	$1, %esi
	call	rc_parse_uint.part.0
	testl	%eax, %eax
	je	.L1081
	movl	24(%rsp), %r12d
.L1080:
	movd	%r13d, %xmm1
	movd	%r15d, %xmm0
	leaq	80(%rsp), %rdi
	movl	%r12d, 136(%rsp)
	punpckldq	%xmm1, %xmm0
	leaq	32(%rsp), %rsi
	movq	%xmm0, 80(%rsp)
	call	route_find
	movslq	32(%rsp), %rbp
	movq	664+cfg(%rip), %rdi
	movl	%eax, %ebx
	testl	%eax, %eax
	je	.L1082
	movq	%rbp, %rax
	salq	$4, %rax
	subq	%rbp, %rax
	leaq	(%rdi,%rax,4), %rax
	cmpl	%r12d, 56(%rax)
	je	.L1063
	movl	%r12d, 56(%rax)
.L1084:
	xorl	%ebx, %ebx
	jmp	.L1063
	.p2align 4,,10
	.p2align 3
.L1111:
	movq	%r12, %rdx
	leaq	.LC132(%rip), %rsi
	xorl	%edi, %edi
	call	bad_arg
.L1065:
	movl	$-1, %ebx
.L1063:
	addq	$152, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movl	%ebx, %eax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1110:
	.cfi_restore_state
	leaq	.LC53(%rip), %rdi
	xorl	%eax, %eax
	call	err
	jmp	.L1065
	.p2align 4,,10
	.p2align 3
.L1067:
	movq	%r14, %rdx
	leaq	.LC153(%rip), %rsi
	movl	$1, %edi
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L1065
	.p2align 4,,10
	.p2align 3
.L1112:
	call	rc_ipstr
	leaq	.LC154(%rip), %rsi
	xorl	%edi, %edi
	movq	%rax, %rdx
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L1065
	.p2align 4,,10
	.p2align 3
.L1071:
	leaq	.LC155(%rip), %rsi
	movl	$2, %edi
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L1065
	.p2align 4,,10
	.p2align 3
.L1070:
	leaq	32(%rsp), %rax
	movl	$40, %edx
	movq	%r14, %rdi
	movq	%rax, %rsi
	movq	%rax, 8(%rsp)
	call	rc_canon_iface
	testl	%eax, %eax
	je	.L1114
	movq	8(%rsp), %rdi
	call	if_find
	testq	%rax, %rax
	je	.L1115
	movq	8(%rsp), %rcx
	leaq	92(%rsp), %rdi
	leaq	.LC28(%rip), %rdx
	xorl	%eax, %eax
	movl	$40, %esi
	call	snprintf@PLT
	jmp	.L1076
	.p2align 4,,10
	.p2align 3
.L1081:
	leaq	.LC159(%rip), %rsi
	movl	$3, %edi
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L1065
	.p2align 4,,10
	.p2align 3
.L1113:
	movq	%r14, %rdx
	leaq	.LC156(%rip), %rsi
	movl	$2, %edi
	xorl	%eax, %eax
	call	bad_arg
	jmp	.L1065
	.p2align 4,,10
	.p2align 3
.L1114:
	leaq	.LC157(%rip), %rsi
	movl	$2, %edi
	call	bad_arg
	jmp	.L1065
	.p2align 4,,10
	.p2align 3
.L1082:
	movl	672+cfg(%rip), %eax
	movl	676+cfg(%rip), %edx
	cmpl	%edx, %eax
	jl	.L1085
	testl	%edx, %edx
	je	.L1091
	addl	%edx, %edx
	movslq	%edx, %rax
	movq	%rax, %rsi
	salq	$4, %rsi
	subq	%rax, %rsi
	salq	$2, %rsi
.L1086:
	movl	%edx, 676+cfg(%rip)
	call	realloc@PLT
	movq	%rax, %rdi
	testq	%rax, %rax
	je	.L1116
	movq	%rax, 664+cfg(%rip)
	movl	672+cfg(%rip), %eax
.L1085:
	movslq	%ebp, %rdx
	subl	%ebp, %eax
	movq	%rdx, %r14
	cltq
	salq	$4, %r14
	subq	%rdx, %r14
	movq	%rax, %rdx
	salq	$4, %rdx
	salq	$2, %r14
	subq	%rax, %rdx
	leaq	(%rdi,%r14), %rsi
	leaq	60(%rdi,%r14), %rdi
	salq	$2, %rdx
	call	memmove@PLT
	movdqa	80(%rsp), %xmm0
	movq	664+cfg(%rip), %rax
	movups	%xmm0, (%rax,%r14)
	movdqa	96(%rsp), %xmm0
	movups	%xmm0, 16(%rax,%r14)
	movdqa	112(%rsp), %xmm0
	movups	%xmm0, 32(%rax,%r14)
	movdqu	124(%rsp), %xmm0
	movups	%xmm0, 44(%rax,%r14)
	addl	$1, 672+cfg(%rip)
	testl	%r13d, %r13d
	je	.L1088
	.p2align 4
	.p2align 4
	.p2align 3
.L1089:
	movl	%r13d, %eax
	andl	$1, %eax
	addl	%eax, %ebx
	shrl	%r13d
	jne	.L1089
.L1088:
	movl	%r15d, %edi
	call	rc_ipstr
	movl	%r12d, %r9d
	movl	%ebx, %r8d
	movl	$1, %edi
	movq	%rax, %rcx
	leaq	.LC160(%rip), %rdx
	leaq	.LC2(%rip), %rsi
	xorl	%eax, %eax
	call	rlog_log@PLT
	movl	loading(%rip), %edx
	testl	%edx, %edx
	jne	.L1084
	movl	132(%rsp), %eax
	testl	%eax, %eax
	je	.L1084
	movl	88(%rsp), %edi
	call	connected_if
	testq	%rax, %rax
	jne	.L1084
	call	rc_ipstr
	leaq	.LC161(%rip), %rdi
	xorl	%ebx, %ebx
	movq	%rax, %rsi
	xorl	%eax, %eax
	call	printf@PLT
	jmp	.L1063
	.p2align 4,,10
	.p2align 3
.L1115:
	movq	8(%rsp), %rdx
	leaq	.LC158(%rip), %rsi
	movl	$2, %edi
	call	bad_arg
	jmp	.L1065
.L1091:
	movl	$480, %esi
	movl	$8, %edx
	jmp	.L1086
.L1116:
	call	xrealloc.part.0
	.cfi_endproc
.LFE68:
	.size	h_ip_route, .-h_ip_route
	.section	.rodata.str1.8
	.align 8
.LC162:
	.string	"Invalid interface. Examples: g0/0, fa0/1, s0/0/0, loopback0."
	.section	.rodata.str1.1
.LC163:
	.string	"created interface %s"
	.text
	.p2align 4
	.type	h_interface, @function
h_interface:
.LFB57:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	addq	$-128, %rsp
	.cfi_def_cfa_offset 160
	movq	(%rsi), %rcx
	leaq	48(%rsp), %rbx
	cmpl	$2, %edi
	je	.L1133
	leaq	.LC28(%rip), %rdx
	movl	$80, %esi
	movq	%rbx, %rdi
	xorl	%eax, %eax
	call	snprintf@PLT
.L1119:
	movl	$40, %edx
	movq	%rsp, %rsi
	movq	%rbx, %rdi
	movq	%rsp, %r12
	call	rc_canon_iface
	testl	%eax, %eax
	je	.L1134
	movq	%rsp, %rdi
	call	if_find
	movq	%rax, %rbp
	testq	%rax, %rax
	je	.L1135
.L1122:
	movq	%rbp, cur_if(%rip)
	xorl	%eax, %eax
	movl	$3, mode(%rip)
.L1117:
	subq	$-128, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1133:
	.cfi_restore_state
	movq	8(%rsi), %r8
	leaq	.LC142(%rip), %rdx
	movq	%rbx, %rdi
	xorl	%eax, %eax
	movl	$80, %esi
	call	snprintf@PLT
	jmp	.L1119
	.p2align 4,,10
	.p2align 3
.L1135:
	movl	$1, %esi
	movl	$184, %edi
	call	calloc@PLT
	movq	%rax, %rbp
	testq	%rax, %rax
	je	.L1123
	movzbl	(%rsp), %ebx
	testb	%bl, %bl
	je	.L1136
	call	__ctype_tolower_loc@PLT
	movq	%rsp, %rdx
	movq	(%rax), %rsi
	movl	$5381, %eax
	.p2align 5
	.p2align 4
	.p2align 3
.L1126:
	movl	%eax, %ecx
	addq	$1, %rdx
	sall	$5, %ecx
	addl	%ecx, %eax
	movzbl	(%rsi,%rbx,4), %ecx
	movzbl	(%rdx), %ebx
	addl	%ecx, %eax
	testb	%bl, %bl
	jne	.L1126
	andl	$63, %eax
	movl	%eax, %ebx
.L1125:
	movq	%r12, %rcx
	leaq	.LC28(%rip), %rdx
	xorl	%eax, %eax
	movq	%rbp, %rdi
	movl	$40, %esi
	call	snprintf@PLT
	leaq	cfg(%rip), %rdx
	movabsq	$7738135660173684556, %rax
	cmpq	%rax, (%rsp)
	setne	%al
	movzbl	%al, %eax
	movl	%eax, 152(%rbp)
	movl	%ebx, %eax
	addq	$16, %rax
	movq	(%rdx,%rax,8), %rcx
	movq	%rbp, (%rdx,%rax,8)
	movq	648+cfg(%rip), %rax
	movq	%rcx, 168(%rbp)
	testq	%rax, %rax
	je	.L1129
	movq	%rbp, 176(%rax)
.L1130:
	movq	%r12, %rcx
	leaq	.LC163(%rip), %rdx
	xorl	%edi, %edi
	xorl	%eax, %eax
	leaq	.LC2(%rip), %rsi
	addl	$1, 656+cfg(%rip)
	movq	%rbp, 648+cfg(%rip)
	call	rlog_log@PLT
	jmp	.L1122
	.p2align 4,,10
	.p2align 3
.L1129:
	movq	%rbp, 640+cfg(%rip)
	jmp	.L1130
	.p2align 4,,10
	.p2align 3
.L1136:
	movl	$5, %ebx
	jmp	.L1125
.L1134:
	leaq	.LC162(%rip), %rsi
	xorl	%edi, %edi
	call	bad_arg
	movl	$-1, %eax
	jmp	.L1117
.L1123:
	movq	stderr(%rip), %rcx
	movl	$14, %edx
	movl	$1, %esi
	leaq	.LC19(%rip), %rdi
	call	fwrite@PLT
	movl	$1, %edi
	call	exit@PLT
	.cfi_endproc
.LFE57:
	.size	h_interface, .-h_interface
	.section	.rodata.str1.1
.LC164:
	.string	"Invalid interface name."
	.section	.rodata.str1.8
	.align 8
.LC165:
	.string	"Cannot delete physical interface %s (only loopbacks can be removed)."
	.section	.rodata.str1.1
.LC166:
	.string	"Interface %s does not exist."
.LC167:
	.string	"deleted interface %s"
	.text
	.p2align 4
	.type	h_no_interface, @function
h_no_interface:
.LFB58:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	addq	$-128, %rsp
	.cfi_def_cfa_offset 176
	movq	(%rsi), %rcx
	leaq	48(%rsp), %rbx
	cmpl	$2, %edi
	je	.L1192
	leaq	.LC28(%rip), %rdx
	movl	$80, %esi
	movq	%rbx, %rdi
	xorl	%eax, %eax
	call	snprintf@PLT
.L1139:
	movl	$40, %edx
	movq	%rsp, %rsi
	movq	%rbx, %rdi
	movq	%rsp, %r14
	call	rc_canon_iface
	testl	%eax, %eax
	je	.L1193
	movabsq	$7738135660173684556, %rax
	cmpq	%rax, (%rsp)
	je	.L1194
	movq	%rsp, %rsi
	leaq	.LC165(%rip), %rdi
	xorl	%eax, %eax
	call	err
.L1141:
	movl	$-1, %ebx
.L1137:
	subq	$-128, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 48
	movl	%ebx, %eax
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1192:
	.cfi_restore_state
	movq	8(%rsi), %r8
	leaq	.LC142(%rip), %rdx
	movq	%rbx, %rdi
	xorl	%eax, %eax
	movl	$80, %esi
	call	snprintf@PLT
	jmp	.L1139
	.p2align 4,,10
	.p2align 3
.L1194:
	movq	%rsp, %rdi
	xorl	%ebx, %ebx
	call	if_find
	movq	%rax, %r12
	testq	%rax, %rax
	je	.L1195
	movl	672+cfg(%rip), %ebp
	subl	$1, %ebp
	js	.L1151
	movslq	%ebp, %rax
	movq	%rax, %r13
	salq	$4, %r13
	subq	%rax, %r13
	salq	$2, %r13
	jmp	.L1150
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L1149:
	subl	$1, %ebp
	subq	$60, %r13
	cmpl	$-1, %ebp
	je	.L1151
.L1150:
	movq	664+cfg(%rip), %rdi
	addq	%r13, %rdi
	movl	52(%rdi), %eax
	testl	%eax, %eax
	jne	.L1149
	addq	$12, %rdi
	movq	%r14, %rsi
	call	strcmp@PLT
	testl	%eax, %eax
	jne	.L1149
	movl	%ebp, %edi
	subl	$1, %ebp
	subq	$60, %r13
	call	route_remove
	cmpl	$-1, %ebp
	jne	.L1150
	.p2align 4
	.p2align 3
.L1151:
	cmpq	%r12, cur_if(%rip)
	je	.L1196
	movzbl	(%r12), %ebp
	testb	%bpl, %bpl
	je	.L1169
.L1198:
	call	__ctype_tolower_loc@PLT
	movq	%r12, %rdx
	movq	(%rax), %rsi
	movl	$5381, %eax
	.p2align 5
	.p2align 4
	.p2align 3
.L1153:
	movl	%eax, %ecx
	addq	$1, %rdx
	sall	$5, %ecx
	addl	%ecx, %eax
	movzbl	(%rsi,%rbp,4), %ecx
	movzbl	(%rdx), %ebp
	addl	%ecx, %eax
	testb	%bpl, %bpl
	jne	.L1153
	andl	$63, %eax
	leal	16(%rax), %edx
	salq	$3, %rdx
.L1152:
	leaq	cfg(%rip), %rcx
	addq	%rcx, %rdx
	cmpq	$0, 128(%rcx,%rax,8)
	je	.L1154
	movq	(%rdx), %rax
	jmp	.L1155
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L1156:
	leaq	168(%rax), %rdx
	movq	168(%rax), %rax
	testq	%rax, %rax
	je	.L1154
.L1155:
	cmpq	%rax, %r12
	jne	.L1156
	movq	168(%r12), %rax
	movq	%rax, (%rdx)
.L1154:
	movq	640+cfg(%rip), %rax
	cmpq	%rax, %r12
	je	.L1158
	testq	%rax, %rax
	je	.L1163
	.p2align 5
	.p2align 4
	.p2align 3
.L1159:
	movq	%rax, %rdx
	movq	176(%rax), %rax
	testq	%rax, %rax
	je	.L1163
	cmpq	%rax, %r12
	jne	.L1159
	testq	%rax, %rax
	je	.L1163
	movq	176(%r12), %rax
	movq	%rax, 176(%rdx)
.L1165:
	cmpq	648+cfg(%rip), %r12
	je	.L1197
.L1163:
	xorl	%edi, %edi
	xorl	%eax, %eax
	movq	%r12, %rcx
	subl	$1, 656+cfg(%rip)
	leaq	.LC167(%rip), %rdx
	leaq	.LC2(%rip), %rsi
	call	rlog_log@PLT
	movq	%r12, %rdi
	call	free@PLT
	cmpl	$3, mode(%rip)
	jne	.L1137
	movl	$2, mode(%rip)
	subq	$-128, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 48
	movl	%ebx, %eax
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1196:
	.cfi_restore_state
	movq	$0, cur_if(%rip)
	movzbl	(%r12), %ebp
	testb	%bpl, %bpl
	jne	.L1198
.L1169:
	movl	$168, %edx
	movl	$5, %eax
	jmp	.L1152
	.p2align 4,,10
	.p2align 3
.L1197:
	movq	%rdx, 648+cfg(%rip)
	jmp	.L1163
.L1158:
	testq	%rax, %rax
	je	.L1163
	movq	176(%r12), %rax
	xorl	%edx, %edx
	movq	%rax, 640+cfg(%rip)
	jmp	.L1165
.L1193:
	leaq	.LC164(%rip), %rsi
	xorl	%edi, %edi
	call	bad_arg
	jmp	.L1141
.L1195:
	movq	%rsp, %rsi
	leaq	.LC166(%rip), %rdi
	xorl	%eax, %eax
	call	err
	jmp	.L1141
	.cfi_endproc
.LFE58:
	.size	h_no_interface, .-h_no_interface
	.section	.rodata.str1.8
	.align 8
.LC168:
	.string	"Interface %s is not configured."
	.text
	.p2align 4
	.type	h_show_if, @function
h_show_if:
.LFB87:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$136, %rsp
	.cfi_def_cfa_offset 160
	testl	%edi, %edi
	jne	.L1215
	movq	640+cfg(%rip), %rbx
	testq	%rbx, %rbx
	je	.L1210
	.p2align 4
	.p2align 3
.L1208:
	movq	%rbx, %rdi
	call	print_if_detail
	movq	176(%rbx), %rbx
	testq	%rbx, %rbx
	jne	.L1208
.L1210:
	movl	656+cfg(%rip), %eax
	testl	%eax, %eax
	je	.L1209
.L1211:
	addq	$136, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1209:
	.cfi_restore_state
	leaq	.LC97(%rip), %rdi
	call	puts@PLT
	jmp	.L1211
	.p2align 4,,10
	.p2align 3
.L1215:
	movq	(%rsi), %rcx
	leaq	48(%rsp), %rbx
	cmpl	$2, %edi
	je	.L1216
	leaq	.LC28(%rip), %rdx
	movl	$80, %esi
	movq	%rbx, %rdi
	xorl	%eax, %eax
	call	snprintf@PLT
.L1202:
	movl	$40, %edx
	movq	%rsp, %rsi
	movq	%rbx, %rdi
	call	rc_canon_iface
	testl	%eax, %eax
	je	.L1217
	movq	%rsp, %rdi
	call	if_find
	movq	%rax, %rdi
	testq	%rax, %rax
	je	.L1218
	call	print_if_detail
	addq	$136, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1218:
	.cfi_restore_state
	movq	%rsp, %rsi
	leaq	.LC168(%rip), %rdi
	xorl	%eax, %eax
	call	err
.L1204:
	addq	$136, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	movl	$-1, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1217:
	.cfi_restore_state
	leaq	.LC164(%rip), %rsi
	xorl	%edi, %edi
	call	bad_arg
	jmp	.L1204
	.p2align 4,,10
	.p2align 3
.L1216:
	movq	8(%rsi), %r8
	leaq	.LC142(%rip), %rdx
	movq	%rbx, %rdi
	xorl	%eax, %eax
	movl	$80, %esi
	call	snprintf@PLT
	jmp	.L1202
	.cfi_endproc
.LFE87:
	.size	h_show_if, .-h_show_if
	.p2align 4
	.globl	rc_join_iface
	.type	rc_join_iface, @function
rc_join_iface:
.LFB37:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	movq	%rcx, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movq	%rdx, %rbx
	subq	$80, %rsp
	.cfi_def_cfa_offset 112
	movq	(%rsi), %rcx
	movq	%rsp, %r12
	cmpl	$2, %edi
	je	.L1223
	leaq	.LC28(%rip), %rdx
	movl	$80, %esi
	movq	%rsp, %rdi
	xorl	%eax, %eax
	call	snprintf@PLT
.L1221:
	movq	%rbp, %rdx
	movq	%rbx, %rsi
	movq	%r12, %rdi
	call	rc_canon_iface
	addq	$80, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1223:
	.cfi_restore_state
	movq	8(%rsi), %r8
	leaq	.LC142(%rip), %rdx
	movq	%rsp, %rdi
	xorl	%eax, %eax
	movl	$80, %esi
	call	snprintf@PLT
	jmp	.L1221
	.cfi_endproc
.LFE37:
	.size	rc_join_iface, .-rc_join_iface
	.section	.rodata.str1.1
.LC169:
	.string	"reset to default"
	.text
	.p2align 4
	.globl	rc_reset_config
	.type	rc_reset_config, @function
rc_reset_config:
.LFB42:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movq	640+cfg(%rip), %rbx
	testq	%rbx, %rbx
	je	.L1225
	.p2align 4
	.p2align 3
.L1226:
	movq	%rbx, %rdi
	movq	176(%rbx), %rbx
	call	free@PLT
	testq	%rbx, %rbx
	jne	.L1226
.L1225:
	movq	664+cfg(%rip), %rdi
	leaq	cfg(%rip), %rbx
	call	free@PLT
	movq	696+cfg(%rip), %rdi
	call	free@PLT
	movq	728+cfg(%rip), %rdi
	call	free@PLT
	xorl	%eax, %eax
	movq	%rbx, %rdi
	movl	$93, %ecx
	rep stosq
	movl	$1, %edi
	leaq	.LC36(%rip), %rax
	leaq	.LC169(%rip), %rdx
	movq	%rax, load_name(%rip)
	xorl	%eax, %eax
	leaq	.LC2(%rip), %rsi
	movl	$1953853266, cfg(%rip)
	popq	%rbx
	.cfi_def_cfa_offset 8
	movl	$7497076, 3+cfg(%rip)
	movl	$0, mode(%rip)
	movq	$0, cur_if(%rip)
	movl	$0, quit_flag(%rip)
	movl	$0, loading(%rip)
	movl	$0, load_line(%rip)
	jmp	rlog_log@PLT
	.cfi_endproc
.LFE42:
	.size	rc_reset_config, .-rc_reset_config
	.section	.rodata.str1.8
	.align 8
.LC170:
	.string	"--- Validating configuration of %s ---\n"
	.align 8
.LC171:
	.string	"  [warn ] hostname is still the default 'Router'."
	.align 8
.LC172:
	.string	"  [warn ] %s is up but has no IP address.\n"
	.align 8
.LC173:
	.string	"  [warn ] %s has an IP address but is administratively down.\n"
	.align 8
.LC174:
	.string	"  [warn ] %s has a clock rate but is down.\n"
	.align 8
.LC175:
	.string	"  [warn ] static route %s/%d via %s is NOT installed (next hop unreachable).\n"
	.align 8
.LC176:
	.string	"  [warn ] static route %s/%d via %s is NOT installed (interface down).\n"
	.align 8
.LC177:
	.string	"  [warn ] RIP is enabled but has no network statements."
	.align 8
.LC178:
	.string	"  [warn ] RIP network %s matches no interface.\n"
	.align 8
.LC179:
	.string	"  [warn ] OSPF is enabled but has no network statements."
	.align 8
.LC180:
	.string	"  [error] OSPF has no router-id and no up interface with an IP to derive one from."
	.align 8
.LC181:
	.string	"  [warn ] OSPF network %s %s matches no interface.\n"
	.align 8
.LC182:
	.string	"  [error] %s and %s share IP %s.\n"
	.align 8
.LC183:
	.string	"--- Result: %d error(s), %d warning(s) ---\n"
	.text
	.p2align 4
	.globl	rc_validate
	.type	rc_validate, @function
rc_validate:
.LFB92:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	xorl	%eax, %eax
	leaq	cfg(%rip), %rsi
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movq	%rdi, 8(%rsp)
	leaq	.LC170(%rip), %rdi
	call	printf@PLT
	cmpl	$1953853266, cfg(%rip)
	je	.L1338
.L1233:
	xorl	%r12d, %r12d
.L1235:
	movq	640+cfg(%rip), %rbx
	testq	%rbx, %rbx
	je	.L1236
	leaq	.LC174(%rip), %r15
	leaq	.LC173(%rip), %r13
	leaq	.LC124(%rip), %rbp
	jmp	.L1241
	.p2align 4,,10
	.p2align 3
.L1340:
	movl	$8, %edx
	movq	%rbp, %rsi
	movq	%rbx, %rdi
	call	strncmp@PLT
	movl	148(%rbx), %ecx
	testl	%ecx, %ecx
	jne	.L1240
	testl	%eax, %eax
	jne	.L1339
.L1240:
	movq	176(%rbx), %rbx
	testq	%rbx, %rbx
	je	.L1236
.L1241:
	movl	152(%rbx), %esi
	testl	%esi, %esi
	je	.L1340
.L1237:
	movl	148(%rbx), %eax
	testl	%eax, %eax
	jne	.L1341
	cmpq	$0, 160(%rbx)
	je	.L1240
.L1283:
	movq	%rbx, %rsi
	movq	%r15, %rdi
	xorl	%eax, %eax
	addl	$1, %r12d
	call	printf@PLT
	movq	176(%rbx), %rbx
	testq	%rbx, %rbx
	jne	.L1241
	.p2align 4
	.p2align 3
.L1236:
	movl	672+cfg(%rip), %eax
	testl	%eax, %eax
	jle	.L1242
	xorl	%ebp, %ebp
	xorl	%ebx, %ebx
	.p2align 4
	.p2align 3
.L1252:
	movq	664+cfg(%rip), %r15
	addq	%rbp, %r15
	movl	52(%r15), %r14d
	testl	%r14d, %r14d
	jne	.L1342
	leaq	12(%r15), %r13
	movq	%r13, %rdi
	call	if_find
	testq	%rax, %rax
	je	.L1246
	movl	152(%rax), %eax
	testl	%eax, %eax
	je	.L1245
.L1246:
	movl	4(%r15), %eax
	testl	%eax, %eax
	je	.L1250
	.p2align 4
	.p2align 4
	.p2align 3
.L1251:
	movl	%eax, %ecx
	andl	$1, %ecx
	addl	%ecx, %r14d
	shrl	%eax
	jne	.L1251
.L1250:
	movl	(%r15), %edi
	call	rc_ipstr
	movq	%r13, %rcx
	movl	%r14d, %edx
	leaq	.LC176(%rip), %rdi
	movq	%rax, %rsi
	xorl	%eax, %eax
	call	printf@PLT
.L1249:
	addl	$1, %r12d
.L1245:
	addl	$1, %ebx
	addq	$60, %rbp
	cmpl	%ebx, 672+cfg(%rip)
	jg	.L1252
.L1242:
	movl	680+cfg(%rip), %eax
	testl	%eax, %eax
	je	.L1253
	movl	704+cfg(%rip), %eax
	testl	%eax, %eax
	je	.L1343
.L1254:
	xorl	%ebp, %ebp
	leaq	.LC178(%rip), %rbx
	testl	%eax, %eax
	jle	.L1253
	.p2align 4
	.p2align 3
.L1262:
	movq	696+cfg(%rip), %rdx
	movq	640+cfg(%rip), %rax
	leaq	(%rdx,%rbp,4), %r8
	testq	%rax, %rax
	je	.L1255
	xorl	%edi, %edi
	jmp	.L1260
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L1256:
	movq	176(%rax), %rax
	testq	%rax, %rax
	je	.L1344
.L1260:
	movl	148(%rax), %r15d
	testl	%r15d, %r15d
	je	.L1256
	movl	140(%rax), %ecx
	movl	%ecx, %edx
	shrl	$24, %edx
	leal	-1(%rdx), %esi
	cmpl	$125, %esi
	jbe	.L1345
	leal	-128(%rdx), %esi
	cmpl	$63, %esi
	jbe	.L1346
	subl	$192, %edx
	cmpl	$31, %edx
	ja	.L1256
	xorb	%cl, %cl
.L1258:
	xorl	%edx, %edx
	movq	176(%rax), %rax
	cmpl	%ecx, (%r8)
	sete	%dl
	orl	%edx, %edi
	testq	%rax, %rax
	jne	.L1260
	.p2align 4
	.p2align 3
.L1344:
	testl	%edi, %edi
	je	.L1255
.L1261:
	addq	$1, %rbp
	cmpl	%ebp, 704+cfg(%rip)
	jg	.L1262
.L1253:
	movl	712+cfg(%rip), %r13d
	testl	%r13d, %r13d
	je	.L1263
	movl	736+cfg(%rip), %r14d
	testl	%r14d, %r14d
	je	.L1347
.L1264:
	movq	640+cfg(%rip), %rbp
	testq	%rbp, %rbp
	je	.L1265
	movq	%rbp, %rax
	xorl	%edx, %edx
	.p2align 6
	.p2align 4
	.p2align 3
.L1267:
	movl	148(%rax), %r13d
	testl	%r13d, %r13d
	je	.L1266
	movl	152(%rax), %ebx
	xorl	%ecx, %ecx
	testl	%ebx, %ebx
	sete	%cl
	orl	%ecx, %edx
.L1266:
	movq	176(%rax), %rax
	testq	%rax, %rax
	jne	.L1267
	orl	720+cfg(%rip), %edx
	je	.L1269
	movl	736+cfg(%rip), %eax
	xorl	%r13d, %r13d
	testl	%eax, %eax
	jle	.L1284
.L1270:
	xorl	%r15d, %r15d
	leaq	.LC181(%rip), %r14
.L1278:
	movq	728+cfg(%rip), %rdi
	movq	%r15, %rbx
	salq	$4, %rbx
	leaq	(%rdi,%rbx), %rsi
	testq	%rbp, %rbp
	je	.L1274
.L1277:
	movq	%rbp, %rax
	xorl	%ecx, %ecx
	.p2align 6
	.p2align 4
	.p2align 3
.L1276:
	movl	148(%rax), %r8d
	testl	%r8d, %r8d
	je	.L1275
	movl	4(%rsi), %edx
	notl	%edx
	andl	140(%rax), %edx
	cmpl	(%rsi), %edx
	sete	%dl
	movzbl	%dl, %edx
	orl	%edx, %ecx
.L1275:
	movq	176(%rax), %rax
	testq	%rax, %rax
	jne	.L1276
	testl	%ecx, %ecx
	je	.L1274
	addq	$1, %r15
	cmpl	%r15d, 736+cfg(%rip)
	jle	.L1273
	movq	%r15, %rbx
	salq	$4, %rbx
	leaq	(%rdi,%rbx), %rsi
	jmp	.L1277
	.p2align 4,,10
	.p2align 3
.L1341:
	xorl	%eax, %eax
	movq	%rbx, %rsi
	movq	%r13, %rdi
	addl	$1, %r12d
	call	printf@PLT
	cmpq	$0, 160(%rbx)
	je	.L1240
	movl	152(%rbx), %eax
	testl	%eax, %eax
	je	.L1240
	jmp	.L1283
	.p2align 4,,10
	.p2align 3
.L1342:
	movl	8(%r15), %edi
	call	connected_if
	testq	%rax, %rax
	jne	.L1245
	call	rc_ipstr
	xorl	%r14d, %r14d
	movq	%rax, %r13
	movl	4(%r15), %eax
	testl	%eax, %eax
	je	.L1247
	.p2align 4
	.p2align 4
	.p2align 3
.L1248:
	movl	%eax, %ecx
	andl	$1, %ecx
	addl	%ecx, %r14d
	shrl	%eax
	jne	.L1248
.L1247:
	movl	(%r15), %edi
	call	rc_ipstr
	movq	%r13, %rcx
	movl	%r14d, %edx
	leaq	.LC175(%rip), %rdi
	movq	%rax, %rsi
	xorl	%eax, %eax
	call	printf@PLT
	jmp	.L1249
.L1339:
	movq	%rbx, %rsi
	leaq	.LC172(%rip), %rdi
	xorl	%eax, %eax
	addl	$1, %r12d
	call	printf@PLT
	movl	152(%rbx), %edx
	testl	%edx, %edx
	je	.L1240
	jmp	.L1237
	.p2align 4,,10
	.p2align 3
.L1263:
	movq	640+cfg(%rip), %rbp
.L1273:
	testq	%rbp, %rbp
	je	.L1271
.L1284:
	leaq	.LC182(%rip), %r15
	.p2align 4
	.p2align 3
.L1281:
	movq	176(%rbp), %rbx
	testq	%rbx, %rbx
	je	.L1271
	.p2align 4
	.p2align 3
.L1280:
	movl	148(%rbp), %ecx
	testl	%ecx, %ecx
	je	.L1279
	movl	148(%rbx), %edx
	testl	%edx, %edx
	je	.L1279
	movl	140(%rbp), %edi
	cmpl	140(%rbx), %edi
	je	.L1348
	.p2align 4
	.p2align 3
.L1279:
	movq	176(%rbx), %rbx
	testq	%rbx, %rbx
	jne	.L1280
	movq	176(%rbp), %rbp
	testq	%rbp, %rbp
	jne	.L1281
	.p2align 4
	.p2align 3
.L1271:
	movl	%r12d, %edx
	movl	%r13d, %esi
	leaq	.LC183(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
	movq	8(%rsp), %rax
	testq	%rax, %rax
	je	.L1232
	movl	%r12d, (%rax)
.L1232:
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movl	%r13d, %eax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1348:
	.cfi_restore_state
	call	rc_ipstr
	movq	%rbx, %rdx
	movq	%rbp, %rsi
	movq	%r15, %rdi
	movq	%rax, %rcx
	xorl	%eax, %eax
	addl	$1, %r13d
	call	printf@PLT
	jmp	.L1279
	.p2align 4,,10
	.p2align 3
.L1345:
	andl	$-16777216, %ecx
	jmp	.L1258
	.p2align 4,,10
	.p2align 3
.L1346:
	xorw	%cx, %cx
	jmp	.L1258
	.p2align 4,,10
	.p2align 3
.L1255:
	movl	(%r8), %edi
	addl	$1, %r12d
	call	rc_ipstr
	movq	%rbx, %rdi
	movq	%rax, %rsi
	xorl	%eax, %eax
	call	printf@PLT
	jmp	.L1261
	.p2align 4,,10
	.p2align 3
.L1274:
	movl	4(%rsi), %edi
	addl	$1, %r12d
	addq	$1, %r15
	call	rc_ipstr
	movq	%rax, %rbp
	movq	728+cfg(%rip), %rax
	movl	(%rax,%rbx), %edi
	call	rc_ipstr
	movq	%rbp, %rdx
	movq	%r14, %rdi
	movq	%rax, %rsi
	xorl	%eax, %eax
	call	printf@PLT
	cmpl	%r15d, 736+cfg(%rip)
	movq	640+cfg(%rip), %rbp
	jg	.L1278
	jmp	.L1273
.L1338:
	cmpl	$7497076, 3+cfg(%rip)
	jne	.L1233
	leaq	.LC171(%rip), %rdi
	movl	$1, %r12d
	call	puts@PLT
	jmp	.L1235
.L1347:
	leaq	.LC179(%rip), %rdi
	addl	$1, %r12d
	call	puts@PLT
	jmp	.L1264
.L1343:
	leaq	.LC177(%rip), %rdi
	addl	$1, %r12d
	call	puts@PLT
	movl	704+cfg(%rip), %eax
	jmp	.L1254
.L1265:
	movl	720+cfg(%rip), %r11d
	testl	%r11d, %r11d
	jne	.L1349
.L1269:
	leaq	.LC180(%rip), %rdi
	movl	$1, %r13d
	call	puts@PLT
	movl	736+cfg(%rip), %r9d
	movq	640+cfg(%rip), %rbp
	testl	%r9d, %r9d
	jg	.L1270
	jmp	.L1273
.L1349:
	movl	736+cfg(%rip), %r10d
	xorl	%r13d, %r13d
	testl	%r10d, %r10d
	jg	.L1270
	jmp	.L1271
	.cfi_endproc
.LFE92:
	.size	rc_validate, .-rc_validate
	.section	.rodata.str1.1
.LC184:
	.string	"ON"
.LC185:
	.string	"OFF"
	.section	.rodata.str1.8
	.align 8
.LC186:
	.string	"Compilation aborted: %d configuration error(s)."
	.section	.rodata.str1.1
.LC187:
	.string	"%s.rcx"
.LC188:
	.string	"w"
.LC189:
	.string	"Cannot write %s"
	.section	.rodata.str1.8
	.align 8
.LC190:
	.string	"\n--- Generated executable instructions ---"
	.align 8
.LC191:
	.string	"; RCC executable configuration for %s\n"
	.section	.rodata.str1.1
.LC192:
	.string	"SET_HOST"
.LC193:
	.string	"SET_SECRET"
.LC194:
	.string	"IF_SELECT"
.LC195:
	.string	"\"%s\""
.LC196:
	.string	"IF_DESC"
.LC197:
	.string	"%s %s"
.LC198:
	.string	"IF_IPV4"
.LC199:
	.string	"%ld"
.LC200:
	.string	"IF_CLOCK"
.LC201:
	.string	"-"
.LC202:
	.string	"IF_ADMIN_DN"
.LC203:
	.string	"IF_ADMIN_UP"
.LC204:
	.string	"%s %s VIA %s AD %d"
.LC205:
	.string	"ROUTE_ADD"
.LC206:
	.string	"%s %s OUT %s AD %d"
.LC207:
	.string	"v%d"
.LC208:
	.string	"RIP_ENABLE"
.LC209:
	.string	"RIP_NET"
.LC210:
	.string	"RIP_AUTOSUM"
.LC211:
	.string	"%d"
.LC212:
	.string	"OSPF_ENABLE"
.LC213:
	.string	"OSPF_RID"
.LC214:
	.string	"%s %s AREA %llu"
.LC215:
	.string	"OSPF_NET"
.LC216:
	.string	"checksum=0x%08lX"
.LC217:
	.string	"COMMIT"
	.section	.rodata.str1.8
	.align 8
.LC218:
	.string	"compiled %d instructions -> %s"
	.section	.rodata.str1.1
.LC219:
	.string	"codegen"
	.section	.rodata.str1.8
	.align 8
.LC220:
	.string	"\nCompiled %d instruction(s) -> %s\n"
	.align 8
.LC221:
	.string	"Optimisation report: %d config command(s) accepted, %d duplicate/no-op command(s) skipped,\n  %d default-state interface(s) pruned, routes emitted in sorted order, final state only (no history).\n"
	.section	.rodata.str1.1
.LC222:
	.string	"Compiled with %d warning(s).\n"
	.text
	.p2align 4
	.type	h_compile, @function
h_compile:
.LFB95:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	movq	%rsi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movl	%edi, %ebx
	subq	$248, %rsp
	.cfi_def_cfa_offset 304
	leaq	44(%rsp), %rdi
	call	rc_validate
	movl	%eax, 28(%rsp)
	testl	%eax, %eax
	jne	.L1396
	testl	%ebx, %ebx
	jne	.L1397
	leaq	80(%rsp), %rdi
	leaq	cfg(%rip), %rcx
	movl	$160, %esi
	xorl	%eax, %eax
	leaq	.LC187(%rip), %rdx
	movq	%rdi, 16(%rsp)
	call	snprintf@PLT
.L1354:
	movq	16(%rsp), %rdi
	pxor	%xmm0, %xmm0
	leaq	.LC188(%rip), %rsi
	movq	$0, 64(%rsp)
	movaps	%xmm0, 48(%rsp)
	leaq	48(%rsp), %rbx
	call	fopen@PLT
	movq	%rax, %rbp
	testq	%rax, %rax
	je	.L1398
	leaq	.LC190(%rip), %rdi
	leaq	cfg(%rip), %r12
	call	puts@PLT
	movq	%r12, %rdx
	movq	%rbp, %rdi
	xorl	%eax, %eax
	leaq	.LC191(%rip), %rsi
	call	fprintf@PLT
	xorl	%eax, %eax
	movq	%r12, %r8
	movl	$1, %esi
	leaq	.LC28(%rip), %rcx
	leaq	.LC192(%rip), %rdx
	movq	%rbx, %rdi
	movq	%rbp, 56(%rsp)
	call	emit
	cmpb	$0, 64+cfg(%rip)
	jne	.L1356
.L1392:
	movq	640+cfg(%rip), %r15
	movl	$0, 24(%rsp)
	movq	56(%rsp), %r14
	testq	%r15, %r15
	je	.L1358
	leaq	.LC194(%rip), %r13
	leaq	.LC201(%rip), %r12
	jmp	.L1366
	.p2align 4,,10
	.p2align 3
.L1402:
	leaq	.LC202(%rip), %rdx
	movl	$21, %esi
	movq	%rbx, %rdi
	xorl	%eax, %eax
	call	emit
	movq	56(%rsp), %r14
.L1360:
	movq	176(%r15), %r15
	testq	%r15, %r15
	je	.L1358
.L1366:
	movl	152(%r15), %eax
	testl	%eax, %eax
	je	.L1359
	movl	148(%r15), %eax
	testl	%eax, %eax
	jne	.L1359
	cmpb	$0, 40(%r15)
	jne	.L1359
	cmpq	$0, 160(%r15)
	je	.L1399
	.p2align 4
	.p2align 3
.L1359:
	xorl	%eax, %eax
	movq	%r15, %r8
	leaq	.LC28(%rip), %rcx
	movq	%r13, %rdx
	movl	$16, %esi
	movq	%rbx, %rdi
	movq	%r14, 56(%rsp)
	call	emit
	cmpb	$0, 40(%r15)
	jne	.L1361
.L1393:
	movl	148(%r15), %eax
	movq	56(%rsp), %rbp
	testl	%eax, %eax
	jne	.L1400
.L1363:
	movq	160(%r15), %r8
	testq	%r8, %r8
	jne	.L1401
.L1364:
	movl	152(%r15), %r14d
	movq	%rbp, 56(%rsp)
	movq	%r12, %rcx
	testl	%r14d, %r14d
	jne	.L1402
	leaq	.LC203(%rip), %rdx
	movl	$20, %esi
	movq	%rbx, %rdi
	xorl	%eax, %eax
	call	emit
	movq	176(%r15), %r15
	movq	56(%rsp), %r14
	testq	%r15, %r15
	jne	.L1366
.L1358:
	movl	672+cfg(%rip), %r13d
	testl	%r13d, %r13d
	jle	.L1367
	movq	%rbx, (%rsp)
	xorl	%r13d, %r13d
	xorl	%r15d, %r15d
	jmp	.L1370
	.p2align 4,,10
	.p2align 3
.L1404:
	movl	8(%rbp), %edi
	call	rc_ipstr
	movl	4(%rbp), %edi
	movq	%rax, %r12
	call	rc_ipstr
	movl	0(%rbp), %edi
	movq	%rax, 8(%rsp)
	call	rc_ipstr
	movq	%r14, 56(%rsp)
	leaq	.LC204(%rip), %rcx
	pushq	%rbx
	.cfi_def_cfa_offset 312
	movq	%rax, %r8
	pushq	%r12
	.cfi_def_cfa_offset 320
	movq	24(%rsp), %r9
.L1394:
	movq	16(%rsp), %rdi
	xorl	%eax, %eax
	movl	$32, %esi
	addl	$1, %r13d
	leaq	.LC205(%rip), %rdx
	addq	$60, %r15
	call	emit
	cmpl	%r13d, 672+cfg(%rip)
	movq	72(%rsp), %r14
	popq	%r11
	.cfi_def_cfa_offset 312
	popq	%rbx
	.cfi_def_cfa_offset 304
	jle	.L1403
.L1370:
	movq	664+cfg(%rip), %rbp
	addq	%r15, %rbp
	movl	52(%rbp), %r12d
	movl	56(%rbp), %ebx
	testl	%r12d, %r12d
	jne	.L1404
	movl	4(%rbp), %edi
	addq	$12, %rbp
	call	rc_ipstr
	movl	-12(%rbp), %edi
	movq	%rax, %r12
	call	rc_ipstr
	movq	%r14, 56(%rsp)
	movq	%r12, %r9
	leaq	.LC206(%rip), %rcx
	pushq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 312
	movq	%rax, %r8
	pushq	%rbp
	.cfi_def_cfa_offset 320
	jmp	.L1394
	.p2align 4,,10
	.p2align 3
.L1397:
	.cfi_restore_state
	movq	0(%rbp), %rcx
	leaq	80(%rsp), %rdi
	movl	$160, %esi
	xorl	%eax, %eax
	leaq	.LC28(%rip), %rdx
	movq	%rdi, 16(%rsp)
	call	snprintf@PLT
	jmp	.L1354
	.p2align 4,,10
	.p2align 3
.L1401:
	movl	$19, %esi
	movq	%rbx, %rdi
	xorl	%eax, %eax
	movq	%rbp, 56(%rsp)
	leaq	.LC199(%rip), %rcx
	leaq	.LC200(%rip), %rdx
	call	emit
	movq	56(%rsp), %rbp
	jmp	.L1364
	.p2align 4,,10
	.p2align 3
.L1400:
	movl	144(%r15), %edi
	call	rc_ipstr
	movl	140(%r15), %edi
	movq	%rax, %r14
	call	rc_ipstr
	movq	%r14, %r9
	movl	$18, %esi
	movq	%rbx, %rdi
	movq	%rax, %r8
	leaq	.LC197(%rip), %rcx
	xorl	%eax, %eax
	movq	%rbp, 56(%rsp)
	leaq	.LC198(%rip), %rdx
	call	emit
	movq	56(%rsp), %rbp
	jmp	.L1363
	.p2align 4,,10
	.p2align 3
.L1361:
	leaq	40(%r15), %r8
	leaq	.LC195(%rip), %rcx
	movq	%rbx, %rdi
	xorl	%eax, %eax
	leaq	.LC196(%rip), %rdx
	movl	$17, %esi
	call	emit
	jmp	.L1393
	.p2align 4,,10
	.p2align 3
.L1403:
	movq	(%rsp), %rbx
.L1367:
	movl	680+cfg(%rip), %r10d
	testl	%r10d, %r10d
	jne	.L1405
.L1371:
	movl	712+cfg(%rip), %edi
	testl	%edi, %edi
	jne	.L1406
.L1375:
	movl	64(%rsp), %r8d
	movl	$255, %esi
	movq	%rbx, %rdi
	xorl	%eax, %eax
	leaq	.LC216(%rip), %rcx
	leaq	.LC217(%rip), %rdx
	movq	%r14, 56(%rsp)
	call	emit
	movq	56(%rsp), %rdi
	call	fclose@PLT
	movl	48(%rsp), %ebx
	movq	16(%rsp), %r14
	xorl	%eax, %eax
	leaq	.LC218(%rip), %rdx
	leaq	.LC219(%rip), %rsi
	movl	$1, %edi
	movq	%r14, %r8
	movl	%ebx, %ecx
	call	rlog_log@PLT
	movq	%r14, %rdx
	movl	%ebx, %esi
	xorl	%eax, %eax
	leaq	.LC220(%rip), %rdi
	call	printf@PLT
	movl	4+st(%rip), %esi
	movl	24(%rsp), %ecx
	xorl	%eax, %eax
	movl	8+st(%rip), %edx
	leaq	.LC221(%rip), %rdi
	call	printf@PLT
	movl	44(%rsp), %esi
	testl	%esi, %esi
	jne	.L1407
.L1350:
	movl	28(%rsp), %eax
	addq	$248, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1399:
	.cfi_restore_state
	addl	$1, 24(%rsp)
	jmp	.L1360
	.p2align 4,,10
	.p2align 3
.L1356:
	leaq	64+cfg(%rip), %r8
	movl	$2, %esi
	movq	%rbx, %rdi
	xorl	%eax, %eax
	leaq	.LC28(%rip), %rcx
	leaq	.LC193(%rip), %rdx
	call	emit
	jmp	.L1392
	.p2align 4,,10
	.p2align 3
.L1407:
	leaq	.LC222(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
	jmp	.L1350
	.p2align 4,,10
	.p2align 3
.L1406:
	movl	$64, %esi
	movq	%rbx, %rdi
	xorl	%eax, %eax
	movq	%r14, 56(%rsp)
	movl	716+cfg(%rip), %r8d
	leaq	.LC211(%rip), %rcx
	leaq	.LC212(%rip), %rdx
	call	emit
	movl	720+cfg(%rip), %esi
	testl	%esi, %esi
	jne	.L1376
.L1395:
	movl	736+cfg(%rip), %ecx
	movq	56(%rsp), %r14
	testl	%ecx, %ecx
	jle	.L1375
	xorl	%r13d, %r13d
	.p2align 4
	.p2align 3
.L1378:
	movq	728+cfg(%rip), %rax
	movq	%r13, %r12
	addq	$1, %r13
	salq	$4, %r12
	addq	%r12, %rax
	movl	4(%rax), %edi
	movq	8(%rax), %r15
	call	rc_ipstr
	movq	%rax, %rbp
	movq	728+cfg(%rip), %rax
	movl	(%rax,%r12), %edi
	call	rc_ipstr
	movq	%r14, 56(%rsp)
	movq	%rbp, %r9
	movq	%rbx, %rdi
	subq	$8, %rsp
	.cfi_def_cfa_offset 312
	movq	%rax, %r8
	xorl	%eax, %eax
	movl	$66, %esi
	pushq	%r15
	.cfi_def_cfa_offset 320
	leaq	.LC215(%rip), %rdx
	leaq	.LC214(%rip), %rcx
	call	emit
	cmpl	%r13d, 736+cfg(%rip)
	movq	72(%rsp), %r14
	popq	%rax
	.cfi_def_cfa_offset 312
	popq	%rdx
	.cfi_def_cfa_offset 304
	jg	.L1378
	jmp	.L1375
	.p2align 4,,10
	.p2align 3
.L1405:
	movl	$48, %esi
	movq	%rbx, %rdi
	xorl	%eax, %eax
	movq	%r14, 56(%rsp)
	movl	684+cfg(%rip), %r8d
	leaq	.LC207(%rip), %rcx
	leaq	.LC208(%rip), %rdx
	call	emit
	movl	704+cfg(%rip), %r9d
	movq	56(%rsp), %r14
	testl	%r9d, %r9d
	jle	.L1372
	xorl	%r13d, %r13d
	leaq	.LC209(%rip), %r12
	.p2align 4
	.p2align 3
.L1373:
	movq	696+cfg(%rip), %rax
	movl	(%rax,%r13,4), %edi
	addq	$1, %r13
	call	rc_ipstr
	movq	%r12, %rdx
	movl	$49, %esi
	movq	%rbx, %rdi
	movq	%rax, %r8
	leaq	.LC28(%rip), %rcx
	xorl	%eax, %eax
	movq	%r14, 56(%rsp)
	call	emit
	cmpl	%r13d, 704+cfg(%rip)
	movq	56(%rsp), %r14
	jg	.L1373
.L1372:
	movl	688+cfg(%rip), %r8d
	movl	$50, %esi
	movq	%rbx, %rdi
	leaq	.LC185(%rip), %rax
	leaq	.LC28(%rip), %rcx
	leaq	.LC210(%rip), %rdx
	movq	%r14, 56(%rsp)
	testl	%r8d, %r8d
	leaq	.LC184(%rip), %r8
	cmove	%rax, %r8
	xorl	%eax, %eax
	call	emit
	movq	56(%rsp), %r14
	jmp	.L1371
	.p2align 4,,10
	.p2align 3
.L1376:
	movl	724+cfg(%rip), %edi
	call	rc_ipstr
	leaq	.LC28(%rip), %rcx
	movl	$65, %esi
	movq	%rbx, %rdi
	movq	%rax, %r8
	leaq	.LC213(%rip), %rdx
	xorl	%eax, %eax
	call	emit
	jmp	.L1395
.L1396:
	movl	%eax, %esi
	leaq	.LC186(%rip), %rdi
	xorl	%eax, %eax
	call	err
.L1352:
	movl	$-1, 28(%rsp)
	jmp	.L1350
.L1398:
	movq	16(%rsp), %rsi
	leaq	.LC189(%rip), %rdi
	xorl	%eax, %eax
	call	err
	jmp	.L1352
	.cfi_endproc
.LFE95:
	.size	h_compile, .-h_compile
	.p2align 4
	.type	h_validate, @function
h_validate:
.LFB93:
	.cfi_startproc
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	xorl	%edi, %edi
	call	rc_validate
	xorl	%eax, %eax
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE93:
	.size	h_validate, .-h_validate
	.section	.rodata.str1.1
.LC223:
	.string	"Cannot open %s for writing."
	.text
	.p2align 4
	.globl	rc_save_file
	.type	rc_save_file, @function
rc_save_file:
.LFB97:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pxor	%xmm0, %xmm0
	leaq	.LC188(%rip), %rsi
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rdi, %rbx
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movaps	%xmm0, (%rsp)
	call	fopen@PLT
	testq	%rax, %rax
	je	.L1420
	movq	%rsp, %rdi
	movq	%rax, %r13
	call	gen_config
	movslq	8(%rsp), %rax
	movq	(%rsp), %r15
	testl	%eax, %eax
	jle	.L1416
	movq	%r15, %rbp
	leaq	(%r15,%rax,8), %r12
	movq	%r15, %rbx
	leaq	.LC7(%rip), %r14
	.p2align 4
	.p2align 3
.L1414:
	movq	(%rbx), %rdx
	movq	%r14, %rsi
	movq	%r13, %rdi
	xorl	%eax, %eax
	addq	$8, %rbx
	call	fprintf@PLT
	cmpq	%r12, %rbx
	jne	.L1414
	.p2align 4
	.p2align 3
.L1415:
	movq	0(%rbp), %rdi
	addq	$8, %rbp
	call	free@PLT
	cmpq	%r12, %rbp
	jne	.L1415
.L1416:
	movq	%r15, %rdi
	call	free@PLT
	movq	%r13, %rdi
	call	fclose@PLT
	xorl	%eax, %eax
.L1410:
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L1420:
	.cfi_restore_state
	movq	%rbx, %rsi
	leaq	.LC223(%rip), %rdi
	xorl	%eax, %eax
	call	err
	orl	$-1, %eax
	jmp	.L1410
	.cfi_endproc
.LFE97:
	.size	rc_save_file, .-rc_save_file
	.section	.rodata.str1.8
	.align 8
.LC224:
	.string	"[OK] configuration saved to %s\n"
	.text
	.p2align 4
	.type	h_save, @function
h_save:
.LFB102:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movq	(%rsi), %rdi
	call	rc_save_file
	testl	%eax, %eax
	jne	.L1423
	movq	0(%rbp), %rsi
	movl	%eax, %ebx
	leaq	.LC224(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
.L1421:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	movl	%ebx, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1423:
	.cfi_restore_state
	movl	$-1, %ebx
	jmp	.L1421
	.cfi_endproc
.LFE102:
	.size	h_save, .-h_save
	.section	.rodata.str1.1
.LC225:
	.string	"memory"
.LC226:
	.string	"Did you mean 'write memory'?"
.LC227:
	.string	"Building configuration..."
	.section	.rodata.str1.8
	.align 8
.LC228:
	.string	"[OK] saved to startup-config.cfg"
	.text
	.p2align 4
	.type	h_write, @function
h_write:
.LFB99:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	testl	%edi, %edi
	je	.L1426
	movq	(%rsi), %rdi
	cmpb	$0, (%rdi)
	je	.L1427
	leaq	.LC225(%rip), %rsi
	call	rc_is_prefix_ci.part.0
	testl	%eax, %eax
	je	.L1427
.L1426:
	leaq	.LC227(%rip), %rdi
	call	puts@PLT
	leaq	.LC9(%rip), %rdi
	call	rc_save_file
	movl	%eax, %ebx
	testl	%eax, %eax
	jne	.L1428
	leaq	.LC228(%rip), %rdi
	call	puts@PLT
	movl	%ebx, %eax
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1427:
	.cfi_restore_state
	leaq	.LC226(%rip), %rsi
	xorl	%edi, %edi
	xorl	%eax, %eax
	call	bad_arg
.L1428:
	movl	$-1, %ebx
	movl	%ebx, %eax
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE99:
	.size	h_write, .-h_write
	.p2align 4
	.type	h_copy, @function
h_copy:
.LFB100:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	leaq	.LC227(%rip), %rdi
	call	puts@PLT
	leaq	.LC9(%rip), %rdi
	call	rc_save_file
	testl	%eax, %eax
	jne	.L1437
	leaq	.LC228(%rip), %rdi
	movl	%eax, %ebx
	call	puts@PLT
.L1435:
	movl	%ebx, %eax
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1437:
	.cfi_restore_state
	movl	$-1, %ebx
	jmp	.L1435
	.cfi_endproc
.LFE100:
	.size	h_copy, .-h_copy
	.section	.rodata.str1.1
.LC229:
	.string	"Cannot open file \"%s\"."
	.section	.rodata.str1.8
	.align 8
.LC230:
	.string	"loaded %d line(s) from %s (%d error(s))"
	.section	.rodata.str1.1
.LC231:
	.string	"loader"
	.section	.rodata.str1.8
	.align 8
.LC232:
	.string	"Loaded %d line(s) from %s (%d error(s)).\n"
	.text
	.p2align 4
	.globl	rc_load_file
	.type	rc_load_file, @function
rc_load_file:
.LFB98:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	leaq	.LC8(%rip), %rsi
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rdi, %rbx
	subq	$264, %rsp
	.cfi_def_cfa_offset 320
	call	fopen@PLT
	movl	mode(%rip), %r15d
	movl	nerr(%rip), %r14d
	testq	%rax, %rax
	je	.L1446
	movq	%rbx, %rdi
	movq	%rax, %r12
	call	strlen@PLT
	leaq	1(%rax), %rbp
	movq	%rbp, %rdi
	call	malloc@PLT
	movq	%rax, %r13
	testq	%rax, %rax
	je	.L1447
	movq	%rbp, %rdx
	movq	%rbx, %rsi
	movq	%rax, %rdi
	xorl	%ebx, %ebx
	call	memcpy@PLT
	movq	%rsp, %rbp
	call	rc_reset_config
	movq	%r13, load_name(%rip)
	movl	$2, mode(%rip)
	movl	$1, loading(%rip)
	jmp	.L1443
	.p2align 4,,10
	.p2align 3
.L1444:
	addl	$1, %ebx
	movq	%rbp, %rdi
	movl	%ebx, load_line(%rip)
	call	execute_line_impl
.L1443:
	movq	%r12, %rdx
	movl	$256, %esi
	movq	%rbp, %rdi
	call	fgets@PLT
	testq	%rax, %rax
	jne	.L1444
	leaq	.LC36(%rip), %rax
	movq	%r12, %rdi
	movl	$0, loading(%rip)
	movq	%rax, load_name(%rip)
	movl	%r15d, mode(%rip)
	movq	$0, cur_if(%rip)
	call	fclose@PLT
	movl	nerr(%rip), %r9d
	xorl	%eax, %eax
	movl	%ebx, %ecx
	movq	%r13, %r8
	leaq	.LC230(%rip), %rdx
	movl	$1, %edi
	subl	%r14d, %r9d
	leaq	.LC231(%rip), %rsi
	call	rlog_log@PLT
	movl	nerr(%rip), %ecx
	movq	%r13, %rdx
	movl	%ebx, %esi
	leaq	.LC232(%rip), %rdi
	xorl	%eax, %eax
	subl	%r14d, %ecx
	call	printf@PLT
	movq	%r13, %rdi
	call	free@PLT
	xorl	%eax, %eax
	cmpl	%r14d, nerr(%rip)
	setne	%al
	negl	%eax
.L1439:
	addq	$264, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L1446:
	.cfi_restore_state
	movq	%rbx, %rsi
	leaq	.LC229(%rip), %rdi
	xorl	%eax, %eax
	call	err
	orl	$-1, %eax
	jmp	.L1439
.L1447:
	movq	stderr(%rip), %rcx
	movl	$14, %edx
	movl	$1, %esi
	leaq	.LC19(%rip), %rdi
	call	fwrite@PLT
	movl	$1, %edi
	call	exit@PLT
	.cfi_endproc
.LFE98:
	.size	rc_load_file, .-rc_load_file
	.section	.rodata.str1.8
	.align 8
.LC233:
	.string	"Proceed with reload? [confirm]"
	.section	.rodata.str1.1
.LC234:
	.string	"Restarting system..."
.LC235:
	.string	"reload requested"
	.text
	.p2align 4
	.type	h_reload, @function
h_reload:
.LFB104:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	leaq	.LC233(%rip), %rdi
	xorl	%eax, %eax
	subq	$16, %rsp
	.cfi_def_cfa_offset 32
	call	printf@PLT
	movq	stdout(%rip), %rdi
	call	fflush@PLT
	movq	stdin(%rip), %rdx
	movq	%rsp, %rdi
	movl	$16, %esi
	call	fgets@PLT
	testq	%rax, %rax
	je	.L1452
	movzbl	(%rsp), %eax
	andl	$-33, %eax
	cmpb	$78, %al
	jne	.L1460
.L1450:
	xorl	%eax, %eax
.L1448:
	addq	$16, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1460:
	.cfi_restore_state
	call	rc_reset_config
	leaq	.LC9(%rip), %rbx
	leaq	.LC234(%rip), %rdi
	movl	$0, mode(%rip)
	call	puts@PLT
	movq	%rbx, %rdi
	leaq	.LC8(%rip), %rsi
	call	fopen@PLT
	movq	%rax, %rdi
	testq	%rax, %rax
	je	.L1451
	call	fclose@PLT
	movq	%rbx, %rdi
	call	rc_load_file
	movl	$0, mode(%rip)
.L1451:
	leaq	.LC235(%rip), %rdx
	leaq	.LC5(%rip), %rsi
	movl	$1, %edi
	xorl	%eax, %eax
	call	rlog_log@PLT
	jmp	.L1450
.L1452:
	movl	$-1, %eax
	jmp	.L1448
	.cfi_endproc
.LFE104:
	.size	h_reload, .-h_reload
	.p2align 4
	.type	h_load, @function
h_load:
.LFB103:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	leaq	.LC28(%rip), %rdx
	xorl	%eax, %eax
	subq	$208, %rsp
	.cfi_def_cfa_offset 224
	movq	(%rsi), %rcx
	movl	$200, %esi
	movq	%rsp, %rdi
	call	snprintf@PLT
	movq	%rsp, %rdi
	call	rc_load_file
	addq	$208, %rsp
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE103:
	.size	h_load, .-h_load
	.p2align 4
	.globl	rc_execute_line
	.type	rc_execute_line, @function
rc_execute_line:
.LFB113:
	.cfi_startproc
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	call	execute_line_impl
	movl	nerr(%rip), %eax
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE113:
	.size	rc_execute_line, .-rc_execute_line
	.p2align 4
	.globl	rc_set_quit_flag
	.type	rc_set_quit_flag, @function
rc_set_quit_flag:
.LFB114:
	.cfi_startproc
	movl	%edi, quit_flag(%rip)
	ret
	.cfi_endproc
.LFE114:
	.size	rc_set_quit_flag, .-rc_set_quit_flag
	.p2align 4
	.globl	rc_get_quit_flag
	.type	rc_get_quit_flag, @function
rc_get_quit_flag:
.LFB115:
	.cfi_startproc
	movl	quit_flag(%rip), %eax
	ret
	.cfi_endproc
.LFE115:
	.size	rc_get_quit_flag, .-rc_get_quit_flag
	.p2align 4
	.globl	rc_gen_config_lines
	.type	rc_gen_config_lines, @function
rc_gen_config_lines:
.LFB116:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pxor	%xmm0, %xmm0
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	movq	%rsi, %r14
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	movq	%rdi, %r13
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movq	%rsp, %rdi
	movaps	%xmm0, (%rsp)
	call	gen_config
	movslq	8(%rsp), %rax
	movq	(%rsp), %r15
	testl	%eax, %eax
	jle	.L1471
	movq	%r15, %rbp
	leaq	(%r15,%rax,8), %r12
	movq	%r15, %rbx
	.p2align 4
	.p2align 3
.L1469:
	movq	(%rbx), %rdi
	addq	$8, %rbx
	movq	%r14, %rsi
	call	*%r13
	cmpq	%r12, %rbx
	jne	.L1469
	.p2align 4
	.p2align 3
.L1470:
	movq	0(%rbp), %rdi
	addq	$8, %rbp
	call	free@PLT
	cmpq	%r12, %rbp
	jne	.L1470
.L1471:
	addq	$24, %rsp
	.cfi_def_cfa_offset 56
	movq	%r15, %rdi
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	jmp	free@PLT
	.cfi_endproc
.LFE116:
	.size	rc_gen_config_lines, .-rc_gen_config_lines
	.section	.rodata.str1.1
.LC236:
	.string	"reports/router_compiler.log"
	.section	.rodata.str1.8
	.align 8
.LC237:
	.string	"warning: could not open %s for logging\n"
	.align 8
.LC238:
	.string	"router compiler start (Linux POC)"
	.section	.rodata.str1.1
.LC239:
	.string	"main"
	.section	.rodata.str1.8
	.align 8
.LC240:
	.string	"===================================================================="
	.align 8
.LC241:
	.string	"  Network Router Configuration Compiler  (Cisco IOS style CLI)"
	.align 8
.LC242:
	.string	"  Type '?' or 'help' for commands, 'exit' in user mode to quit."
	.align 8
.LC243:
	.string	"Restoring saved startup-config..."
	.section	.rodata.str1.1
.LC244:
	.string	"\nBye."
.LC245:
	.string	"router compiler exit"
	.text
	.p2align 4
	.globl	rc_run_cli
	.type	rc_run_cli, @function
rc_run_cli:
.LFB117:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	leaq	.LC236(%rip), %rbx
	subq	$376, %rsp
	.cfi_def_cfa_offset 432
	call	rc_reset_config
	movl	$1, %esi
	movq	%rbx, %rdi
	call	rlog_init@PLT
	testl	%eax, %eax
	jne	.L1491
.L1476:
	leaq	.LC238(%rip), %rdx
	leaq	.LC239(%rip), %rsi
	movl	$1, %edi
	xorl	%eax, %eax
	call	rlog_log@PLT
	leaq	.LC240(%rip), %rbx
	movq	%rbx, %rdi
	call	puts@PLT
	leaq	.LC241(%rip), %rdi
	call	puts@PLT
	leaq	.LC242(%rip), %rdi
	call	puts@PLT
	movq	%rbx, %rdi
	leaq	.LC9(%rip), %rbx
	call	puts@PLT
	movq	%rbx, %rdi
	leaq	.LC8(%rip), %rsi
	call	fopen@PLT
	movq	%rax, %rdi
	testq	%rax, %rax
	je	.L1477
	call	fclose@PLT
	leaq	.LC243(%rip), %rdi
	call	puts@PLT
	movq	%rbx, %rdi
	call	rc_load_file
	movl	$0, mode(%rip)
.L1477:
	movl	quit_flag(%rip), %edx
	testl	%edx, %edx
	jne	.L1478
	leaq	suffix.0(%rip), %r15
	movq	%rsp, %rbx
	leaq	cfg(%rip), %r14
	leaq	.LC142(%rip), %r13
	leaq	.LC28(%rip), %r12
	leaq	112(%rsp), %rbp
	jmp	.L1479
	.p2align 4,,10
	.p2align 3
.L1492:
	movq	%rbp, %rdi
	call	execute_line_impl
	movl	quit_flag(%rip), %eax
	testl	%eax, %eax
	jne	.L1478
.L1479:
	movl	mode(%rip), %eax
	movq	%r13, %rdx
	movq	%r14, %rcx
	movq	%rbx, %rdi
	movl	$100, %esi
	movq	(%r15,%rax,8), %r8
	xorl	%eax, %eax
	call	snprintf@PLT
	movq	%rbx, %rdi
	call	strlen@PLT
	movq	%rbx, %rsi
	movq	%r12, %rdi
	movl	%eax, prompt_len(%rip)
	xorl	%eax, %eax
	call	printf@PLT
	movq	stdout(%rip), %rdi
	call	fflush@PLT
	movq	stdin(%rip), %rdx
	movl	$256, %esi
	movq	%rbp, %rdi
	call	fgets@PLT
	testq	%rax, %rax
	jne	.L1492
.L1478:
	leaq	.LC244(%rip), %rdi
	call	puts@PLT
	xorl	%eax, %eax
	movl	$1, %edi
	leaq	.LC245(%rip), %rdx
	leaq	.LC239(%rip), %rsi
	call	rlog_log@PLT
	call	rc_reset_config
	movq	errlog(%rip), %rdi
	call	free@PLT
	movq	$0, errlog(%rip)
	movl	$0, cerr(%rip)
	movl	$0, nerr(%rip)
	call	rlog_close@PLT
	addq	$376, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1491:
	.cfi_restore_state
	movq	stderr(%rip), %rdi
	movq	%rbx, %rdx
	leaq	.LC237(%rip), %rsi
	xorl	%eax, %eax
	call	fprintf@PLT
	jmp	.L1476
	.cfi_endproc
.LFE117:
	.size	rc_run_cli, .-rc_run_cli
	.section	.rodata.str1.1
.LC246:
	.string	">"
.LC247:
	.string	"#"
.LC248:
	.string	"(config)#"
.LC249:
	.string	"(config-if)#"
.LC250:
	.string	"(config-router)#"
	.section	.data.rel.ro.local,"aw"
	.align 32
	.type	suffix.0, @object
	.size	suffix.0, 48
suffix.0:
	.quad	.LC246
	.quad	.LC247
	.quad	.LC248
	.quad	.LC249
	.quad	.LC250
	.quad	.LC250
	.local	b.1
	.comm	b.1,64,32
	.local	i.2
	.comm	i.2,4,4
	.section	.rodata.str1.1
.LC251:
	.string	"enable"
.LC252:
	.string	"Enter privileged EXEC mode"
.LC253:
	.string	"disable"
.LC254:
	.string	"Return to user EXEC mode"
.LC255:
	.string	"configure terminal"
	.section	.rodata.str1.8
	.align 8
.LC256:
	.string	"Enter global configuration mode"
	.section	.rodata.str1.1
.LC257:
	.string	"exit"
	.section	.rodata.str1.8
	.align 8
.LC258:
	.string	"Go back one level (in user mode: quit program)"
	.section	.rodata.str1.1
.LC259:
	.string	"quit"
.LC260:
	.string	"Quit the program"
.LC261:
	.string	"help"
	.section	.rodata.str1.8
	.align 8
.LC262:
	.string	"List commands for the current mode"
	.align 8
.LC263:
	.string	"Return to privileged EXEC mode"
	.section	.rodata.str1.1
.LC264:
	.string	"hostname"
.LC265:
	.string	"<name>"
.LC266:
	.string	"Set the router name"
.LC267:
	.string	"no hostname"
.LC268:
	.string	"Reset hostname to 'Router'"
.LC269:
	.string	"enable secret"
.LC270:
	.string	"<password>"
.LC271:
	.string	"Set privileged-mode password"
.LC272:
	.string	"no enable secret"
	.section	.rodata.str1.8
	.align 8
.LC273:
	.string	"Remove privileged-mode password"
	.section	.rodata.str1.1
.LC274:
	.string	"interface"
.LC275:
	.string	"<type> <number>"
	.section	.rodata.str1.8
	.align 8
.LC276:
	.string	"Select/create an interface (g0/0, fa0/1, s0/0/0, lo0)"
	.section	.rodata.str1.1
.LC277:
	.string	"no interface"
.LC278:
	.string	"<loopback>"
.LC279:
	.string	"Delete a loopback interface"
.LC280:
	.string	"ip route"
.LC281:
	.string	"<net> <mask> <nh|if> [ad]"
.LC282:
	.string	"Add a static route"
.LC283:
	.string	"no ip route"
.LC284:
	.string	"<net> <mask> [nh|if]"
.LC285:
	.string	"Remove a static route"
	.section	.rodata.str1.8
	.align 8
.LC286:
	.string	"Enable RIP and enter router mode"
	.section	.rodata.str1.1
.LC287:
	.string	"no router rip"
.LC288:
	.string	"Disable RIP"
.LC289:
	.string	"router ospf"
.LC290:
	.string	"<process-id>"
	.section	.rodata.str1.8
	.align 8
.LC291:
	.string	"Enable OSPF and enter router mode"
	.section	.rodata.str1.1
.LC292:
	.string	"no router ospf"
.LC293:
	.string	"Disable OSPF"
.LC294:
	.string	"ip address"
.LC295:
	.string	"<ip> <mask>"
	.section	.rodata.str1.8
	.align 8
.LC296:
	.string	"Assign IPv4 address to the interface"
	.section	.rodata.str1.1
.LC297:
	.string	"no ip address"
.LC298:
	.string	"Remove IPv4 address"
.LC299:
	.string	"shutdown"
	.section	.rodata.str1.8
	.align 8
.LC300:
	.string	"Administratively disable the interface"
	.section	.rodata.str1.1
.LC301:
	.string	"no shutdown"
.LC302:
	.string	"Enable the interface"
.LC303:
	.string	"description"
.LC304:
	.string	"<text>"
.LC305:
	.string	"Set interface description"
.LC306:
	.string	"no description"
.LC307:
	.string	"Remove interface description"
.LC308:
	.string	"clock rate"
.LC309:
	.string	"<bits/sec>"
	.section	.rodata.str1.8
	.align 8
.LC310:
	.string	"Set DCE clock rate (Serial only)"
	.section	.rodata.str1.1
.LC311:
	.string	"no clock rate"
.LC312:
	.string	"Remove clock rate"
.LC313:
	.string	"version"
.LC314:
	.string	"<1|2>"
.LC315:
	.string	"Set RIP version"
.LC316:
	.string	"auto-summary"
	.section	.rodata.str1.8
	.align 8
.LC317:
	.string	"Enable automatic summarisation"
	.section	.rodata.str1.1
.LC318:
	.string	"no auto-summary"
	.section	.rodata.str1.8
	.align 8
.LC319:
	.string	"Disable automatic summarisation"
	.section	.rodata.str1.1
.LC320:
	.string	"router-id"
.LC321:
	.string	"<a.b.c.d>"
.LC322:
	.string	"Set OSPF router-id"
.LC323:
	.string	"no router-id"
.LC324:
	.string	"Remove OSPF router-id"
.LC325:
	.string	"network"
.LC326:
	.string	"<net> | <net> <wild> area <n>"
	.section	.rodata.str1.8
	.align 8
.LC327:
	.string	"Advertise a network (RIP: classful; OSPF: wildcard+area)"
	.section	.rodata.str1.1
.LC328:
	.string	"no network"
.LC329:
	.string	"<same as network>"
.LC330:
	.string	"Remove a network statement"
.LC331:
	.string	"show ip interface brief"
	.section	.rodata.str1.8
	.align 8
.LC332:
	.string	"One-line status of every interface"
	.section	.rodata.str1.1
.LC333:
	.string	"show ip route"
.LC334:
	.string	"[ip]"
	.section	.rodata.str1.8
	.align 8
.LC335:
	.string	"Routing table (or lookup of one address)"
	.section	.rodata.str1.1
.LC336:
	.string	"show ip protocols"
.LC337:
	.string	"RIP / OSPF settings"
.LC338:
	.string	"show interfaces"
.LC339:
	.string	"[type number]"
	.section	.rodata.str1.8
	.align 8
.LC340:
	.string	"Detailed interface information"
	.section	.rodata.str1.1
.LC341:
	.string	"show errors"
	.section	.rodata.str1.8
	.align 8
.LC342:
	.string	"All configuration errors seen this session"
	.section	.rodata.str1.1
.LC343:
	.string	"show running-config"
.LC344:
	.string	"Display current configuration"
.LC345:
	.string	"show startup-config"
.LC346:
	.string	"Display saved configuration"
.LC347:
	.string	"ping"
.LC348:
	.string	"<ip>"
	.section	.rodata.str1.8
	.align 8
.LC349:
	.string	"Simulated ping using the routing table"
	.section	.rodata.str1.1
.LC350:
	.string	"write"
.LC351:
	.string	"[memory]"
	.section	.rodata.str1.8
	.align 8
.LC352:
	.string	"Save running-config to startup-config"
	.align 8
.LC353:
	.string	"copy running-config startup-config"
	.section	.rodata.str1.1
.LC354:
	.string	"erase startup-config"
	.section	.rodata.str1.8
	.align 8
.LC355:
	.string	"Delete the saved startup-config"
	.section	.rodata.str1.1
.LC356:
	.string	"save"
.LC357:
	.string	"<file>"
	.section	.rodata.str1.8
	.align 8
.LC358:
	.string	"Save running-config to any file"
	.section	.rodata.str1.1
.LC359:
	.string	"load"
	.section	.rodata.str1.8
	.align 8
.LC360:
	.string	"Load a config file (replaces running-config)"
	.section	.rodata.str1.1
.LC361:
	.string	"reload"
	.section	.rodata.str1.8
	.align 8
.LC362:
	.string	"Restart: clear running-config, reload startup-config"
	.section	.rodata.str1.1
.LC363:
	.string	"validate"
	.section	.rodata.str1.8
	.align 8
.LC364:
	.string	"Semantic check of the whole configuration"
	.section	.rodata.str1.1
.LC365:
	.string	"compile"
.LC366:
	.string	"[file.rcx]"
	.section	.rodata.str1.8
	.align 8
.LC367:
	.string	"Validate + generate executable instructions"
	.section	.rodata.str1.1
.LC368:
	.string	"search"
.LC369:
	.string	"<keyword>"
	.section	.rodata.str1.8
	.align 8
.LC370:
	.string	"Search configuration text / interface name"
	.section	.data.rel.ro.local
	.align 32
	.type	CMDS, @object
	.size	CMDS, 2448
CMDS:
	.long	1
	.zero	4
	.quad	.LC251
	.quad	.LC36
	.long	0
	.long	0
	.quad	h_enable
	.quad	.LC252
	.long	2
	.zero	4
	.quad	.LC253
	.quad	.LC36
	.long	0
	.long	0
	.quad	h_disable
	.quad	.LC254
	.long	2
	.zero	4
	.quad	.LC255
	.quad	.LC36
	.long	0
	.long	0
	.quad	h_configure
	.quad	.LC256
	.long	63
	.zero	4
	.quad	.LC257
	.quad	.LC36
	.long	0
	.long	0
	.quad	h_exit
	.quad	.LC258
	.long	63
	.zero	4
	.quad	.LC259
	.quad	.LC36
	.long	0
	.long	0
	.quad	h_quit
	.quad	.LC260
	.long	63
	.zero	4
	.quad	.LC261
	.quad	.LC36
	.long	0
	.long	0
	.quad	h_help
	.quad	.LC262
	.long	60
	.zero	4
	.quad	.LC76
	.quad	.LC36
	.long	0
	.long	0
	.quad	h_end
	.quad	.LC263
	.long	60
	.zero	4
	.quad	.LC264
	.quad	.LC265
	.long	1
	.long	1
	.quad	h_hostname
	.quad	.LC266
	.long	60
	.zero	4
	.quad	.LC267
	.quad	.LC36
	.long	0
	.long	0
	.quad	h_no_hostname
	.quad	.LC268
	.long	60
	.zero	4
	.quad	.LC269
	.quad	.LC270
	.long	1
	.long	1
	.quad	h_secret
	.quad	.LC271
	.long	60
	.zero	4
	.quad	.LC272
	.quad	.LC36
	.long	0
	.long	0
	.quad	h_no_secret
	.quad	.LC273
	.long	60
	.zero	4
	.quad	.LC274
	.quad	.LC275
	.long	1
	.long	2
	.quad	h_interface
	.quad	.LC276
	.long	60
	.zero	4
	.quad	.LC277
	.quad	.LC278
	.long	1
	.long	2
	.quad	h_no_interface
	.quad	.LC279
	.long	60
	.zero	4
	.quad	.LC280
	.quad	.LC281
	.long	3
	.long	4
	.quad	h_ip_route
	.quad	.LC282
	.long	60
	.zero	4
	.quad	.LC283
	.quad	.LC284
	.long	2
	.long	4
	.quad	h_no_ip_route
	.quad	.LC285
	.long	60
	.zero	4
	.quad	.LC67
	.quad	.LC36
	.long	0
	.long	0
	.quad	h_router_rip
	.quad	.LC286
	.long	60
	.zero	4
	.quad	.LC287
	.quad	.LC36
	.long	0
	.long	0
	.quad	h_no_router_rip
	.quad	.LC288
	.long	60
	.zero	4
	.quad	.LC289
	.quad	.LC290
	.long	1
	.long	1
	.quad	h_router_ospf
	.quad	.LC291
	.long	60
	.zero	4
	.quad	.LC292
	.quad	.LC290
	.long	1
	.long	1
	.quad	h_no_router_ospf
	.quad	.LC293
	.long	8
	.zero	4
	.quad	.LC294
	.quad	.LC295
	.long	2
	.long	2
	.quad	h_ip_address
	.quad	.LC296
	.long	8
	.zero	4
	.quad	.LC297
	.quad	.LC36
	.long	0
	.long	0
	.quad	h_no_ip_address
	.quad	.LC298
	.long	8
	.zero	4
	.quad	.LC299
	.quad	.LC36
	.long	0
	.long	0
	.quad	h_shutdown
	.quad	.LC300
	.long	8
	.zero	4
	.quad	.LC301
	.quad	.LC36
	.long	0
	.long	0
	.quad	h_no_shutdown
	.quad	.LC302
	.long	8
	.zero	4
	.quad	.LC303
	.quad	.LC304
	.long	1
	.long	12
	.quad	h_description
	.quad	.LC305
	.long	8
	.zero	4
	.quad	.LC306
	.quad	.LC36
	.long	0
	.long	12
	.quad	h_no_description
	.quad	.LC307
	.long	8
	.zero	4
	.quad	.LC308
	.quad	.LC309
	.long	1
	.long	1
	.quad	h_clock
	.quad	.LC310
	.long	8
	.zero	4
	.quad	.LC311
	.quad	.LC36
	.long	0
	.long	1
	.quad	h_no_clock
	.quad	.LC312
	.long	16
	.zero	4
	.quad	.LC313
	.quad	.LC314
	.long	1
	.long	1
	.quad	h_rip_version
	.quad	.LC315
	.long	16
	.zero	4
	.quad	.LC316
	.quad	.LC36
	.long	0
	.long	0
	.quad	h_autosum
	.quad	.LC317
	.long	16
	.zero	4
	.quad	.LC318
	.quad	.LC36
	.long	0
	.long	0
	.quad	h_no_autosum
	.quad	.LC319
	.long	32
	.zero	4
	.quad	.LC320
	.quad	.LC321
	.long	1
	.long	1
	.quad	h_router_id
	.quad	.LC322
	.long	32
	.zero	4
	.quad	.LC323
	.quad	.LC36
	.long	0
	.long	1
	.quad	h_no_router_id
	.quad	.LC324
	.long	48
	.zero	4
	.quad	.LC325
	.quad	.LC326
	.long	1
	.long	4
	.quad	h_network
	.quad	.LC327
	.long	48
	.zero	4
	.quad	.LC328
	.quad	.LC329
	.long	1
	.long	4
	.quad	h_no_network
	.quad	.LC330
	.long	3
	.zero	4
	.quad	.LC331
	.quad	.LC36
	.long	0
	.long	0
	.quad	h_show_ipbrief
	.quad	.LC332
	.long	3
	.zero	4
	.quad	.LC333
	.quad	.LC334
	.long	0
	.long	1
	.quad	h_show_route
	.quad	.LC335
	.long	3
	.zero	4
	.quad	.LC336
	.quad	.LC36
	.long	0
	.long	0
	.quad	h_show_protocols
	.quad	.LC337
	.long	3
	.zero	4
	.quad	.LC338
	.quad	.LC339
	.long	0
	.long	2
	.quad	h_show_if
	.quad	.LC340
	.long	3
	.zero	4
	.quad	.LC341
	.quad	.LC36
	.long	0
	.long	0
	.quad	h_show_errors
	.quad	.LC342
	.long	2
	.zero	4
	.quad	.LC343
	.quad	.LC36
	.long	0
	.long	0
	.quad	h_show_run
	.quad	.LC344
	.long	2
	.zero	4
	.quad	.LC345
	.quad	.LC36
	.long	0
	.long	0
	.quad	h_show_startup
	.quad	.LC346
	.long	3
	.zero	4
	.quad	.LC347
	.quad	.LC348
	.long	1
	.long	1
	.quad	h_ping
	.quad	.LC349
	.long	2
	.zero	4
	.quad	.LC350
	.quad	.LC351
	.long	0
	.long	1
	.quad	h_write
	.quad	.LC352
	.long	2
	.zero	4
	.quad	.LC353
	.quad	.LC36
	.long	0
	.long	0
	.quad	h_copy
	.quad	.LC352
	.long	2
	.zero	4
	.quad	.LC354
	.quad	.LC36
	.long	0
	.long	0
	.quad	h_erase
	.quad	.LC355
	.long	2
	.zero	4
	.quad	.LC356
	.quad	.LC357
	.long	1
	.long	1
	.quad	h_save
	.quad	.LC358
	.long	2
	.zero	4
	.quad	.LC359
	.quad	.LC357
	.long	1
	.long	1
	.quad	h_load
	.quad	.LC360
	.long	2
	.zero	4
	.quad	.LC361
	.quad	.LC36
	.long	0
	.long	0
	.quad	h_reload
	.quad	.LC362
	.long	2
	.zero	4
	.quad	.LC363
	.quad	.LC36
	.long	0
	.long	0
	.quad	h_validate
	.quad	.LC364
	.long	2
	.zero	4
	.quad	.LC365
	.quad	.LC366
	.long	0
	.long	1
	.quad	h_compile
	.quad	.LC367
	.long	2
	.zero	4
	.quad	.LC368
	.quad	.LC369
	.long	1
	.long	8
	.quad	h_search
	.quad	.LC370
	.section	.rodata.str1.1
.LC371:
	.string	"GigabitEthernet"
.LC372:
	.string	"FastEthernet"
	.section	.data.rel.ro.local
	.align 32
	.type	IFTYPES, @object
	.size	IFTYPES, 32
IFTYPES:
	.quad	.LC371
	.quad	.LC372
	.quad	.LC44
	.quad	.LC124
	.local	st
	.comm	st,12,8
	.local	cerr
	.comm	cerr,4,4
	.local	nerr
	.comm	nerr,4,4
	.local	errlog
	.comm	errlog,8,8
	.section	.data.rel.local,"aw"
	.align 8
	.type	load_name, @object
	.size	load_name, 8
load_name:
	.quad	.LC36
	.local	load_line
	.comm	load_line,4,4
	.local	loading
	.comm	loading,4,4
	.local	quit_flag
	.comm	quit_flag,4,4
	.local	prompt_len
	.comm	prompt_len,4,4
	.local	C
	.comm	C,712,32
	.local	cur_if
	.comm	cur_if,8,8
	.local	mode
	.comm	mode,4,4
	.local	cfg
	.comm	cfg,744,32
	.section	.rodata.cst8,"aM",@progbits,8
	.align 8
.LC0:
	.long	1
	.long	1
	.ident	"GCC: (Debian 14.2.0-19) 14.2.0"
	.section	.note.GNU-stack,"",@progbits
