	.file	"router_compiler.c"
	.text
	.type	connected_if, @function
connected_if:
.LFB43:
	.cfi_startproc
	movq	640+cfg(%rip), %rax
	testq	%rax, %rax
	je	.L5
	movl	$0, %edx
	jmp	.L4
.L6:
	movq	%rax, %rdx
	.p2align 5
.L3:
	movq	176(%rax), %rax
	testq	%rax, %rax
	je	.L1
.L4:
	cmpl	$0, 148(%rax)
	je	.L3
	cmpl	$0, 152(%rax)
	jne	.L3
	movl	144(%rax), %ecx
	movl	%edi, %esi
	xorl	140(%rax), %esi
	testl	%ecx, %esi
	jne	.L3
	testq	%rdx, %rdx
	je	.L6
	cmpl	%ecx, 144(%rdx)
	cmovb	%rax, %rdx
	jmp	.L3
.L5:
	movq	%rax, %rdx
.L1:
	movq	%rdx, %rax
	ret
	.cfi_endproc
.LFE43:
	.size	connected_if, .-connected_if
	.type	h_disable, @function
h_disable:
.LFB48:
	.cfi_startproc
	movl	$0, mode(%rip)
	movl	$0, %eax
	ret
	.cfi_endproc
.LFE48:
	.size	h_disable, .-h_disable
	.type	h_exit, @function
h_exit:
.LFB50:
	.cfi_startproc
	movl	mode(%rip), %eax
	cmpl	$2, %eax
	je	.L11
	ja	.L12
	testl	%eax, %eax
	je	.L20
	movl	$0, mode(%rip)
	jmp	.L17
.L12:
	subl	$3, %eax
	cmpl	$2, %eax
	ja	.L21
	movl	$2, mode(%rip)
	movq	$0, cur_if(%rip)
	jmp	.L17
.L20:
	movl	$1, quit_flag(%rip)
.L17:
	movl	$0, %eax
	ret
.L11:
	movl	$1, mode(%rip)
	jmp	.L17
.L21:
	movl	$0, mode(%rip)
	movl	$1, quit_flag(%rip)
	jmp	.L17
	.cfi_endproc
.LFE50:
	.size	h_exit, .-h_exit
	.type	h_quit, @function
h_quit:
.LFB51:
	.cfi_startproc
	movl	$1, quit_flag(%rip)
	movl	$0, %eax
	ret
	.cfi_endproc
.LFE51:
	.size	h_quit, .-h_quit
	.type	h_end, @function
h_end:
.LFB52:
	.cfi_startproc
	movl	$1, mode(%rip)
	movq	$0, cur_if(%rip)
	movl	$0, %eax
	ret
	.cfi_endproc
.LFE52:
	.size	h_end, .-h_end
	.type	h_no_secret, @function
h_no_secret:
.LFB56:
	.cfi_startproc
	movl	$1, %eax
	cmpb	$0, 64+cfg(%rip)
	je	.L24
	movb	$0, 64+cfg(%rip)
	movl	$0, %eax
.L24:
	ret
	.cfi_endproc
.LFE56:
	.size	h_no_secret, .-h_no_secret
	.type	h_no_ip_address, @function
h_no_ip_address:
.LFB60:
	.cfi_startproc
	movq	cur_if(%rip), %rax
	movl	$1, %edx
	cmpl	$0, 148(%rax)
	je	.L27
	movl	$0, 148(%rax)
	movl	$0, 144(%rax)
	movl	$0, 140(%rax)
	movl	$0, %edx
.L27:
	movl	%edx, %eax
	ret
	.cfi_endproc
.LFE60:
	.size	h_no_ip_address, .-h_no_ip_address
	.type	h_no_description, @function
h_no_description:
.LFB65:
	.cfi_startproc
	movq	cur_if(%rip), %rdx
	movl	$1, %eax
	cmpb	$0, 40(%rdx)
	je	.L30
	movb	$0, 40(%rdx)
	movl	$0, %eax
.L30:
	ret
	.cfi_endproc
.LFE65:
	.size	h_no_description, .-h_no_description
	.type	h_no_clock, @function
h_no_clock:
.LFB67:
	.cfi_startproc
	movq	cur_if(%rip), %rdx
	movl	$1, %eax
	cmpq	$0, 160(%rdx)
	je	.L33
	movq	$0, 160(%rdx)
	movl	$0, %eax
.L33:
	ret
	.cfi_endproc
.LFE67:
	.size	h_no_clock, .-h_no_clock
	.type	h_autosum, @function
h_autosum:
.LFB75:
	.cfi_startproc
	movl	688+cfg(%rip), %eax
	testl	%eax, %eax
	jne	.L38
	movl	$1, 688+cfg(%rip)
	ret
.L38:
	movl	$1, %eax
	ret
	.cfi_endproc
.LFE75:
	.size	h_autosum, .-h_autosum
	.type	h_no_autosum, @function
h_no_autosum:
.LFB76:
	.cfi_startproc
	movl	$1, %eax
	cmpl	$0, 688+cfg(%rip)
	je	.L39
	movl	$0, 688+cfg(%rip)
	movl	$0, %eax
.L39:
	ret
	.cfi_endproc
.LFE76:
	.size	h_no_autosum, .-h_no_autosum
	.type	h_no_router_id, @function
h_no_router_id:
.LFB78:
	.cfi_startproc
	movl	$1, %eax
	cmpl	$0, 720+cfg(%rip)
	je	.L42
	movl	$0, 720+cfg(%rip)
	movl	$0, %eax
.L42:
	ret
	.cfi_endproc
.LFE78:
	.size	h_no_router_id, .-h_no_router_id
	.type	pat_split, @function
pat_split:
.LFB106:
	.cfi_startproc
	cmpb	$0, (%rdi)
	je	.L52
	movl	$0, %r11d
	jmp	.L47
	.p2align 6
.L50:
	addq	$1, %rdi
	movb	%dl, -1(%r10,%rax)
	movzbl	(%rdi), %edx
	testb	$-33, %dl
	setne	%r8b
	cmpl	$22, %eax
	setle	%cl
	movq	%rax, %r9
	addq	$1, %rax
	testb	%cl, %r8b
	jne	.L50
.L49:
	addl	$1, %r11d
	movslq	%r9d, %r9
	movb	$0, (%rsi,%r9)
	addq	$24, %rsi
	cmpb	$0, (%rdi)
	je	.L45
.L47:
	movzbl	(%rdi), %eax
	cmpb	$32, %al
	jne	.L51
	.p2align 4
.L48:
	addq	$1, %rdi
	movzbl	(%rdi), %eax
	cmpb	$32, %al
	je	.L48
.L51:
	testb	%al, %al
	je	.L45
	movzbl	(%rdi), %edx
	testb	$-33, %dl
	je	.L53
	movq	%rsi, %r10
	movl	$1, %eax
	jmp	.L50
.L53:
	movl	$0, %r9d
	jmp	.L49
.L52:
	movl	$0, %r11d
.L45:
	movl	%r11d, %eax
	ret
	.cfi_endproc
.LFE106:
	.size	pat_split, .-pat_split
	.type	hash_name, @function
hash_name:
.LFB32:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movzbl	(%rdi), %ebx
	testb	%bl, %bl
	je	.L60
	movq	%rdi, %rbp
	call	__ctype_tolower_loc@PLT
	movq	(%rax), %rcx
	movl	$5381, %eax
	.p2align 5
.L59:
	movl	%eax, %edx
	sall	$5, %edx
	addl	%edx, %eax
	movzbl	%bl, %ebx
	movzbl	(%rcx,%rbx,4), %edx
	addl	%edx, %eax
	addq	$1, %rbp
	movzbl	0(%rbp), %ebx
	testb	%bl, %bl
	jne	.L59
.L58:
	andl	$63, %eax
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L60:
	.cfi_restore_state
	movl	$5381, %eax
	jmp	.L58
	.cfi_endproc
.LFE32:
	.size	hash_name, .-hash_name
	.type	lines_free, @function
lines_free:
.LFB27:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movq	%rdi, %rbp
	cmpl	$0, 8(%rdi)
	jle	.L64
	movl	$0, %ebx
.L65:
	movq	0(%rbp), %rax
	movq	(%rax,%rbx,8), %rdi
	call	free@PLT
	addq	$1, %rbx
	cmpl	%ebx, 8(%rbp)
	jg	.L65
.L64:
	movq	0(%rbp), %rdi
	call	free@PLT
	movq	$0, 0(%rbp)
	movl	$0, 12(%rbp)
	movl	$0, 8(%rbp)
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE27:
	.size	lines_free, .-lines_free
	.type	h_no_router_rip, @function
h_no_router_rip:
.LFB71:
	.cfi_startproc
	movl	$1, %eax
	cmpl	$0, 680+cfg(%rip)
	jne	.L75
	ret
.L75:
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	movq	696+cfg(%rip), %rdi
	call	free@PLT
	movq	$0, 696+cfg(%rip)
	movl	$0, 708+cfg(%rip)
	movl	$0, 704+cfg(%rip)
	movl	$0, 680+cfg(%rip)
	movl	$0, %eax
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE71:
	.size	h_no_router_rip, .-h_no_router_rip
	.section	.rodata.str1.1,"aMS",@progbits,1
.LC0:
	.string	"RIP enabled"
.LC1:
	.string	"config"
	.text
	.type	h_router_rip, @function
h_router_rip:
.LFB70:
	.cfi_startproc
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	cmpl	$0, 680+cfg(%rip)
	jne	.L77
	movl	$1, 680+cfg(%rip)
	movl	$1, 684+cfg(%rip)
	movl	$1, 688+cfg(%rip)
.L77:
	movl	$4, mode(%rip)
	leaq	.LC0(%rip), %rdx
	leaq	.LC1(%rip), %rsi
	movl	$1, %edi
	movl	$0, %eax
	call	rlog_log@PLT
	movl	$0, %eax
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE70:
	.size	h_router_rip, .-h_router_rip
	.section	.rodata.str1.1
.LC2:
	.string	"up"
	.section	.rodata.str1.8,"aMS",@progbits,1
	.align 8
.LC3:
	.string	"%%LINK-5-CHANGED: Interface %s, changed state to %s\n"
	.align 8
.LC4:
	.string	"%%LINEPROTO-5-UPDOWN: Line protocol on Interface %s, changed state to %s\n"
	.text
	.type	h_no_shutdown, @function
h_no_shutdown:
.LFB63:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movq	cur_if(%rip), %rbp
	movl	$1, %ebx
	cmpl	$0, 152(%rbp)
	jne	.L84
.L79:
	movl	%ebx, %eax
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
.L84:
	.cfi_restore_state
	movl	$0, 152(%rbp)
	movl	loading(%rip), %ebx
	testl	%ebx, %ebx
	jne	.L82
	leaq	.LC2(%rip), %r12
	movq	%r12, %rdx
	movq	%rbp, %rsi
	leaq	.LC3(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	movq	%r12, %rdx
	movq	%rbp, %rsi
	leaq	.LC4(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	jmp	.L79
.L82:
	movl	$0, %ebx
	jmp	.L79
	.cfi_endproc
.LFE63:
	.size	h_no_shutdown, .-h_no_shutdown
	.type	if_find, @function
if_find:
.LFB33:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movq	%rdi, %rbp
	call	hash_name
	movl	%eax, %eax
	leaq	cfg(%rip), %rdx
	movq	128(%rdx,%rax,8), %rbx
	testq	%rbx, %rbx
	je	.L85
.L87:
	movq	%rbp, %rsi
	movq	%rbx, %rdi
	call	strcmp@PLT
	testl	%eax, %eax
	je	.L85
	movq	168(%rbx), %rbx
	testq	%rbx, %rbx
	jne	.L87
.L85:
	movq	%rbx, %rax
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE33:
	.size	if_find, .-if_find
	.type	route_installed, @function
route_installed:
.LFB44:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movl	52(%rdi), %ebx
	testl	%ebx, %ebx
	jne	.L94
	addq	$12, %rdi
	call	if_find
	testq	%rax, %rax
	je	.L90
	cmpl	$0, 152(%rax)
	sete	%bl
	movzbl	%bl, %ebx
.L90:
	movl	%ebx, %eax
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L94:
	.cfi_restore_state
	movl	8(%rdi), %edi
	call	connected_if
	testq	%rax, %rax
	setne	%bl
	movzbl	%bl, %ebx
	jmp	.L90
	.cfi_endproc
.LFE44:
	.size	route_installed, .-route_installed
	.type	route_find, @function
route_find:
.LFB39:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movq	%rsi, 8(%rsp)
	movl	672+cfg(%rip), %ebp
	subl	$1, %ebp
	js	.L107
	movq	%rdi, %r14
	movq	664+cfg(%rip), %r15
	movl	(%rdi), %r13d
	movl	$0, %r12d
	jmp	.L106
.L97:
	movl	4(%rdi), %edx
	movl	4(%r14), %eax
	cmpl	%eax, %edx
	je	.L100
	jb	.L98
	jmp	.L99
.L100:
	movl	52(%rdi), %eax
	movl	52(%r14), %edx
	cmpl	%edx, %eax
	je	.L101
	subl	%edx, %eax
.L102:
	testl	%eax, %eax
	js	.L98
.L99:
	leal	-1(%rbx), %ebp
.L105:
	cmpl	%r12d, %ebp
	jl	.L96
.L106:
	leal	(%r12,%rbp), %eax
	movl	%eax, %ebx
	shrl	$31, %ebx
	addl	%eax, %ebx
	sarl	%ebx
	movl	%ebx, 4(%rsp)
	movslq	%ebx, %rdx
	movq	%rdx, %rax
	salq	$4, %rax
	subq	%rdx, %rax
	leaq	(%r15,%rax,4), %rdi
	movl	(%rdi), %eax
	cmpl	%r13d, %eax
	je	.L97
	jnb	.L99
.L98:
	leal	1(%rbx), %r12d
	jmp	.L105
.L101:
	testl	%eax, %eax
	jne	.L112
	leaq	12(%r14), %rsi
	addq	$12, %rdi
	call	strcmp@PLT
	testl	%eax, %eax
	jne	.L102
	movl	$1, %eax
	jmp	.L104
.L112:
	movl	8(%rdi), %edx
	movl	8(%r14), %eax
	cmpl	%eax, %edx
	je	.L108
	cmpl	%eax, %edx
	jb	.L98
	jmp	.L99
.L107:
	movl	$0, %r12d
.L96:
	movl	%r12d, 4(%rsp)
	movl	$0, %eax
.L104:
	movq	8(%rsp), %rcx
	movl	4(%rsp), %esi
	movl	%esi, (%rcx)
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L108:
	.cfi_restore_state
	movl	$1, %eax
	jmp	.L104
	.cfi_endproc
.LFE39:
	.size	route_find, .-route_find
	.section	.rodata.str1.1
.LC5:
	.string	"Router"
	.text
	.type	h_no_hostname, @function
h_no_hostname:
.LFB54:
	.cfi_startproc
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	leaq	.LC5(%rip), %rsi
	leaq	cfg(%rip), %rdi
	call	strcmp@PLT
	movl	%eax, %edx
	movl	$1, %eax
	testl	%edx, %edx
	jne	.L117
.L113:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L117:
	.cfi_restore_state
	movl	$1953853266, cfg(%rip)
	movl	$7497076, 3+cfg(%rip)
	movl	$0, %eax
	jmp	.L113
	.cfi_endproc
.LFE54:
	.size	h_no_hostname, .-h_no_hostname
	.section	.rodata.str1.8
	.align 8
.LC6:
	.string	"No errors recorded in this session."
	.section	.rodata.str1.1
.LC7:
	.string	"%d error(s) recorded:\n"
.LC8:
	.string	"%3d. [%s] \"%s\"\n       -> %s\n"
	.text
	.type	h_show_errors, @function
h_show_errors:
.LFB90:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movl	nerr(%rip), %esi
	testl	%esi, %esi
	je	.L124
	leaq	.LC7(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	cmpl	$0, nerr(%rip)
	jle	.L120
	movl	$0, %ebp
	movl	$0, %ebx
	leaq	.LC8(%rip), %r12
.L121:
	movq	%rbp, %rdx
	addq	errlog(%rip), %rdx
	addl	$1, %ebx
	leaq	64(%rdx), %rcx
	leaq	320(%rdx), %r8
	movl	%ebx, %esi
	movq	%r12, %rdi
	movl	$0, %eax
	call	printf@PLT
	addq	$520, %rbp
	cmpl	nerr(%rip), %ebx
	jl	.L121
.L120:
	movl	$0, %eax
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
.L124:
	.cfi_restore_state
	leaq	.LC6(%rip), %rdi
	call	puts@PLT
	jmp	.L120
	.cfi_endproc
.LFE90:
	.size	h_show_errors, .-h_show_errors
	.section	.rodata.str1.8
	.align 8
.LC9:
	.string	"Enter configuration commands, one per line.  End with 'end'."
	.section	.rodata.str1.1
.LC10:
	.string	"entered config mode"
.LC11:
	.string	"cli"
	.text
	.type	h_configure, @function
h_configure:
.LFB49:
	.cfi_startproc
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	movl	$2, mode(%rip)
	cmpl	$0, loading(%rip)
	je	.L128
.L126:
	leaq	.LC10(%rip), %rdx
	leaq	.LC11(%rip), %rsi
	movl	$0, %edi
	movl	$0, %eax
	call	rlog_log@PLT
	movl	$0, %eax
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L128:
	.cfi_restore_state
	leaq	.LC9(%rip), %rdi
	call	puts@PLT
	jmp	.L126
	.cfi_endproc
.LFE49:
	.size	h_configure, .-h_configure
	.section	.rodata.str1.1
.LC12:
	.string	"%04d  0x%02X  %-11s %s"
.LC13:
	.string	"%s\n"
	.text
	.type	emit, @function
emit:
.LFB94:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	subq	$688, %rsp
	.cfi_def_cfa_offset 736
	movq	%rdi, %rbx
	movl	%esi, %ebp
	movq	%rdx, %r12
	movq	%rcx, %rdx
	movq	%r8, 544(%rsp)
	movq	%r9, 552(%rsp)
	testb	%al, %al
	je	.L134
	movaps	%xmm0, 560(%rsp)
	movaps	%xmm1, 576(%rsp)
	movaps	%xmm2, 592(%rsp)
	movaps	%xmm3, 608(%rsp)
	movaps	%xmm4, 624(%rsp)
	movaps	%xmm5, 640(%rsp)
	movaps	%xmm6, 656(%rsp)
	movaps	%xmm7, 672(%rsp)
.L134:
	movl	$32, 8(%rsp)
	movl	$48, 12(%rsp)
	leaq	736(%rsp), %rax
	movq	%rax, 16(%rsp)
	leaq	512(%rsp), %rax
	movq	%rax, 24(%rsp)
	leaq	8(%rsp), %rcx
	leaq	304(%rsp), %r14
	movl	$200, %esi
	movq	%r14, %rdi
	call	vsnprintf@PLT
	movl	(%rbx), %ecx
	leal	1(%rcx), %eax
	movl	%eax, (%rbx)
	leaq	32(%rsp), %r13
	subq	$8, %rsp
	.cfi_def_cfa_offset 744
	pushq	%r14
	.cfi_def_cfa_offset 752
	movq	%r12, %r9
	movl	%ebp, %r8d
	leaq	.LC12(%rip), %rdx
	movl	$260, %esi
	movq	%r13, %rdi
	movl	$0, %eax
	call	snprintf@PLT
	movq	%r13, %rdi
	call	puts@PLT
	movq	8(%rbx), %rdi
	addq	$16, %rsp
	.cfi_def_cfa_offset 736
	testq	%rdi, %rdi
	je	.L131
	movq	%r13, %rdx
	leaq	.LC13(%rip), %rsi
	movl	$0, %eax
	call	fprintf@PLT
.L131:
	movq	16(%rbx), %rax
	movq	%rax, %rdx
	salq	$6, %rdx
	addq	%rax, %rdx
	leaq	(%rax,%rdx,2), %rax
	movl	%ebp, %ebp
	addq	%rbp, %rax
	movq	%rax, 16(%rbx)
	movzbl	304(%rsp), %edx
	testb	%dl, %dl
	je	.L129
	leaq	304(%rsp), %rsi
	.p2align 5
.L133:
	movq	%rax, %rcx
	salq	$6, %rcx
	addq	%rax, %rcx
	leaq	(%rax,%rcx,2), %rax
	movzbl	%dl, %edx
	addq	%rdx, %rax
	addq	$1, %rsi
	movzbl	(%rsi), %edx
	testb	%dl, %dl
	jne	.L133
	movq	%rax, 16(%rbx)
.L129:
	addq	$688, %rsp
	.cfi_def_cfa_offset 48
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE94:
	.size	emit, .-emit
	.section	.rodata.str1.1
.LC14:
	.string	"out of memory\n"
	.text
	.type	xrealloc, @function
xrealloc:
.LFB15:
	.cfi_startproc
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	call	realloc@PLT
	testq	%rax, %rax
	je	.L140
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L140:
	.cfi_restore_state
	movq	stderr(%rip), %rcx
	movl	$14, %edx
	movl	$1, %esi
	leaq	.LC14(%rip), %rdi
	call	fwrite@PLT
	movl	$1, %edi
	call	exit@PLT
	.cfi_endproc
.LFE15:
	.size	xrealloc, .-xrealloc
	.section	.rodata.str1.1
.LC15:
	.string	"  %s:%d: %% %s\n"
.LC16:
	.string	"%s:%d %s"
.LC17:
	.string	"parser"
.LC18:
	.string	"%% %s\n"
.LC19:
	.string	"%s"
.LC20:
	.string	"%s:%d"
.LC21:
	.string	"cmd #%d"
	.text
	.type	err, @function
err:
.LFB28:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$424, %rsp
	.cfi_def_cfa_offset 448
	movq	%rsi, 248(%rsp)
	movq	%rdx, 256(%rsp)
	movq	%rcx, 264(%rsp)
	movq	%r8, 272(%rsp)
	movq	%r9, 280(%rsp)
	testb	%al, %al
	je	.L150
	movaps	%xmm0, 288(%rsp)
	movaps	%xmm1, 304(%rsp)
	movaps	%xmm2, 320(%rsp)
	movaps	%xmm3, 336(%rsp)
	movaps	%xmm4, 352(%rsp)
	movaps	%xmm5, 368(%rsp)
	movaps	%xmm6, 384(%rsp)
	movaps	%xmm7, 400(%rsp)
.L150:
	movl	$8, 8(%rsp)
	movl	$48, 12(%rsp)
	leaq	448(%rsp), %rax
	movq	%rax, 16(%rsp)
	leaq	240(%rsp), %rax
	movq	%rax, 24(%rsp)
	leaq	8(%rsp), %rcx
	leaq	32(%rsp), %rax
	movq	%rdi, %rdx
	movl	$200, %esi
	movq	%rax, %rdi
	call	vsnprintf@PLT
	cmpl	$0, loading(%rip)
	je	.L143
	leaq	32(%rsp), %rbx
	movq	%rbx, %rcx
	movl	load_line(%rip), %edx
	movq	load_name(%rip), %rsi
	leaq	.LC15(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	movq	%rbx, %r9
	movl	load_line(%rip), %r8d
	movq	load_name(%rip), %rcx
	leaq	.LC16(%rip), %rdx
	leaq	.LC17(%rip), %rsi
	movl	$2, %edi
	movl	$0, %eax
	call	rlog_log@PLT
.L144:
	movl	cerr(%rip), %edx
	cmpl	%edx, nerr(%rip)
	jl	.L145
	leal	(%rdx,%rdx), %eax
	testl	%edx, %edx
	movl	$8, %edx
	cmove	%edx, %eax
	movl	%eax, cerr(%rip)
	cltq
	movq	%rax, %rsi
	salq	$6, %rsi
	addq	%rax, %rsi
	salq	$3, %rsi
	movq	errlog(%rip), %rdi
	call	xrealloc
	movq	%rax, errlog(%rip)
.L145:
	movl	nerr(%rip), %eax
	leal	1(%rax), %edx
	movl	%edx, nerr(%rip)
	cltq
	movq	%rax, %rbx
	salq	$6, %rbx
	addq	%rax, %rbx
	salq	$3, %rbx
	addq	errlog(%rip), %rbx
	cmpl	$0, loading(%rip)
	je	.L147
	movl	load_line(%rip), %r8d
	movq	load_name(%rip), %rcx
	leaq	.LC20(%rip), %rdx
	movl	$64, %esi
	movq	%rbx, %rdi
	movl	$0, %eax
	call	snprintf@PLT
.L148:
	leaq	64(%rbx), %rdi
	leaq	C(%rip), %rcx
	leaq	.LC19(%rip), %rbp
	movq	%rbp, %rdx
	movl	$256, %esi
	movl	$0, %eax
	call	snprintf@PLT
	leaq	32(%rsp), %rcx
	leaq	320(%rbx), %rdi
	movq	%rbp, %rdx
	movl	$200, %esi
	movl	$0, %eax
	call	snprintf@PLT
	movl	$-1, %eax
	addq	$424, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L143:
	.cfi_restore_state
	leaq	32(%rsp), %rbx
	movq	%rbx, %rsi
	leaq	.LC18(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	movq	%rbx, %rcx
	leaq	.LC19(%rip), %rdx
	leaq	.LC17(%rip), %rsi
	movl	$2, %edi
	movl	$0, %eax
	call	rlog_log@PLT
	jmp	.L144
.L147:
	movl	st(%rip), %ecx
	leaq	.LC21(%rip), %rdx
	movl	$64, %esi
	movq	%rbx, %rdi
	movl	$0, %eax
	call	snprintf@PLT
	jmp	.L148
	.cfi_endproc
.LFE28:
	.size	err, .-err
	.section	.rodata.str1.1
.LC22:
	.string	""
.LC23:
	.string	"%*s^\n"
	.text
	.type	caret, @function
caret:
.LFB29:
	.cfi_startproc
	cmpl	$0, loading(%rip)
	jne	.L157
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	cmpl	%edi, 704+C(%rip)
	jle	.L154
	movslq	%edi, %rdi
	leaq	C(%rip), %rax
	movl	640(%rax,%rdi,4), %esi
.L155:
	addl	prompt_len(%rip), %esi
	leaq	.LC22(%rip), %rdx
	leaq	.LC23(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L154:
	.cfi_restore_state
	leaq	C(%rip), %rdi
	call	strlen@PLT
	movl	%eax, %esi
	jmp	.L155
.L157:
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE29:
	.size	caret, .-caret
	.type	bad_arg, @function
bad_arg:
.LFB30:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$376, %rsp
	.cfi_def_cfa_offset 400
	movl	%edi, %ebx
	movq	%rdx, 208(%rsp)
	movq	%rcx, 216(%rsp)
	movq	%r8, 224(%rsp)
	movq	%r9, 232(%rsp)
	testb	%al, %al
	je	.L162
	movaps	%xmm0, 240(%rsp)
	movaps	%xmm1, 256(%rsp)
	movaps	%xmm2, 272(%rsp)
	movaps	%xmm3, 288(%rsp)
	movaps	%xmm4, 304(%rsp)
	movaps	%xmm5, 320(%rsp)
	movaps	%xmm6, 336(%rsp)
	movaps	%xmm7, 352(%rsp)
.L162:
	movl	$16, 8(%rsp)
	movl	$48, 12(%rsp)
	leaq	400(%rsp), %rax
	movq	%rax, 16(%rsp)
	leaq	192(%rsp), %rax
	movq	%rax, 24(%rsp)
	leaq	8(%rsp), %rcx
	leaq	32(%rsp), %rbp
	movq	%rsi, %rdx
	movl	$160, %esi
	movq	%rbp, %rdi
	call	vsnprintf@PLT
	addl	708+C(%rip), %ebx
	movl	%ebx, %edi
	call	caret
	movq	%rbp, %rsi
	leaq	.LC19(%rip), %rdi
	movl	$0, %eax
	call	err
	addq	$376, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE30:
	.size	bad_arg, .-bad_arg
	.section	.rodata.str1.1
.LC24:
	.string	"1"
.LC25:
	.string	"2"
.LC26:
	.string	"RIP version must be 1 or 2."
	.text
	.type	h_rip_version, @function
h_rip_version:
.LFB74:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movq	(%rsi), %rbx
	leaq	.LC24(%rip), %rsi
	movq	%rbx, %rdi
	call	strcmp@PLT
	testl	%eax, %eax
	je	.L165
	leaq	.LC25(%rip), %rsi
	movq	%rbx, %rdi
	call	strcmp@PLT
	testl	%eax, %eax
	jne	.L169
.L165:
	movsbl	(%rbx), %edx
	subl	$48, %edx
	movl	$1, %eax
	cmpl	%edx, 684+cfg(%rip)
	je	.L164
	movl	%edx, 684+cfg(%rip)
	movl	$0, %eax
.L164:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L169:
	.cfi_restore_state
	leaq	.LC26(%rip), %rsi
	movl	$0, %edi
	movl	$0, %eax
	call	bad_arg
	jmp	.L164
	.cfi_endproc
.LFE74:
	.size	h_rip_version, .-h_rip_version
	.section	.rodata.str1.8
	.align 8
.LC27:
	.string	"Description too long (max 99 characters)."
	.text
	.type	h_description, @function
h_description:
.LFB64:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movl	708+C(%rip), %eax
	cmpl	704+C(%rip), %eax
	jge	.L173
	leaq	C(%rip), %rdx
	cltq
	movslq	640(%rdx,%rax,4), %rbx
	addq	%rdx, %rbx
	movq	%rbx, %rdi
	call	strlen@PLT
	cmpq	$99, %rax
	jbe	.L171
	leaq	.LC27(%rip), %rsi
	movl	$0, %edi
	movl	$0, %eax
	call	bad_arg
	jmp	.L170
.L173:
	leaq	.LC22(%rip), %rbx
.L171:
	movq	cur_if(%rip), %rax
	leaq	40(%rax), %rbp
	movq	%rbx, %rsi
	movq	%rbp, %rdi
	call	strcmp@PLT
	movl	%eax, %edx
	movl	$1, %eax
	testl	%edx, %edx
	jne	.L176
.L170:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L176:
	.cfi_restore_state
	movq	%rbx, %rcx
	leaq	.LC19(%rip), %rdx
	movl	$100, %esi
	movq	%rbp, %rdi
	movl	$0, %eax
	call	snprintf@PLT
	movl	$0, %eax
	jmp	.L170
	.cfi_endproc
.LFE64:
	.size	h_description, .-h_description
	.section	.rodata.str1.1
.LC28:
	.string	"Password too long (max 63)."
	.text
	.type	h_secret, @function
h_secret:
.LFB55:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movq	(%rsi), %rbx
	movq	%rbx, %rdi
	call	strlen@PLT
	cmpq	$63, %rax
	ja	.L182
	movq	%rbx, %rsi
	leaq	64+cfg(%rip), %rdi
	call	strcmp@PLT
	movl	%eax, %edx
	movl	$1, %eax
	testl	%edx, %edx
	jne	.L183
.L177:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L182:
	.cfi_restore_state
	leaq	.LC28(%rip), %rsi
	movl	$0, %edi
	movl	$0, %eax
	call	bad_arg
	jmp	.L177
.L183:
	movq	%rbx, %rcx
	leaq	.LC19(%rip), %rdx
	movl	$64, %esi
	leaq	64+cfg(%rip), %rdi
	movl	$0, %eax
	call	snprintf@PLT
	movl	$0, %eax
	jmp	.L177
	.cfi_endproc
.LFE55:
	.size	h_secret, .-h_secret
	.section	.rodata.str1.8
	.align 8
.LC29:
	.string	"Hostname must start with a letter and be at most 63 characters."
	.align 8
.LC30:
	.string	"Hostname may contain only letters, digits, '-' and '_'."
	.section	.rodata.str1.1
.LC31:
	.string	"hostname -> %s"
	.text
	.type	h_hostname, @function
h_hostname:
.LFB53:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movq	(%rsi), %r12
	call	__ctype_b_loc@PLT
	movq	(%rax), %rbp
	movzbl	(%r12), %ebx
	movzbl	%bl, %eax
	testb	$4, 1(%rbp,%rax,2)
	je	.L185
	movq	%r12, %rdi
	call	strlen@PLT
	cmpq	$63, %rax
	ja	.L185
	leaq	1(%r12), %rax
	testb	%bl, %bl
	jne	.L190
.L187:
	movq	%r12, %rsi
	leaq	cfg(%rip), %rdi
	call	strcmp@PLT
	movl	%eax, %edx
	movl	$1, %eax
	testl	%edx, %edx
	je	.L184
	movq	%r12, %rcx
	leaq	.LC19(%rip), %rdx
	movl	$64, %esi
	leaq	cfg(%rip), %rdi
	movl	$0, %eax
	call	snprintf@PLT
	movq	%r12, %rcx
	leaq	.LC31(%rip), %rdx
	leaq	.LC1(%rip), %rsi
	movl	$1, %edi
	movl	$0, %eax
	call	rlog_log@PLT
	movl	$0, %eax
	jmp	.L184
.L185:
	leaq	.LC29(%rip), %rsi
	movl	$0, %edi
	movl	$0, %eax
	call	bad_arg
.L184:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.p2align 5
.L189:
	.cfi_restore_state
	addq	$1, %rax
	movzbl	-1(%rax), %ebx
	testb	%bl, %bl
	je	.L187
.L190:
	movzbl	%bl, %edx
	testb	$8, 0(%rbp,%rdx,2)
	jne	.L189
	cmpb	$45, %bl
	setne	%cl
	cmpb	$95, %bl
	setne	%dl
	testb	%dl, %cl
	je	.L189
	leaq	.LC30(%rip), %rsi
	movl	$0, %edi
	movl	$0, %eax
	call	bad_arg
	jmp	.L184
	.cfi_endproc
.LFE53:
	.size	h_hostname, .-h_hostname
	.type	xmalloc, @function
xmalloc:
.LFB14:
	.cfi_startproc
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	testq	%rdi, %rdi
	movl	$1, %eax
	cmove	%rax, %rdi
	call	malloc@PLT
	testq	%rax, %rax
	je	.L198
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L198:
	.cfi_restore_state
	movq	stderr(%rip), %rcx
	movl	$14, %edx
	movl	$1, %esi
	leaq	.LC14(%rip), %rdi
	call	fwrite@PLT
	movl	$1, %edi
	call	exit@PLT
	.cfi_endproc
.LFE14:
	.size	xmalloc, .-xmalloc
	.type	xstrdup, @function
xstrdup:
.LFB16:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movq	%rdi, %rbp
	call	strlen@PLT
	leaq	1(%rax), %r12
	movq	%r12, %rdi
	call	xmalloc
	movq	%r12, %rdx
	movq	%rbp, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE16:
	.size	xstrdup, .-xstrdup
	.type	addf, @function
addf:
.LFB26:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	subq	$512, %rsp
	.cfi_def_cfa_offset 528
	movq	%rdi, %rbx
	movq	%rdx, 352(%rsp)
	movq	%rcx, 360(%rsp)
	movq	%r8, 368(%rsp)
	movq	%r9, 376(%rsp)
	testb	%al, %al
	je	.L206
	movaps	%xmm0, 384(%rsp)
	movaps	%xmm1, 400(%rsp)
	movaps	%xmm2, 416(%rsp)
	movaps	%xmm3, 432(%rsp)
	movaps	%xmm4, 448(%rsp)
	movaps	%xmm5, 464(%rsp)
	movaps	%xmm6, 480(%rsp)
	movaps	%xmm7, 496(%rsp)
.L206:
	movl	$16, 8(%rsp)
	movl	$48, 12(%rsp)
	leaq	528(%rsp), %rax
	movq	%rax, 16(%rsp)
	leaq	336(%rsp), %rax
	movq	%rax, 24(%rsp)
	leaq	8(%rsp), %rcx
	leaq	32(%rsp), %rdi
	movq	%rsi, %rdx
	movl	$300, %esi
	call	vsnprintf@PLT
	movl	12(%rbx), %eax
	cmpl	%eax, 8(%rbx)
	jl	.L203
	leal	(%rax,%rax), %esi
	testl	%eax, %eax
	movl	$8, %eax
	cmove	%eax, %esi
	movl	%esi, 12(%rbx)
	movslq	%esi, %rsi
	salq	$3, %rsi
	movq	(%rbx), %rdi
	call	xrealloc
	movq	%rax, (%rbx)
.L203:
	movl	8(%rbx), %eax
	leal	1(%rax), %edx
	movl	%edx, 8(%rbx)
	cltq
	salq	$3, %rax
	addq	(%rbx), %rax
	movq	%rax, %rbx
	leaq	32(%rsp), %rdi
	call	xstrdup
	movq	%rax, (%rbx)
	addq	$512, %rsp
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE26:
	.size	addf, .-addf
	.section	.rodata.str1.1
.LC32:
	.string	"Password: "
.LC33:
	.string	"Access denied"
.LC34:
	.string	"entered privileged EXEC"
	.text
	.type	h_enable, @function
h_enable:
.LFB47:
	.cfi_startproc
	subq	$120, %rsp
	.cfi_def_cfa_offset 128
	cmpb	$0, 64+cfg(%rip)
	je	.L209
	cmpl	$0, loading(%rip)
	je	.L219
.L209:
	movl	$1, mode(%rip)
	leaq	.LC34(%rip), %rdx
	leaq	.LC11(%rip), %rsi
	movl	$0, %edi
	movl	$0, %eax
	call	rlog_log@PLT
	movl	$0, %eax
.L208:
	addq	$120, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L219:
	.cfi_restore_state
	leaq	.LC32(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	movq	stdout(%rip), %rdi
	call	fflush@PLT
	movq	%rsp, %rdi
	movq	stdin(%rip), %rdx
	movl	$100, %esi
	call	fgets@PLT
	testq	%rax, %rax
	je	.L216
	movq	%rsp, %rdi
	call	strlen@PLT
	movq	%rax, %rdx
	testq	%rax, %rax
	jne	.L211
	jmp	.L212
	.p2align 5
.L213:
	movb	$0, (%rsp,%rdx)
	testq	%rdx, %rdx
	je	.L212
.L211:
	subq	$1, %rdx
	movzbl	(%rsp,%rdx), %eax
	cmpb	$10, %al
	je	.L213
	cmpb	$13, %al
	je	.L213
.L212:
	movq	%rsp, %rdi
	leaq	64+cfg(%rip), %rsi
	call	strcmp@PLT
	testl	%eax, %eax
	je	.L209
	leaq	.LC33(%rip), %rdi
	movl	$0, %eax
	call	err
	jmp	.L208
.L216:
	movl	$-1, %eax
	jmp	.L208
	.cfi_endproc
.LFE47:
	.size	h_enable, .-h_enable
	.section	.rodata.str1.1
.LC35:
	.string	"startup-config.cfg"
.LC36:
	.string	"No startup-config to erase."
.LC37:
	.string	"[OK] startup-config erased"
	.text
	.type	h_erase, @function
h_erase:
.LFB101:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	leaq	.LC35(%rip), %rdi
	call	remove@PLT
	testl	%eax, %eax
	jne	.L224
	movl	%eax, %ebx
	leaq	.LC37(%rip), %rdi
	call	puts@PLT
.L220:
	movl	%ebx, %eax
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L224:
	.cfi_restore_state
	leaq	.LC36(%rip), %rdi
	movl	$0, %eax
	call	err
	movl	%eax, %ebx
	jmp	.L220
	.cfi_endproc
.LFE101:
	.size	h_erase, .-h_erase
	.section	.rodata.str1.1
.LC38:
	.string	"r"
.LC39:
	.string	"startup-config is not present"
	.text
	.type	h_show_startup, @function
h_show_startup:
.LFB84:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$312, %rsp
	.cfi_def_cfa_offset 336
	leaq	.LC38(%rip), %rsi
	leaq	.LC35(%rip), %rdi
	call	fopen@PLT
	testq	%rax, %rax
	je	.L230
	movq	%rax, %rbp
	movq	%rsp, %rbx
	jmp	.L226
.L230:
	leaq	.LC39(%rip), %rdi
	call	puts@PLT
	jmp	.L227
.L228:
	movq	stdout(%rip), %rsi
	movq	%rbx, %rdi
	call	fputs@PLT
.L226:
	movq	%rbp, %rdx
	movl	$300, %esi
	movq	%rbx, %rdi
	call	fgets@PLT
	testq	%rax, %rax
	jne	.L228
	movq	%rbp, %rdi
	call	fclose@PLT
.L227:
	movl	$0, %eax
	addq	$312, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE84:
	.size	h_show_startup, .-h_show_startup
	.type	route_remove, @function
route_remove:
.LFB41:
	.cfi_startproc
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	movq	664+cfg(%rip), %rsi
	movslq	%edi, %rax
	addq	$1, %rax
	movq	%rax, %rcx
	salq	$4, %rcx
	subq	%rax, %rcx
	salq	$2, %rcx
	notl	%edi
	addl	672+cfg(%rip), %edi
	movslq	%edi, %rax
	movq	%rax, %rdx
	salq	$4, %rdx
	subq	%rax, %rdx
	salq	$2, %rdx
	leaq	(%rsi,%rcx), %rax
	leaq	-60(%rsi,%rcx), %rdi
	movq	%rax, %rsi
	call	memmove@PLT
	subl	$1, 672+cfg(%rip)
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE41:
	.size	route_remove, .-route_remove
	.section	.rodata.str1.1
.LC40:
	.string	"administratively down"
.LC41:
	.string	"down"
	.text
	.type	h_shutdown, @function
h_shutdown:
.LFB62:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movq	cur_if(%rip), %rbx
	movl	152(%rbx), %eax
	testl	%eax, %eax
	je	.L238
	movl	$1, %eax
.L234:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L238:
	.cfi_restore_state
	movl	$1, 152(%rbx)
	movl	loading(%rip), %ebp
	testl	%ebp, %ebp
	jne	.L234
	leaq	.LC40(%rip), %rdx
	movq	%rbx, %rsi
	leaq	.LC3(%rip), %rdi
	call	printf@PLT
	leaq	.LC41(%rip), %rdx
	movq	%rbx, %rsi
	leaq	.LC4(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	movl	%ebp, %eax
	jmp	.L234
	.cfi_endproc
.LFE62:
	.size	h_shutdown, .-h_shutdown
	.globl	rc_ieq
	.type	rc_ieq, @function
rc_ieq:
.LFB17:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$8, %rsp
	.cfi_def_cfa_offset 48
	movq	%rdi, %r13
	movq	%rsi, %r12
	movzbl	(%rdi), %ebx
	testb	%bl, %bl
	je	.L241
.L240:
	movzbl	(%r12), %ebp
	testb	%bpl, %bpl
	je	.L241
	call	__ctype_tolower_loc@PLT
	movq	(%rax), %rax
	movzbl	%bpl, %ebp
	movzbl	%bl, %ebx
	movl	(%rax,%rbx,4), %edx
	cmpl	%edx, (%rax,%rbp,4)
	jne	.L244
	addq	$1, %r13
	addq	$1, %r12
	movzbl	0(%r13), %ebx
	testb	%bl, %bl
	jne	.L240
.L241:
	cmpb	%bl, (%r12)
	sete	%al
	movzbl	%al, %eax
.L239:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
.L244:
	.cfi_restore_state
	movl	$0, %eax
	jmp	.L239
	.cfi_endproc
.LFE17:
	.size	rc_ieq, .-rc_ieq
	.globl	rc_is_prefix_ci
	.type	rc_is_prefix_ci, @function
rc_is_prefix_ci:
.LFB18:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$8, %rsp
	.cfi_def_cfa_offset 48
	movq	%rdi, %r12
	movq	%rsi, %r13
	movzbl	(%rdi), %ebx
	movl	$0, %eax
	testb	%bl, %bl
	je	.L247
.L249:
	movzbl	0(%r13), %ebp
	testb	%bpl, %bpl
	je	.L250
	call	__ctype_tolower_loc@PLT
	movq	(%rax), %rax
	movzbl	%bpl, %ebp
	movzbl	%bl, %ebx
	movl	(%rax,%rbx,4), %edx
	cmpl	%edx, (%rax,%rbp,4)
	jne	.L253
	addq	$1, %r12
	addq	$1, %r13
	movzbl	(%r12), %ebx
	testb	%bl, %bl
	jne	.L249
.L250:
	testb	%bl, %bl
	sete	%al
	movzbl	%al, %eax
.L247:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
.L253:
	.cfi_restore_state
	movl	$0, %eax
	jmp	.L247
	.cfi_endproc
.LFE18:
	.size	rc_is_prefix_ci, .-rc_is_prefix_ci
	.section	.rodata.str1.1
.LC42:
	.string	"  %-34s %-26s %s\n"
.LC43:
	.string	"% Unrecognized command"
	.section	.rodata.str1.8
	.align 8
.LC44:
	.string	"  (abbreviations work: conf t, int g0/0, sh ip int br, no sh ...)"
	.text
	.type	show_help, @function
show_help:
.LFB108:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$152, %rsp
	.cfi_def_cfa_offset 208
	movl	%edi, 8(%rsp)
	leaq	CMDS(%rip), %r12
	leaq	2448(%r12), %r14
	movl	$0, 12(%rsp)
	jmp	.L260
.L257:
	movq	(%rsp), %rax
	movq	40(%rax), %rcx
	movq	16(%rax), %rdx
	movq	%r15, %rsi
	leaq	.LC42(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	addl	$1, 12(%rsp)
	.p2align 5
.L259:
	addq	$48, %r12
	cmpq	%r14, %r12
	je	.L266
.L260:
	movq	%r12, (%rsp)
	movl	(%r12), %edx
	movl	mode(%rip), %eax
	btl	%eax, %edx
	jnc	.L259
	movq	8(%r12), %r15
	leaq	16(%rsp), %rsi
	movq	%r15, %rdi
	call	pat_split
	movl	8(%rsp), %ecx
	cmpl	%ecx, %eax
	cmovg	%ecx, %eax
	testl	%eax, %eax
	jle	.L257
	leaq	C(%rip), %rbx
	leaq	16(%rsp), %rbp
	cltq
	leaq	(%rbx,%rax,8), %r13
.L258:
	movq	512(%rbx), %rdi
	movq	%rbp, %rsi
	call	rc_is_prefix_ci
	testl	%eax, %eax
	je	.L259
	addq	$8, %rbx
	addq	$24, %rbp
	cmpq	%r13, %rbx
	jne	.L258
	jmp	.L257
.L266:
	cmpl	$0, 12(%rsp)
	jne	.L261
	leaq	.LC43(%rip), %rdi
	call	puts@PLT
.L255:
	addq	$152, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L261:
	.cfi_restore_state
	leaq	.LC44(%rip), %rdi
	call	puts@PLT
	jmp	.L255
	.cfi_endproc
.LFE108:
	.size	show_help, .-show_help
	.type	h_help, @function
h_help:
.LFB109:
	.cfi_startproc
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	movl	$0, 704+C(%rip)
	movl	$0, %edi
	call	show_help
	movl	$0, %eax
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE109:
	.size	h_help, .-h_help
	.section	.rodata.str1.8
	.align 8
.LC45:
	.string	"Too many words on one line (max %d)."
	.section	.rodata.str1.1
.LC46:
	.string	"do"
.LC47:
	.string	"Incomplete command."
	.section	.rodata.str1.8
	.align 8
.LC48:
	.string	"Invalid input detected at '^' marker."
	.section	.rodata.str1.1
.LC49:
	.string	"Ambiguous command: \"%s\""
	.text
	.type	execute_line_impl, @function
execute_line_impl:
.LFB111:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$1160, %rsp
	.cfi_def_cfa_offset 1216
	movq	%rdi, %rax
	leaq	432(%rsp), %rdi
	leaq	C(%rip), %rsi
	movl	$89, %ecx
	rep movsq
	addl	$1, st(%rip)
	leaq	176(%rsp), %rbp
	movq	%rax, %rcx
	leaq	.LC19(%rip), %rbx
	movq	%rbx, %rdx
	movl	$256, %esi
	movq	%rbp, %rdi
	movl	$0, %eax
	call	snprintf@PLT
	movq	%rbp, %rcx
	movq	%rbx, %rdx
	movl	$256, %esi
	leaq	C(%rip), %rbx
	movq	%rbx, %rdi
	movl	$0, %eax
	call	snprintf@PLT
	movq	%rbx, %rdi
	call	strlen@PLT
	testq	%rax, %rax
	je	.L270
	movq	%rax, %rbx
	call	__ctype_b_loc@PLT
	leaq	C(%rip), %rdx
	.p2align 5
.L271:
	subq	$1, %rbx
	movzbl	(%rdx,%rbx), %esi
	movq	(%rax), %rcx
	testb	$32, 1(%rcx,%rsi,2)
	je	.L270
	movb	$0, (%rdx,%rbx)
	testq	%rbx, %rbx
	jne	.L271
.L270:
	movdqa	C(%rip), %xmm0
	movaps	%xmm0, 256+C(%rip)
	movdqa	16+C(%rip), %xmm1
	movaps	%xmm1, 272+C(%rip)
	movdqa	32+C(%rip), %xmm2
	movaps	%xmm2, 288+C(%rip)
	movdqa	48+C(%rip), %xmm3
	movaps	%xmm3, 304+C(%rip)
	movdqa	64+C(%rip), %xmm4
	movaps	%xmm4, 320+C(%rip)
	movdqa	80+C(%rip), %xmm5
	movaps	%xmm5, 336+C(%rip)
	movdqa	96+C(%rip), %xmm6
	movaps	%xmm6, 352+C(%rip)
	movdqa	112+C(%rip), %xmm7
	movaps	%xmm7, 368+C(%rip)
	movdqa	128+C(%rip), %xmm0
	movaps	%xmm0, 384+C(%rip)
	movdqa	144+C(%rip), %xmm1
	movaps	%xmm1, 400+C(%rip)
	movdqa	160+C(%rip), %xmm2
	movaps	%xmm2, 416+C(%rip)
	movdqa	176+C(%rip), %xmm3
	movaps	%xmm3, 432+C(%rip)
	movdqa	192+C(%rip), %xmm4
	movaps	%xmm4, 448+C(%rip)
	movdqa	208+C(%rip), %xmm5
	movaps	%xmm5, 464+C(%rip)
	movdqa	224+C(%rip), %xmm6
	movaps	%xmm6, 480+C(%rip)
	movdqa	240+C(%rip), %xmm7
	movaps	%xmm7, 496+C(%rip)
	movl	$0, 704+C(%rip)
	movl	$0, 708+C(%rip)
	leaq	256+C(%rip), %rbx
	movq	%rbx, %r12
	jmp	.L282
.L317:
	movl	704+C(%rip), %edx
	cmpl	$15, %edx
	jg	.L315
	leaq	C(%rip), %rcx
	movslq	%edx, %rsi
	movq	%rbx, 512(%rcx,%rsi,8)
	movq	%rbx, %rdi
	subq	%r12, %rdi
	movl	%edi, 640(%rcx,%rsi,4)
	addl	$1, %edx
	movl	%edx, 704+C(%rip)
	movzbl	(%rbx), %edx
	testb	%dl, %dl
	je	.L282
	movq	(%rax), %rax
	.p2align 5
.L279:
	movzbl	%dl, %edx
	testb	$32, 1(%rax,%rdx,2)
	jne	.L316
	addq	$1, %rbx
	movzbl	(%rbx), %edx
	testb	%dl, %dl
	jne	.L279
.L282:
	movzbl	(%rbx), %ebp
	testb	%bpl, %bpl
	je	.L274
	call	__ctype_b_loc@PLT
	movq	(%rax), %rdx
	.p2align 5
.L283:
	movzbl	%bpl, %ebp
	testb	$32, 1(%rdx,%rbp,2)
	je	.L317
	addq	$1, %rbx
	movzbl	(%rbx), %ebp
	testb	%bpl, %bpl
	jne	.L283
.L274:
	movl	704+C(%rip), %ebx
	testl	%ebx, %ebx
	je	.L284
	movq	512+C(%rip), %r13
	cmpb	$33, 0(%r13)
	je	.L284
	leal	-1(%rbx), %r12d
	movslq	%r12d, %rdx
	leaq	C(%rip), %rax
	movq	512(%rax,%rdx,8), %rbp
	movq	%rbp, %rdi
	call	strlen@PLT
	leaq	-1(%rbp,%rax), %rax
	cmpb	$63, (%rax)
	je	.L318
	leaq	.LC46(%rip), %rsi
	movq	%r13, %rdi
	call	rc_ieq
	testl	%eax, %eax
	je	.L288
	movl	mode(%rip), %ebp
	cmpl	$1, %ebp
	jbe	.L288
	cmpl	$1, %ebx
	je	.L319
	movq	cur_if(%rip), %rbx
	movl	$1, mode(%rip)
	movslq	644+C(%rip), %rdi
	leaq	C(%rip), %rax
	addq	%rax, %rdi
	call	execute_line_impl
	movl	%ebp, mode(%rip)
	movq	%rbx, cur_if(%rip)
	jmp	.L277
.L315:
	movl	$16, %esi
	leaq	.LC45(%rip), %rdi
	movl	$0, %eax
	call	err
.L277:
	leaq	C(%rip), %rdi
	leaq	432(%rsp), %rsi
	movl	$89, %ecx
	rep movsq
	addq	$1160, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L316:
	.cfi_restore_state
	movb	$0, (%rbx)
	leaq	1(%rbx), %rbx
	jmp	.L282
.L284:
	subl	$1, st(%rip)
	jmp	.L277
.L318:
	movb	$0, (%rax)
	cmpb	$0, 0(%rbp)
	cmovne	%ebx, %r12d
	movl	%r12d, %edi
	call	show_help
	jmp	.L277
.L319:
	leaq	.LC47(%rip), %rdi
	movl	$0, %eax
	call	err
	jmp	.L277
.L288:
	leaq	CMDS(%rip), %r14
	movl	$0, 20(%rsp)
	movl	$-1, %esi
	movl	$-1, 32(%rsp)
	movl	$-1, 12(%rsp)
	movl	$0, 16(%rsp)
	movl	$0, %r12d
	leaq	48(%rsp), %rax
	movq	%rax, 40(%rsp)
	movl	%r12d, 4(%rsp)
	movl	%esi, 36(%rsp)
	jmp	.L299
.L321:
	movl	%r14d, %ecx
	movq	24(%rsp), %r14
.L291:
	movl	16(%rsp), %eax
	cmpl	%r13d, %eax
	cmovl	%r13d, %eax
	movl	%eax, 16(%rsp)
	cmpl	%r13d, %ecx
	jne	.L298
	jmp	.L306
.L307:
	movl	$0, %r15d
	movl	$0, %r13d
	jmp	.L291
.L313:
	movl	%r14d, %ecx
	movq	24(%rsp), %r14
	jmp	.L291
.L310:
	movl	32(%rsp), %ecx
	cmpl	%ecx, %r15d
	sete	%al
	movzbl	%al, %eax
	andl	%edx, %eax
	orl	%eax, 20(%rsp)
	movl	%ecx, %r15d
	movl	12(%rsp), %r13d
	jmp	.L296
.L308:
	movl	4(%rsp), %eax
	movl	%eax, 36(%rsp)
	movl	$0, 20(%rsp)
.L296:
	movl	%r15d, 32(%rsp)
	movl	%r13d, 12(%rsp)
.L298:
	addl	$1, 4(%rsp)
	movl	4(%rsp), %eax
	addq	$48, %r14
	cmpl	$51, %eax
	je	.L320
.L299:
	movl	(%r14), %edx
	movl	mode(%rip), %eax
	btl	%eax, %edx
	jnc	.L298
	movq	8(%r14), %rdi
	movq	40(%rsp), %rsi
	call	pat_split
	movl	%eax, %ecx
	testl	%eax, %eax
	jle	.L307
	movl	704+C(%rip), %eax
	movl	%eax, 8(%rsp)
	leaq	48(%rsp), %rbx
	leaq	512+C(%rip), %rbp
	movl	$0, %r15d
	movl	$0, %r13d
	movq	%r14, 24(%rsp)
	movl	%ecx, %r14d
.L292:
	cmpl	%r13d, 8(%rsp)
	jle	.L321
	movq	0(%rbp), %r12
	movq	%rbx, %rsi
	movq	%r12, %rdi
	call	rc_is_prefix_ci
	testl	%eax, %eax
	je	.L313
	addl	$1, %r13d
	movq	%rbx, %rsi
	movq	%r12, %rdi
	call	rc_ieq
	cmpl	$1, %eax
	sbbl	$-1, %r15d
	addq	$24, %rbx
	addq	$8, %rbp
	cmpl	%r13d, %r14d
	jne	.L292
	movl	%r14d, %ecx
	movq	24(%rsp), %r14
	movl	16(%rsp), %eax
	cmpl	%ecx, %eax
	cmovl	%ecx, %eax
	movl	%eax, 16(%rsp)
	movl	%ecx, %r13d
.L306:
	movl	12(%rsp), %eax
	cmpl	%eax, %r13d
	jg	.L308
	sete	%dl
	movl	32(%rsp), %eax
	cmpl	%eax, %r15d
	jle	.L310
	testb	%dl, %dl
	je	.L310
	movl	12(%rsp), %r13d
	movl	4(%rsp), %eax
	movl	%eax, 36(%rsp)
	movl	$0, 20(%rsp)
	jmp	.L296
.L320:
	movl	36(%rsp), %esi
	testl	%esi, %esi
	js	.L322
	cmpl	$0, 20(%rsp)
	jne	.L323
	movslq	%esi, %rsi
	leaq	(%rsi,%rsi,2), %rbx
	salq	$4, %rbx
	leaq	CMDS(%rip), %rax
	addq	%rax, %rbx
	movl	704+C(%rip), %edi
	movl	12(%rsp), %eax
	subl	%eax, %edi
	movl	%eax, 708+C(%rip)
	cmpl	24(%rbx), %edi
	jl	.L324
	movl	28(%rbx), %eax
	cmpl	%eax, %edi
	jg	.L325
	movslq	12(%rsp), %rax
	leaq	512+C(%rip), %rdx
	leaq	(%rdx,%rax,8), %rsi
	call	*32(%rbx)
	movl	(%rbx), %edx
	testl	%edx, %edx
	je	.L277
	testl	$-61, %edx
	jne	.L277
	testl	%eax, %eax
	jne	.L305
	addl	$1, 4+st(%rip)
	jmp	.L277
.L322:
	movl	16(%rsp), %eax
	cmpl	%eax, 704+C(%rip)
	jg	.L301
	leaq	.LC47(%rip), %rdi
	movl	$0, %eax
	call	err
	jmp	.L277
.L301:
	movl	16(%rsp), %edi
	call	caret
	leaq	.LC48(%rip), %rdi
	movl	$0, %eax
	call	err
	jmp	.L277
.L323:
	movq	512+C(%rip), %rsi
	leaq	.LC49(%rip), %rdi
	movl	$0, %eax
	call	err
	jmp	.L277
.L324:
	leaq	.LC47(%rip), %rdi
	movl	$0, %eax
	call	err
	jmp	.L277
.L325:
	movl	12(%rsp), %edi
	addl	%eax, %edi
	call	caret
	leaq	.LC48(%rip), %rdi
	movl	$0, %eax
	call	err
	jmp	.L277
.L305:
	jle	.L277
	addl	$1, 8+st(%rip)
	jmp	.L277
	.cfi_endproc
.LFE111:
	.size	execute_line_impl, .-execute_line_impl
	.section	.rodata.str1.1
.LC50:
	.string	"%u.%u.%u.%u"
	.text
	.globl	rc_ipstr
	.type	rc_ipstr, @function
rc_ipstr:
.LFB20:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movl	%edi, %eax
	movl	i.2(%rip), %ebx
	leal	1(%rbx), %edx
	movl	%edx, i.2(%rip)
	andl	$3, %ebx
	salq	$4, %rbx
	leaq	b.1(%rip), %rdx
	addq	%rdx, %rbx
	movzbl	%ah, %esi
	movl	%esi, %r9d
	movl	%edi, %r8d
	shrl	$16, %r8d
	movl	%edi, %ecx
	shrl	$24, %ecx
	subq	$8, %rsp
	.cfi_def_cfa_offset 24
	movzbl	%dil, %eax
	pushq	%rax
	.cfi_def_cfa_offset 32
	movzbl	%r8b, %r8d
	leaq	.LC50(%rip), %rdx
	movl	$16, %esi
	movq	%rbx, %rdi
	movl	$0, %eax
	call	snprintf@PLT
	addq	$16, %rsp
	.cfi_def_cfa_offset 16
	movq	%rbx, %rax
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE20:
	.size	rc_ipstr, .-rc_ipstr
	.section	.rodata.str1.1
.LC51:
	.string	" shutdown"
.LC52:
	.string	" no shutdown"
.LC53:
	.string	"!"
.LC54:
	.string	"hostname %s"
.LC55:
	.string	"enable secret %s"
.LC56:
	.string	"interface %s"
.LC57:
	.string	" description %s"
.LC58:
	.string	" ip address %s %s"
.LC59:
	.string	" no ip address"
.LC60:
	.string	" clock rate %ld"
.LC61:
	.string	"router rip"
.LC62:
	.string	" version %d"
.LC63:
	.string	" network %s"
.LC64:
	.string	" no auto-summary"
.LC65:
	.string	"router ospf %d"
.LC66:
	.string	" router-id %s"
.LC67:
	.string	" network %s %s area %llu"
.LC68:
	.string	" %d"
.LC69:
	.string	"ip route %s %s %s%s"
.LC70:
	.string	"end"
	.text
	.type	gen_config, @function
gen_config:
.LFB46:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$40, %rsp
	.cfi_def_cfa_offset 96
	movq	%rdi, %rbx
	leaq	.LC53(%rip), %rbp
	movq	%rbp, %rsi
	movl	$0, %eax
	call	addf
	leaq	cfg(%rip), %rdx
	leaq	.LC54(%rip), %rsi
	movq	%rbx, %rdi
	movl	$0, %eax
	call	addf
	movq	%rbp, %rsi
	movq	%rbx, %rdi
	movl	$0, %eax
	call	addf
	cmpb	$0, 64+cfg(%rip)
	jne	.L357
.L329:
	movq	640+cfg(%rip), %rbp
	testq	%rbp, %rbp
	je	.L330
	leaq	.LC56(%rip), %r13
	leaq	.LC59(%rip), %r15
	leaq	.LC58(%rip), %r14
	jmp	.L336
.L357:
	leaq	64+cfg(%rip), %rdx
	leaq	.LC55(%rip), %rsi
	movq	%rbx, %rdi
	movl	$0, %eax
	call	addf
	movq	%rbp, %rsi
	movq	%rbx, %rdi
	movl	$0, %eax
	call	addf
	jmp	.L329
.L358:
	leaq	40(%rbp), %rdx
	leaq	.LC57(%rip), %rsi
	movq	%rbx, %rdi
	movl	$0, %eax
	call	addf
	jmp	.L331
.L332:
	movq	%r15, %rsi
	movq	%rbx, %rdi
	movl	$0, %eax
	call	addf
	jmp	.L333
.L359:
	leaq	.LC60(%rip), %rsi
	movq	%rbx, %rdi
	movl	$0, %eax
	call	addf
	jmp	.L334
.L335:
	movq	%rbx, %rdi
	movl	$0, %eax
	call	addf
	leaq	.LC53(%rip), %rsi
	movq	%rbx, %rdi
	movl	$0, %eax
	call	addf
	movq	176(%rbp), %rbp
	testq	%rbp, %rbp
	je	.L330
.L336:
	movq	%rbp, %rdx
	movq	%r13, %rsi
	movq	%rbx, %rdi
	movl	$0, %eax
	call	addf
	cmpb	$0, 40(%rbp)
	jne	.L358
.L331:
	cmpl	$0, 148(%rbp)
	je	.L332
	movl	144(%rbp), %edi
	call	rc_ipstr
	movq	%rax, %r12
	movl	140(%rbp), %edi
	call	rc_ipstr
	movq	%rax, %rdx
	movq	%r12, %rcx
	movq	%r14, %rsi
	movq	%rbx, %rdi
	movl	$0, %eax
	call	addf
.L333:
	movq	160(%rbp), %rdx
	testq	%rdx, %rdx
	jne	.L359
.L334:
	leaq	.LC52(%rip), %rsi
	cmpl	$0, 152(%rbp)
	je	.L335
	leaq	.LC51(%rip), %rsi
	jmp	.L335
.L330:
	cmpl	$0, 680+cfg(%rip)
	jne	.L360
.L337:
	cmpl	$0, 712+cfg(%rip)
	jne	.L361
.L341:
	movl	672+cfg(%rip), %eax
	testl	%eax, %eax
	jle	.L345
	movl	$0, %r12d
	leaq	16(%rsp), %r14
	leaq	.LC69(%rip), %r15
	jmp	.L349
.L360:
	leaq	.LC61(%rip), %rsi
	movq	%rbx, %rdi
	movl	$0, %eax
	call	addf
	movl	684+cfg(%rip), %edx
	leaq	.LC62(%rip), %rsi
	movq	%rbx, %rdi
	movl	$0, %eax
	call	addf
	cmpl	$0, 704+cfg(%rip)
	jle	.L338
	movl	$0, %ebp
	leaq	cfg(%rip), %r12
	leaq	.LC63(%rip), %r13
.L339:
	movq	696(%r12), %rax
	movl	(%rax,%rbp,4), %edi
	call	rc_ipstr
	movq	%rax, %rdx
	movq	%r13, %rsi
	movq	%rbx, %rdi
	movl	$0, %eax
	call	addf
	addq	$1, %rbp
	cmpl	%ebp, 704(%r12)
	jg	.L339
.L338:
	cmpl	$0, 688+cfg(%rip)
	je	.L362
.L340:
	leaq	.LC53(%rip), %rsi
	movq	%rbx, %rdi
	movl	$0, %eax
	call	addf
	jmp	.L337
.L362:
	leaq	.LC64(%rip), %rsi
	movq	%rbx, %rdi
	movl	$0, %eax
	call	addf
	jmp	.L340
.L361:
	movl	716+cfg(%rip), %edx
	leaq	.LC65(%rip), %rsi
	movq	%rbx, %rdi
	movl	$0, %eax
	call	addf
	cmpl	$0, 720+cfg(%rip)
	jne	.L363
.L342:
	cmpl	$0, 736+cfg(%rip)
	jle	.L343
	movl	$0, %ebp
	leaq	cfg(%rip), %r13
.L344:
	movq	%rbp, %r14
	salq	$4, %r14
	movq	%r14, %rax
	addq	728(%r13), %rax
	movq	8(%rax), %r15
	movl	4(%rax), %edi
	call	rc_ipstr
	movq	%rax, %r12
	movq	728(%r13), %rax
	movl	(%rax,%r14), %edi
	call	rc_ipstr
	movq	%rax, %rdx
	movq	%r15, %r8
	movq	%r12, %rcx
	leaq	.LC67(%rip), %rsi
	movq	%rbx, %rdi
	movl	$0, %eax
	call	addf
	addq	$1, %rbp
	cmpl	%ebp, 736(%r13)
	jg	.L344
.L343:
	leaq	.LC53(%rip), %rsi
	movq	%rbx, %rdi
	movl	$0, %eax
	call	addf
	jmp	.L341
.L363:
	movl	724+cfg(%rip), %edi
	call	rc_ipstr
	movq	%rax, %rdx
	leaq	.LC66(%rip), %rsi
	movq	%rbx, %rdi
	movl	$0, %eax
	call	addf
	jmp	.L342
.L364:
	leaq	.LC68(%rip), %rdx
	movl	$16, %esi
	movq	%r14, %rdi
	movl	$0, %eax
	call	snprintf@PLT
	jmp	.L346
.L347:
	movl	4(%rbp), %edi
	call	rc_ipstr
	movq	%rax, %r13
	movl	0(%rbp), %edi
	call	rc_ipstr
	movq	%rax, %rdx
	movq	%r14, %r9
	leaq	12(%rbp), %r8
	movq	%r13, %rcx
	movq	%r15, %rsi
	movq	%rbx, %rdi
	movl	$0, %eax
	call	addf
.L348:
	movl	672+cfg(%rip), %eax
	addq	$1, %r12
	cmpl	%r12d, %eax
	jle	.L345
.L349:
	movq	%r12, %rax
	salq	$4, %rax
	subq	%r12, %rax
	movq	664+cfg(%rip), %rdx
	leaq	(%rdx,%rax,4), %rbp
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movl	56(%rbp), %ecx
	cmpl	$1, %ecx
	jne	.L364
.L346:
	cmpl	$0, 52(%rbp)
	je	.L347
	movl	8(%rbp), %edi
	call	rc_ipstr
	movq	%rax, %r13
	movl	4(%rbp), %edi
	call	rc_ipstr
	movq	%rax, 8(%rsp)
	movl	0(%rbp), %edi
	call	rc_ipstr
	movq	%rax, %rdx
	movq	%r14, %r9
	movq	%r13, %r8
	movq	8(%rsp), %rcx
	movq	%r15, %rsi
	movq	%rbx, %rdi
	movl	$0, %eax
	call	addf
	jmp	.L348
.L345:
	testl	%eax, %eax
	jne	.L365
.L350:
	leaq	.LC70(%rip), %rsi
	movq	%rbx, %rdi
	movl	$0, %eax
	call	addf
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L365:
	.cfi_restore_state
	leaq	.LC53(%rip), %rsi
	movq	%rbx, %rdi
	movl	$0, %eax
	call	addf
	jmp	.L350
	.cfi_endproc
.LFE46:
	.size	gen_config, .-gen_config
	.section	.rodata.str1.8
	.align 8
.LC71:
	.string	"Building configuration...\n\nCurrent configuration : %lu bytes\n"
	.text
	.type	h_show_run, @function
h_show_run:
.LFB83:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$24, %rsp
	.cfi_def_cfa_offset 64
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	%rsp, %rdi
	call	gen_config
	movq	(%rsp), %rbx
	movl	8(%rsp), %eax
	testl	%eax, %eax
	jle	.L367
	movq	%rbx, %rbp
	cltq
	leaq	(%rbx,%rax,8), %r13
	movl	$0, %r12d
.L368:
	movq	(%rbx), %rdi
	call	strlen@PLT
	leaq	1(%r12,%rax), %r12
	addq	$8, %rbx
	cmpq	%r13, %rbx
	jne	.L368
	movq	%r12, %rsi
	leaq	.LC71(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
.L369:
	movq	0(%rbp), %rdi
	call	puts@PLT
	addq	$8, %rbp
	cmpq	%r13, %rbp
	jne	.L369
.L370:
	movq	%rsp, %rdi
	call	lines_free
	movl	$0, %eax
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
.L367:
	.cfi_restore_state
	movl	$0, %esi
	leaq	.LC71(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	jmp	.L370
	.cfi_endproc
.LFE83:
	.size	h_show_run, .-h_show_run
	.section	.rodata.str1.1
.LC72:
	.string	"enabled"
.LC73:
	.string	"disabled"
.LC74:
	.string	"(not set)"
	.section	.rodata.str1.8
	.align 8
.LC75:
	.string	"No routing protocol is configured."
	.align 8
.LC76:
	.string	"Routing Protocol is \"rip\"\n  Version %d, automatic summarization %s\n  Routing for Networks:\n"
	.section	.rodata.str1.1
.LC77:
	.string	"    %s\n"
	.section	.rodata.str1.8
	.align 8
.LC78:
	.string	"Routing Protocol is \"ospf %d\"\n  Router ID %s\n  Routing for Networks:\n"
	.section	.rodata.str1.1
.LC79:
	.string	"    %s %s area %llu\n"
	.text
	.type	h_show_protocols, @function
h_show_protocols:
.LFB89:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$8, %rsp
	.cfi_def_cfa_offset 64
	cmpl	$0, 680+cfg(%rip)
	jne	.L376
	cmpl	$0, 712+cfg(%rip)
	je	.L389
.L377:
	leaq	.LC74(%rip), %rdx
	cmpl	$0, 720+cfg(%rip)
	jne	.L390
.L382:
	movl	716+cfg(%rip), %esi
	leaq	.LC78(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	cmpl	$0, 736+cfg(%rip)
	jle	.L378
	movl	$0, %ebx
	leaq	cfg(%rip), %r12
	leaq	.LC79(%rip), %r14
.L383:
	movq	%rbx, %r15
	salq	$4, %r15
	movq	%r15, %rax
	addq	728(%r12), %rax
	movq	8(%rax), %r13
	movl	4(%rax), %edi
	call	rc_ipstr
	movq	%rax, %rbp
	movq	728(%r12), %rax
	movl	(%rax,%r15), %edi
	call	rc_ipstr
	movq	%rax, %rsi
	movq	%r13, %rcx
	movq	%rbp, %rdx
	movq	%r14, %rdi
	movl	$0, %eax
	call	printf@PLT
	addq	$1, %rbx
	cmpl	%ebx, 736(%r12)
	jg	.L383
	jmp	.L378
.L389:
	leaq	.LC75(%rip), %rdi
	call	puts@PLT
	jmp	.L378
.L376:
	leaq	.LC73(%rip), %rdx
	cmpl	$0, 688+cfg(%rip)
	leaq	.LC72(%rip), %rax
	cmovne	%rax, %rdx
	movl	684+cfg(%rip), %esi
	leaq	.LC76(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	cmpl	$0, 704+cfg(%rip)
	jle	.L380
	movl	$0, %ebx
	leaq	cfg(%rip), %rbp
	leaq	.LC77(%rip), %r12
.L381:
	movq	696(%rbp), %rax
	movl	(%rax,%rbx,4), %edi
	call	rc_ipstr
	movq	%rax, %rsi
	movq	%r12, %rdi
	movl	$0, %eax
	call	printf@PLT
	addq	$1, %rbx
	cmpl	%ebx, 704(%rbp)
	jg	.L381
.L380:
	cmpl	$0, 712+cfg(%rip)
	jne	.L377
.L378:
	movl	$0, %eax
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L390:
	.cfi_restore_state
	movl	724+cfg(%rip), %edi
	call	rc_ipstr
	movq	%rax, %rdx
	jmp	.L382
	.cfi_endproc
.LFE89:
	.size	h_show_protocols, .-h_show_protocols
	.section	.rodata.str1.1
.LC80:
	.string	"manual"
.LC81:
	.string	"unset"
.LC82:
	.string	"unassigned"
.LC83:
	.string	"Status"
.LC84:
	.string	"Method"
.LC85:
	.string	"OK?"
.LC86:
	.string	"IP-Address"
.LC87:
	.string	"Interface"
	.section	.rodata.str1.8
	.align 8
.LC88:
	.string	"%-22s %-15s %-4s %-7s %-21s %s\n"
	.section	.rodata.str1.1
.LC89:
	.string	"Protocol"
.LC90:
	.string	"YES"
.LC91:
	.string	"(no interfaces configured)"
	.text
	.type	h_show_ipbrief, @function
h_show_ipbrief:
.LFB85:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$16, %rsp
	.cfi_def_cfa_offset 72
	leaq	.LC89(%rip), %rax
	pushq	%rax
	.cfi_def_cfa_offset 80
	leaq	.LC83(%rip), %r9
	leaq	.LC84(%rip), %r8
	leaq	.LC85(%rip), %rcx
	leaq	.LC86(%rip), %rdx
	leaq	.LC87(%rip), %rsi
	leaq	.LC88(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	movq	640+cfg(%rip), %rbx
	addq	$16, %rsp
	.cfi_def_cfa_offset 64
	testq	%rbx, %rbx
	je	.L392
	leaq	.LC2(%rip), %r13
	leaq	.LC41(%rip), %r15
	leaq	.LC40(%rip), %r14
	jmp	.L395
.L392:
	cmpl	$0, 656+cfg(%rip)
	je	.L402
.L399:
	movl	$0, %eax
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L402:
	.cfi_restore_state
	leaq	.LC91(%rip), %rdi
	call	puts@PLT
	jmp	.L399
.L394:
	movl	140(%rbx), %edi
	call	rc_ipstr
	movq	%rax, %rdx
	leaq	.LC80(%rip), %r8
.L397:
	subq	$8, %rsp
	.cfi_def_cfa_offset 72
	pushq	%r12
	.cfi_def_cfa_offset 80
	movq	%rbp, %r9
	leaq	.LC90(%rip), %rcx
	movq	%rbx, %rsi
	leaq	.LC88(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	movq	176(%rbx), %rbx
	addq	$16, %rsp
	.cfi_def_cfa_offset 64
	testq	%rbx, %rbx
	je	.L392
.L395:
	movq	%r13, %r12
	movq	%r13, %rbp
	cmpl	$0, 152(%rbx)
	je	.L393
	movq	%r15, %r12
	movq	%r14, %rbp
.L393:
	cmpl	$0, 148(%rbx)
	jne	.L394
	leaq	.LC81(%rip), %r8
	leaq	.LC82(%rip), %rdx
	jmp	.L397
	.cfi_endproc
.LFE85:
	.size	h_show_ipbrief, .-h_show_ipbrief
	.globl	rc_parse_ip
	.type	rc_parse_ip, @function
rc_parse_ip:
.LFB21:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	movq	%rdi, %rbx
	movq	%rsi, %rbp
	movl	$4, %r14d
	movl	$0, %r13d
	movl	$0, %r12d
.L404:
	call	__ctype_b_loc@PLT
	movq	(%rax), %rdi
	movl	%r12d, %edx
	movl	$0, %ecx
.L408:
	movzbl	(%rbx), %eax
	movzbl	%al, %esi
	testb	$8, 1(%rdi,%rsi,2)
	je	.L414
	leal	(%rdx,%rdx,4), %edx
	movsbl	%al, %eax
	leal	-48(%rax,%rdx,2), %edx
	addq	$1, %rbx
	addl	$1, %ecx
	cmpl	$4, %ecx
	jne	.L408
	movl	$0, %eax
.L403:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
.L414:
	.cfi_restore_state
	testl	%ecx, %ecx
	je	.L410
	cmpl	$255, %edx
	ja	.L410
	sall	$8, %r13d
	orl	%edx, %r13d
	cmpl	$1, %r14d
	je	.L407
	cmpb	$46, %al
	jne	.L411
	addq	$1, %rbx
	subl	$1, %r14d
	jmp	.L404
.L407:
	movl	$0, %eax
	cmpb	$0, (%rbx)
	jne	.L403
	movl	%r13d, 0(%rbp)
	movl	$1, %eax
	jmp	.L403
.L410:
	movl	$0, %eax
	jmp	.L403
.L411:
	movl	$0, %eax
	jmp	.L403
	.cfi_endproc
.LFE21:
	.size	rc_parse_ip, .-rc_parse_ip
	.section	.rodata.str1.8
	.align 8
.LC92:
	.string	"Router-id must be a valid non-zero IPv4 address."
	.text
	.type	h_router_id, @function
h_router_id:
.LFB77:
	.cfi_startproc
	subq	$24, %rsp
	.cfi_def_cfa_offset 32
	movq	%rsi, %rax
	leaq	12(%rsp), %rsi
	movq	(%rax), %rdi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L416
	movl	12(%rsp), %edx
	testl	%edx, %edx
	je	.L416
	cmpl	$0, 720+cfg(%rip)
	je	.L419
	movl	$1, %eax
	cmpl	724+cfg(%rip), %edx
	je	.L415
.L419:
	movl	%edx, 724+cfg(%rip)
	movl	$1, 720+cfg(%rip)
	movl	$0, %eax
	jmp	.L415
.L416:
	leaq	.LC92(%rip), %rsi
	movl	$0, %edi
	movl	$0, %eax
	call	bad_arg
.L415:
	addq	$24, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE77:
	.size	h_router_id, .-h_router_id
	.globl	rc_parse_uint
	.type	rc_parse_uint, @function
rc_parse_uint:
.LFB22:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	movzbl	(%rdi), %ebx
	movl	$0, %eax
	testb	%bl, %bl
	je	.L422
	movq	%rdi, %rbp
	movq	%rsi, %r12
	movq	%rdx, %r13
	movq	%rcx, %r14
	call	__ctype_b_loc@PLT
	movq	(%rax), %rcx
	leaq	10(%rbp), %rsi
	movl	$0, %eax
.L424:
	movzbl	%bl, %edx
	testb	$8, 1(%rcx,%rdx,2)
	je	.L426
	cmpq	%rbp, %rsi
	je	.L427
	leaq	(%rax,%rax,4), %rax
	movsbl	%bl, %ebx
	subl	$48, %ebx
	movslq	%ebx, %rbx
	leaq	(%rbx,%rax,2), %rax
	addq	$1, %rbp
	movzbl	0(%rbp), %ebx
	testb	%bl, %bl
	jne	.L424
	cmpq	%r12, %rax
	jb	.L428
	cmpq	%rax, %r13
	jb	.L428
	movq	%rax, (%r14)
	movl	$1, %eax
	jmp	.L422
.L426:
	movl	$0, %eax
	jmp	.L422
.L427:
	movl	$0, %eax
.L422:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
.L428:
	.cfi_restore_state
	movl	$0, %eax
	jmp	.L422
	.cfi_endproc
.LFE22:
	.size	rc_parse_uint, .-rc_parse_uint
	.section	.rodata.str1.1
.LC93:
	.string	"Serial"
	.section	.rodata.str1.8
	.align 8
.LC94:
	.string	"Clock rate can only be set on Serial interfaces."
	.align 8
.LC95:
	.string	"Clock rate must be 1200-8000000 (e.g. 64000)."
	.text
	.type	h_clock, @function
h_clock:
.LFB66:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	subq	$16, %rsp
	.cfi_def_cfa_offset 48
	movq	%rsi, %rbp
	movq	cur_if(%rip), %r12
	movl	$6, %edx
	leaq	.LC93(%rip), %rsi
	movq	%r12, %rdi
	call	strncmp@PLT
	testl	%eax, %eax
	jne	.L437
	movl	%eax, %ebx
	leaq	8(%rsp), %rcx
	movq	0(%rbp), %rdi
	movl	$8000000, %edx
	movl	$1200, %esi
	call	rc_parse_uint
	testl	%eax, %eax
	je	.L438
	movq	8(%rsp), %rax
	cmpq	%rax, 160(%r12)
	je	.L435
	movq	%rax, 160(%r12)
.L431:
	movl	%ebx, %eax
	addq	$16, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
.L437:
	.cfi_restore_state
	leaq	.LC94(%rip), %rdi
	movl	$0, %eax
	call	err
	movl	%eax, %ebx
	jmp	.L431
.L438:
	leaq	.LC95(%rip), %rsi
	movl	$0, %edi
	call	bad_arg
	movl	%eax, %ebx
	jmp	.L431
.L435:
	movl	$1, %ebx
	jmp	.L431
	.cfi_endproc
.LFE66:
	.size	h_clock, .-h_clock
	.section	.rodata.str1.8
	.align 8
.LC96:
	.string	"OSPF process id must be 1-65535."
	.align 8
.LC97:
	.string	"OSPF process %llu is not configured."
	.text
	.type	h_no_router_ospf, @function
h_no_router_ospf:
.LFB73:
	.cfi_startproc
	subq	$24, %rsp
	.cfi_def_cfa_offset 32
	leaq	8(%rsp), %rcx
	movq	(%rsi), %rdi
	movl	$65535, %edx
	movl	$1, %esi
	call	rc_parse_uint
	testl	%eax, %eax
	je	.L445
	cmpl	$0, 712+cfg(%rip)
	je	.L442
	movl	8(%rsp), %eax
	cmpl	%eax, 716+cfg(%rip)
	je	.L443
.L442:
	movq	8(%rsp), %rsi
	leaq	.LC97(%rip), %rdi
	movl	$0, %eax
	call	err
.L439:
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L445:
	.cfi_restore_state
	leaq	.LC96(%rip), %rsi
	movl	$0, %edi
	call	bad_arg
	jmp	.L439
.L443:
	movq	728+cfg(%rip), %rdi
	call	free@PLT
	movq	$0, 728+cfg(%rip)
	movl	$0, 740+cfg(%rip)
	movl	$0, 736+cfg(%rip)
	movl	$0, 712+cfg(%rip)
	movl	$0, 720+cfg(%rip)
	movl	$0, %eax
	jmp	.L439
	.cfi_endproc
.LFE73:
	.size	h_no_router_ospf, .-h_no_router_ospf
	.section	.rodata.str1.8
	.align 8
.LC98:
	.string	"OSPF process %d already exists (this compiler supports one OSPF process)."
	.section	.rodata.str1.1
.LC99:
	.string	"OSPF %d enabled"
	.text
	.type	h_router_ospf, @function
h_router_ospf:
.LFB72:
	.cfi_startproc
	subq	$24, %rsp
	.cfi_def_cfa_offset 32
	leaq	8(%rsp), %rcx
	movq	(%rsi), %rdi
	movl	$65535, %edx
	movl	$1, %esi
	call	rc_parse_uint
	testl	%eax, %eax
	je	.L452
	cmpl	$0, 712+cfg(%rip)
	je	.L449
	movl	716+cfg(%rip), %esi
	cmpl	8(%rsp), %esi
	je	.L450
	leaq	.LC98(%rip), %rdi
	movl	$0, %eax
	call	err
	jmp	.L446
.L452:
	leaq	.LC96(%rip), %rsi
	movl	$0, %edi
	call	bad_arg
	jmp	.L446
.L449:
	movl	$1, 712+cfg(%rip)
	movq	8(%rsp), %rax
	movl	%eax, 716+cfg(%rip)
.L450:
	movl	$5, mode(%rip)
	movl	8(%rsp), %ecx
	leaq	.LC99(%rip), %rdx
	leaq	.LC1(%rip), %rsi
	movl	$1, %edi
	movl	$0, %eax
	call	rlog_log@PLT
	movl	$0, %eax
.L446:
	addq	$24, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE72:
	.size	h_router_ospf, .-h_router_ospf
	.globl	rc_mask_ok
	.type	rc_mask_ok, @function
rc_mask_ok:
.LFB23:
	.cfi_startproc
	movl	%edi, %eax
	negl	%eax
	notl	%edi
	testl	%eax, %edi
	sete	%al
	movzbl	%al, %eax
	ret
	.cfi_endproc
.LFE23:
	.size	rc_mask_ok, .-rc_mask_ok
	.globl	rc_plen
	.type	rc_plen, @function
rc_plen:
.LFB24:
	.cfi_startproc
	testl	%edi, %edi
	je	.L457
	movl	$0, %eax
	.p2align 4
.L456:
	movl	%edi, %edx
	andl	$1, %edx
	addl	%edx, %eax
	shrl	%edi
	jne	.L456
	ret
.L457:
	movl	$0, %eax
	ret
	.cfi_endproc
.LFE24:
	.size	rc_plen, .-rc_plen
	.section	.rodata.str1.8
	.align 8
.LC100:
	.string	"%s is %s, line protocol is %s\n"
	.section	.rodata.str1.1
.LC101:
	.string	"  Description: %s\n"
.LC102:
	.string	"  Internet address is %s/%d\n"
	.section	.rodata.str1.8
	.align 8
.LC103:
	.string	"  Internet protocol processing disabled"
	.section	.rodata.str1.1
.LC104:
	.string	"  Clock rate %ld\n"
	.text
	.type	print_if_detail, @function
print_if_detail:
.LFB86:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movq	%rdi, %rbx
	leaq	.LC41(%rip), %rcx
	leaq	.LC40(%rip), %rdx
	cmpl	$0, 152(%rdi)
	jne	.L460
	leaq	.LC2(%rip), %rcx
	movq	%rcx, %rdx
.L460:
	movq	%rbx, %rsi
	leaq	.LC100(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	cmpb	$0, 40(%rbx)
	jne	.L467
.L461:
	cmpl	$0, 148(%rbx)
	je	.L462
	movl	144(%rbx), %edi
	call	rc_plen
	movl	%eax, %ebp
	movl	140(%rbx), %edi
	call	rc_ipstr
	movq	%rax, %rsi
	movl	%ebp, %edx
	leaq	.LC102(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
.L463:
	movq	160(%rbx), %rsi
	testq	%rsi, %rsi
	jne	.L468
.L459:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L467:
	.cfi_restore_state
	leaq	40(%rbx), %rsi
	leaq	.LC101(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	jmp	.L461
.L462:
	leaq	.LC103(%rip), %rdi
	call	puts@PLT
	jmp	.L463
.L468:
	leaq	.LC104(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	jmp	.L459
	.cfi_endproc
.LFE86:
	.size	print_if_detail, .-print_if_detail
	.type	lookup, @function
lookup:
.LFB45:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movl	%edi, %r14d
	movq	%rsi, %r12
	movq	640+cfg(%rip), %rbx
	testq	%rbx, %rbx
	je	.L478
	movl	$999, 8(%rsp)
	movl	$-1, %r15d
	movl	$0, 12(%rsp)
	movl	$1, %r13d
	jmp	.L473
.L472:
	movb	$67, (%r12)
	movl	140(%rbx), %edx
	andl	144(%rbx), %edx
	movl	%edx, 4(%r12)
	movl	144(%rbx), %edx
	movl	%edx, 8(%r12)
	movq	%rbx, 16(%r12)
	movl	$0, 24(%r12)
	movl	$0, 28(%r12)
	movl	$0, 12(%r12)
	movl	%ebp, 8(%rsp)
	movl	%eax, %r15d
	movl	%r13d, 12(%rsp)
	.p2align 5
.L471:
	movq	176(%rbx), %rbx
	testq	%rbx, %rbx
	je	.L470
.L473:
	cmpl	$0, 148(%rbx)
	je	.L471
	movl	152(%rbx), %ebp
	testl	%ebp, %ebp
	jne	.L471
	movl	144(%rbx), %edi
	movl	%r14d, %eax
	xorl	140(%rbx), %eax
	testl	%edi, %eax
	jne	.L471
	call	rc_plen
	cmpl	%r15d, %eax
	jg	.L472
	cmpl	$0, 8(%rsp)
	jle	.L471
	cmpl	%r15d, %eax
	jne	.L471
	jmp	.L472
.L478:
	movl	$999, 8(%rsp)
	movl	$-1, %r15d
	movl	$0, 12(%rsp)
.L470:
	cmpl	$0, 672+cfg(%rip)
	jle	.L469
	movl	$0, %ebx
	jmp	.L477
.L476:
	movl	56(%rbp), %ecx
	movl	%ecx, 8(%rsp)
	movb	$83, (%r12)
	movl	0(%rbp), %edx
	movl	%edx, 4(%r12)
	movl	4(%rbp), %edx
	movl	%edx, 8(%r12)
	movl	8(%rbp), %edx
	movl	%edx, 12(%r12)
	movl	52(%rbp), %edx
	movl	%edx, 28(%r12)
	leaq	12(%rbp), %rdx
	movq	%rdx, 16(%r12)
	movl	56(%rbp), %edx
	movl	%edx, 24(%r12)
	movl	%eax, %r15d
	movl	$1, 12(%rsp)
	.p2align 6
.L475:
	addq	$1, %rbx
	cmpl	%ebx, 672+cfg(%rip)
	jle	.L469
.L477:
	movq	%rbx, %rax
	salq	$4, %rax
	subq	%rbx, %rax
	movq	664+cfg(%rip), %rdx
	leaq	(%rdx,%rax,4), %rbp
	movl	4(%rbp), %r13d
	movl	%r13d, %eax
	andl	%r14d, %eax
	cmpl	0(%rbp), %eax
	jne	.L475
	movq	%rbp, %rdi
	call	route_installed
	testl	%eax, %eax
	je	.L475
	movl	%r13d, %edi
	call	rc_plen
	cmpl	%r15d, %eax
	jg	.L476
	jne	.L475
	movl	8(%rsp), %esi
	cmpl	%esi, 56(%rbp)
	jge	.L475
	jmp	.L476
.L469:
	movl	12(%rsp), %eax
	addq	$24, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE45:
	.size	lookup, .-lookup
	.section	.rodata.str1.1
.LC105:
	.string	"Invalid IP address."
	.section	.rodata.str1.8
	.align 8
.LC106:
	.string	"Success rate is %d percent (%d/5)\n"
	.align 8
.LC107:
	.string	"(simulation: result is based on this router's own routing table only)"
	.section	.rodata.str1.1
.LC108:
	.string	"!!!!!"
	.section	.rodata.str1.8
	.align 8
.LC109:
	.string	"Type escape sequence to abort.\nSending 5, 100-byte ICMP Echos to %s, timeout is 2 seconds:\n%s\n"
	.section	.rodata.str1.1
.LC110:
	.string	"UUUUU"
	.text
	.type	h_ping, @function
h_ping:
.LFB91:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$56, %rsp
	.cfi_def_cfa_offset 80
	movq	%rsi, %rax
	leaq	44(%rsp), %rsi
	movq	(%rax), %rdi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L494
	movq	640+cfg(%rip), %rax
	testq	%rax, %rax
	je	.L485
	movl	44(%rsp), %esi
	movl	$0, %edx
	jmp	.L487
.L494:
	leaq	.LC105(%rip), %rsi
	movl	$0, %edi
	call	bad_arg
	jmp	.L482
	.p2align 5
.L486:
	movq	176(%rax), %rax
	testq	%rax, %rax
	je	.L495
.L487:
	cmpl	$0, 148(%rax)
	je	.L486
	cmpl	$0, 152(%rax)
	jne	.L486
	cmpl	%esi, 140(%rax)
	sete	%cl
	movzbl	%cl, %ecx
	orl	%ecx, %edx
	jmp	.L486
.L495:
	testl	%edx, %edx
	je	.L485
.L488:
	movl	44(%rsp), %edi
	call	rc_ipstr
	movq	%rax, %rsi
	leaq	.LC108(%rip), %rdx
	leaq	.LC109(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	movl	$5, %edx
	movl	$100, %ebx
.L490:
	movl	%ebx, %esi
	leaq	.LC106(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	leaq	.LC107(%rip), %rdi
	call	puts@PLT
	movl	$0, %eax
.L482:
	addq	$56, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L485:
	.cfi_restore_state
	movl	44(%rsp), %ebp
	movq	%rsp, %rsi
	movl	%ebp, %edi
	call	lookup
	movl	%eax, %ebx
	testl	%eax, %eax
	jne	.L488
	movl	%ebp, %edi
	call	rc_ipstr
	movq	%rax, %rsi
	leaq	.LC110(%rip), %rdx
	leaq	.LC109(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	movl	%ebx, %edx
	jmp	.L490
	.cfi_endproc
.LFE91:
	.size	h_ping, .-h_ping
	.section	.rodata.str1.1
.LC111:
	.string	"Network not in table."
.LC112:
	.string	"  Directly connected, via %s\n"
.LC113:
	.string	"  Via next hop %s\n"
	.section	.rodata.str1.8
	.align 8
.LC114:
	.string	"Gateway of last resort is %s to network 0.0.0.0\n\n"
	.align 8
.LC115:
	.string	"Gateway of last resort is not set\n"
	.align 8
.LC116:
	.string	"C    %s/%d is directly connected, %s\n"
	.section	.rodata.str1.1
.LC117:
	.string	"S    %s/%d [%d/0] via %s\n"
	.section	.rodata.str1.8
	.align 8
.LC118:
	.string	"S    %s/%d is directly connected, %s\n"
	.align 8
.LC119:
	.string	"(routing table is empty - no up interface with an IP address)"
	.align 8
.LC120:
	.string	"\n(RIP/OSPF are configured but there are no neighbours in this simulator, so they learn no routes.)"
	.section	.rodata.str1.1
.LC121:
	.string	"static"
	.section	.rodata.str1.8
	.align 8
.LC122:
	.string	"Routing entry for %s/%d\n  Known via \"%s\", distance %d\n"
	.section	.rodata.str1.1
.LC123:
	.string	"connected"
	.section	.rodata.str1.8
	.align 8
.LC124:
	.string	"Codes: C - connected, S - static, R - RIP, O - OSPF\n"
	.text
	.type	h_show_route, @function
h_show_route:
.LFB88:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$72, %rsp
	.cfi_def_cfa_offset 128
	testl	%edi, %edi
	jne	.L497
	movl	%edi, %r13d
	movl	672+cfg(%rip), %eax
	testl	%eax, %eax
	jle	.L537
	movq	664+cfg(%rip), %rbx
	cltq
	movq	%rax, %rdx
	salq	$4, %rdx
	subq	%rax, %rdx
	leaq	(%rbx,%rdx,4), %rbp
	jmp	.L508
.L497:
	leaq	28(%rsp), %rax
	movq	(%rsi), %rdi
	movq	%rax, %rsi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L538
	leaq	32(%rsp), %rsi
	movl	28(%rsp), %edi
	call	lookup
	testl	%eax, %eax
	je	.L539
	movl	56(%rsp), %ebp
	cmpb	$67, 32(%rsp)
	je	.L540
	movl	40(%rsp), %edi
	call	rc_plen
	movl	%eax, %ebx
	movl	36(%rsp), %edi
	call	rc_ipstr
	movq	%rax, %rsi
	movl	%ebp, %r8d
	leaq	.LC121(%rip), %rcx
	movl	%ebx, %edx
	leaq	.LC122(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	cmpl	$0, 60(%rsp)
	jne	.L541
.L520:
	movq	48(%rsp), %rsi
	leaq	.LC112(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	movl	$0, %eax
	jmp	.L496
.L538:
	leaq	.LC105(%rip), %rsi
	movl	$0, %edi
	call	bad_arg
	jmp	.L496
.L539:
	leaq	.LC111(%rip), %rdi
	call	err
	jmp	.L496
.L541:
	movl	44(%rsp), %edi
	call	rc_ipstr
	movq	%rax, %rsi
	leaq	.LC113(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	movl	$0, %eax
	jmp	.L496
	.p2align 5
.L506:
	addq	$60, %rbx
	cmpq	%rbx, %rbp
	je	.L542
.L508:
	movq	%rbx, %r12
	cmpl	$0, (%rbx)
	jne	.L506
	cmpl	$0, 4(%rbx)
	jne	.L506
	movq	%rbx, %rdi
	call	route_installed
	testl	%eax, %eax
	je	.L506
	leaq	.LC124(%rip), %rdi
	call	puts@PLT
	leaq	12(%rbx), %rsi
	cmpl	$0, 52(%rbx)
	jne	.L543
.L510:
	leaq	.LC114(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
.L511:
	movq	640+cfg(%rip), %rbx
	testq	%rbx, %rbx
	je	.L512
	movl	%r13d, %r15d
	leaq	.LC116(%rip), %r12
	jmp	.L514
.L543:
	movl	8(%r12), %edi
	call	rc_ipstr
	movq	%rax, %rsi
	jmp	.L510
	.p2align 5
.L513:
	movq	176(%rbx), %rbx
	testq	%rbx, %rbx
	je	.L544
.L514:
	cmpl	$0, 148(%rbx)
	je	.L513
	cmpl	$0, 152(%rbx)
	jne	.L513
	movl	144(%rbx), %ebp
	movl	%ebp, %edi
	call	rc_plen
	movl	%eax, %r14d
	movl	%ebp, %edi
	andl	140(%rbx), %edi
	call	rc_ipstr
	movq	%rax, %rsi
	movq	%rbx, %rcx
	movl	%r14d, %edx
	movq	%r12, %rdi
	movl	$0, %eax
	call	printf@PLT
	movl	$1, %r15d
	jmp	.L513
.L544:
	cmpl	$0, 672+cfg(%rip)
	jle	.L515
.L522:
	movl	%r13d, %r12d
	movl	$0, %ebp
	movl	$1, %r14d
	jmp	.L518
.L517:
	movl	4(%rbx), %edi
	call	rc_plen
	movl	%eax, %r15d
	movl	(%rbx), %edi
	call	rc_ipstr
	movq	%rax, %rsi
	leaq	12(%rbx), %rcx
	movl	%r15d, %edx
	leaq	.LC118(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	movl	%r14d, %r15d
.L516:
	addl	$1, %r12d
	addq	$60, %rbp
	cmpl	%r12d, 672+cfg(%rip)
	jle	.L515
.L518:
	movq	%rbp, %rbx
	addq	664+cfg(%rip), %rbx
	movq	%rbx, %rdi
	call	route_installed
	testl	%eax, %eax
	je	.L516
	cmpl	$0, 52(%rbx)
	je	.L517
	movl	8(%rbx), %edi
	call	rc_ipstr
	movq	%rax, (%rsp)
	movl	56(%rbx), %r15d
	movl	4(%rbx), %edi
	call	rc_plen
	movl	%eax, 12(%rsp)
	movl	(%rbx), %edi
	call	rc_ipstr
	movq	%rax, %rsi
	movq	(%rsp), %r8
	movl	%r15d, %ecx
	movl	12(%rsp), %edx
	leaq	.LC117(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	movl	%r14d, %r15d
	jmp	.L516
.L515:
	testl	%r15d, %r15d
	je	.L523
.L519:
	movl	680+cfg(%rip), %eax
	orl	712+cfg(%rip), %eax
	je	.L496
	leaq	.LC120(%rip), %rdi
	call	puts@PLT
	movl	%r13d, %eax
.L496:
	addq	$72, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L540:
	.cfi_restore_state
	movl	40(%rsp), %edi
	call	rc_plen
	movl	%eax, %ebx
	movl	36(%rsp), %edi
	call	rc_ipstr
	movq	%rax, %rsi
	movl	%ebp, %r8d
	leaq	.LC123(%rip), %rcx
	movl	%ebx, %edx
	leaq	.LC122(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	jmp	.L520
.L512:
	movl	%r13d, %r15d
	cmpl	$0, 672+cfg(%rip)
	jg	.L522
.L523:
	leaq	.LC119(%rip), %rdi
	call	puts@PLT
	jmp	.L519
.L537:
	leaq	.LC124(%rip), %rdi
	call	puts@PLT
	jmp	.L524
.L542:
	leaq	.LC124(%rip), %rdi
	call	puts@PLT
.L524:
	leaq	.LC115(%rip), %rdi
	call	puts@PLT
	jmp	.L511
	.cfi_endproc
.LFE88:
	.size	h_show_route, .-h_show_route
	.section	.rodata.str1.1
.LC125:
	.string	"Loopback"
	.section	.rodata.str1.8
	.align 8
.LC126:
	.string	"Invalid IP address \"%s\" (must be a unicast host address)."
	.align 8
.LC127:
	.string	"Invalid subnet mask \"%s\" (1-bits must be contiguous, e.g. 255.255.255.0)."
	.align 8
.LC128:
	.string	"Bad mask /32 for address %s (allowed only on loopbacks)."
	.align 8
.LC129:
	.string	"Bad mask /%d for address %s (it is the network or broadcast address)."
	.align 8
.LC130:
	.string	"%s/%d overlaps with %s (%s/%d)."
	.section	.rodata.str1.1
.LC131:
	.string	"%s ip = %s/%d"
	.text
	.type	h_ip_address, @function
h_ip_address:
.LFB59:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$40, %rsp
	.cfi_def_cfa_offset 96
	movq	%rsi, %r13
	movq	cur_if(%rip), %rbp
	movl	$8, %edx
	leaq	.LC125(%rip), %rsi
	movq	%rbp, %rdi
	call	strncmp@PLT
	movl	%eax, %ebx
	movq	0(%r13), %r14
	leaq	28(%rsp), %rsi
	movq	%r14, %rdi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L546
	movl	28(%rsp), %r12d
	testl	%r12d, %r12d
	je	.L546
	movl	%r12d, %eax
	shrl	$24, %eax
	cmpl	$127, %eax
	je	.L546
	cmpl	$223, %eax
	ja	.L546
	movq	8(%r13), %r15
	leaq	24(%rsp), %rsi
	movq	%r15, %rdi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L550
	movl	24(%rsp), %r13d
	testl	%r13d, %r13d
	je	.L550
	movl	%r13d, %edi
	call	rc_mask_ok
	testl	%eax, %eax
	je	.L550
	movl	%r12d, %eax
	andl	%r13d, %eax
	movl	%eax, 12(%rsp)
	movl	%r13d, %edi
	call	rc_plen
	movl	%eax, 8(%rsp)
	testl	%ebx, %ebx
	je	.L552
	cmpl	$32, %eax
	je	.L563
.L552:
	cmpl	$30, 8(%rsp)
	jg	.L553
	movl	%r12d, %edx
	notl	%edx
	movl	%r13d, %eax
	notl	%eax
	testl	%eax, %edx
	je	.L560
	movl	12(%rsp), %eax
	cmpl	%eax, %r12d
	je	.L560
.L553:
	movq	640+cfg(%rip), %rbx
	testq	%rbx, %rbx
	jne	.L557
.L555:
	cmpl	$0, 148(%rbp)
	je	.L558
	cmpl	140(%rbp), %r12d
	je	.L564
.L558:
	movl	%r12d, 140(%rbp)
	movl	%r13d, 144(%rbp)
	movl	$1, 148(%rbp)
	movl	%r12d, %edi
	call	rc_ipstr
	movq	%rax, %r8
	movl	8(%rsp), %r9d
	movq	cur_if(%rip), %rcx
	leaq	.LC131(%rip), %rdx
	leaq	.LC1(%rip), %rsi
	movl	$1, %edi
	movl	$0, %eax
	call	rlog_log@PLT
	movl	$0, %eax
	jmp	.L545
.L546:
	movq	%r14, %rdx
	leaq	.LC126(%rip), %rsi
	movl	$0, %edi
	movl	$0, %eax
	call	bad_arg
.L545:
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L550:
	.cfi_restore_state
	movq	%r15, %rdx
	leaq	.LC127(%rip), %rsi
	movl	$1, %edi
	movl	$0, %eax
	call	bad_arg
	jmp	.L545
.L563:
	movq	%r14, %rdx
	leaq	.LC128(%rip), %rsi
	movl	$1, %edi
	movl	$0, %eax
	call	bad_arg
	jmp	.L545
.L560:
	movq	%r14, %rcx
	movl	8(%rsp), %edx
	leaq	.LC129(%rip), %rsi
	movl	$0, %edi
	movl	$0, %eax
	call	bad_arg
	jmp	.L545
	.p2align 5
.L556:
	movq	176(%rbx), %rbx
	testq	%rbx, %rbx
	je	.L555
.L557:
	cmpq	%rbx, %rbp
	je	.L556
	cmpl	$0, 148(%rbx)
	je	.L556
	movl	144(%rbx), %r14d
	movl	140(%rbx), %r15d
	movl	%r12d, %edx
	xorl	%r15d, %edx
	movl	%r13d, %eax
	andl	%r14d, %eax
	testl	%eax, %edx
	jne	.L556
	movl	%r14d, %edi
	call	rc_plen
	movl	%eax, %ebp
	movl	%r14d, %edi
	andl	%r15d, %edi
	call	rc_ipstr
	movq	%rax, %r12
	movl	12(%rsp), %edi
	call	rc_ipstr
	movq	%rax, %rsi
	movl	%ebp, %r9d
	movq	%r12, %r8
	movq	%rbx, %rcx
	movl	8(%rsp), %edx
	leaq	.LC130(%rip), %rdi
	movl	$0, %eax
	call	err
	jmp	.L545
.L564:
	movl	$1, %eax
	cmpl	144(%rbp), %r13d
	jne	.L558
	jmp	.L545
	.cfi_endproc
.LFE59:
	.size	h_ip_address, .-h_ip_address
	.globl	rc_classful
	.type	rc_classful, @function
rc_classful:
.LFB25:
	.cfi_startproc
	movl	%edi, %eax
	shrl	$24, %eax
	leal	-1(%rax), %edx
	cmpl	$125, %edx
	jbe	.L570
	leal	-128(%rax), %edx
	cmpl	$63, %edx
	jbe	.L571
	subl	$192, %eax
	movl	$0, %edx
	cmpl	$31, %eax
	ja	.L565
	movb	$0, %dil
	movl	%edi, (%rsi)
	movl	$1, %edx
	jmp	.L565
.L570:
	andl	$-16777216, %edi
	movl	%edi, (%rsi)
	movl	$1, %edx
.L565:
	movl	%edx, %eax
	ret
.L571:
	movw	$0, %di
	movl	%edi, (%rsi)
	movl	$1, %edx
	jmp	.L565
	.cfi_endproc
.LFE25:
	.size	rc_classful, .-rc_classful
	.section	.rodata.str1.8
	.align 8
.LC132:
	.string	"RIP syntax: network <classful-network>"
	.section	.rodata.str1.1
.LC133:
	.string	"Invalid network address \"%s\"."
	.section	.rodata.str1.8
	.align 8
.LC134:
	.string	"Not a valid class A/B/C network."
	.section	.rodata.str1.1
.LC135:
	.string	"Network not configured."
	.section	.rodata.str1.8
	.align 8
.LC136:
	.string	"Incomplete command. OSPF syntax: network <ip> <wildcard> area <n>"
	.section	.rodata.str1.1
.LC137:
	.string	"Unexpected extra argument."
	.section	.rodata.str1.8
	.align 8
.LC138:
	.string	"Invalid wildcard mask \"%s\" (e.g. 0.0.0.255)."
	.section	.rodata.str1.1
.LC139:
	.string	"area"
.LC140:
	.string	"Expected keyword 'area'."
	.section	.rodata.str1.8
	.align 8
.LC141:
	.string	"Area must be a number 0-4294967295."
	.align 8
.LC142:
	.string	"Network statement not configured."
	.text
	.type	net_stmt, @function
net_stmt:
.LFB79:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	subq	$16, %rsp
	.cfi_def_cfa_offset 64
	movl	%edi, %ebx
	movq	%rsi, %r12
	movl	%edx, %ebp
	cmpl	$4, mode(%rip)
	je	.L623
	cmpl	$3, %edi
	jle	.L624
	cmpl	$4, %edi
	jg	.L625
	movq	(%rsi), %rbx
	movq	%rsp, %rsi
	movq	%rbx, %rdi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L626
	movq	8(%r12), %rbx
	leaq	4(%rsp), %rsi
	movq	%rbx, %rdi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L592
	movl	4(%rsp), %r13d
	movl	%r13d, %r14d
	notl	%r14d
	movl	%r14d, %edi
	call	rc_mask_ok
	testl	%eax, %eax
	jne	.L593
.L592:
	movq	%rbx, %rdx
	leaq	.LC138(%rip), %rsi
	movl	$1, %edi
	movl	$0, %eax
	call	bad_arg
	jmp	.L572
.L623:
	cmpl	$1, %edi
	je	.L574
	leaq	.LC132(%rip), %rsi
	movl	$1, %edi
	movl	$0, %eax
	call	bad_arg
	jmp	.L572
.L574:
	movq	(%rsi), %r12
	leaq	4(%rsp), %rsi
	movq	%r12, %rdi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L627
	leaq	8(%rsp), %rsi
	movl	4(%rsp), %edi
	call	rc_classful
	testl	%eax, %eax
	je	.L577
	movl	704+cfg(%rip), %ecx
	testl	%ecx, %ecx
	jle	.L628
	movl	8(%rsp), %esi
	movq	696+cfg(%rip), %rdx
	movl	$0, %eax
	.p2align 4
.L581:
	cmpl	%esi, (%rdx)
	je	.L580
	addl	$1, %eax
	addq	$4, %rdx
	cmpl	%ecx, %eax
	jne	.L581
	movl	%ecx, %eax
	testl	%ebp, %ebp
	je	.L607
.L606:
	cmpl	%eax, %ecx
	je	.L629
	movq	696+cfg(%rip), %rdi
	movslq	%eax, %rdx
	leaq	4(,%rdx,4), %rsi
	subl	%eax, %ecx
	leal	-1(%rcx), %edx
	movslq	%edx, %rdx
	salq	$2, %rdx
	leaq	(%rdi,%rsi), %rax
	leaq	-4(%rdi,%rsi), %rdi
	movq	%rax, %rsi
	call	memmove@PLT
	subl	$1, 704+cfg(%rip)
	movl	$0, %eax
	jmp	.L572
.L627:
	movq	%r12, %rdx
	leaq	.LC133(%rip), %rsi
	movl	$0, %edi
	call	bad_arg
	jmp	.L572
.L577:
	leaq	.LC134(%rip), %rsi
	movl	$0, %edi
	movl	$0, %eax
	call	bad_arg
	jmp	.L572
.L580:
	testl	%ebp, %ebp
	jne	.L606
	cmpl	%eax, %ecx
	jle	.L607
	movl	%ebx, %eax
	jmp	.L572
.L614:
	movl	$0, %eax
	jmp	.L606
.L629:
	leaq	.LC135(%rip), %rdi
	movl	$0, %eax
	call	err
	jmp	.L572
.L624:
	leaq	.LC136(%rip), %rdi
	movl	$0, %eax
	call	err
	jmp	.L572
.L625:
	leaq	.LC137(%rip), %rsi
	movl	$4, %edi
	movl	$0, %eax
	call	bad_arg
.L572:
	addq	$16, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 48
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
.L626:
	.cfi_restore_state
	movq	%rbx, %rdx
	leaq	.LC133(%rip), %rsi
	movl	$0, %edi
	call	bad_arg
	jmp	.L572
.L593:
	movq	16(%r12), %rdi
	leaq	.LC139(%rip), %rsi
	call	rc_is_prefix_ci
	testl	%eax, %eax
	je	.L630
	leaq	8(%rsp), %rcx
	movq	24(%r12), %rdi
	movl	$4294967295, %edx
	movl	$0, %esi
	call	rc_parse_uint
	testl	%eax, %eax
	je	.L631
	andl	(%rsp), %r14d
	movq	8(%rsp), %rbx
	movl	736+cfg(%rip), %ecx
	testl	%ecx, %ecx
	jle	.L596
	movq	728+cfg(%rip), %rsi
	movq	%rsi, %rax
	movl	$0, %edx
	jmp	.L599
.L630:
	leaq	.LC140(%rip), %rsi
	movl	$2, %edi
	call	bad_arg
	jmp	.L572
.L631:
	leaq	.LC141(%rip), %rsi
	movl	$3, %edi
	call	bad_arg
	jmp	.L572
	.p2align 4
.L597:
	addl	$1, %edx
	addq	$16, %rax
	cmpl	%ecx, %edx
	je	.L632
.L599:
	cmpl	(%rax), %r14d
	jne	.L597
	cmpl	4(%rax), %r13d
	jne	.L597
	testl	%ebp, %ebp
	je	.L601
.L608:
	cmpl	%edx, %ecx
	je	.L609
	movq	728+cfg(%rip), %rsi
	movslq	%edx, %rax
	addq	$1, %rax
	salq	$4, %rax
	subl	%edx, %ecx
	leal	-1(%rcx), %edx
	movslq	%edx, %rdx
	salq	$4, %rdx
	leaq	(%rsi,%rax), %rcx
	leaq	-16(%rsi,%rax), %rdi
	movq	%rcx, %rsi
	call	memmove@PLT
	subl	$1, 736+cfg(%rip)
	movl	$0, %eax
	jmp	.L572
.L609:
	leaq	.LC142(%rip), %rdi
	movl	$0, %eax
	call	err
	jmp	.L572
.L628:
	testl	%ebp, %ebp
	jne	.L614
.L607:
	movl	708+cfg(%rip), %edx
	cmpl	%ecx, %edx
	jg	.L585
	leal	(%rdx,%rdx), %eax
	testl	%edx, %edx
	movl	$8, %edx
	cmove	%edx, %eax
	movl	%eax, 708+cfg(%rip)
	cltq
	leaq	0(,%rax,4), %rsi
	movq	696+cfg(%rip), %rdi
	call	xrealloc
	movq	%rax, 696+cfg(%rip)
.L585:
	movl	704+cfg(%rip), %eax
	leal	1(%rax), %edx
	movl	%edx, 704+cfg(%rip)
	cltq
	movq	696+cfg(%rip), %rdx
	movl	8(%rsp), %ecx
	movl	%ecx, (%rdx,%rax,4)
	movl	$0, %eax
	jmp	.L572
.L596:
	movl	$0, %edx
	testl	%ebp, %ebp
	jne	.L608
.L603:
	movl	740+cfg(%rip), %edx
	cmpl	%ecx, %edx
	jg	.L604
	leal	(%rdx,%rdx), %eax
	testl	%edx, %edx
	movl	$8, %edx
	cmove	%edx, %eax
	movl	%eax, 740+cfg(%rip)
	movslq	%eax, %rsi
	salq	$4, %rsi
	movq	728+cfg(%rip), %rdi
	call	xrealloc
	movq	%rax, 728+cfg(%rip)
.L604:
	movl	736+cfg(%rip), %eax
	leal	1(%rax), %edx
	movl	%edx, 736+cfg(%rip)
	cltq
	salq	$4, %rax
	addq	728+cfg(%rip), %rax
	movl	%r14d, (%rax)
	movl	%r13d, 4(%rax)
	movq	%rbx, 8(%rax)
	movl	$0, %eax
	jmp	.L572
.L632:
	movl	%ecx, %edx
	testl	%ebp, %ebp
	jne	.L609
.L601:
	cmpl	%ecx, %edx
	jge	.L603
	movslq	%edx, %rdx
	salq	$4, %rdx
	addq	%rdx, %rsi
	movl	$1, %eax
	cmpq	8(%rsi), %rbx
	je	.L572
	movq	%rbx, 8(%rsi)
	movl	$0, %eax
	jmp	.L572
	.cfi_endproc
.LFE79:
	.size	net_stmt, .-net_stmt
	.type	h_no_network, @function
h_no_network:
.LFB81:
	.cfi_startproc
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	movl	$1, %edx
	call	net_stmt
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE81:
	.size	h_no_network, .-h_no_network
	.type	h_network, @function
h_network:
.LFB80:
	.cfi_startproc
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	movl	$0, %edx
	call	net_stmt
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE80:
	.size	h_network, .-h_network
	.section	.rodata.str1.1
.LC143:
	.string	"%s%s"
	.text
	.globl	rc_canon_iface
	.type	rc_canon_iface, @function
rc_canon_iface:
.LFB36:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$40, %rsp
	.cfi_def_cfa_offset 96
	movq	%rdi, %rbx
	movq	%rsi, %rbp
	movq	%rdx, %r12
	call	__ctype_b_loc@PLT
	movq	(%rax), %rsi
	movl	$0, %edx
	jmp	.L638
	.p2align 5
.L639:
	addq	$1, %rbx
.L638:
	movzbl	(%rbx), %eax
	movzbl	%al, %ecx
	movzwl	(%rsi,%rcx,2), %ecx
	testb	$4, %ch
	je	.L660
	cmpq	$22, %rdx
	ja	.L639
	movb	%al, (%rsp,%rdx)
	leaq	1(%rdx), %rdx
	jmp	.L639
.L660:
	movb	$0, (%rsp,%rdx)
	testb	%al, %al
	je	.L650
	testq	%rdx, %rdx
	je	.L650
	testb	$8, %ch
	je	.L651
	movq	%rbx, %rax
	movl	$0, %r13d
.L646:
	movzbl	(%rax), %edx
	movzbl	%dl, %ecx
	testb	$8, 1(%rsi,%rcx,2)
	je	.L642
	leaq	6(%rax), %rdi
.L643:
	addq	$1, %rax
	movzbl	(%rax), %edx
	movzbl	%dl, %ecx
	testb	$8, 1(%rsi,%rcx,2)
	je	.L642
	cmpq	%rdi, %rax
	jne	.L643
	movl	$0, %eax
	jmp	.L637
.L642:
	addl	$1, %r13d
	cmpb	$47, %dl
	je	.L661
	cmpl	$3, %r13d
	jg	.L654
	testb	%dl, %dl
	jne	.L654
	movl	$0, %r14d
	leaq	IFTYPES(%rip), %r15
.L648:
	movq	(%r15,%r14,8), %rsi
	movq	%rsp, %rdi
	call	rc_is_prefix_ci
	testl	%eax, %eax
	jne	.L647
	addq	$1, %r14
	cmpq	$4, %r14
	jne	.L648
	jmp	.L637
.L661:
	leaq	1(%rax), %rdx
	movzbl	1(%rax), %eax
	testb	$8, 1(%rsi,%rax,2)
	je	.L653
	movq	%rdx, %rax
	jmp	.L646
.L647:
	movl	%r14d, %edx
	testl	%r14d, %r14d
	js	.L655
	cmpl	$3, %r14d
	jne	.L657
	movl	$0, %eax
	cmpl	$1, %r13d
	jne	.L637
.L657:
	movslq	%edx, %rdx
	leaq	IFTYPES(%rip), %rax
	movq	(%rax,%rdx,8), %rcx
	movq	%rbx, %r8
	leaq	.LC143(%rip), %rdx
	movq	%r12, %rsi
	movq	%rbp, %rdi
	movl	$0, %eax
	call	snprintf@PLT
	movl	$1, %eax
	jmp	.L637
.L650:
	movl	$0, %eax
.L637:
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L651:
	.cfi_restore_state
	movl	$0, %eax
	jmp	.L637
.L653:
	movl	$0, %eax
	jmp	.L637
.L654:
	movl	$0, %eax
	jmp	.L637
.L655:
	movl	$0, %eax
	jmp	.L637
	.cfi_endproc
.LFE36:
	.size	rc_canon_iface, .-rc_canon_iface
	.section	.rodata.str1.8
	.align 8
.LC144:
	.string	"Interface found by hash lookup:"
	.section	.rodata.str1.1
.LC145:
	.string	"Matches for \"%s\":\n"
.LC146:
	.string	"  [%s] %s\n"
.LC147:
	.string	"  %s\n"
	.section	.rodata.str1.8
	.align 8
.LC148:
	.string	"No configuration line contains \"%s\".\n"
	.section	.rodata.str1.1
.LC149:
	.string	"%d match(es).\n"
	.text
	.type	h_search, @function
h_search:
.LFB96:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$232, %rsp
	.cfi_def_cfa_offset 288
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movl	708+C(%rip), %eax
	leaq	.LC22(%rip), %r14
	cmpl	704+C(%rip), %eax
	jge	.L663
	leaq	C(%rip), %rdx
	cltq
	movslq	640(%rdx,%rax,4), %r14
	addq	%rdx, %r14
.L663:
	leaq	32(%rsp), %rsi
	movl	$40, %edx
	movq	%r14, %rdi
	call	rc_canon_iface
	testl	%eax, %eax
	jne	.L687
.L664:
	movq	$0, 208(%rsp)
	movl	$0, 216(%rsp)
	leaq	208(%rsp), %rdi
	call	gen_config
	movq	208(%rsp), %rdx
	movl	216(%rsp), %eax
	testl	%eax, %eax
	jle	.L665
	movq	%rdx, 8(%rsp)
	cltq
	leaq	(%rdx,%rax,8), %rax
	movq	%rax, 24(%rsp)
	movl	$0, 20(%rsp)
	jmp	.L677
.L687:
	leaq	32(%rsp), %rdi
	call	if_find
	testq	%rax, %rax
	je	.L664
	leaq	.LC144(%rip), %rdi
	call	puts@PLT
	leaq	32(%rsp), %rdi
	call	if_find
	movq	%rax, %rdi
	call	print_if_detail
	leaq	.LC22(%rip), %rdi
	call	puts@PLT
	jmp	.L664
.L691:
	leaq	80(%rsp), %rdi
	movq	%r15, %rcx
	leaq	.LC19(%rip), %rdx
	movl	$120, %esi
	movl	$0, %eax
	call	snprintf@PLT
	movq	%r14, %rdi
	call	strlen@PLT
	movq	%rax, %r13
	testq	%rax, %rax
	je	.L682
	cmpb	$0, (%r15)
	jne	.L668
	jmp	.L669
.L670:
	cmpq	%rbx, %r13
	je	.L667
	addq	$1, %r12
	cmpb	$0, (%r12)
	je	.L669
.L672:
	movl	$0, %ebx
.L673:
	movzbl	(%r12,%rbx), %ebp
	testb	%bpl, %bpl
	je	.L670
	call	__ctype_tolower_loc@PLT
	movq	(%rax), %rax
	movzbl	%bpl, %ebp
	movzbl	(%r14,%rbx), %edx
	movl	(%rax,%rdx,4), %ecx
	cmpl	%ecx, (%rax,%rbp,4)
	jne	.L670
	addq	$1, %rbx
	cmpq	%r13, %rbx
	jb	.L673
	jmp	.L670
.L682:
	movq	%r15, %r12
.L667:
	testq	%r12, %r12
	je	.L669
.L680:
	cmpl	$0, 20(%rsp)
	je	.L688
.L674:
	cmpb	$32, (%r15)
	je	.L689
	movq	%r15, %rsi
	leaq	.LC147(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
.L676:
	addl	$1, 20(%rsp)
.L669:
	addq	$8, 8(%rsp)
	movq	8(%rsp), %rax
	cmpq	%rax, 24(%rsp)
	je	.L690
.L677:
	movq	8(%rsp), %rax
	movq	(%rax), %r15
	movzbl	(%r15), %eax
	subl	$32, %eax
	cmpb	$1, %al
	ja	.L691
	movq	%r14, %rdi
	call	strlen@PLT
	movq	%rax, %r13
	testq	%rax, %rax
	je	.L680
.L668:
	movq	%r15, %r12
	jmp	.L672
.L688:
	movq	%r14, %rsi
	leaq	.LC145(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	jmp	.L674
.L689:
	leaq	1(%r15), %rdx
	leaq	80(%rsp), %rsi
	leaq	.LC146(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	jmp	.L676
.L690:
	cmpl	$0, 20(%rsp)
	je	.L665
	movl	20(%rsp), %esi
	leaq	.LC149(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	jmp	.L679
.L665:
	movq	%r14, %rsi
	leaq	.LC148(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
.L679:
	leaq	208(%rsp), %rdi
	call	lines_free
	movl	$0, %eax
	addq	$232, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE96:
	.size	h_search, .-h_search
	.section	.rodata.str1.1
.LC150:
	.string	"Invalid network address."
.LC151:
	.string	"Invalid subnet mask."
.LC152:
	.string	"Invalid next hop / interface."
.LC153:
	.string	"No matching route to delete."
	.text
	.type	h_no_ip_route, @function
h_no_ip_route:
.LFB69:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$104, %rsp
	.cfi_def_cfa_offset 144
	cmpl	$1, %edi
	jle	.L709
	movl	%edi, %ebp
	movq	%rsi, %rbx
	leaq	92(%rsp), %rsi
	movq	(%rbx), %rdi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L710
	leaq	88(%rsp), %rsi
	movq	8(%rbx), %rdi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L696
	movl	88(%rsp), %r12d
	movl	%r12d, %edi
	call	rc_mask_ok
	testl	%eax, %eax
	je	.L696
	cmpl	$2, %ebp
	jg	.L711
	movl	672+cfg(%rip), %ebx
	subl	$1, %ebx
	js	.L703
	movslq	%ebx, %rax
	movq	%rax, %rbp
	salq	$4, %rbp
	subq	%rax, %rbp
	salq	$2, %rbp
	movl	$0, %r13d
	jmp	.L705
.L709:
	leaq	.LC47(%rip), %rdi
	movl	$0, %eax
	call	err
.L692:
	addq	$104, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
.L710:
	.cfi_restore_state
	leaq	.LC150(%rip), %rsi
	movl	$0, %edi
	call	bad_arg
	jmp	.L692
.L696:
	leaq	.LC151(%rip), %rsi
	movl	$1, %edi
	movl	$0, %eax
	call	bad_arg
	jmp	.L692
.L711:
	leaq	24(%rsp), %rsi
	pxor	%xmm0, %xmm0
	movups	%xmm0, 24(%rsp)
	movups	%xmm0, 40(%rsp)
	movups	%xmm0, 56(%rsp)
	movl	$0, 72(%rsp)
	movl	92(%rsp), %eax
	movl	%eax, 16(%rsp)
	movl	%r12d, 20(%rsp)
	movq	16(%rbx), %rbx
	movq	%rbx, %rdi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L699
	movl	$1, 68(%rsp)
.L700:
	leaq	12(%rsp), %rsi
	leaq	16(%rsp), %rdi
	call	route_find
	testl	%eax, %eax
	jne	.L702
	leaq	.LC153(%rip), %rdi
	call	err
	jmp	.L692
.L699:
	leaq	28(%rsp), %rsi
	movl	$40, %edx
	movq	%rbx, %rdi
	call	rc_canon_iface
	testl	%eax, %eax
	jne	.L700
	leaq	.LC152(%rip), %rsi
	movl	$2, %edi
	call	bad_arg
	jmp	.L692
.L702:
	movl	12(%rsp), %edi
	call	route_remove
	movl	$0, %eax
	jmp	.L692
	.p2align 5
.L704:
	subl	$1, %ebx
	subq	$60, %rbp
	cmpl	$-1, %ebx
	je	.L712
.L705:
	movq	%rbp, %rax
	addq	664+cfg(%rip), %rax
	movl	92(%rsp), %ecx
	cmpl	%ecx, (%rax)
	jne	.L704
	cmpl	4(%rax), %r12d
	jne	.L704
	movl	%ebx, %edi
	call	route_remove
	addl	$1, %r13d
	jmp	.L704
.L712:
	movl	$0, %eax
	testl	%r13d, %r13d
	jne	.L692
.L703:
	leaq	.LC153(%rip), %rdi
	movl	$0, %eax
	call	err
	jmp	.L692
	.cfi_endproc
.LFE69:
	.size	h_no_ip_route, .-h_no_ip_route
	.section	.rodata.str1.1
.LC154:
	.string	"Invalid subnet mask \"%s\"."
	.section	.rodata.str1.8
	.align 8
.LC155:
	.string	"Inconsistent address and mask: host bits set (did you mean %s?)."
	.section	.rodata.str1.1
.LC156:
	.string	"Invalid next-hop address."
	.section	.rodata.str1.8
	.align 8
.LC157:
	.string	"Invalid next hop %s (it is this router's own interface address)."
	.align 8
.LC158:
	.string	"Next hop must be an IP address or an exit interface."
	.align 8
.LC159:
	.string	"Exit interface %s does not exist (create it with 'interface' first)."
	.align 8
.LC160:
	.string	"Administrative distance must be 1-255."
	.section	.rodata.str1.1
.LC161:
	.string	"route added %s/%d ad=%d"
	.section	.rodata.str1.8
	.align 8
.LC162:
	.string	"%% Warning: next hop %s is not on a connected, up network - route not installed yet.\n"
	.text
	.type	h_ip_route, @function
h_ip_route:
.LFB68:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$136, %rsp
	.cfi_def_cfa_offset 192
	movq	$1, 48(%rsp)
	pxor	%xmm0, %xmm0
	movaps	%xmm0, 64(%rsp)
	movaps	%xmm0, 80(%rsp)
	movaps	%xmm0, 96(%rsp)
	movups	%xmm0, 108(%rsp)
	cmpl	$2, %edi
	jle	.L739
	movl	%edi, %ebp
	movq	%rsi, %rbx
	movq	(%rsi), %r12
	leaq	60(%rsp), %rsi
	movq	%r12, %rdi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L740
	movq	8(%rbx), %r12
	leaq	56(%rsp), %rsi
	movq	%r12, %rdi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L717
	movl	56(%rsp), %r13d
	movl	%r13d, %edi
	call	rc_mask_ok
	testl	%eax, %eax
	je	.L717
	movl	60(%rsp), %r12d
	movl	%r13d, %edi
	andl	%r12d, %edi
	cmpl	%edi, %r12d
	je	.L719
	call	rc_ipstr
	movq	%rax, %rdx
	leaq	.LC155(%rip), %rsi
	movl	$0, %edi
	movl	$0, %eax
	call	bad_arg
	movl	%eax, %ebx
	jmp	.L713
.L739:
	leaq	.LC47(%rip), %rdi
	movl	$0, %eax
	call	err
	movl	%eax, %ebx
.L713:
	movl	%ebx, %eax
	addq	$136, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L740:
	.cfi_restore_state
	movq	%r12, %rdx
	leaq	.LC133(%rip), %rsi
	movl	$0, %edi
	call	bad_arg
	movl	%eax, %ebx
	jmp	.L713
.L717:
	movq	%r12, %rdx
	leaq	.LC154(%rip), %rsi
	movl	$1, %edi
	movl	$0, %eax
	call	bad_arg
	movl	%eax, %ebx
	jmp	.L713
.L719:
	movq	16(%rbx), %r14
	leaq	72(%rsp), %rsi
	movq	%r14, %rdi
	call	rc_parse_ip
	testl	%eax, %eax
	je	.L720
	movl	72(%rsp), %edx
	testl	%edx, %edx
	je	.L721
	cmpl	$-536870913, %edx
	ja	.L721
	movq	640+cfg(%rip), %rax
	testq	%rax, %rax
	jne	.L725
.L723:
	movl	$1, 116(%rsp)
.L726:
	cmpl	$4, %ebp
	je	.L741
.L730:
	movl	%r12d, 64(%rsp)
	movl	%r13d, 68(%rsp)
	movq	48(%rsp), %r14
	movl	%r14d, 120(%rsp)
	leaq	44(%rsp), %rsi
	leaq	64(%rsp), %rdi
	call	route_find
	movl	%eax, %ebx
	testl	%eax, %eax
	je	.L731
	movslq	44(%rsp), %rdx
	movq	%rdx, %rax
	salq	$4, %rax
	subq	%rdx, %rax
	movq	664+cfg(%rip), %rdx
	leaq	(%rdx,%rax,4), %rax
	movl	$1, %ebx
	cmpl	56(%rax), %r14d
	je	.L713
	movl	%r14d, 56(%rax)
	movl	$0, %ebx
	jmp	.L713
.L721:
	leaq	.LC156(%rip), %rsi
	movl	$2, %edi
	movl	$0, %eax
	call	bad_arg
	movl	%eax, %ebx
	jmp	.L713
	.p2align 5
.L724:
	movq	176(%rax), %rax
	testq	%rax, %rax
	je	.L723
.L725:
	cmpl	$0, 148(%rax)
	je	.L724
	cmpl	140(%rax), %edx
	jne	.L724
	movq	%r14, %rdx
	leaq	.LC157(%rip), %rsi
	movl	$2, %edi
	movl	$0, %eax
	call	bad_arg
	movl	%eax, %ebx
	jmp	.L713
.L720:
	movq	%rsp, %rsi
	movl	$40, %edx
	movq	%r14, %rdi
	call	rc_canon_iface
	testl	%eax, %eax
	je	.L742
	movq	%rsp, %rdi
	call	if_find
	testq	%rax, %rax
	je	.L743
	movq	%rsp, %rcx
	leaq	76(%rsp), %rdi
	leaq	.LC19(%rip), %rdx
	movl	$40, %esi
	movl	$0, %eax
	call	snprintf@PLT
	jmp	.L726
.L742:
	leaq	.LC158(%rip), %rsi
	movl	$2, %edi
	call	bad_arg
	movl	%eax, %ebx
	jmp	.L713
.L743:
	movq	%rsp, %rdx
	leaq	.LC159(%rip), %rsi
	movl	$2, %edi
	call	bad_arg
	movl	%eax, %ebx
	jmp	.L713
.L741:
	leaq	48(%rsp), %rcx
	movq	24(%rbx), %rdi
	movl	$255, %edx
	movl	$1, %esi
	call	rc_parse_uint
	testl	%eax, %eax
	jne	.L730
	leaq	.LC160(%rip), %rsi
	movl	$3, %edi
	call	bad_arg
	movl	%eax, %ebx
	jmp	.L713
.L731:
	movl	44(%rsp), %r15d
	movl	676+cfg(%rip), %edx
	cmpl	%edx, 672+cfg(%rip)
	jl	.L732
	leal	(%rdx,%rdx), %eax
	testl	%edx, %edx
	movl	$8, %edx
	cmove	%edx, %eax
	movl	%eax, 676+cfg(%rip)
	cltq
	movq	%rax, %rsi
	salq	$4, %rsi
	subq	%rax, %rsi
	salq	$2, %rsi
	movq	664+cfg(%rip), %rdi
	call	xrealloc
	movq	%rax, 664+cfg(%rip)
.L732:
	movq	664+cfg(%rip), %rcx
	movslq	%r15d, %rax
	movq	%rax, %rbp
	salq	$4, %rbp
	subq	%rax, %rbp
	salq	$2, %rbp
	movl	672+cfg(%rip), %eax
	subl	%r15d, %eax
	cltq
	movq	%rax, %rdx
	salq	$4, %rdx
	subq	%rax, %rdx
	salq	$2, %rdx
	leaq	(%rcx,%rbp), %rsi
	leaq	60(%rcx,%rbp), %rdi
	call	memmove@PLT
	movq	664+cfg(%rip), %rax
	movdqa	64(%rsp), %xmm1
	movups	%xmm1, (%rax,%rbp)
	movdqa	80(%rsp), %xmm2
	movups	%xmm2, 16(%rax,%rbp)
	movdqa	96(%rsp), %xmm3
	movups	%xmm3, 32(%rax,%rbp)
	movdqu	108(%rsp), %xmm4
	movups	%xmm4, 44(%rax,%rbp)
	addl	$1, 672+cfg(%rip)
	movl	%r13d, %edi
	call	rc_plen
	movl	%eax, %ebp
	movl	%r12d, %edi
	call	rc_ipstr
	movq	%rax, %rcx
	movl	%r14d, %r9d
	movl	%ebp, %r8d
	leaq	.LC161(%rip), %rdx
	leaq	.LC1(%rip), %rsi
	movl	$1, %edi
	movl	$0, %eax
	call	rlog_log@PLT
	movl	loading(%rip), %ebp
	testl	%ebp, %ebp
	jne	.L713
	movl	116(%rsp), %ebx
	testl	%ebx, %ebx
	je	.L713
	movl	72(%rsp), %r12d
	movl	%r12d, %edi
	call	connected_if
	movl	%ebp, %ebx
	testq	%rax, %rax
	jne	.L713
	movl	%r12d, %edi
	call	rc_ipstr
	movq	%rax, %rsi
	leaq	.LC162(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	jmp	.L713
	.cfi_endproc
.LFE68:
	.size	h_ip_route, .-h_ip_route
	.globl	rc_join_iface
	.type	rc_join_iface, @function
rc_join_iface:
.LFB37:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$88, %rsp
	.cfi_def_cfa_offset 112
	movq	%rdx, %rbx
	movq	%rcx, %rbp
	cmpl	$2, %edi
	je	.L748
	movq	(%rsi), %rcx
	movq	%rsp, %rdi
	leaq	.LC19(%rip), %rdx
	movl	$80, %esi
	movl	$0, %eax
	call	snprintf@PLT
.L746:
	movq	%rsp, %rdi
	movq	%rbp, %rdx
	movq	%rbx, %rsi
	call	rc_canon_iface
	addq	$88, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L748:
	.cfi_restore_state
	movq	(%rsi), %rcx
	movq	%rsp, %rdi
	movq	8(%rsi), %r8
	leaq	.LC143(%rip), %rdx
	movl	$80, %esi
	movl	$0, %eax
	call	snprintf@PLT
	jmp	.L746
	.cfi_endproc
.LFE37:
	.size	rc_join_iface, .-rc_join_iface
	.section	.rodata.str1.1
.LC163:
	.string	"Invalid interface name."
	.section	.rodata.str1.8
	.align 8
.LC164:
	.string	"Interface %s is not configured."
	.text
	.type	h_show_if, @function
h_show_if:
.LFB87:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$56, %rsp
	.cfi_def_cfa_offset 80
	movl	%edi, %ebp
	testl	%edi, %edi
	jne	.L760
	movq	640+cfg(%rip), %rbx
	testq	%rbx, %rbx
	je	.L755
.L756:
	movq	%rbx, %rdi
	call	print_if_detail
	movq	176(%rbx), %rbx
	testq	%rbx, %rbx
	jne	.L756
.L755:
	movl	656+cfg(%rip), %ebx
	testl	%ebx, %ebx
	je	.L761
	movl	%ebp, %ebx
.L749:
	movl	%ebx, %eax
	addq	$56, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L760:
	.cfi_restore_state
	movq	%rsp, %rdx
	movl	$40, %ecx
	call	rc_join_iface
	testl	%eax, %eax
	je	.L762
	movq	%rsp, %rdi
	call	if_find
	movq	%rax, %rdi
	testq	%rax, %rax
	je	.L763
	call	print_if_detail
	movl	$0, %ebx
	jmp	.L749
.L762:
	leaq	.LC163(%rip), %rsi
	movl	$0, %edi
	call	bad_arg
	movl	%eax, %ebx
	jmp	.L749
.L763:
	movq	%rsp, %rsi
	leaq	.LC164(%rip), %rdi
	movl	$0, %eax
	call	err
	movl	%eax, %ebx
	jmp	.L749
.L761:
	leaq	.LC91(%rip), %rdi
	call	puts@PLT
	jmp	.L749
	.cfi_endproc
.LFE87:
	.size	h_show_if, .-h_show_if
	.section	.rodata.str1.8
	.align 8
.LC165:
	.string	"Cannot delete physical interface %s (only loopbacks can be removed)."
	.section	.rodata.str1.1
.LC166:
	.string	"Interface %s does not exist."
.LC167:
	.string	"deleted interface %s"
	.text
	.type	h_no_interface, @function
h_no_interface:
.LFB58:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	subq	$48, %rsp
	.cfi_def_cfa_offset 96
	movq	%rsp, %rdx
	movl	$40, %ecx
	call	rc_join_iface
	testl	%eax, %eax
	je	.L789
	movq	%rsp, %rdi
	movl	$8, %edx
	leaq	.LC125(%rip), %rsi
	call	strncmp@PLT
	movl	%eax, %r13d
	testl	%eax, %eax
	jne	.L790
	movq	%rsp, %rdi
	call	if_find
	movq	%rax, %r12
	testq	%rax, %rax
	je	.L791
	movl	672+cfg(%rip), %ebx
	subl	$1, %ebx
	js	.L769
	movslq	%ebx, %rax
	movq	%rax, %rbp
	salq	$4, %rbp
	subq	%rax, %rbp
	salq	$2, %rbp
	movq	%rsp, %r14
	jmp	.L771
.L789:
	leaq	.LC163(%rip), %rsi
	movl	$0, %edi
	call	bad_arg
	movl	%eax, %r13d
	jmp	.L764
.L790:
	movq	%rsp, %rsi
	leaq	.LC165(%rip), %rdi
	movl	$0, %eax
	call	err
	movl	%eax, %r13d
	jmp	.L764
.L791:
	movq	%rsp, %rsi
	leaq	.LC166(%rip), %rdi
	movl	$0, %eax
	call	err
	movl	%eax, %r13d
	jmp	.L764
	.p2align 5
.L770:
	subl	$1, %ebx
	subq	$60, %rbp
	cmpl	$-1, %ebx
	je	.L769
.L771:
	movq	%rbp, %rdi
	addq	664+cfg(%rip), %rdi
	cmpl	$0, 52(%rdi)
	jne	.L770
	addq	$12, %rdi
	movq	%r14, %rsi
	call	strcmp@PLT
	testl	%eax, %eax
	jne	.L770
	movl	%ebx, %edi
	call	route_remove
	jmp	.L770
.L769:
	cmpq	%r12, cur_if(%rip)
	je	.L792
.L772:
	movq	%r12, %rdi
	call	hash_name
	movl	%eax, %eax
	addq	$16, %rax
	leaq	cfg(%rip), %rcx
	leaq	(%rcx,%rax,8), %rdx
	cmpq	$0, (%rcx,%rax,8)
	je	.L774
	.p2align 5
.L773:
	movq	(%rdx), %rax
	cmpq	%rax, %r12
	je	.L793
	leaq	168(%rax), %rdx
	cmpq	$0, 168(%rax)
	jne	.L773
	jmp	.L774
.L792:
	movq	$0, cur_if(%rip)
	jmp	.L772
.L794:
	movq	%rdx, 648+cfg(%rip)
	jmp	.L780
.L795:
	movl	$2, mode(%rip)
	jmp	.L764
.L777:
	testq	%rax, %rax
	je	.L780
	movq	176(%r12), %rax
	movq	%rax, 640+cfg(%rip)
	movl	$0, %edx
	jmp	.L781
.L793:
	movq	168(%r12), %rax
	movq	%rax, (%rdx)
.L774:
	movq	640+cfg(%rip), %rax
	testq	%rax, %rax
	je	.L777
	cmpq	%rax, %r12
	je	.L777
	.p2align 5
.L778:
	movq	%rax, %rdx
	movq	176(%rax), %rax
	testq	%rax, %rax
	je	.L783
	cmpq	%rax, %r12
	jne	.L778
.L783:
	testq	%rax, %rax
	je	.L780
	movq	176(%r12), %rax
	movq	%rax, 176(%rdx)
.L781:
	cmpq	648+cfg(%rip), %r12
	je	.L794
.L780:
	subl	$1, 656+cfg(%rip)
	movq	%r12, %rcx
	leaq	.LC167(%rip), %rdx
	leaq	.LC1(%rip), %rsi
	movl	$0, %edi
	movl	$0, %eax
	call	rlog_log@PLT
	movq	%r12, %rdi
	call	free@PLT
	cmpl	$3, mode(%rip)
	je	.L795
.L764:
	movl	%r13d, %eax
	addq	$48, %rsp
	.cfi_def_cfa_offset 48
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE58:
	.size	h_no_interface, .-h_no_interface
	.section	.rodata.str1.8
	.align 8
.LC168:
	.string	"Invalid interface. Examples: g0/0, fa0/1, s0/0/0, loopback0."
	.section	.rodata.str1.1
.LC169:
	.string	"created interface %s"
	.text
	.type	h_interface, @function
h_interface:
.LFB57:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	subq	$48, %rsp
	.cfi_def_cfa_offset 80
	movq	%rsp, %rdx
	movl	$40, %ecx
	call	rc_join_iface
	testl	%eax, %eax
	je	.L803
	movq	%rsp, %rdi
	call	if_find
	movq	%rax, %rbx
	testq	%rax, %rax
	je	.L804
.L799:
	movq	%rbx, cur_if(%rip)
	movl	$3, mode(%rip)
	movl	$0, %eax
.L796:
	addq	$48, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
.L803:
	.cfi_restore_state
	leaq	.LC168(%rip), %rsi
	movl	$0, %edi
	call	bad_arg
	jmp	.L796
.L804:
	movl	$184, %edi
	call	xmalloc
	movq	%rax, %rbx
	movq	%rsp, %rdi
	call	hash_name
	movl	%eax, %ebp
	movq	$0, (%rbx)
	movq	$0, 176(%rbx)
	leaq	8(%rbx), %rdi
	andq	$-8, %rdi
	movq	%rbx, %rcx
	subq	%rdi, %rcx
	addl	$184, %ecx
	shrl	$3, %ecx
	movl	%ecx, %ecx
	movl	$0, %eax
	rep stosq
	movq	%rsp, %rcx
	leaq	.LC19(%rip), %rdx
	movl	$40, %esi
	movq	%rbx, %rdi
	call	snprintf@PLT
	movl	$8, %edx
	leaq	.LC125(%rip), %rsi
	movq	%rsp, %rdi
	call	strncmp@PLT
	testl	%eax, %eax
	setne	%al
	movzbl	%al, %eax
	movl	%eax, 152(%rbx)
	leaq	cfg(%rip), %rax
	movl	%ebp, %ebp
	addq	$16, %rbp
	movq	(%rax,%rbp,8), %rdx
	movq	%rdx, 168(%rbx)
	movq	%rbx, (%rax,%rbp,8)
	movq	648+cfg(%rip), %rax
	testq	%rax, %rax
	je	.L800
	movq	%rbx, 176(%rax)
.L801:
	movq	%rbx, 648+cfg(%rip)
	addl	$1, 656+cfg(%rip)
	movq	%rsp, %rcx
	leaq	.LC169(%rip), %rdx
	leaq	.LC1(%rip), %rsi
	movl	$0, %edi
	movl	$0, %eax
	call	rlog_log@PLT
	jmp	.L799
.L800:
	movq	%rbx, 640+cfg(%rip)
	jmp	.L801
	.cfi_endproc
.LFE57:
	.size	h_interface, .-h_interface
	.section	.rodata.str1.1
.LC170:
	.string	"reset to default"
	.text
	.globl	rc_reset_config
	.type	rc_reset_config, @function
rc_reset_config:
.LFB42:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movq	640+cfg(%rip), %rbx
	testq	%rbx, %rbx
	je	.L806
.L807:
	movq	%rbx, %rdi
	movq	176(%rbx), %rbx
	call	free@PLT
	testq	%rbx, %rbx
	jne	.L807
.L806:
	leaq	cfg(%rip), %rbx
	movq	664+cfg(%rip), %rdi
	call	free@PLT
	movq	696+cfg(%rip), %rdi
	call	free@PLT
	movq	728+cfg(%rip), %rdi
	call	free@PLT
	movl	$93, %ecx
	movl	$0, %eax
	movq	%rbx, %rdi
	rep stosq
	movl	$1953853266, cfg(%rip)
	movl	$7497076, 3+cfg(%rip)
	movl	$0, mode(%rip)
	movq	$0, cur_if(%rip)
	movl	$0, quit_flag(%rip)
	movl	$0, loading(%rip)
	movl	$0, load_line(%rip)
	leaq	.LC22(%rip), %rax
	movq	%rax, load_name(%rip)
	leaq	.LC170(%rip), %rdx
	leaq	.LC1(%rip), %rsi
	movl	$1, %edi
	movl	$0, %eax
	call	rlog_log@PLT
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE42:
	.size	rc_reset_config, .-rc_reset_config
	.section	.rodata.str1.8
	.align 8
.LC171:
	.string	"--- Validating configuration of %s ---\n"
	.align 8
.LC172:
	.string	"  [warn ] hostname is still the default 'Router'."
	.align 8
.LC173:
	.string	"  [warn ] %s is up but has no IP address.\n"
	.align 8
.LC174:
	.string	"  [warn ] %s has an IP address but is administratively down.\n"
	.align 8
.LC175:
	.string	"  [warn ] %s has a clock rate but is down.\n"
	.align 8
.LC176:
	.string	"  [warn ] static route %s/%d via %s is NOT installed (next hop unreachable).\n"
	.align 8
.LC177:
	.string	"  [warn ] static route %s/%d via %s is NOT installed (interface down).\n"
	.align 8
.LC178:
	.string	"  [warn ] RIP is enabled but has no network statements."
	.align 8
.LC179:
	.string	"  [warn ] RIP network %s matches no interface.\n"
	.align 8
.LC180:
	.string	"  [warn ] OSPF is enabled but has no network statements."
	.align 8
.LC181:
	.string	"  [error] OSPF has no router-id and no up interface with an IP to derive one from."
	.align 8
.LC182:
	.string	"  [warn ] OSPF network %s %s matches no interface.\n"
	.align 8
.LC183:
	.string	"  [error] %s and %s share IP %s.\n"
	.align 8
.LC184:
	.string	"--- Result: %d error(s), %d warning(s) ---\n"
	.text
	.globl	rc_validate
	.type	rc_validate, @function
rc_validate:
.LFB92:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$56, %rsp
	.cfi_def_cfa_offset 112
	movq	%rdi, 24(%rsp)
	leaq	cfg(%rip), %rbx
	movq	%rbx, %rsi
	leaq	.LC171(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	leaq	.LC5(%rip), %rsi
	movq	%rbx, %rdi
	call	strcmp@PLT
	movl	$0, %r13d
	testl	%eax, %eax
	je	.L862
.L811:
	movq	640+cfg(%rip), %rbx
	testq	%rbx, %rbx
	je	.L812
	leaq	.LC175(%rip), %r14
	leaq	.LC174(%rip), %r15
	leaq	.LC125(%rip), %r12
	jmp	.L817
.L862:
	leaq	.LC172(%rip), %rdi
	call	puts@PLT
	movl	$1, %r13d
	jmp	.L811
.L813:
	cmpl	$0, 148(%rbx)
	jne	.L863
	cmpq	$0, 160(%rbx)
	jne	.L846
.L816:
	movq	176(%rbx), %rbx
	testq	%rbx, %rbx
	je	.L812
.L817:
	movq	%rbx, %rbp
	cmpl	$0, 152(%rbx)
	jne	.L813
	movl	$8, %edx
	movq	%r12, %rsi
	movq	%rbx, %rdi
	call	strncmp@PLT
	cmpl	$0, 148(%rbx)
	jne	.L816
	testl	%eax, %eax
	je	.L816
	movq	%rbx, %rsi
	leaq	.LC173(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	addl	$1, %r13d
	cmpl	$0, 152(%rbx)
	je	.L816
	jmp	.L813
.L863:
	movq	%rbp, %rsi
	movq	%r15, %rdi
	movl	$0, %eax
	call	printf@PLT
	addl	$1, %r13d
	cmpq	$0, 160(%rbx)
	je	.L816
	cmpl	$0, 152(%rbx)
	je	.L816
.L846:
	movq	%rbp, %rsi
	movq	%r14, %rdi
	movl	$0, %eax
	call	printf@PLT
	addl	$1, %r13d
	jmp	.L816
.L812:
	cmpl	$0, 672+cfg(%rip)
	jle	.L818
	movl	$0, %r12d
	movl	$0, %ebp
	leaq	.LC177(%rip), %r15
	leaq	.LC176(%rip), %r14
	jmp	.L822
.L820:
	movl	4(%rbx), %edi
	call	rc_plen
	movl	%eax, 8(%rsp)
	movl	(%rbx), %edi
	call	rc_ipstr
	movq	%rax, %rsi
	leaq	12(%rbx), %rcx
	movl	8(%rsp), %edx
	movq	%r15, %rdi
	movl	$0, %eax
	call	printf@PLT
.L821:
	addl	$1, %r13d
.L819:
	addl	$1, %ebp
	addq	$60, %r12
	cmpl	%ebp, 672+cfg(%rip)
	jle	.L818
.L822:
	movq	%r12, %rbx
	addq	664+cfg(%rip), %rbx
	movq	%rbx, %rdi
	call	route_installed
	testl	%eax, %eax
	jne	.L819
	cmpl	$0, 52(%rbx)
	je	.L820
	movl	8(%rbx), %edi
	call	rc_ipstr
	movq	%rax, 8(%rsp)
	movl	4(%rbx), %edi
	call	rc_plen
	movl	%eax, 20(%rsp)
	movl	(%rbx), %edi
	call	rc_ipstr
	movq	%rax, %rsi
	movq	8(%rsp), %rcx
	movl	20(%rsp), %edx
	movq	%r14, %rdi
	movl	$0, %eax
	call	printf@PLT
	jmp	.L821
.L818:
	cmpl	$0, 680+cfg(%rip)
	je	.L823
	cmpl	$0, 704+cfg(%rip)
	je	.L864
.L824:
	movl	$0, %r12d
	leaq	44(%rsp), %r14
	cmpl	$0, 704+cfg(%rip)
	jg	.L829
.L823:
	movl	712+cfg(%rip), %ebp
	testl	%ebp, %ebp
	je	.L830
	cmpl	$0, 736+cfg(%rip)
	je	.L865
.L831:
	movq	640+cfg(%rip), %rax
	testq	%rax, %rax
	je	.L849
	movl	$0, %edx
	jmp	.L834
.L864:
	leaq	.LC178(%rip), %rdi
	call	puts@PLT
	addl	$1, %r13d
	jmp	.L824
	.p2align 5
.L826:
	movq	176(%rbx), %rbx
	testq	%rbx, %rbx
	je	.L866
.L827:
	cmpl	$0, 148(%rbx)
	je	.L826
	movl	140(%rbx), %edi
	movq	%r14, %rsi
	call	rc_classful
	testl	%eax, %eax
	je	.L826
	movq	696+cfg(%rip), %rax
	movl	44(%rsp), %esi
	cmpl	%esi, (%rax,%r15)
	sete	%al
	movzbl	%al, %eax
	orl	%eax, %ebp
	jmp	.L826
.L866:
	testl	%ebp, %ebp
	je	.L825
.L828:
	addq	$1, %r12
	cmpl	%r12d, 704+cfg(%rip)
	jle	.L823
.L829:
	movq	640+cfg(%rip), %rbx
	testq	%rbx, %rbx
	je	.L825
	leaq	0(,%r12,4), %r15
	movl	$0, %ebp
	jmp	.L827
.L825:
	movq	696+cfg(%rip), %rax
	movl	(%rax,%r12,4), %edi
	call	rc_ipstr
	movq	%rax, %rsi
	leaq	.LC179(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	addl	$1, %r13d
	jmp	.L828
.L865:
	leaq	.LC180(%rip), %rdi
	call	puts@PLT
	addl	$1, %r13d
	jmp	.L831
	.p2align 5
.L833:
	movq	176(%rax), %rax
	testq	%rax, %rax
	je	.L832
.L834:
	cmpl	$0, 148(%rax)
	je	.L833
	cmpl	$0, 152(%rax)
	sete	%cl
	movzbl	%cl, %ecx
	orl	%ecx, %edx
	jmp	.L833
.L849:
	movl	$0, %edx
.L832:
	movl	$0, %ebp
	orl	720+cfg(%rip), %edx
	je	.L867
.L835:
	cmpl	$0, 736+cfg(%rip)
	jle	.L830
	movl	$0, %ebx
	leaq	.LC182(%rip), %r14
	jmp	.L840
.L867:
	leaq	.LC181(%rip), %rdi
	call	puts@PLT
	movl	$1, %ebp
	jmp	.L835
	.p2align 5
.L837:
	movq	176(%rax), %rax
	testq	%rax, %rax
	je	.L868
.L838:
	cmpl	$0, 148(%rax)
	je	.L837
	movl	4(%rcx), %edx
	notl	%edx
	andl	140(%rax), %edx
	cmpl	(%rcx), %edx
	sete	%dl
	movzbl	%dl, %edx
	orl	%edx, %esi
	jmp	.L837
.L868:
	testl	%esi, %esi
	je	.L836
.L839:
	addq	$1, %rbx
	cmpl	%ebx, 736+cfg(%rip)
	jle	.L830
.L840:
	movq	640+cfg(%rip), %rax
	testq	%rax, %rax
	je	.L836
	movq	%rbx, %rcx
	salq	$4, %rcx
	addq	728+cfg(%rip), %rcx
	movl	$0, %esi
	jmp	.L838
.L836:
	movq	%rbx, %r12
	salq	$4, %r12
	movq	728+cfg(%rip), %rax
	movl	4(%rax,%r12), %edi
	call	rc_ipstr
	movq	%rax, %r15
	movq	728+cfg(%rip), %rax
	movl	(%rax,%r12), %edi
	call	rc_ipstr
	movq	%rax, %rsi
	movq	%r15, %rdx
	movq	%r14, %rdi
	movl	$0, %eax
	call	printf@PLT
	addl	$1, %r13d
	jmp	.L839
.L830:
	movq	640+cfg(%rip), %r12
	testq	%r12, %r12
	je	.L841
	leaq	.LC183(%rip), %r14
	jmp	.L844
	.p2align 5
.L842:
	movq	176(%rbx), %rbx
	testq	%rbx, %rbx
	je	.L869
.L843:
	cmpl	$0, 148(%r12)
	je	.L842
	cmpl	$0, 148(%rbx)
	je	.L842
	movl	140(%r12), %edi
	cmpl	140(%rbx), %edi
	jne	.L842
	call	rc_ipstr
	movq	%rax, %rcx
	movq	%rbx, %rdx
	movq	%r12, %rsi
	movq	%r14, %rdi
	movl	$0, %eax
	call	printf@PLT
	addl	$1, %ebp
	jmp	.L842
.L869:
	movq	176(%r12), %r12
	testq	%r12, %r12
	je	.L841
.L844:
	movq	176(%r12), %rbx
	testq	%rbx, %rbx
	jne	.L843
.L841:
	movl	%r13d, %edx
	movl	%ebp, %esi
	leaq	.LC184(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	movq	24(%rsp), %rax
	testq	%rax, %rax
	je	.L810
	movl	%r13d, (%rax)
.L810:
	movl	%ebp, %eax
	addq	$56, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE92:
	.size	rc_validate, .-rc_validate
	.section	.rodata.str1.1
.LC185:
	.string	"ON"
.LC186:
	.string	"OFF"
	.section	.rodata.str1.8
	.align 8
.LC187:
	.string	"Compilation aborted: %d configuration error(s)."
	.section	.rodata.str1.1
.LC188:
	.string	"%s.rcx"
.LC189:
	.string	"w"
.LC190:
	.string	"Cannot write %s"
	.section	.rodata.str1.8
	.align 8
.LC191:
	.string	"\n--- Generated executable instructions ---"
	.align 8
.LC192:
	.string	"; RCC executable configuration for %s\n"
	.section	.rodata.str1.1
.LC193:
	.string	"SET_HOST"
.LC194:
	.string	"SET_SECRET"
.LC195:
	.string	"IF_SELECT"
.LC196:
	.string	"\"%s\""
.LC197:
	.string	"IF_DESC"
.LC198:
	.string	"%s %s"
.LC199:
	.string	"IF_IPV4"
.LC200:
	.string	"%ld"
.LC201:
	.string	"IF_CLOCK"
.LC202:
	.string	"-"
.LC203:
	.string	"IF_ADMIN_DN"
.LC204:
	.string	"IF_ADMIN_UP"
.LC205:
	.string	"%s %s VIA %s AD %d"
.LC206:
	.string	"ROUTE_ADD"
.LC207:
	.string	"%s %s OUT %s AD %d"
.LC208:
	.string	"v%d"
.LC209:
	.string	"RIP_ENABLE"
.LC210:
	.string	"RIP_NET"
.LC211:
	.string	"RIP_AUTOSUM"
.LC212:
	.string	"%d"
.LC213:
	.string	"OSPF_ENABLE"
.LC214:
	.string	"OSPF_RID"
.LC215:
	.string	"%s %s AREA %llu"
.LC216:
	.string	"OSPF_NET"
.LC217:
	.string	"checksum=0x%08lX"
.LC218:
	.string	"COMMIT"
	.section	.rodata.str1.8
	.align 8
.LC219:
	.string	"compiled %d instructions -> %s"
	.section	.rodata.str1.1
.LC220:
	.string	"codegen"
	.section	.rodata.str1.8
	.align 8
.LC221:
	.string	"\nCompiled %d instruction(s) -> %s\n"
	.align 8
.LC222:
	.string	"Optimisation report: %d config command(s) accepted, %d duplicate/no-op command(s) skipped,\n  %d default-state interface(s) pruned, routes emitted in sorted order, final state only (no history).\n"
	.section	.rodata.str1.1
.LC223:
	.string	"Compiled with %d warning(s).\n"
	.text
	.type	h_compile, @function
h_compile:
.LFB95:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$248, %rsp
	.cfi_def_cfa_offset 304
	movl	%edi, %ebx
	movq	%rsi, %rbp
	leaq	44(%rsp), %rdi
	call	rc_validate
	movl	%eax, 24(%rsp)
	testl	%eax, %eax
	jne	.L906
	testl	%ebx, %ebx
	je	.L873
	movq	0(%rbp), %rcx
	leaq	80(%rsp), %rdi
	leaq	.LC19(%rip), %rdx
	movl	$160, %esi
	movl	$0, %eax
	call	snprintf@PLT
.L874:
	pxor	%xmm0, %xmm0
	movaps	%xmm0, 48(%rsp)
	movq	$0, 64(%rsp)
	leaq	80(%rsp), %rdi
	leaq	.LC189(%rip), %rsi
	call	fopen@PLT
	movq	%rax, %rbx
	testq	%rax, %rax
	je	.L907
	leaq	.LC191(%rip), %rdi
	call	puts@PLT
	leaq	cfg(%rip), %rbp
	movq	%rbp, %rdx
	leaq	.LC192(%rip), %rsi
	movq	%rbx, %rdi
	movl	$0, %eax
	call	fprintf@PLT
	movq	%rbx, 56(%rsp)
	leaq	48(%rsp), %rdi
	movq	%rbp, %r8
	leaq	.LC19(%rip), %rcx
	leaq	.LC193(%rip), %rdx
	movl	$1, %esi
	movl	$0, %eax
	call	emit
	cmpb	$0, 64+cfg(%rip)
	jne	.L876
	movq	56(%rsp), %rbp
.L877:
	movq	640+cfg(%rip), %rbx
	testq	%rbx, %rbx
	je	.L899
	movl	24(%rsp), %eax
	movl	%eax, 28(%rsp)
	leaq	.LC19(%rip), %r14
	leaq	.LC195(%rip), %r13
	leaq	.LC202(%rip), %r12
	leaq	.LC204(%rip), %r15
	jmp	.L886
.L906:
	movl	%eax, %esi
	leaq	.LC187(%rip), %rdi
	movl	$0, %eax
	call	err
	jmp	.L870
.L873:
	leaq	80(%rsp), %rdi
	leaq	cfg(%rip), %rcx
	leaq	.LC188(%rip), %rdx
	movl	$160, %esi
	movl	$0, %eax
	call	snprintf@PLT
	jmp	.L874
.L907:
	leaq	80(%rsp), %rsi
	leaq	.LC190(%rip), %rdi
	movl	$0, %eax
	call	err
	jmp	.L870
.L876:
	leaq	48(%rsp), %rdi
	leaq	64+cfg(%rip), %r8
	leaq	.LC19(%rip), %rcx
	leaq	.LC194(%rip), %rdx
	movl	$2, %esi
	movl	$0, %eax
	call	emit
	movq	56(%rsp), %rbp
	jmp	.L877
.L879:
	movq	%rbp, 56(%rsp)
	leaq	48(%rsp), %rdi
	movq	%rbx, %r8
	movq	%r14, %rcx
	movq	%r13, %rdx
	movl	$16, %esi
	movl	$0, %eax
	call	emit
	cmpb	$0, 40(%rbx)
	jne	.L881
	movq	56(%rsp), %rbp
.L882:
	cmpl	$0, 148(%rbx)
	jne	.L908
.L883:
	movq	160(%rbx), %r8
	testq	%r8, %r8
	jne	.L909
.L884:
	cmpl	$0, 152(%rbx)
	je	.L885
	movq	%rbp, 56(%rsp)
	leaq	48(%rsp), %rdi
	movq	%r12, %rcx
	leaq	.LC203(%rip), %rdx
	movl	$21, %esi
	movl	$0, %eax
	call	emit
	movq	56(%rsp), %rbp
.L880:
	movq	176(%rbx), %rbx
	testq	%rbx, %rbx
	je	.L878
.L886:
	cmpl	$0, 152(%rbx)
	je	.L879
	cmpl	$0, 148(%rbx)
	jne	.L879
	cmpb	$0, 40(%rbx)
	jne	.L879
	cmpq	$0, 160(%rbx)
	jne	.L879
	addl	$1, 28(%rsp)
	jmp	.L880
.L881:
	leaq	48(%rsp), %rdi
	leaq	40(%rbx), %r8
	leaq	.LC196(%rip), %rcx
	leaq	.LC197(%rip), %rdx
	movl	$17, %esi
	movl	$0, %eax
	call	emit
	movq	56(%rsp), %rbp
	jmp	.L882
.L908:
	movl	144(%rbx), %edi
	call	rc_ipstr
	movq	%rax, 8(%rsp)
	movl	140(%rbx), %edi
	call	rc_ipstr
	movq	%rax, %r8
	movq	%rbp, 56(%rsp)
	leaq	48(%rsp), %rdi
	movq	8(%rsp), %r9
	leaq	.LC198(%rip), %rcx
	leaq	.LC199(%rip), %rdx
	movl	$18, %esi
	movl	$0, %eax
	call	emit
	movq	56(%rsp), %rbp
	jmp	.L883
.L909:
	movq	%rbp, 56(%rsp)
	leaq	48(%rsp), %rdi
	leaq	.LC200(%rip), %rcx
	leaq	.LC201(%rip), %rdx
	movl	$19, %esi
	movl	$0, %eax
	call	emit
	movq	56(%rsp), %rbp
	jmp	.L884
.L885:
	movq	%rbp, 56(%rsp)
	leaq	48(%rsp), %rdi
	movq	%r12, %rcx
	movq	%r15, %rdx
	movl	$20, %esi
	movl	$0, %eax
	call	emit
	movq	56(%rsp), %rbp
	jmp	.L880
.L899:
	movl	24(%rsp), %eax
	movl	%eax, 28(%rsp)
.L878:
	cmpl	$0, 672+cfg(%rip)
	jle	.L887
	movl	24(%rsp), %r13d
	movl	$0, %r12d
	leaq	48(%rsp), %r14
	jmp	.L890
.L888:
	movl	56(%rbx), %r15d
	movl	4(%rbx), %edi
	call	rc_ipstr
	movq	%rax, 8(%rsp)
	movl	(%rbx), %edi
	call	rc_ipstr
	movq	%rax, %r8
	movq	%rbp, 56(%rsp)
	pushq	%r15
	.cfi_def_cfa_offset 312
	addq	$12, %rbx
	pushq	%rbx
	.cfi_def_cfa_offset 320
	movq	24(%rsp), %r9
	leaq	.LC207(%rip), %rcx
	leaq	.LC206(%rip), %rdx
	movl	$32, %esi
	movq	%r14, %rdi
	movl	$0, %eax
	call	emit
	movq	72(%rsp), %rbp
	addq	$16, %rsp
	.cfi_def_cfa_offset 304
.L889:
	addl	$1, %r13d
	addq	$60, %r12
	cmpl	%r13d, 672+cfg(%rip)
	jle	.L887
.L890:
	movq	%r12, %rbx
	addq	664+cfg(%rip), %rbx
	cmpl	$0, 52(%rbx)
	je	.L888
	movl	56(%rbx), %r15d
	movl	8(%rbx), %edi
	call	rc_ipstr
	movq	%rax, 8(%rsp)
	movl	4(%rbx), %edi
	call	rc_ipstr
	movq	%rax, 16(%rsp)
	movl	(%rbx), %edi
	call	rc_ipstr
	movq	%rax, %r8
	movq	%rbp, 56(%rsp)
	pushq	%r15
	.cfi_def_cfa_offset 312
	pushq	16(%rsp)
	.cfi_def_cfa_offset 320
	movq	32(%rsp), %r9
	leaq	.LC205(%rip), %rcx
	leaq	.LC206(%rip), %rdx
	movl	$32, %esi
	movq	%r14, %rdi
	movl	$0, %eax
	call	emit
	movq	72(%rsp), %rbp
	addq	$16, %rsp
	.cfi_def_cfa_offset 304
	jmp	.L889
.L887:
	cmpl	$0, 680+cfg(%rip)
	jne	.L910
.L891:
	cmpl	$0, 712+cfg(%rip)
	jne	.L911
.L895:
	movq	%rbp, 56(%rsp)
	leaq	48(%rsp), %rdi
	movl	64(%rsp), %r8d
	leaq	.LC217(%rip), %rcx
	leaq	.LC218(%rip), %rdx
	movl	$255, %esi
	movl	$0, %eax
	call	emit
	movq	56(%rsp), %rdi
	call	fclose@PLT
	movl	48(%rsp), %ebx
	leaq	80(%rsp), %rbp
	movq	%rbp, %r8
	movl	%ebx, %ecx
	leaq	.LC219(%rip), %rdx
	leaq	.LC220(%rip), %rsi
	movl	$1, %edi
	movl	$0, %eax
	call	rlog_log@PLT
	movq	%rbp, %rdx
	movl	%ebx, %esi
	leaq	.LC221(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	movl	28(%rsp), %ecx
	movl	8+st(%rip), %edx
	movl	4+st(%rip), %esi
	leaq	.LC222(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	movl	44(%rsp), %eax
	testl	%eax, %eax
	jne	.L912
.L870:
	addq	$248, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L910:
	.cfi_restore_state
	movq	%rbp, 56(%rsp)
	leaq	48(%rsp), %rdi
	movl	684+cfg(%rip), %r8d
	leaq	.LC208(%rip), %rcx
	leaq	.LC209(%rip), %rdx
	movl	$48, %esi
	movl	$0, %eax
	call	emit
	movq	56(%rsp), %rbp
	cmpl	$0, 704+cfg(%rip)
	jle	.L892
	movl	$0, %ebx
	leaq	cfg(%rip), %r12
	leaq	48(%rsp), %r14
	leaq	.LC19(%rip), %r13
	leaq	.LC210(%rip), %r15
.L893:
	movq	696(%r12), %rax
	movl	(%rax,%rbx,4), %edi
	call	rc_ipstr
	movq	%rax, %r8
	movq	%rbp, 56(%rsp)
	movq	%r13, %rcx
	movq	%r15, %rdx
	movl	$49, %esi
	movq	%r14, %rdi
	movl	$0, %eax
	call	emit
	movq	56(%rsp), %rbp
	addq	$1, %rbx
	cmpl	%ebx, 704(%r12)
	jg	.L893
.L892:
	leaq	.LC186(%rip), %r8
	cmpl	$0, 688+cfg(%rip)
	leaq	.LC185(%rip), %rax
	cmovne	%rax, %r8
	movq	%rbp, 56(%rsp)
	leaq	48(%rsp), %rdi
	leaq	.LC19(%rip), %rcx
	leaq	.LC211(%rip), %rdx
	movl	$50, %esi
	movl	$0, %eax
	call	emit
	movq	56(%rsp), %rbp
	jmp	.L891
.L911:
	movq	%rbp, 56(%rsp)
	leaq	48(%rsp), %rdi
	movl	716+cfg(%rip), %r8d
	leaq	.LC212(%rip), %rcx
	leaq	.LC213(%rip), %rdx
	movl	$64, %esi
	movl	$0, %eax
	call	emit
	cmpl	$0, 720+cfg(%rip)
	jne	.L896
	movq	56(%rsp), %rbp
.L897:
	cmpl	$0, 736+cfg(%rip)
	jle	.L895
	movl	$0, %ebx
	leaq	cfg(%rip), %r12
	leaq	48(%rsp), %rax
	movq	%rax, 8(%rsp)
.L898:
	movq	%rbx, %r13
	salq	$4, %r13
	movq	%r13, %rax
	addq	728(%r12), %rax
	movq	8(%rax), %r14
	movl	4(%rax), %edi
	call	rc_ipstr
	movq	%rax, %r15
	movq	728(%r12), %rax
	movl	(%rax,%r13), %edi
	call	rc_ipstr
	movq	%rax, %r8
	movq	%rbp, 56(%rsp)
	subq	$8, %rsp
	.cfi_def_cfa_offset 312
	pushq	%r14
	.cfi_def_cfa_offset 320
	movq	%r15, %r9
	leaq	.LC215(%rip), %rcx
	leaq	.LC216(%rip), %rdx
	movl	$66, %esi
	movq	24(%rsp), %rdi
	movl	$0, %eax
	call	emit
	movq	72(%rsp), %rbp
	addq	$1, %rbx
	addq	$16, %rsp
	.cfi_def_cfa_offset 304
	cmpl	%ebx, 736(%r12)
	jg	.L898
	jmp	.L895
.L896:
	movl	724+cfg(%rip), %edi
	call	rc_ipstr
	movq	%rax, %r8
	leaq	48(%rsp), %rdi
	leaq	.LC19(%rip), %rcx
	leaq	.LC214(%rip), %rdx
	movl	$65, %esi
	movl	$0, %eax
	call	emit
	movq	56(%rsp), %rbp
	jmp	.L897
.L912:
	movl	%eax, %esi
	leaq	.LC223(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	movl	24(%rsp), %eax
	jmp	.L870
	.cfi_endproc
.LFE95:
	.size	h_compile, .-h_compile
	.type	h_validate, @function
h_validate:
.LFB93:
	.cfi_startproc
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	movl	$0, %edi
	call	rc_validate
	movl	$0, %eax
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE93:
	.size	h_validate, .-h_validate
	.section	.rodata.str1.1
.LC224:
	.string	"Cannot open %s for writing."
	.text
	.globl	rc_save_file
	.type	rc_save_file, @function
rc_save_file:
.LFB97:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$24, %rsp
	.cfi_def_cfa_offset 64
	movq	%rdi, %rbx
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	leaq	.LC189(%rip), %rsi
	call	fopen@PLT
	testq	%rax, %rax
	je	.L922
	movq	%rax, %rbp
	movq	$0, (%rsp)
	movl	$0, 8(%rsp)
	movq	%rsp, %rdi
	call	gen_config
	movq	(%rsp), %rdx
	movl	8(%rsp), %eax
	testl	%eax, %eax
	jle	.L918
	movq	%rdx, %rbx
	cltq
	leaq	(%rdx,%rax,8), %r13
	leaq	.LC13(%rip), %r12
.L919:
	movq	(%rbx), %rdx
	movq	%r12, %rsi
	movq	%rbp, %rdi
	movl	$0, %eax
	call	fprintf@PLT
	addq	$8, %rbx
	cmpq	%r13, %rbx
	jne	.L919
.L918:
	movq	%rsp, %rdi
	call	lines_free
	movq	%rbp, %rdi
	call	fclose@PLT
	movl	$0, %eax
.L915:
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
.L922:
	.cfi_restore_state
	movq	%rbx, %rsi
	leaq	.LC224(%rip), %rdi
	movl	$0, %eax
	call	err
	jmp	.L915
	.cfi_endproc
.LFE97:
	.size	rc_save_file, .-rc_save_file
	.section	.rodata.str1.8
	.align 8
.LC225:
	.string	"[OK] configuration saved to %s\n"
	.text
	.type	h_save, @function
h_save:
.LFB102:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movq	%rsi, %rbp
	movq	(%rsi), %rdi
	call	rc_save_file
	testl	%eax, %eax
	jne	.L925
	movl	%eax, %ebx
	movq	0(%rbp), %rsi
	leaq	.LC225(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
.L923:
	movl	%ebx, %eax
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L925:
	.cfi_restore_state
	movl	$-1, %ebx
	jmp	.L923
	.cfi_endproc
.LFE102:
	.size	h_save, .-h_save
	.section	.rodata.str1.1
.LC226:
	.string	"memory"
.LC227:
	.string	"Did you mean 'write memory'?"
.LC228:
	.string	"Building configuration..."
	.section	.rodata.str1.8
	.align 8
.LC229:
	.string	"[OK] saved to startup-config.cfg"
	.text
	.type	h_write, @function
h_write:
.LFB99:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	testl	%edi, %edi
	je	.L928
	movq	(%rsi), %rdi
	leaq	.LC226(%rip), %rsi
	call	rc_is_prefix_ci
	testl	%eax, %eax
	je	.L932
.L928:
	leaq	.LC228(%rip), %rdi
	call	puts@PLT
	leaq	.LC35(%rip), %rdi
	call	rc_save_file
	movl	%eax, %ebx
	testl	%eax, %eax
	jne	.L930
	leaq	.LC229(%rip), %rdi
	call	puts@PLT
.L927:
	movl	%ebx, %eax
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L932:
	.cfi_restore_state
	leaq	.LC227(%rip), %rsi
	movl	$0, %edi
	call	bad_arg
	movl	%eax, %ebx
	jmp	.L927
.L930:
	movl	$-1, %ebx
	jmp	.L927
	.cfi_endproc
.LFE99:
	.size	h_write, .-h_write
	.type	h_copy, @function
h_copy:
.LFB100:
	.cfi_startproc
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	movslq	%edi, %rdi
	leaq	(%rsi,%rdi,8), %rsi
	movl	$0, %edi
	call	h_write
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE100:
	.size	h_copy, .-h_copy
	.section	.rodata.str1.1
.LC230:
	.string	"Cannot open file \"%s\"."
	.section	.rodata.str1.8
	.align 8
.LC231:
	.string	"loaded %d line(s) from %s (%d error(s))"
	.section	.rodata.str1.1
.LC232:
	.string	"loader"
	.section	.rodata.str1.8
	.align 8
.LC233:
	.string	"Loaded %d line(s) from %s (%d error(s)).\n"
	.text
	.globl	rc_load_file
	.type	rc_load_file, @function
rc_load_file:
.LFB98:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$264, %rsp
	.cfi_def_cfa_offset 320
	movq	%rdi, %rbx
	leaq	.LC38(%rip), %rsi
	call	fopen@PLT
	movl	mode(%rip), %r15d
	movl	nerr(%rip), %r14d
	testq	%rax, %rax
	je	.L941
	movq	%rax, %r12
	movq	%rbx, %rdi
	call	xstrdup
	movq	%rax, %r13
	call	rc_reset_config
	movl	$2, mode(%rip)
	movl	$1, loading(%rip)
	movq	%r13, load_name(%rip)
	movl	$0, %ebx
	movq	%rsp, %rbp
	jmp	.L938
.L941:
	movq	%rbx, %rsi
	leaq	.LC230(%rip), %rdi
	movl	$0, %eax
	call	err
	jmp	.L935
.L939:
	addl	$1, %ebx
	movl	%ebx, load_line(%rip)
	movq	%rbp, %rdi
	call	execute_line_impl
.L938:
	movq	%r12, %rdx
	movl	$256, %esi
	movq	%rbp, %rdi
	call	fgets@PLT
	testq	%rax, %rax
	jne	.L939
	movl	$0, loading(%rip)
	leaq	.LC22(%rip), %rax
	movq	%rax, load_name(%rip)
	movl	%r15d, mode(%rip)
	movq	$0, cur_if(%rip)
	movq	%r12, %rdi
	call	fclose@PLT
	movl	nerr(%rip), %r9d
	subl	%r14d, %r9d
	movq	%r13, %r8
	movl	%ebx, %ecx
	leaq	.LC231(%rip), %rdx
	leaq	.LC232(%rip), %rsi
	movl	$1, %edi
	movl	$0, %eax
	call	rlog_log@PLT
	movl	nerr(%rip), %ecx
	subl	%r14d, %ecx
	movq	%r13, %rdx
	movl	%ebx, %esi
	leaq	.LC233(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	movq	%r13, %rdi
	call	free@PLT
	cmpl	%r14d, nerr(%rip)
	setne	%al
	movzbl	%al, %eax
	negl	%eax
.L935:
	addq	$264, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE98:
	.size	rc_load_file, .-rc_load_file
	.section	.rodata.str1.8
	.align 8
.LC234:
	.string	"Proceed with reload? [confirm]"
	.section	.rodata.str1.1
.LC235:
	.string	"Restarting system..."
.LC236:
	.string	"reload requested"
	.text
	.type	h_reload, @function
h_reload:
.LFB104:
	.cfi_startproc
	subq	$24, %rsp
	.cfi_def_cfa_offset 32
	leaq	.LC234(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	movq	stdout(%rip), %rdi
	call	fflush@PLT
	movq	%rsp, %rdi
	movq	stdin(%rip), %rdx
	movl	$16, %esi
	call	fgets@PLT
	testq	%rax, %rax
	je	.L945
	movzbl	(%rsp), %eax
	andl	$-33, %eax
	movl	$0, %edx
	cmpb	$78, %al
	jne	.L948
.L942:
	movl	%edx, %eax
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L948:
	.cfi_restore_state
	call	rc_reset_config
	movl	$0, mode(%rip)
	leaq	.LC235(%rip), %rdi
	call	puts@PLT
	leaq	.LC38(%rip), %rsi
	leaq	.LC35(%rip), %rdi
	call	fopen@PLT
	movq	%rax, %rdi
	testq	%rax, %rax
	je	.L944
	call	fclose@PLT
	leaq	.LC35(%rip), %rdi
	call	rc_load_file
	movl	$0, mode(%rip)
.L944:
	leaq	.LC236(%rip), %rdx
	leaq	.LC11(%rip), %rsi
	movl	$1, %edi
	movl	$0, %eax
	call	rlog_log@PLT
	movl	$0, %edx
	jmp	.L942
.L945:
	movl	$-1, %edx
	jmp	.L942
	.cfi_endproc
.LFE104:
	.size	h_reload, .-h_reload
	.type	h_load, @function
h_load:
.LFB103:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	subq	$208, %rsp
	.cfi_def_cfa_offset 224
	movq	(%rsi), %rcx
	leaq	.LC19(%rip), %rdx
	movl	$200, %esi
	movq	%rsp, %rdi
	movl	$0, %eax
	call	snprintf@PLT
	movq	%rsp, %rdi
	call	rc_load_file
	addq	$208, %rsp
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE103:
	.size	h_load, .-h_load
	.globl	rc_execute_line
	.type	rc_execute_line, @function
rc_execute_line:
.LFB113:
	.cfi_startproc
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	call	execute_line_impl
	movl	nerr(%rip), %eax
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE113:
	.size	rc_execute_line, .-rc_execute_line
	.globl	rc_set_quit_flag
	.type	rc_set_quit_flag, @function
rc_set_quit_flag:
.LFB114:
	.cfi_startproc
	movl	%edi, quit_flag(%rip)
	ret
	.cfi_endproc
.LFE114:
	.size	rc_set_quit_flag, .-rc_set_quit_flag
	.globl	rc_get_quit_flag
	.type	rc_get_quit_flag, @function
rc_get_quit_flag:
.LFB115:
	.cfi_startproc
	movl	quit_flag(%rip), %eax
	ret
	.cfi_endproc
.LFE115:
	.size	rc_get_quit_flag, .-rc_get_quit_flag
	.globl	rc_gen_config_lines
	.type	rc_gen_config_lines, @function
rc_gen_config_lines:
.LFB116:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$24, %rsp
	.cfi_def_cfa_offset 64
	movq	%rdi, %rbp
	movq	%rsi, %r12
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	%rsp, %rdi
	call	gen_config
	movq	(%rsp), %rdx
	movl	8(%rsp), %eax
	testl	%eax, %eax
	jle	.L956
	movq	%rdx, %rbx
	cltq
	leaq	(%rdx,%rax,8), %r13
.L957:
	movq	(%rbx), %rdi
	movq	%r12, %rsi
	call	*%rbp
	addq	$8, %rbx
	cmpq	%rbx, %r13
	jne	.L957
.L956:
	movq	%rsp, %rdi
	call	lines_free
	addq	$24, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE116:
	.size	rc_gen_config_lines, .-rc_gen_config_lines
	.section	.rodata.str1.1
.LC237:
	.string	"reports/router_compiler.log"
	.section	.rodata.str1.8
	.align 8
.LC238:
	.string	"warning: could not open %s for logging\n"
	.align 8
.LC239:
	.string	"router compiler start (Linux POC)"
	.section	.rodata.str1.1
.LC240:
	.string	"main"
	.section	.rodata.str1.8
	.align 8
.LC241:
	.string	"===================================================================="
	.align 8
.LC242:
	.string	"  Network Router Configuration Compiler  (Cisco IOS style CLI)"
	.align 8
.LC243:
	.string	"  Type '?' or 'help' for commands, 'exit' in user mode to quit."
	.align 8
.LC244:
	.string	"Restoring saved startup-config..."
	.section	.rodata.str1.1
.LC245:
	.string	"\nBye."
.LC246:
	.string	"router compiler exit"
	.text
	.globl	rc_run_cli
	.type	rc_run_cli, @function
rc_run_cli:
.LFB117:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	subq	$368, %rsp
	.cfi_def_cfa_offset 416
	call	rc_reset_config
	movl	$1, %esi
	leaq	.LC237(%rip), %rdi
	call	rlog_init@PLT
	testl	%eax, %eax
	jne	.L967
.L961:
	leaq	.LC239(%rip), %rdx
	leaq	.LC240(%rip), %rsi
	movl	$1, %edi
	movl	$0, %eax
	call	rlog_log@PLT
	leaq	.LC241(%rip), %rbx
	movq	%rbx, %rdi
	call	puts@PLT
	leaq	.LC242(%rip), %rdi
	call	puts@PLT
	leaq	.LC243(%rip), %rdi
	call	puts@PLT
	movq	%rbx, %rdi
	call	puts@PLT
	leaq	.LC38(%rip), %rsi
	leaq	.LC35(%rip), %rdi
	call	fopen@PLT
	movq	%rax, %rdi
	testq	%rax, %rax
	je	.L962
	call	fclose@PLT
	leaq	.LC244(%rip), %rdi
	call	puts@PLT
	leaq	.LC35(%rip), %rdi
	call	rc_load_file
	movl	$0, mode(%rip)
.L962:
	cmpl	$0, quit_flag(%rip)
	jne	.L963
	leaq	suffix.0(%rip), %r14
	leaq	cfg(%rip), %r13
	leaq	.LC143(%rip), %r12
	leaq	.LC19(%rip), %rbp
.L964:
	movl	mode(%rip), %eax
	movq	(%r14,%rax,8), %r8
	movq	%r13, %rcx
	movq	%r12, %rdx
	movl	$100, %esi
	movq	%rsp, %rdi
	movl	$0, %eax
	call	snprintf@PLT
	movq	%rsp, %rdi
	call	strlen@PLT
	movl	%eax, prompt_len(%rip)
	movq	%rsp, %rsi
	movq	%rbp, %rdi
	movl	$0, %eax
	call	printf@PLT
	movq	stdout(%rip), %rdi
	call	fflush@PLT
	leaq	112(%rsp), %rdi
	movq	stdin(%rip), %rdx
	movl	$256, %esi
	call	fgets@PLT
	testq	%rax, %rax
	je	.L963
	leaq	112(%rsp), %rdi
	call	execute_line_impl
	cmpl	$0, quit_flag(%rip)
	je	.L964
.L963:
	leaq	.LC245(%rip), %rdi
	call	puts@PLT
	leaq	.LC246(%rip), %rdx
	leaq	.LC240(%rip), %rsi
	movl	$1, %edi
	movl	$0, %eax
	call	rlog_log@PLT
	call	rc_reset_config
	movq	errlog(%rip), %rdi
	call	free@PLT
	movq	$0, errlog(%rip)
	movl	$0, cerr(%rip)
	movl	$0, nerr(%rip)
	call	rlog_close@PLT
	movl	$0, %eax
	addq	$368, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 48
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
.L967:
	.cfi_restore_state
	leaq	.LC237(%rip), %rdx
	leaq	.LC238(%rip), %rsi
	movq	stderr(%rip), %rdi
	movl	$0, %eax
	call	fprintf@PLT
	jmp	.L961
	.cfi_endproc
.LFE117:
	.size	rc_run_cli, .-rc_run_cli
	.section	.rodata.str1.1
.LC247:
	.string	">"
.LC248:
	.string	"#"
.LC249:
	.string	"(config)#"
.LC250:
	.string	"(config-if)#"
.LC251:
	.string	"(config-router)#"
	.section	.data.rel.ro.local,"aw"
	.align 32
	.type	suffix.0, @object
	.size	suffix.0, 48
suffix.0:
	.quad	.LC247
	.quad	.LC248
	.quad	.LC249
	.quad	.LC250
	.quad	.LC251
	.quad	.LC251
	.local	b.1
	.comm	b.1,64,32
	.local	i.2
	.comm	i.2,4,4
	.section	.rodata.str1.1
.LC252:
	.string	"enable"
.LC253:
	.string	"Enter privileged EXEC mode"
.LC254:
	.string	"disable"
.LC255:
	.string	"Return to user EXEC mode"
.LC256:
	.string	"configure terminal"
	.section	.rodata.str1.8
	.align 8
.LC257:
	.string	"Enter global configuration mode"
	.section	.rodata.str1.1
.LC258:
	.string	"exit"
	.section	.rodata.str1.8
	.align 8
.LC259:
	.string	"Go back one level (in user mode: quit program)"
	.section	.rodata.str1.1
.LC260:
	.string	"quit"
.LC261:
	.string	"Quit the program"
.LC262:
	.string	"help"
	.section	.rodata.str1.8
	.align 8
.LC263:
	.string	"List commands for the current mode"
	.align 8
.LC264:
	.string	"Return to privileged EXEC mode"
	.section	.rodata.str1.1
.LC265:
	.string	"hostname"
.LC266:
	.string	"<name>"
.LC267:
	.string	"Set the router name"
.LC268:
	.string	"no hostname"
.LC269:
	.string	"Reset hostname to 'Router'"
.LC270:
	.string	"enable secret"
.LC271:
	.string	"<password>"
.LC272:
	.string	"Set privileged-mode password"
.LC273:
	.string	"no enable secret"
	.section	.rodata.str1.8
	.align 8
.LC274:
	.string	"Remove privileged-mode password"
	.section	.rodata.str1.1
.LC275:
	.string	"interface"
.LC276:
	.string	"<type> <number>"
	.section	.rodata.str1.8
	.align 8
.LC277:
	.string	"Select/create an interface (g0/0, fa0/1, s0/0/0, lo0)"
	.section	.rodata.str1.1
.LC278:
	.string	"no interface"
.LC279:
	.string	"<loopback>"
.LC280:
	.string	"Delete a loopback interface"
.LC281:
	.string	"ip route"
.LC282:
	.string	"<net> <mask> <nh|if> [ad]"
.LC283:
	.string	"Add a static route"
.LC284:
	.string	"no ip route"
.LC285:
	.string	"<net> <mask> [nh|if]"
.LC286:
	.string	"Remove a static route"
	.section	.rodata.str1.8
	.align 8
.LC287:
	.string	"Enable RIP and enter router mode"
	.section	.rodata.str1.1
.LC288:
	.string	"no router rip"
.LC289:
	.string	"Disable RIP"
.LC290:
	.string	"router ospf"
.LC291:
	.string	"<process-id>"
	.section	.rodata.str1.8
	.align 8
.LC292:
	.string	"Enable OSPF and enter router mode"
	.section	.rodata.str1.1
.LC293:
	.string	"no router ospf"
.LC294:
	.string	"Disable OSPF"
.LC295:
	.string	"ip address"
.LC296:
	.string	"<ip> <mask>"
	.section	.rodata.str1.8
	.align 8
.LC297:
	.string	"Assign IPv4 address to the interface"
	.section	.rodata.str1.1
.LC298:
	.string	"no ip address"
.LC299:
	.string	"Remove IPv4 address"
.LC300:
	.string	"shutdown"
	.section	.rodata.str1.8
	.align 8
.LC301:
	.string	"Administratively disable the interface"
	.section	.rodata.str1.1
.LC302:
	.string	"no shutdown"
.LC303:
	.string	"Enable the interface"
.LC304:
	.string	"description"
.LC305:
	.string	"<text>"
.LC306:
	.string	"Set interface description"
.LC307:
	.string	"no description"
.LC308:
	.string	"Remove interface description"
.LC309:
	.string	"clock rate"
.LC310:
	.string	"<bits/sec>"
	.section	.rodata.str1.8
	.align 8
.LC311:
	.string	"Set DCE clock rate (Serial only)"
	.section	.rodata.str1.1
.LC312:
	.string	"no clock rate"
.LC313:
	.string	"Remove clock rate"
.LC314:
	.string	"version"
.LC315:
	.string	"<1|2>"
.LC316:
	.string	"Set RIP version"
.LC317:
	.string	"auto-summary"
	.section	.rodata.str1.8
	.align 8
.LC318:
	.string	"Enable automatic summarisation"
	.section	.rodata.str1.1
.LC319:
	.string	"no auto-summary"
	.section	.rodata.str1.8
	.align 8
.LC320:
	.string	"Disable automatic summarisation"
	.section	.rodata.str1.1
.LC321:
	.string	"router-id"
.LC322:
	.string	"<a.b.c.d>"
.LC323:
	.string	"Set OSPF router-id"
.LC324:
	.string	"no router-id"
.LC325:
	.string	"Remove OSPF router-id"
.LC326:
	.string	"network"
.LC327:
	.string	"<net> | <net> <wild> area <n>"
	.section	.rodata.str1.8
	.align 8
.LC328:
	.string	"Advertise a network (RIP: classful; OSPF: wildcard+area)"
	.section	.rodata.str1.1
.LC329:
	.string	"no network"
.LC330:
	.string	"<same as network>"
.LC331:
	.string	"Remove a network statement"
.LC332:
	.string	"show ip interface brief"
	.section	.rodata.str1.8
	.align 8
.LC333:
	.string	"One-line status of every interface"
	.section	.rodata.str1.1
.LC334:
	.string	"show ip route"
.LC335:
	.string	"[ip]"
	.section	.rodata.str1.8
	.align 8
.LC336:
	.string	"Routing table (or lookup of one address)"
	.section	.rodata.str1.1
.LC337:
	.string	"show ip protocols"
.LC338:
	.string	"RIP / OSPF settings"
.LC339:
	.string	"show interfaces"
.LC340:
	.string	"[type number]"
	.section	.rodata.str1.8
	.align 8
.LC341:
	.string	"Detailed interface information"
	.section	.rodata.str1.1
.LC342:
	.string	"show errors"
	.section	.rodata.str1.8
	.align 8
.LC343:
	.string	"All configuration errors seen this session"
	.section	.rodata.str1.1
.LC344:
	.string	"show running-config"
.LC345:
	.string	"Display current configuration"
.LC346:
	.string	"show startup-config"
.LC347:
	.string	"Display saved configuration"
.LC348:
	.string	"ping"
.LC349:
	.string	"<ip>"
	.section	.rodata.str1.8
	.align 8
.LC350:
	.string	"Simulated ping using the routing table"
	.section	.rodata.str1.1
.LC351:
	.string	"write"
.LC352:
	.string	"[memory]"
	.section	.rodata.str1.8
	.align 8
.LC353:
	.string	"Save running-config to startup-config"
	.align 8
.LC354:
	.string	"copy running-config startup-config"
	.section	.rodata.str1.1
.LC355:
	.string	"erase startup-config"
	.section	.rodata.str1.8
	.align 8
.LC356:
	.string	"Delete the saved startup-config"
	.section	.rodata.str1.1
.LC357:
	.string	"save"
.LC358:
	.string	"<file>"
	.section	.rodata.str1.8
	.align 8
.LC359:
	.string	"Save running-config to any file"
	.section	.rodata.str1.1
.LC360:
	.string	"load"
	.section	.rodata.str1.8
	.align 8
.LC361:
	.string	"Load a config file (replaces running-config)"
	.section	.rodata.str1.1
.LC362:
	.string	"reload"
	.section	.rodata.str1.8
	.align 8
.LC363:
	.string	"Restart: clear running-config, reload startup-config"
	.section	.rodata.str1.1
.LC364:
	.string	"validate"
	.section	.rodata.str1.8
	.align 8
.LC365:
	.string	"Semantic check of the whole configuration"
	.section	.rodata.str1.1
.LC366:
	.string	"compile"
.LC367:
	.string	"[file.rcx]"
	.section	.rodata.str1.8
	.align 8
.LC368:
	.string	"Validate + generate executable instructions"
	.section	.rodata.str1.1
.LC369:
	.string	"search"
.LC370:
	.string	"<keyword>"
	.section	.rodata.str1.8
	.align 8
.LC371:
	.string	"Search configuration text / interface name"
	.section	.data.rel.ro.local
	.align 32
	.type	CMDS, @object
	.size	CMDS, 2448
CMDS:
	.long	1
	.zero	4
	.quad	.LC252
	.quad	.LC22
	.long	0
	.long	0
	.quad	h_enable
	.quad	.LC253
	.long	2
	.zero	4
	.quad	.LC254
	.quad	.LC22
	.long	0
	.long	0
	.quad	h_disable
	.quad	.LC255
	.long	2
	.zero	4
	.quad	.LC256
	.quad	.LC22
	.long	0
	.long	0
	.quad	h_configure
	.quad	.LC257
	.long	63
	.zero	4
	.quad	.LC258
	.quad	.LC22
	.long	0
	.long	0
	.quad	h_exit
	.quad	.LC259
	.long	63
	.zero	4
	.quad	.LC260
	.quad	.LC22
	.long	0
	.long	0
	.quad	h_quit
	.quad	.LC261
	.long	63
	.zero	4
	.quad	.LC262
	.quad	.LC22
	.long	0
	.long	0
	.quad	h_help
	.quad	.LC263
	.long	60
	.zero	4
	.quad	.LC70
	.quad	.LC22
	.long	0
	.long	0
	.quad	h_end
	.quad	.LC264
	.long	60
	.zero	4
	.quad	.LC265
	.quad	.LC266
	.long	1
	.long	1
	.quad	h_hostname
	.quad	.LC267
	.long	60
	.zero	4
	.quad	.LC268
	.quad	.LC22
	.long	0
	.long	0
	.quad	h_no_hostname
	.quad	.LC269
	.long	60
	.zero	4
	.quad	.LC270
	.quad	.LC271
	.long	1
	.long	1
	.quad	h_secret
	.quad	.LC272
	.long	60
	.zero	4
	.quad	.LC273
	.quad	.LC22
	.long	0
	.long	0
	.quad	h_no_secret
	.quad	.LC274
	.long	60
	.zero	4
	.quad	.LC275
	.quad	.LC276
	.long	1
	.long	2
	.quad	h_interface
	.quad	.LC277
	.long	60
	.zero	4
	.quad	.LC278
	.quad	.LC279
	.long	1
	.long	2
	.quad	h_no_interface
	.quad	.LC280
	.long	60
	.zero	4
	.quad	.LC281
	.quad	.LC282
	.long	3
	.long	4
	.quad	h_ip_route
	.quad	.LC283
	.long	60
	.zero	4
	.quad	.LC284
	.quad	.LC285
	.long	2
	.long	4
	.quad	h_no_ip_route
	.quad	.LC286
	.long	60
	.zero	4
	.quad	.LC61
	.quad	.LC22
	.long	0
	.long	0
	.quad	h_router_rip
	.quad	.LC287
	.long	60
	.zero	4
	.quad	.LC288
	.quad	.LC22
	.long	0
	.long	0
	.quad	h_no_router_rip
	.quad	.LC289
	.long	60
	.zero	4
	.quad	.LC290
	.quad	.LC291
	.long	1
	.long	1
	.quad	h_router_ospf
	.quad	.LC292
	.long	60
	.zero	4
	.quad	.LC293
	.quad	.LC291
	.long	1
	.long	1
	.quad	h_no_router_ospf
	.quad	.LC294
	.long	8
	.zero	4
	.quad	.LC295
	.quad	.LC296
	.long	2
	.long	2
	.quad	h_ip_address
	.quad	.LC297
	.long	8
	.zero	4
	.quad	.LC298
	.quad	.LC22
	.long	0
	.long	0
	.quad	h_no_ip_address
	.quad	.LC299
	.long	8
	.zero	4
	.quad	.LC300
	.quad	.LC22
	.long	0
	.long	0
	.quad	h_shutdown
	.quad	.LC301
	.long	8
	.zero	4
	.quad	.LC302
	.quad	.LC22
	.long	0
	.long	0
	.quad	h_no_shutdown
	.quad	.LC303
	.long	8
	.zero	4
	.quad	.LC304
	.quad	.LC305
	.long	1
	.long	12
	.quad	h_description
	.quad	.LC306
	.long	8
	.zero	4
	.quad	.LC307
	.quad	.LC22
	.long	0
	.long	12
	.quad	h_no_description
	.quad	.LC308
	.long	8
	.zero	4
	.quad	.LC309
	.quad	.LC310
	.long	1
	.long	1
	.quad	h_clock
	.quad	.LC311
	.long	8
	.zero	4
	.quad	.LC312
	.quad	.LC22
	.long	0
	.long	1
	.quad	h_no_clock
	.quad	.LC313
	.long	16
	.zero	4
	.quad	.LC314
	.quad	.LC315
	.long	1
	.long	1
	.quad	h_rip_version
	.quad	.LC316
	.long	16
	.zero	4
	.quad	.LC317
	.quad	.LC22
	.long	0
	.long	0
	.quad	h_autosum
	.quad	.LC318
	.long	16
	.zero	4
	.quad	.LC319
	.quad	.LC22
	.long	0
	.long	0
	.quad	h_no_autosum
	.quad	.LC320
	.long	32
	.zero	4
	.quad	.LC321
	.quad	.LC322
	.long	1
	.long	1
	.quad	h_router_id
	.quad	.LC323
	.long	32
	.zero	4
	.quad	.LC324
	.quad	.LC22
	.long	0
	.long	1
	.quad	h_no_router_id
	.quad	.LC325
	.long	48
	.zero	4
	.quad	.LC326
	.quad	.LC327
	.long	1
	.long	4
	.quad	h_network
	.quad	.LC328
	.long	48
	.zero	4
	.quad	.LC329
	.quad	.LC330
	.long	1
	.long	4
	.quad	h_no_network
	.quad	.LC331
	.long	3
	.zero	4
	.quad	.LC332
	.quad	.LC22
	.long	0
	.long	0
	.quad	h_show_ipbrief
	.quad	.LC333
	.long	3
	.zero	4
	.quad	.LC334
	.quad	.LC335
	.long	0
	.long	1
	.quad	h_show_route
	.quad	.LC336
	.long	3
	.zero	4
	.quad	.LC337
	.quad	.LC22
	.long	0
	.long	0
	.quad	h_show_protocols
	.quad	.LC338
	.long	3
	.zero	4
	.quad	.LC339
	.quad	.LC340
	.long	0
	.long	2
	.quad	h_show_if
	.quad	.LC341
	.long	3
	.zero	4
	.quad	.LC342
	.quad	.LC22
	.long	0
	.long	0
	.quad	h_show_errors
	.quad	.LC343
	.long	2
	.zero	4
	.quad	.LC344
	.quad	.LC22
	.long	0
	.long	0
	.quad	h_show_run
	.quad	.LC345
	.long	2
	.zero	4
	.quad	.LC346
	.quad	.LC22
	.long	0
	.long	0
	.quad	h_show_startup
	.quad	.LC347
	.long	3
	.zero	4
	.quad	.LC348
	.quad	.LC349
	.long	1
	.long	1
	.quad	h_ping
	.quad	.LC350
	.long	2
	.zero	4
	.quad	.LC351
	.quad	.LC352
	.long	0
	.long	1
	.quad	h_write
	.quad	.LC353
	.long	2
	.zero	4
	.quad	.LC354
	.quad	.LC22
	.long	0
	.long	0
	.quad	h_copy
	.quad	.LC353
	.long	2
	.zero	4
	.quad	.LC355
	.quad	.LC22
	.long	0
	.long	0
	.quad	h_erase
	.quad	.LC356
	.long	2
	.zero	4
	.quad	.LC357
	.quad	.LC358
	.long	1
	.long	1
	.quad	h_save
	.quad	.LC359
	.long	2
	.zero	4
	.quad	.LC360
	.quad	.LC358
	.long	1
	.long	1
	.quad	h_load
	.quad	.LC361
	.long	2
	.zero	4
	.quad	.LC362
	.quad	.LC22
	.long	0
	.long	0
	.quad	h_reload
	.quad	.LC363
	.long	2
	.zero	4
	.quad	.LC364
	.quad	.LC22
	.long	0
	.long	0
	.quad	h_validate
	.quad	.LC365
	.long	2
	.zero	4
	.quad	.LC366
	.quad	.LC367
	.long	0
	.long	1
	.quad	h_compile
	.quad	.LC368
	.long	2
	.zero	4
	.quad	.LC369
	.quad	.LC370
	.long	1
	.long	8
	.quad	h_search
	.quad	.LC371
	.section	.rodata.str1.1
.LC372:
	.string	"GigabitEthernet"
.LC373:
	.string	"FastEthernet"
	.section	.data.rel.ro.local
	.align 32
	.type	IFTYPES, @object
	.size	IFTYPES, 32
IFTYPES:
	.quad	.LC372
	.quad	.LC373
	.quad	.LC93
	.quad	.LC125
	.local	st
	.comm	st,12,8
	.local	cerr
	.comm	cerr,4,4
	.local	nerr
	.comm	nerr,4,4
	.local	errlog
	.comm	errlog,8,8
	.section	.data.rel.local,"aw"
	.align 8
	.type	load_name, @object
	.size	load_name, 8
load_name:
	.quad	.LC22
	.local	load_line
	.comm	load_line,4,4
	.local	loading
	.comm	loading,4,4
	.local	quit_flag
	.comm	quit_flag,4,4
	.local	prompt_len
	.comm	prompt_len,4,4
	.local	C
	.comm	C,712,32
	.local	cur_if
	.comm	cur_if,8,8
	.local	mode
	.comm	mode,4,4
	.local	cfg
	.comm	cfg,744,32
	.ident	"GCC: (Debian 14.2.0-19) 14.2.0"
	.section	.note.GNU-stack,"",@progbits
