#!/usr/bin/env bash
# Run all checks supported by the current machine; missing tools are recorded as NOT RUN.
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p reports

run_required() {
    local title="$1"; shift
    local report="$1"; shift
    echo "== ${title} ==" | tee "$report"
    "$@" 2>&1 | tee -a "$report"
}

make clean
run_required "Build (strict GCC warnings)" reports/build.txt make all
run_required "C unit and integration tests" reports/tests.txt make test
run_required "AddressSanitizer / UndefinedBehaviorSanitizer" reports/sanitizers.txt make sanitize
run_required "gcov coverage" reports/coverage_run.txt make coverage
run_required "Optimization assembly comparison" reports/optimization_run.txt make optimization

if command -v valgrind >/dev/null 2>&1; then
    run_required "Valgrind Memcheck" reports/valgrind_run.txt make valgrind
else
    echo "NOT RUN: Valgrind is not installed or is not on PATH." | tee reports/valgrind_run.txt
fi

if command -v cppcheck >/dev/null 2>&1; then
    run_required "Cppcheck static analysis" reports/cppcheck_run.txt make cppcheck
    run_required "Cppcheck MISRA addon" reports/misra_run.txt make misra
else
    echo "NOT RUN: Cppcheck is not installed or is not on PATH; static analysis and MISRA addon need rerunning on a machine with Cppcheck." | tee reports/cppcheck_run.txt reports/misra_run.txt
fi

if pkg-config --exists gtest 2>/dev/null; then
    run_required "GoogleTest" reports/gtest_run.txt make gtest
else
    echo "NOT RUN: GoogleTest development library was not detected; C unit/integration tests ran instead." | tee reports/gtest_run.txt
fi

if command -v gdb >/dev/null 2>&1; then
    echo "AVAILABLE: GDB is installed. Use it for interactive fault-injection demonstrations; no automated GDB session was run by this script." | tee reports/gdb_status.txt
else
    echo "NOT RUN: GDB is not installed or is not on PATH." | tee reports/gdb_status.txt
fi

echo "Checks finished. Review each reports/*_run.txt file; NOT RUN means the relevant tool was unavailable." 
