# Network Router Configuration Compiler

A C99 command-line configuration compiler/simulator with a Cisco-IOS-style command flow. It models router configuration in memory and can validate, save, load, and generate configuration text. It does **not** connect to physical routers or forward packets.

## Project layout

```text
router-compiler/
├── Makefile
├── README.md
├── include/                 # Public API and logging headers
├── src/                     # CLI, compiler logic, timestamped logger
├── test/                    # C unit/integration harness and optional GTest suite
├── scripts/run_all.sh       # Evidence-producing tool runner
└── reports/                 # Reports and raw run evidence
```

## Build and test

- `make all` — build the application and C test binaries using strict GCC warnings (`-Werror`).
- `make test` — run the C unit and integration suites.
- `make sanitize` — rebuild and run tests with AddressSanitizer and UndefinedBehaviorSanitizer.
- `make coverage` — execute tests with gcov instrumentation and write coverage output.
- `make optimization` — generate `-O1`, `-O2`, and `-O3` assembly for `src/router_compiler.c` and compare byte/line counts.
- `make valgrind` — run Memcheck on the C unit and integration binaries (requires Valgrind).
- `make helgrind` — run Helgrind on the unit binary (requires Valgrind; this program is currently single-threaded, so concurrency coverage is limited).
- `make cppcheck` — run Cppcheck across source and tests (requires Cppcheck).
- `make misra` — run the Cppcheck MISRA addon against production C files (requires a compatible addon).
- `make gtest` — build and run the optional GoogleTest suite (requires GTest development libraries).
- `make run-all` or `./scripts/run_all.sh` — execute available checks and explicitly record tools that are missing as `NOT RUN`.

## Current execution snapshot

The checked-in evidence reflects a run in a Linux container with GCC 14.2.0, Make, and gcov available. The strict build passed; the C unit suite passed 52 assertions; the integration suite passed 7 assertions; ASan/UBSan runs completed without sanitizer diagnostics. Coverage was 6.42% line coverage for the unit-only run and 43.64% for the integration run over `src/router_compiler.c`. Assembly sizes are recorded in `reports/optimization.txt`.

Valgrind, Cppcheck, GTest, and GDB were not available in that container. Their reports are intentionally marked pending/not run; no tool-specific clean result is claimed. Install the missing tools on your Linux/WSL environment, rerun `./scripts/run_all.sh`, and update the report conclusions from the resulting logs.
