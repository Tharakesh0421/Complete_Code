#define _POSIX_C_SOURCE 200809L
#include "rlog.h"
#include <stdio.h>
#include <stdarg.h>
#include <time.h>
#include <string.h>

static FILE *g_fp;
static RlogLevel g_min;
static int g_inited;

int rlog_init(const char *path, RlogLevel min_level)
{
    g_min = min_level;
    if (path != NULL) {
        g_fp = fopen(path, "a");
        if (g_fp == NULL) {
            return -1;
        }
    }
    g_inited = 1;
    return 0;
}

void rlog_close(void)
{
    if (g_fp != NULL) {
        (void)fclose(g_fp);
        g_fp = NULL;
    }
    g_inited = 0;
}

void rlog_log(RlogLevel lvl, const char *module, const char *fmt, ...)
{
    struct timespec ts;
    struct tm tm_buf;
    char stamp[32];
    const char *tag;
    va_list ap;
    FILE *out;

    if (fmt == NULL) {
        return;
    }
    if (g_inited && lvl < g_min) {
        return;
    }
    if (clock_gettime(CLOCK_REALTIME, &ts) != 0) {
        (void)fprintf(stderr, "rlog: clock_gettime failed\\n");
        return;
    }
    if (localtime_r(&ts.tv_sec, &tm_buf) == NULL) {
        (void)fprintf(stderr, "rlog: localtime_r failed\\n");
        return;
    }
    if (strftime(stamp, sizeof stamp, "%Y-%m-%d %H:%M:%S", &tm_buf) == 0U) {
        (void)fprintf(stderr, "rlog: timestamp formatting failed\\n");
        return;
    }

    switch (lvl) {
        case RLOG_DEBUG: tag = "DEBUG"; break;
        case RLOG_INFO:  tag = "INFO "; break;
        case RLOG_WARN:  tag = "WARN "; break;
        case RLOG_ERROR: tag = "ERROR"; break;
        default:         tag = "UNKNOWN"; break;
    }

    out = (g_fp != NULL) ? g_fp : stderr;
    (void)fprintf(out, "%s.%03ld [%s] [%s] ", stamp,
                  ts.tv_nsec / 1000000L, tag,
                  (module != NULL) ? module : "-");
    va_start(ap, fmt);
    (void)vfprintf(out, fmt, ap);
    va_end(ap);
    (void)fputc('\n', out);
    (void)fflush(out);
}
