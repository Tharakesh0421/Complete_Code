/*
 * router_compiler.c  --  network router config compiler (Cisco-IOS style)
 * Linux POC build.
 */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdint.h>
#include <stdarg.h>

#include "rlog.h"
#include "router_compiler.h"

typedef uint32_t u32;
typedef unsigned long long u64;

#define MAXLINE 256
#define MAXTOK  16
#define HSIZE   64
#define STARTUP_FILE "startup-config.cfg"
#define LOGFILE      "reports/router_compiler.log"

typedef enum { M_USER, M_PRIV, M_CONFIG, M_IF, M_RIP, M_OSPF } Mode;
#define BIT(m) (1u << (m))
#define MB_USER BIT(M_USER)
#define MB_PRIV BIT(M_PRIV)
#define MB_EXEC (MB_USER | MB_PRIV)
#define MB_CFG  (BIT(M_CONFIG) | BIT(M_IF) | BIT(M_RIP) | BIT(M_OSPF))
#define MB_ALL  (MB_EXEC | MB_CFG)

/* -------------------- data structs -------------------- */
typedef struct Interface {
    char name[40];
    char desc[100];
    u32 ip, mask;
    int has_ip, shutdown;
    long clock_rate;
    struct Interface *hnext;
    struct Interface *onext;
} Interface;

typedef struct { u32 net, mask, nh; char iface[40]; int has_nh, ad; } Route;
typedef struct { u32 net, wild; u64 area; } OspfNet;

typedef struct {
    char hostname[64];
    char secret[64];
    Interface *htab[HSIZE], *ihead, *itail;
    int nif;
    Route *routes; int nr, cr;
    int rip_on, rip_ver, rip_autosum;
    u32 *rip_nets; int nrip, crip;
    int ospf_on, ospf_pid, has_rid; u32 rid;
    OspfNet *onets; int nos, cos;
} Config;

typedef struct { char where[64]; char cmd[MAXLINE]; char msg[200]; } ErrRec;
typedef struct { char **v; int n, cap; } Lines;

typedef struct Cmd Cmd;
typedef int (*Fn)(int argc, char **argv);
struct Cmd { unsigned modes; const char *pat; const char *usage; int minA, maxA; Fn fn; const char *help; };

struct Ctx { char orig[MAXLINE]; char buf[MAXLINE]; char *tok[MAXTOK]; int pos[MAXTOK]; int n, argbase; };

/* -------------------- globals -------------------- */
static Config cfg;
static Mode mode = M_USER;
static Interface *cur_if;
static struct Ctx C;
static int prompt_len, quit_flag, loading, load_line;
static const char *load_name = "";
static ErrRec *errlog; static int nerr, cerr;
static struct { int total, cfg_ok, cfg_dup; } st;

static const Cmd *cmd_table(int *n);

/* -------------------- small helpers -------------------- */
static void *xmalloc(size_t n) { void *p = malloc(n ? n : 1); if (!p) { fputs("out of memory\n", stderr); exit(1); } return p; }
static void *xrealloc(void *p, size_t n) { p = realloc(p, n); if (!p) { fputs("out of memory\n", stderr); exit(1); } return p; }
static char *xstrdup(const char *s) { size_t n = strlen(s) + 1; char *p = xmalloc(n); memcpy(p, s, n); return p; }
#define GROW(arr, n, cap) do { if ((n) >= (cap)) { (cap) = (cap) ? (cap) * 2 : 8; \
    (arr) = xrealloc((arr), (size_t)(cap) * sizeof(*(arr))); } } while (0)

int rc_ieq(const char *a, const char *b) {
    for (; *a && *b; a++, b++) if (tolower((unsigned char)*a) != tolower((unsigned char)*b)) return 0;
    return *a == *b;
}
int rc_is_prefix_ci(const char *t, const char *w) {
    if (!*t) return 0;
    for (; *t && *w; t++, w++) if (tolower((unsigned char)*t) != tolower((unsigned char)*w)) return 0;
    return *t == 0;
}
static const char *stristr(const char *h, const char *nd) {
    size_t n = strlen(nd);
    if (!n) return h;
    for (; *h; h++) { size_t i = 0; while (i < n && h[i] && tolower((unsigned char)h[i]) == tolower((unsigned char)nd[i])) i++; if (i == n) return h; }
    return NULL;
}
const char *rc_ipstr(u32 ip) {
    static char b[4][16]; static int i; char *s = b[i++ & 3];
    snprintf(s, 16, "%u.%u.%u.%u", (unsigned)(ip >> 24), (unsigned)((ip >> 16) & 255), (unsigned)((ip >> 8) & 255), (unsigned)(ip & 255));
    return s;
}
int rc_parse_ip(const char *s, u32 *out) {
    u32 r = 0; int part;
    for (part = 0; part < 4; part++) {
        int digits = 0; unsigned v = 0;
        while (isdigit((unsigned char)*s)) { v = v * 10 + (unsigned)(*s - '0'); s++; if (++digits > 3) return 0; }
        if (!digits || v > 255) return 0;
        r = (r << 8) | v;
        if (part < 3) { if (*s != '.') return 0; s++; }
    }
    if (*s) return 0;
    *out = r; return 1;
}
int rc_parse_uint(const char *s, u64 lo, u64 hi, u64 *out) {
    u64 v = 0; int d = 0;
    if (!*s) return 0;
    for (; *s; s++) { if (!isdigit((unsigned char)*s) || ++d > 10) return 0; v = v * 10 + (u64)(*s - '0'); }
    if (v < lo || v > hi) return 0;
    *out = v; return 1;
}
int rc_mask_ok(u32 m) { u32 n = ~m; return (n & (n + 1)) == 0; }
int rc_plen(u32 m) { int c = 0; while (m) { c += (int)(m & 1); m >>= 1; } return c; }
int rc_classful(u32 ip, u32 *base) {
    unsigned a = ip >> 24;
    if (a >= 1 && a <= 126)   { *base = ip & 0xFF000000u; return 1; }
    if (a >= 128 && a <= 191) { *base = ip & 0xFFFF0000u; return 1; }
    if (a >= 192 && a <= 223) { *base = ip & 0xFFFFFF00u; return 1; }
    return 0;
}

static void addf(Lines *L, const char *fmt, ...) {
    char b[300]; va_list ap;
    va_start(ap, fmt); vsnprintf(b, sizeof b, fmt, ap); va_end(ap);
    GROW(L->v, L->n, L->cap);
    L->v[L->n++] = xstrdup(b);
}
static void lines_free(Lines *L) { int i; for (i = 0; i < L->n; i++) free(L->v[i]); free(L->v); L->v = NULL; L->n = L->cap = 0; }

/* -------------------- error handling -------------------- */
static int err(const char *fmt, ...) {
    char msg[200]; va_list ap; ErrRec *e;
    va_start(ap, fmt); vsnprintf(msg, sizeof msg, fmt, ap); va_end(ap);
    if (loading) { printf("  %s:%d: %% %s\n", load_name, load_line, msg); RLOGW("parser", "%s:%d %s", load_name, load_line, msg); }
    else         { printf("%% %s\n", msg); RLOGW("parser", "%s", msg); }
    GROW(errlog, nerr, cerr);
    e = &errlog[nerr++];
    if (loading) snprintf(e->where, sizeof e->where, "%s:%d", load_name, load_line);
    else snprintf(e->where, sizeof e->where, "cmd #%d", st.total);
    snprintf(e->cmd, sizeof e->cmd, "%s", C.orig);
    snprintf(e->msg, sizeof e->msg, "%s", msg);
    return -1;
}
static void caret(int tokidx) {
    int col;
    if (loading) return;
    col = tokidx < C.n ? C.pos[tokidx] : (int)strlen(C.orig);
    printf("%*s^\n", prompt_len + col, "");
}
static int bad_arg(int i, const char *fmt, ...) {
    char m[160]; va_list ap;
    va_start(ap, fmt); vsnprintf(m, sizeof m, fmt, ap); va_end(ap);
    caret(C.argbase + i);
    return err("%s", m);
}
static const char *rest_text(void) { return C.argbase < C.n ? C.orig + C.pos[C.argbase] : ""; }

/* -------------------- config storage -------------------- */
static unsigned hash_name(const char *s) { unsigned h = 5381; for (; *s; s++) h = h * 33 + (unsigned char)tolower((unsigned char)*s); return h % HSIZE; }
static Interface *if_find(const char *name) {
    Interface *p = cfg.htab[hash_name(name)];
    for (; p; p = p->hnext) if (!strcmp(p->name, name)) return p;
    return NULL;
}
static Interface *if_create(const char *name) {
    Interface *i = xmalloc(sizeof *i); unsigned h = hash_name(name);
    memset(i, 0, sizeof *i);
    snprintf(i->name, sizeof i->name, "%s", name);
    i->shutdown = strncmp(name, "Loopback", 8) != 0;
    i->hnext = cfg.htab[h]; cfg.htab[h] = i;
    if (cfg.itail) cfg.itail->onext = i; else cfg.ihead = i;
    cfg.itail = i; cfg.nif++;
    RLOGD("config", "created interface %s", name);
    return i;
}
static void if_delete(Interface *t) {
    Interface **pp = &cfg.htab[hash_name(t->name)];
    while (*pp && *pp != t) pp = &(*pp)->hnext;
    if (*pp) *pp = t->hnext;
    { Interface *p, *prev = NULL;
      for (p = cfg.ihead; p && p != t; prev = p, p = p->onext) ;
      if (p) { if (prev) prev->onext = t->onext; else cfg.ihead = t->onext; if (cfg.itail == t) cfg.itail = prev; } }
    cfg.nif--;
    RLOGD("config", "deleted interface %s", t->name);
    free(t);                        /* fixed: original leaked */
}
static const char *IFTYPES[] = { "GigabitEthernet", "FastEthernet", "Serial", "Loopback" };
int rc_canon_iface(const char *in, char *out, size_t n) {
    char alpha[24]; size_t a = 0; const char *p = in, *q; int parts = 0, t = -1, i;
    while (isalpha((unsigned char)*p)) { if (a < sizeof alpha - 1) alpha[a++] = *p; p++; }
    alpha[a] = 0;
    if (!a || !*p) return 0;
    q = p;
    for (;;) {
        int d = 0;
        if (!isdigit((unsigned char)*q)) return 0;
        while (isdigit((unsigned char)*q)) { if (++d > 6) return 0; q++; }
        parts++;
        if (*q == '/') { q++; continue; }
        break;
    }
    if (*q || parts > 3) return 0;
    for (i = 0; i < 4; i++) if (rc_is_prefix_ci(alpha, IFTYPES[i])) { t = i; break; }
    if (t < 0 || (t == 3 && parts != 1)) return 0;
    snprintf(out, n, "%s%s", IFTYPES[t], p);
    return 1;
}
int rc_join_iface(int argc, char **argv, char *out, size_t n) {
    char raw[80];
    if (argc == 2) snprintf(raw, sizeof raw, "%s%s", argv[0], argv[1]);
    else snprintf(raw, sizeof raw, "%s", argv[0]);
    return rc_canon_iface(raw, out, n);
}

static int route_cmp(const Route *a, const Route *b) {
    if (a->net != b->net) return a->net < b->net ? -1 : 1;
    if (a->mask != b->mask) return a->mask < b->mask ? -1 : 1;
    if (a->has_nh != b->has_nh) return a->has_nh - b->has_nh;
    if (a->has_nh) return a->nh == b->nh ? 0 : (a->nh < b->nh ? -1 : 1);
    return strcmp(a->iface, b->iface);
}
static int route_find(const Route *k, int *pos) {
    int lo = 0, hi = cfg.nr - 1;
    while (lo <= hi) {
        int mid = (lo + hi) / 2, c = route_cmp(&cfg.routes[mid], k);
        if (!c) { *pos = mid; return 1; }
        if (c < 0) lo = mid + 1; else hi = mid - 1;
    }
    *pos = lo; return 0;
}
static void route_insert(const Route *r, int pos) {
    GROW(cfg.routes, cfg.nr, cfg.cr);
    memmove(&cfg.routes[pos + 1], &cfg.routes[pos], (size_t)(cfg.nr - pos) * sizeof(Route));
    cfg.routes[pos] = *r; cfg.nr++;
}
static void route_remove(int pos) {
    memmove(&cfg.routes[pos], &cfg.routes[pos + 1], (size_t)(cfg.nr - pos - 1) * sizeof(Route)); cfg.nr--;
}

void rc_reset_config(void) {
    Interface *i = cfg.ihead, *nx;
    while (i) { nx = i->onext; free(i); i = nx; }
    free(cfg.routes);      /* fixed: originally leaked */
    free(cfg.rip_nets);    /* fixed: originally leaked */
    free(cfg.onets);       /* fixed: originally leaked */
    memset(&cfg, 0, sizeof cfg);
    snprintf(cfg.hostname, sizeof cfg.hostname, "Router");
    mode = M_USER;
    cur_if = NULL;
    quit_flag = 0;
    loading = 0;
    load_line = 0;
    load_name = "";
    RLOGI("config", "reset to default");
}

static Interface *connected_if(u32 ip) {
    Interface *i, *best = NULL;
    for (i = cfg.ihead; i; i = i->onext)
        if (i->has_ip && !i->shutdown && (ip & i->mask) == (i->ip & i->mask) && (!best || i->mask > best->mask)) best = i;
    return best;
}
static int route_installed(const Route *r) {
    if (r->has_nh) return connected_if(r->nh) != NULL;
    { Interface *i = if_find(r->iface); return i && !i->shutdown; }
}

typedef struct { char code; u32 net, mask, nh; const char *iface; int ad, has_nh; } Hit;
static int lookup(u32 ip, Hit *h) {
    Interface *i; int k, found = 0, bl = -1, bad = 999;
    for (i = cfg.ihead; i; i = i->onext) {
        if (!i->has_ip || i->shutdown || (ip & i->mask) != (i->ip & i->mask)) continue;
        if (rc_plen(i->mask) > bl || (rc_plen(i->mask) == bl && 0 < bad)) {
            bl = rc_plen(i->mask); bad = 0; found = 1;
            h->code = 'C'; h->net = i->ip & i->mask; h->mask = i->mask;
            h->iface = i->name; h->ad = 0; h->has_nh = 0; h->nh = 0;
        }
    }
    for (k = 0; k < cfg.nr; k++) {
        Route *r = &cfg.routes[k]; int l = rc_plen(r->mask);
        if ((ip & r->mask) != r->net || !route_installed(r)) continue;
        if (l > bl || (l == bl && r->ad < bad)) {
            bl = l; bad = r->ad; found = 1;
            h->code = 'S'; h->net = r->net; h->mask = r->mask; h->nh = r->nh;
            h->has_nh = r->has_nh; h->iface = r->iface; h->ad = r->ad;
        }
    }
    return found;
}

/* -------------------- config text -------------------- */
static void gen_config(Lines *L) {
    Interface *i; int k;
    addf(L, "!"); addf(L, "hostname %s", cfg.hostname); addf(L, "!");
    if (cfg.secret[0]) { addf(L, "enable secret %s", cfg.secret); addf(L, "!"); }
    for (i = cfg.ihead; i; i = i->onext) {
        addf(L, "interface %s", i->name);
        if (i->desc[0]) addf(L, " description %s", i->desc);
        if (i->has_ip) addf(L, " ip address %s %s", rc_ipstr(i->ip), rc_ipstr(i->mask)); else addf(L, " no ip address");
        if (i->clock_rate) addf(L, " clock rate %ld", i->clock_rate);
        addf(L, i->shutdown ? " shutdown" : " no shutdown");
        addf(L, "!");
    }
    if (cfg.rip_on) {
        addf(L, "router rip"); addf(L, " version %d", cfg.rip_ver);
        for (k = 0; k < cfg.nrip; k++) addf(L, " network %s", rc_ipstr(cfg.rip_nets[k]));
        if (!cfg.rip_autosum) addf(L, " no auto-summary");
        addf(L, "!");
    }
    if (cfg.ospf_on) {
        addf(L, "router ospf %d", cfg.ospf_pid);
        if (cfg.has_rid) addf(L, " router-id %s", rc_ipstr(cfg.rid));
        for (k = 0; k < cfg.nos; k++)
            addf(L, " network %s %s area %llu", rc_ipstr(cfg.onets[k].net), rc_ipstr(cfg.onets[k].wild), cfg.onets[k].area);
        addf(L, "!");
    }
    for (k = 0; k < cfg.nr; k++) {
        Route *r = &cfg.routes[k]; char ad[16] = "";
        if (r->ad != 1) snprintf(ad, sizeof ad, " %d", r->ad);
        if (r->has_nh) addf(L, "ip route %s %s %s%s", rc_ipstr(r->net), rc_ipstr(r->mask), rc_ipstr(r->nh), ad);
        else           addf(L, "ip route %s %s %s%s", rc_ipstr(r->net), rc_ipstr(r->mask), r->iface, ad);
    }
    if (cfg.nr) addf(L, "!");
    addf(L, "end");
}

/* -------------------- handlers -------------------- */
static int h_enable(int argc, char **argv) {
    (void)argc; (void)argv;
    if (cfg.secret[0] && !loading) {
        char pw[100]; size_t n;
        printf("Password: "); fflush(stdout);
        if (!fgets(pw, sizeof pw, stdin)) return -1;
        n = strlen(pw); while (n && (pw[n - 1] == '\n' || pw[n - 1] == '\r')) pw[--n] = 0;
        if (strcmp(pw, cfg.secret)) return err("Access denied");
    }
    mode = M_PRIV; RLOGD("cli", "entered privileged EXEC"); return 0;
}
static int h_disable(int argc, char **argv) { (void)argc; (void)argv; mode = M_USER; return 0; }
static int h_configure(int argc, char **argv) {
    (void)argc; (void)argv; mode = M_CONFIG;
    if (!loading) puts("Enter configuration commands, one per line.  End with 'end'.");
    RLOGD("cli", "entered config mode"); return 0;
}
static int h_exit(int argc, char **argv) {
    (void)argc; (void)argv;
    switch (mode) {
    case M_USER:   quit_flag = 1; break;
    case M_PRIV:   mode = M_USER; break;
    case M_CONFIG: mode = M_PRIV; break;
    case M_IF:
    case M_RIP:
    case M_OSPF:   mode = M_CONFIG; cur_if = NULL; break;
    default:       mode = M_USER; quit_flag = 1; break;
    }
    return 0;
}
static int h_quit(int argc, char **argv) { (void)argc; (void)argv; quit_flag = 1; return 0; }
static int h_end(int argc, char **argv)  { (void)argc; (void)argv; mode = M_PRIV; cur_if = NULL; return 0; }

static int h_hostname(int argc, char **argv) {
    const char *s = argv[0]; size_t i;
    (void)argc;
    if (!isalpha((unsigned char)s[0]) || strlen(s) > 63)
        return bad_arg(0, "Hostname must start with a letter and be at most 63 characters.");
    for (i = 0; s[i]; i++)
        if (!isalnum((unsigned char)s[i]) && s[i] != '-' && s[i] != '_')
            return bad_arg(0, "Hostname may contain only letters, digits, '-' and '_'.");
    if (!strcmp(cfg.hostname, s)) return 1;
    snprintf(cfg.hostname, sizeof cfg.hostname, "%s", s);
    RLOGI("config", "hostname -> %s", s);
    return 0;
}
static int h_no_hostname(int argc, char **argv) { (void)argc; (void)argv; if (!strcmp(cfg.hostname, "Router")) return 1; snprintf(cfg.hostname, sizeof cfg.hostname, "Router"); return 0; }
static int h_secret(int argc, char **argv) {
    (void)argc;
    if (strlen(argv[0]) > 63) return bad_arg(0, "Password too long (max 63).");
    if (!strcmp(cfg.secret, argv[0])) return 1;
    snprintf(cfg.secret, sizeof cfg.secret, "%s", argv[0]); return 0;
}
static int h_no_secret(int argc, char **argv) { (void)argc; (void)argv; if (!cfg.secret[0]) return 1; cfg.secret[0] = 0; return 0; }

static int h_interface(int argc, char **argv) {
    char nm[40]; Interface *i;
    if (!rc_join_iface(argc, argv, nm, sizeof nm))
        return bad_arg(0, "Invalid interface. Examples: g0/0, fa0/1, s0/0/0, loopback0.");
    i = if_find(nm);
    if (!i) i = if_create(nm);
    cur_if = i; mode = M_IF; return 0;
}
static int h_no_interface(int argc, char **argv) {
    char nm[40]; Interface *i; int k;
    if (!rc_join_iface(argc, argv, nm, sizeof nm)) return bad_arg(0, "Invalid interface name.");
    if (strncmp(nm, "Loopback", 8)) return err("Cannot delete physical interface %s (only loopbacks can be removed).", nm);
    i = if_find(nm);
    if (!i) return err("Interface %s does not exist.", nm);
    for (k = cfg.nr - 1; k >= 0; k--) if (!cfg.routes[k].has_nh && !strcmp(cfg.routes[k].iface, nm)) route_remove(k);
    if (cur_if == i) cur_if = NULL;
    if_delete(i);
    if (mode == M_IF) mode = M_CONFIG;
    return 0;
}

static int h_ip_address(int argc, char **argv) {
    u32 ip, m, net, bc; Interface *o; int islo = !strncmp(cur_if->name, "Loopback", 8);
    (void)argc;
    if (!rc_parse_ip(argv[0], &ip) || ip == 0 || (ip >> 24) >= 224 || (ip >> 24) == 127)
        return bad_arg(0, "Invalid IP address \"%s\" (must be a unicast host address).", argv[0]);
    if (!rc_parse_ip(argv[1], &m) || m == 0 || !rc_mask_ok(m))
        return bad_arg(1, "Invalid subnet mask \"%s\" (1-bits must be contiguous, e.g. 255.255.255.0).", argv[1]);
    net = ip & m; bc = net | ~m;
    if (rc_plen(m) == 32 && !islo) return bad_arg(1, "Bad mask /32 for address %s (allowed only on loopbacks).", argv[0]);
    if (rc_plen(m) < 31 && (ip == net || ip == bc))
        return bad_arg(0, "Bad mask /%d for address %s (it is the network or broadcast address).", rc_plen(m), argv[0]);
    for (o = cfg.ihead; o; o = o->onext) {
        u32 sm;
        if (o == cur_if || !o->has_ip) continue;
        sm = m & o->mask;
        if ((ip & sm) == (o->ip & sm))
            return err("%s/%d overlaps with %s (%s/%d).", rc_ipstr(net), rc_plen(m), o->name,
                       rc_ipstr(o->ip & o->mask), rc_plen(o->mask));
    }
    if (cur_if->has_ip && cur_if->ip == ip && cur_if->mask == m) return 1;
    cur_if->ip = ip; cur_if->mask = m; cur_if->has_ip = 1;
    RLOGI("config", "%s ip = %s/%d", cur_if->name, rc_ipstr(ip), rc_plen(m));
    return 0;
}
static int h_no_ip_address(int argc, char **argv) { (void)argc; (void)argv; if (!cur_if->has_ip) return 1; cur_if->has_ip = 0; cur_if->ip = cur_if->mask = 0; return 0; }
static void link_msg(Interface *i, int up) {
    if (loading) return;
    printf("%%LINK-5-CHANGED: Interface %s, changed state to %s\n", i->name, up ? "up" : "administratively down");
    printf("%%LINEPROTO-5-UPDOWN: Line protocol on Interface %s, changed state to %s\n", i->name, up ? "up" : "down");
}
static int h_shutdown(int argc, char **argv)    { (void)argc; (void)argv; if (cur_if->shutdown) return 1; cur_if->shutdown = 1; link_msg(cur_if, 0); return 0; }
static int h_no_shutdown(int argc, char **argv) { (void)argc; (void)argv; if (!cur_if->shutdown) return 1; cur_if->shutdown = 0; link_msg(cur_if, 1); return 0; }
static int h_description(int argc, char **argv) {
    const char *t = rest_text(); (void)argc; (void)argv;
    if (strlen(t) > 99) return bad_arg(0, "Description too long (max 99 characters).");
    if (!strcmp(cur_if->desc, t)) return 1;
    snprintf(cur_if->desc, sizeof cur_if->desc, "%s", t); return 0;
}
static int h_no_description(int argc, char **argv) { (void)argc; (void)argv; if (!cur_if->desc[0]) return 1; cur_if->desc[0] = 0; return 0; }
static int h_clock(int argc, char **argv) {
    u64 v; (void)argc;
    if (strncmp(cur_if->name, "Serial", 6)) return err("Clock rate can only be set on Serial interfaces.");
    if (!rc_parse_uint(argv[0], 1200, 8000000, &v)) return bad_arg(0, "Clock rate must be 1200-8000000 (e.g. 64000).");
    if (cur_if->clock_rate == (long)v) return 1;
    cur_if->clock_rate = (long)v; return 0;
}
static int h_no_clock(int argc, char **argv) { (void)argc; (void)argv; if (!cur_if->clock_rate) return 1; cur_if->clock_rate = 0; return 0; }

static int h_ip_route(int argc, char **argv) {
    Route r; u32 net, mask; u64 ad = 1; int pos; Interface *o;
    memset(&r, 0, sizeof r);
    if (argc < 3) return err("Incomplete command.");
    if (!rc_parse_ip(argv[0], &net)) return bad_arg(0, "Invalid network address \"%s\".", argv[0]);
    if (!rc_parse_ip(argv[1], &mask) || !rc_mask_ok(mask)) return bad_arg(1, "Invalid subnet mask \"%s\".", argv[1]);
    if ((net & mask) != net) return bad_arg(0, "Inconsistent address and mask: host bits set (did you mean %s?).", rc_ipstr(net & mask));
    if (rc_parse_ip(argv[2], &r.nh)) {
        if (!r.nh || (r.nh >> 24) >= 224) return bad_arg(2, "Invalid next-hop address.");
        for (o = cfg.ihead; o; o = o->onext) if (o->has_ip && o->ip == r.nh) return bad_arg(2, "Invalid next hop %s (it is this router's own interface address).", argv[2]);
        r.has_nh = 1;
    } else {
        char nm[40];
        if (!rc_canon_iface(argv[2], nm, sizeof nm)) return bad_arg(2, "Next hop must be an IP address or an exit interface.");
        if (!if_find(nm)) return bad_arg(2, "Exit interface %s does not exist (create it with 'interface' first).", nm);
        snprintf(r.iface, sizeof r.iface, "%s", nm);
    }
    if (argc == 4 && !rc_parse_uint(argv[3], 1, 255, &ad)) return bad_arg(3, "Administrative distance must be 1-255.");
    r.net = net; r.mask = mask; r.ad = (int)ad;
    if (route_find(&r, &pos)) {
        if (cfg.routes[pos].ad == r.ad) return 1;
        cfg.routes[pos].ad = r.ad; return 0;
    }
    route_insert(&r, pos);
    RLOGI("config", "route added %s/%d ad=%d", rc_ipstr(net), rc_plen(mask), (int)ad);
    if (!loading && r.has_nh && !connected_if(r.nh))
        printf("%% Warning: next hop %s is not on a connected, up network - route not installed yet.\n", rc_ipstr(r.nh));
    return 0;
}
static int h_no_ip_route(int argc, char **argv) {
    u32 net, mask; int k, removed = 0;
    if (argc < 2) return err("Incomplete command.");
    if (!rc_parse_ip(argv[0], &net)) return bad_arg(0, "Invalid network address.");
    if (!rc_parse_ip(argv[1], &mask) || !rc_mask_ok(mask)) return bad_arg(1, "Invalid subnet mask.");
    if (argc >= 3) {
        Route r; int pos; memset(&r, 0, sizeof r); r.net = net; r.mask = mask;
        if (rc_parse_ip(argv[2], &r.nh)) r.has_nh = 1;
        else if (!rc_canon_iface(argv[2], r.iface, sizeof r.iface)) return bad_arg(2, "Invalid next hop / interface.");
        if (!route_find(&r, &pos)) return err("No matching route to delete.");
        route_remove(pos); return 0;
    }
    for (k = cfg.nr - 1; k >= 0; k--)
        if (cfg.routes[k].net == net && cfg.routes[k].mask == mask) { route_remove(k); removed++; }
    return removed ? 0 : err("No matching route to delete.");
}

static int h_router_rip(int argc, char **argv) {
    (void)argc; (void)argv;
    if (!cfg.rip_on) { cfg.rip_on = 1; cfg.rip_ver = 1; cfg.rip_autosum = 1; }
    mode = M_RIP; RLOGI("config", "RIP enabled"); return 0;
}
static int h_no_router_rip(int argc, char **argv) {
    (void)argc; (void)argv;
    if (!cfg.rip_on) return 1;
    free(cfg.rip_nets); cfg.rip_nets = NULL; cfg.nrip = cfg.crip = 0; cfg.rip_on = 0; return 0;
}
static int h_router_ospf(int argc, char **argv) {
    u64 pid; (void)argc;
    if (!rc_parse_uint(argv[0], 1, 65535, &pid)) return bad_arg(0, "OSPF process id must be 1-65535.");
    if (cfg.ospf_on && cfg.ospf_pid != (int)pid)
        return err("OSPF process %d already exists (this compiler supports one OSPF process).", cfg.ospf_pid);
    if (!cfg.ospf_on) { cfg.ospf_on = 1; cfg.ospf_pid = (int)pid; }
    mode = M_OSPF; RLOGI("config", "OSPF %d enabled", (int)pid); return 0;
}
static int h_no_router_ospf(int argc, char **argv) {
    u64 pid; (void)argc;
    if (!rc_parse_uint(argv[0], 1, 65535, &pid)) return bad_arg(0, "OSPF process id must be 1-65535.");
    if (!cfg.ospf_on || cfg.ospf_pid != (int)pid) return err("OSPF process %llu is not configured.", pid);
    free(cfg.onets); cfg.onets = NULL; cfg.nos = cfg.cos = 0; cfg.ospf_on = 0; cfg.has_rid = 0; return 0;
}
static int h_rip_version(int argc, char **argv) {
    (void)argc;
    if (strcmp(argv[0], "1") && strcmp(argv[0], "2")) return bad_arg(0, "RIP version must be 1 or 2.");
    if (cfg.rip_ver == argv[0][0] - '0') return 1;
    cfg.rip_ver = argv[0][0] - '0'; return 0;
}
static int h_autosum(int argc, char **argv)    { (void)argc; (void)argv; if (cfg.rip_autosum) return 1; cfg.rip_autosum = 1; return 0; }
static int h_no_autosum(int argc, char **argv) { (void)argc; (void)argv; if (!cfg.rip_autosum) return 1; cfg.rip_autosum = 0; return 0; }
static int h_router_id(int argc, char **argv) {
    u32 id; (void)argc;
    if (!rc_parse_ip(argv[0], &id) || !id) return bad_arg(0, "Router-id must be a valid non-zero IPv4 address.");
    if (cfg.has_rid && cfg.rid == id) return 1;
    cfg.rid = id; cfg.has_rid = 1; return 0;
}
static int h_no_router_id(int argc, char **argv) { (void)argc; (void)argv; if (!cfg.has_rid) return 1; cfg.has_rid = 0; return 0; }

static int net_stmt(int argc, char **argv, int remove_it) {
    int k;
    if (mode == M_RIP) {
        u32 ip, base;
        if (argc != 1) return bad_arg(1, "RIP syntax: network <classful-network>");
        if (!rc_parse_ip(argv[0], &ip)) return bad_arg(0, "Invalid network address \"%s\".", argv[0]);
        if (!rc_classful(ip, &base)) return bad_arg(0, "Not a valid class A/B/C network.");
        for (k = 0; k < cfg.nrip; k++) if (cfg.rip_nets[k] == base) break;
        if (remove_it) {
            if (k == cfg.nrip) return err("Network not configured.");
            memmove(&cfg.rip_nets[k], &cfg.rip_nets[k + 1],
                    (size_t)(cfg.nrip - k - 1) * sizeof(u32));
            cfg.nrip--; return 0;
        }
        if (k < cfg.nrip) return 1;
        GROW(cfg.rip_nets, cfg.nrip, cfg.crip); cfg.rip_nets[cfg.nrip++] = base; return 0;
    } else {
        u32 ip, w; u64 area; OspfNet o;
        if (argc < 4) return err("Incomplete command. OSPF syntax: network <ip> <wildcard> area <n>");
        if (argc > 4) return bad_arg(4, "Unexpected extra argument.");
        if (!rc_parse_ip(argv[0], &ip)) return bad_arg(0, "Invalid network address \"%s\".", argv[0]);
        if (!rc_parse_ip(argv[1], &w) || !rc_mask_ok(~w)) return bad_arg(1, "Invalid wildcard mask \"%s\" (e.g. 0.0.0.255).", argv[1]);
        if (!rc_is_prefix_ci(argv[2], "area")) return bad_arg(2, "Expected keyword 'area'.");
        if (!rc_parse_uint(argv[3], 0, 4294967295ULL, &area)) return bad_arg(3, "Area must be a number 0-4294967295.");
        o.net = ip & ~w; o.wild = w; o.area = area;
        for (k = 0; k < cfg.nos; k++) if (cfg.onets[k].net == o.net && cfg.onets[k].wild == w) break;
        if (remove_it) {
            if (k == cfg.nos) return err("Network statement not configured.");
            memmove(&cfg.onets[k], &cfg.onets[k + 1],
                    (size_t)(cfg.nos - k - 1) * sizeof(OspfNet));
            cfg.nos--; return 0;
        }
        if (k < cfg.nos) { if (cfg.onets[k].area == area) return 1; cfg.onets[k].area = area; return 0; }
        GROW(cfg.onets, cfg.nos, cfg.cos); cfg.onets[cfg.nos++] = o; return 0;
    }
}
static int h_network(int argc, char **argv)    { return net_stmt(argc, argv, 0); }
static int h_no_network(int argc, char **argv) { return net_stmt(argc, argv, 1); }

/* -------------------- show commands -------------------- */
static void show_running(void) {
    Lines L = { 0 }; int i; size_t bytes = 0;
    gen_config(&L);
    for (i = 0; i < L.n; i++) bytes += strlen(L.v[i]) + 1;
    printf("Building configuration...\n\nCurrent configuration : %lu bytes\n", (unsigned long)bytes);
    for (i = 0; i < L.n; i++) puts(L.v[i]);
    lines_free(&L);                 /* fixed: original leaked */
}
static int h_show_run(int argc, char **argv)     { (void)argc; (void)argv; show_running(); return 0; }
static int h_show_startup(int argc, char **argv) {
    FILE *f = fopen(STARTUP_FILE, "r"); char b[300];
    (void)argc; (void)argv;
    if (!f) { puts("startup-config is not present"); return 0; }
    while (fgets(b, sizeof b, f)) fputs(b, stdout);
    fclose(f); return 0;
}
static int h_show_ipbrief(int argc, char **argv) {
    Interface *i; (void)argc; (void)argv;
    printf("%-22s %-15s %-4s %-7s %-21s %s\n", "Interface", "IP-Address", "OK?", "Method", "Status", "Protocol");
    for (i = cfg.ihead; i; i = i->onext)
        printf("%-22s %-15s %-4s %-7s %-21s %s\n", i->name, i->has_ip ? rc_ipstr(i->ip) : "unassigned", "YES",
               i->has_ip ? "manual" : "unset", i->shutdown ? "administratively down" : "up",
               i->shutdown ? "down" : "up");
    if (!cfg.nif) puts("(no interfaces configured)");
    return 0;
}
static void print_if_detail(const Interface *i) {
    printf("%s is %s, line protocol is %s\n", i->name,
           i->shutdown ? "administratively down" : "up", i->shutdown ? "down" : "up");
    if (i->desc[0]) printf("  Description: %s\n", i->desc);
    if (i->has_ip) printf("  Internet address is %s/%d\n", rc_ipstr(i->ip), rc_plen(i->mask));
    else puts("  Internet protocol processing disabled");
    if (i->clock_rate) printf("  Clock rate %ld\n", i->clock_rate);
}
static int h_show_if(int argc, char **argv) {
    Interface *i;
    if (argc) {
        char nm[40];
        if (!rc_join_iface(argc, argv, nm, sizeof nm)) return bad_arg(0, "Invalid interface name.");
        if (!(i = if_find(nm))) return err("Interface %s is not configured.", nm);
        print_if_detail(i); return 0;
    }
    for (i = cfg.ihead; i; i = i->onext) print_if_detail(i);
    if (!cfg.nif) puts("(no interfaces configured)");
    return 0;
}
static int h_show_route(int argc, char **argv) {
    Interface *i; int k, any = 0; Hit h; Route *gw = NULL;
    if (argc) {
        u32 ip;
        if (!rc_parse_ip(argv[0], &ip)) return bad_arg(0, "Invalid IP address.");
        if (!lookup(ip, &h)) return err("Network not in table.");
        printf("Routing entry for %s/%d\n  Known via \"%s\", distance %d\n",
               rc_ipstr(h.net), rc_plen(h.mask),
               h.code == 'C' ? "connected" : "static", h.ad);
        if (h.code == 'C' || !h.has_nh) printf("  Directly connected, via %s\n", h.iface);
        else printf("  Via next hop %s\n", rc_ipstr(h.nh));
        return 0;
    }
    for (k = 0; k < cfg.nr; k++)
        if (cfg.routes[k].net == 0 && cfg.routes[k].mask == 0 && route_installed(&cfg.routes[k]))
            { gw = &cfg.routes[k]; break; }
    puts("Codes: C - connected, S - static, R - RIP, O - OSPF\n");
    if (gw) printf("Gateway of last resort is %s to network 0.0.0.0\n\n",
                   gw->has_nh ? rc_ipstr(gw->nh) : gw->iface);
    else puts("Gateway of last resort is not set\n");
    for (i = cfg.ihead; i; i = i->onext)
        if (i->has_ip && !i->shutdown) {
            printf("C    %s/%d is directly connected, %s\n",
                   rc_ipstr(i->ip & i->mask), rc_plen(i->mask), i->name); any = 1;
        }
    for (k = 0; k < cfg.nr; k++) {
        Route *r = &cfg.routes[k];
        if (!route_installed(r)) continue;
        any = 1;
        if (r->has_nh) printf("S    %s/%d [%d/0] via %s\n",
                              rc_ipstr(r->net), rc_plen(r->mask), r->ad, rc_ipstr(r->nh));
        else printf("S    %s/%d is directly connected, %s\n",
                    rc_ipstr(r->net), rc_plen(r->mask), r->iface);
    }
    if (!any) puts("(routing table is empty - no up interface with an IP address)");
    if (cfg.rip_on || cfg.ospf_on)
        puts("\n(RIP/OSPF are configured but there are no neighbours in this simulator, so they learn no routes.)");
    return 0;
}
static int h_show_protocols(int argc, char **argv) {
    int k; (void)argc; (void)argv;
    if (!cfg.rip_on && !cfg.ospf_on) { puts("No routing protocol is configured."); return 0; }
    if (cfg.rip_on) {
        printf("Routing Protocol is \"rip\"\n  Version %d, automatic summarization %s\n  Routing for Networks:\n",
               cfg.rip_ver, cfg.rip_autosum ? "enabled" : "disabled");
        for (k = 0; k < cfg.nrip; k++) printf("    %s\n", rc_ipstr(cfg.rip_nets[k]));
    }
    if (cfg.ospf_on) {
        printf("Routing Protocol is \"ospf %d\"\n  Router ID %s\n  Routing for Networks:\n",
               cfg.ospf_pid, cfg.has_rid ? rc_ipstr(cfg.rid) : "(not set)");
        for (k = 0; k < cfg.nos; k++)
            printf("    %s %s area %llu\n", rc_ipstr(cfg.onets[k].net),
                   rc_ipstr(cfg.onets[k].wild), cfg.onets[k].area);
    }
    return 0;
}
static int h_show_errors(int argc, char **argv) {
    int i; (void)argc; (void)argv;
    if (!nerr) { puts("No errors recorded in this session."); return 0; }
    printf("%d error(s) recorded:\n", nerr);
    for (i = 0; i < nerr; i++)
        printf("%3d. [%s] \"%s\"\n       -> %s\n", i + 1, errlog[i].where, errlog[i].cmd, errlog[i].msg);
    return 0;
}
static int h_ping(int argc, char **argv) {
    u32 ip; Hit h; Interface *o; int ok, self = 0; (void)argc;
    if (!rc_parse_ip(argv[0], &ip)) return bad_arg(0, "Invalid IP address.");
    for (o = cfg.ihead; o; o = o->onext)
        if (o->has_ip && !o->shutdown && o->ip == ip) self = 1;
    ok = self || lookup(ip, &h);
    printf("Type escape sequence to abort.\nSending 5, 100-byte ICMP Echos to %s, timeout is 2 seconds:\n%s\n",
           rc_ipstr(ip), ok ? "!!!!!" : "UUUUU");
    printf("Success rate is %d percent (%d/5)\n", ok ? 100 : 0, ok ? 5 : 0);
    puts("(simulation: result is based on this router's own routing table only)");
    return 0;
}

/* -------------------- validator -------------------- */
int rc_validate(int *warns) {
    int errs = 0, w = 0, k; Interface *i; u32 base;
    printf("--- Validating configuration of %s ---\n", cfg.hostname);
    if (!strcmp(cfg.hostname, "Router")) { puts("  [warn ] hostname is still the default 'Router'."); w++; }
    for (i = cfg.ihead; i; i = i->onext) {
        int phys = strncmp(i->name, "Loopback", 8) != 0;
        if (!i->shutdown && !i->has_ip && phys) { printf("  [warn ] %s is up but has no IP address.\n", i->name); w++; }
        if (i->shutdown && i->has_ip) { printf("  [warn ] %s has an IP address but is administratively down.\n", i->name); w++; }
        if (i->clock_rate && i->shutdown) { printf("  [warn ] %s has a clock rate but is down.\n", i->name); w++; }
    }
    for (k = 0; k < cfg.nr; k++) {
        Route *r = &cfg.routes[k];
        if (!route_installed(r)) {
            if (r->has_nh) printf("  [warn ] static route %s/%d via %s is NOT installed (next hop unreachable).\n",
                                  rc_ipstr(r->net), rc_plen(r->mask), rc_ipstr(r->nh));
            else printf("  [warn ] static route %s/%d via %s is NOT installed (interface down).\n",
                        rc_ipstr(r->net), rc_plen(r->mask), r->iface);
            w++;
        }
    }
    if (cfg.rip_on) {
        if (!cfg.nrip) { puts("  [warn ] RIP is enabled but has no network statements."); w++; }
        for (k = 0; k < cfg.nrip; k++) {
            int hit = 0;
            for (i = cfg.ihead; i; i = i->onext)
                if (i->has_ip && rc_classful(i->ip, &base) && base == cfg.rip_nets[k]) hit = 1;
            if (!hit) { printf("  [warn ] RIP network %s matches no interface.\n", rc_ipstr(cfg.rip_nets[k])); w++; }
        }
    }
    if (cfg.ospf_on) {
        int anyip = 0;
        if (!cfg.nos) { puts("  [warn ] OSPF is enabled but has no network statements."); w++; }
        for (i = cfg.ihead; i; i = i->onext) if (i->has_ip && !i->shutdown) anyip = 1;
        if (!cfg.has_rid && !anyip)
            { puts("  [error] OSPF has no router-id and no up interface with an IP to derive one from."); errs++; }
        for (k = 0; k < cfg.nos; k++) {
            int hit = 0;
            for (i = cfg.ihead; i; i = i->onext)
                if (i->has_ip && (i->ip & ~cfg.onets[k].wild) == cfg.onets[k].net) hit = 1;
            if (!hit) { printf("  [warn ] OSPF network %s %s matches no interface.\n",
                               rc_ipstr(cfg.onets[k].net), rc_ipstr(cfg.onets[k].wild)); w++; }
        }
    }
    for (i = cfg.ihead; i; i = i->onext) {
        Interface *o;
        for (o = i->onext; o; o = o->onext)
            if (i->has_ip && o->has_ip && i->ip == o->ip)
                { printf("  [error] %s and %s share IP %s.\n", i->name, o->name, rc_ipstr(i->ip)); errs++; }
    }
    printf("--- Result: %d error(s), %d warning(s) ---\n", errs, w);
    if (warns) *warns = w;
    return errs;
}
static int h_validate(int argc, char **argv) { (void)argc; (void)argv; rc_validate(NULL); return 0; }

/* -------------------- codegen -------------------- */
enum { OP_HOST = 0x01, OP_SECRET = 0x02, OP_IFSEL = 0x10, OP_IFDESC = 0x11, OP_IFIP = 0x12, OP_IFCLK = 0x13,
       OP_IFUP = 0x14, OP_IFDOWN = 0x15, OP_ROUTE = 0x20, OP_RIP = 0x30, OP_RIPNET = 0x31, OP_RIPSUM = 0x32,
       OP_OSPF = 0x40, OP_RID = 0x41, OP_OSPFNET = 0x42, OP_COMMIT = 0xFF };
typedef struct { int n; FILE *f; unsigned long sum; } Emitter;
static void emit(Emitter *E, unsigned op, const char *name, const char *fmt, ...) {
    char operand[200]; char line[260]; const char *p; va_list ap;
    va_start(ap, fmt); vsnprintf(operand, sizeof operand, fmt, ap); va_end(ap);
    snprintf(line, sizeof line, "%04d  0x%02X  %-11s %s", E->n++, op, name, operand);
    puts(line); if (E->f) fprintf(E->f, "%s\n", line);
    E->sum = E->sum * 131 + op;
    for (p = operand; *p; p++) E->sum = E->sum * 131 + (unsigned char)*p;
}
static int h_compile(int argc, char **argv) {
    char path[160]; Emitter E; Interface *i; int k, pruned = 0, errs, warns;
    errs = rc_validate(&warns);
    if (errs) return err("Compilation aborted: %d configuration error(s).", errs);
    if (argc) snprintf(path, sizeof path, "%s", argv[0]);
    else snprintf(path, sizeof path, "%s.rcx", cfg.hostname);
    memset(&E, 0, sizeof E);
    E.f = fopen(path, "w");
    if (!E.f) return err("Cannot write %s", path);
    printf("\n--- Generated executable instructions ---\n");
    fprintf(E.f, "; RCC executable configuration for %s\n", cfg.hostname);
    emit(&E, OP_HOST, "SET_HOST", "%s", cfg.hostname);
    if (cfg.secret[0]) emit(&E, OP_SECRET, "SET_SECRET", "%s", cfg.secret);
    for (i = cfg.ihead; i; i = i->onext) {
        if (i->shutdown && !i->has_ip && !i->desc[0] && !i->clock_rate) { pruned++; continue; }
        emit(&E, OP_IFSEL, "IF_SELECT", "%s", i->name);
        if (i->desc[0]) emit(&E, OP_IFDESC, "IF_DESC", "\"%s\"", i->desc);
        if (i->has_ip) emit(&E, OP_IFIP, "IF_IPV4", "%s %s", rc_ipstr(i->ip), rc_ipstr(i->mask));
        if (i->clock_rate) emit(&E, OP_IFCLK, "IF_CLOCK", "%ld", i->clock_rate);
        if (i->shutdown) emit(&E, OP_IFDOWN, "IF_ADMIN_DN", "-");
        else emit(&E, OP_IFUP, "IF_ADMIN_UP", "-");
    }
    for (k = 0; k < cfg.nr; k++) {
        Route *r = &cfg.routes[k];
        if (r->has_nh) emit(&E, OP_ROUTE, "ROUTE_ADD", "%s %s VIA %s AD %d",
                            rc_ipstr(r->net), rc_ipstr(r->mask), rc_ipstr(r->nh), r->ad);
        else emit(&E, OP_ROUTE, "ROUTE_ADD", "%s %s OUT %s AD %d",
                  rc_ipstr(r->net), rc_ipstr(r->mask), r->iface, r->ad);
    }
    if (cfg.rip_on) {
        emit(&E, OP_RIP, "RIP_ENABLE", "v%d", cfg.rip_ver);
        for (k = 0; k < cfg.nrip; k++) emit(&E, OP_RIPNET, "RIP_NET", "%s", rc_ipstr(cfg.rip_nets[k]));
        emit(&E, OP_RIPSUM, "RIP_AUTOSUM", "%s", cfg.rip_autosum ? "ON" : "OFF");
    }
    if (cfg.ospf_on) {
        emit(&E, OP_OSPF, "OSPF_ENABLE", "%d", cfg.ospf_pid);
        if (cfg.has_rid) emit(&E, OP_RID, "OSPF_RID", "%s", rc_ipstr(cfg.rid));
        for (k = 0; k < cfg.nos; k++)
            emit(&E, OP_OSPFNET, "OSPF_NET", "%s %s AREA %llu",
                 rc_ipstr(cfg.onets[k].net), rc_ipstr(cfg.onets[k].wild), cfg.onets[k].area);
    }
    emit(&E, OP_COMMIT, "COMMIT", "checksum=0x%08lX", E.sum & 0xFFFFFFFFUL);
    fclose(E.f);
    RLOGI("codegen", "compiled %d instructions -> %s", E.n, path);
    printf("\nCompiled %d instruction(s) -> %s\n", E.n, path);
    printf("Optimisation report: %d config command(s) accepted, %d duplicate/no-op command(s) skipped,\n"
           "  %d default-state interface(s) pruned, routes emitted in sorted order, final state only (no history).\n",
           st.cfg_ok, st.cfg_dup, pruned);
    if (warns) printf("Compiled with %d warning(s).\n", warns);
    return 0;
}

/* -------------------- search -------------------- */
static int h_search(int argc, char **argv) {
    Lines L = { 0 }; int i, hits = 0; char section[120] = ""; char nm[40]; const char *kw = rest_text();
    (void)argc; (void)argv;
    if (rc_canon_iface(kw, nm, sizeof nm) && if_find(nm)) {
        puts("Interface found by hash lookup:"); print_if_detail(if_find(nm)); puts("");
    }
    gen_config(&L);
    for (i = 0; i < L.n; i++) {
        const char *ln = L.v[i];
        if (ln[0] != ' ' && ln[0] != '!') snprintf(section, sizeof section, "%s", ln);
        if (stristr(ln, kw)) {
            if (hits == 0) printf("Matches for \"%s\":\n", kw);
            if (ln[0] == ' ') printf("  [%s] %s\n", section, ln + 1);
            else printf("  %s\n", ln);
            hits++;
        }
    }
    if (!hits) printf("No configuration line contains \"%s\".\n", kw);
    else printf("%d match(es).\n", hits);
    lines_free(&L); return 0;
}

/* -------------------- save / load -------------------- */
int rc_save_file(const char *path) {
    Lines L = { 0 }; int i; FILE *f = fopen(path, "w");
    if (!f) return err("Cannot open %s for writing.", path);
    gen_config(&L);
    for (i = 0; i < L.n; i++) fprintf(f, "%s\n", L.v[i]);
    lines_free(&L); fclose(f); return 0;
}
static void execute_line(const char *line);
int rc_load_file(const char *path) {
    FILE *f = fopen(path, "r"); char b[MAXLINE]; Mode saved = mode; int ln = 0, e0 = nerr;
    char *pn;
    if (!f) return err("Cannot open file \"%s\".", path);
    pn = xstrdup(path);
    rc_reset_config();
    mode = M_CONFIG; loading = 1; load_name = pn;
    while (fgets(b, sizeof b, f)) { load_line = ++ln; execute_line(b); }
    loading = 0; load_name = ""; mode = saved; cur_if = NULL;
    fclose(f);
    RLOGI("loader", "loaded %d line(s) from %s (%d error(s))", ln, pn, nerr - e0);
    printf("Loaded %d line(s) from %s (%d error(s)).\n", ln, pn, nerr - e0);
    free(pn);                        /* fixed: original leaked */
    return nerr - e0 ? -1 : 0;
}
static int h_write(int argc, char **argv) {
    if (argc && !rc_is_prefix_ci(argv[0], "memory")) return bad_arg(0, "Did you mean 'write memory'?");
    puts("Building configuration...");
    if (rc_save_file(STARTUP_FILE)) return -1;
    puts("[OK] saved to " STARTUP_FILE); return 0;
}
static int h_copy(int argc, char **argv)  { return h_write(0, argv + argc); }
static int h_erase(int argc, char **argv) { (void)argc; (void)argv; if (remove(STARTUP_FILE)) return err("No startup-config to erase."); puts("[OK] startup-config erased"); return 0; }
static int h_save(int argc, char **argv)  { (void)argc; if (rc_save_file(argv[0])) return -1; printf("[OK] configuration saved to %s\n", argv[0]); return 0; }
static int h_load(int argc, char **argv)  { char p[200]; (void)argc; snprintf(p, sizeof p, "%s", argv[0]); return rc_load_file(p); }
static int h_reload(int argc, char **argv) {
    char b[16]; (void)argc; (void)argv;
    printf("Proceed with reload? [confirm]"); fflush(stdout);
    if (!fgets(b, sizeof b, stdin)) return -1;
    if (b[0] == 'n' || b[0] == 'N') return 0;
    rc_reset_config(); mode = M_USER;
    puts("Restarting system...");
    { FILE *f = fopen(STARTUP_FILE, "r"); if (f) { fclose(f); rc_load_file(STARTUP_FILE); mode = M_USER; } }
    RLOGI("cli", "reload requested"); return 0;
}
static int h_help(int argc, char **argv);

/* -------------------- command table -------------------- */
static const Cmd CMDS[] = {
 { MB_USER,  "enable",                         "",                         0, 0, h_enable,          "Enter privileged EXEC mode" },
 { MB_PRIV,  "disable",                        "",                         0, 0, h_disable,         "Return to user EXEC mode" },
 { MB_PRIV,  "configure terminal",             "",                         0, 0, h_configure,       "Enter global configuration mode" },
 { MB_ALL,   "exit",                           "",                         0, 0, h_exit,            "Go back one level (in user mode: quit program)" },
 { MB_ALL,   "quit",                           "",                         0, 0, h_quit,            "Quit the program" },
 { MB_ALL,   "help",                           "",                         0, 0, h_help,            "List commands for the current mode" },
 { MB_CFG,   "end",                            "",                         0, 0, h_end,             "Return to privileged EXEC mode" },
 { MB_CFG,   "hostname",                       "<name>",                   1, 1, h_hostname,        "Set the router name" },
 { MB_CFG,   "no hostname",                    "",                         0, 0, h_no_hostname,     "Reset hostname to 'Router'" },
 { MB_CFG,   "enable secret",                  "<password>",               1, 1, h_secret,          "Set privileged-mode password" },
 { MB_CFG,   "no enable secret",               "",                         0, 0, h_no_secret,       "Remove privileged-mode password" },
 { MB_CFG,   "interface",                      "<type> <number>",          1, 2, h_interface,       "Select/create an interface (g0/0, fa0/1, s0/0/0, lo0)" },
 { MB_CFG,   "no interface",                   "<loopback>",               1, 2, h_no_interface,    "Delete a loopback interface" },
 { MB_CFG,   "ip route",                       "<net> <mask> <nh|if> [ad]",3, 4, h_ip_route,        "Add a static route" },
 { MB_CFG,   "no ip route",                    "<net> <mask> [nh|if]",     2, 4, h_no_ip_route,     "Remove a static route" },
 { MB_CFG,   "router rip",                     "",                         0, 0, h_router_rip,      "Enable RIP and enter router mode" },
 { MB_CFG,   "no router rip",                  "",                         0, 0, h_no_router_rip,   "Disable RIP" },
 { MB_CFG,   "router ospf",                    "<process-id>",             1, 1, h_router_ospf,     "Enable OSPF and enter router mode" },
 { MB_CFG,   "no router ospf",                 "<process-id>",             1, 1, h_no_router_ospf,  "Disable OSPF" },
 { BIT(M_IF),"ip address",                     "<ip> <mask>",              2, 2, h_ip_address,      "Assign IPv4 address to the interface" },
 { BIT(M_IF),"no ip address",                  "",                         0, 0, h_no_ip_address,   "Remove IPv4 address" },
 { BIT(M_IF),"shutdown",                       "",                         0, 0, h_shutdown,        "Administratively disable the interface" },
 { BIT(M_IF),"no shutdown",                    "",                         0, 0, h_no_shutdown,     "Enable the interface" },
 { BIT(M_IF),"description",                    "<text>",                   1, 12, h_description,    "Set interface description" },
 { BIT(M_IF),"no description",                 "",                         0, 12, h_no_description, "Remove interface description" },
 { BIT(M_IF),"clock rate",                     "<bits/sec>",               1, 1, h_clock,           "Set DCE clock rate (Serial only)" },
 { BIT(M_IF),"no clock rate",                  "",                         0, 1, h_no_clock,        "Remove clock rate" },
 { BIT(M_RIP),"version",                       "<1|2>",                    1, 1, h_rip_version,     "Set RIP version" },
 { BIT(M_RIP),"auto-summary",                  "",                         0, 0, h_autosum,         "Enable automatic summarisation" },
 { BIT(M_RIP),"no auto-summary",               "",                         0, 0, h_no_autosum,      "Disable automatic summarisation" },
 { BIT(M_OSPF),"router-id",                    "<a.b.c.d>",                1, 1, h_router_id,       "Set OSPF router-id" },
 { BIT(M_OSPF),"no router-id",                 "",                         0, 1, h_no_router_id,    "Remove OSPF router-id" },
 { BIT(M_RIP)|BIT(M_OSPF),"network",           "<net> | <net> <wild> area <n>", 1, 4, h_network,  "Advertise a network (RIP: classful; OSPF: wildcard+area)" },
 { BIT(M_RIP)|BIT(M_OSPF),"no network",        "<same as network>",        1, 4, h_no_network,      "Remove a network statement" },
 { MB_EXEC,  "show ip interface brief",        "",                         0, 0, h_show_ipbrief,    "One-line status of every interface" },
 { MB_EXEC,  "show ip route",                  "[ip]",                     0, 1, h_show_route,      "Routing table (or lookup of one address)" },
 { MB_EXEC,  "show ip protocols",              "",                         0, 0, h_show_protocols,  "RIP / OSPF settings" },
 { MB_EXEC,  "show interfaces",                "[type number]",            0, 2, h_show_if,         "Detailed interface information" },
 { MB_EXEC,  "show errors",                    "",                         0, 0, h_show_errors,     "All configuration errors seen this session" },
 { MB_PRIV,  "show running-config",            "",                         0, 0, h_show_run,        "Display current configuration" },
 { MB_PRIV,  "show startup-config",            "",                         0, 0, h_show_startup,    "Display saved configuration" },
 { MB_EXEC,  "ping",                           "<ip>",                     1, 1, h_ping,            "Simulated ping using the routing table" },
 { MB_PRIV,  "write",                          "[memory]",                 0, 1, h_write,           "Save running-config to startup-config" },
 { MB_PRIV,  "copy running-config startup-config","",                      0, 0, h_copy,            "Save running-config to startup-config" },
 { MB_PRIV,  "erase startup-config",           "",                         0, 0, h_erase,           "Delete the saved startup-config" },
 { MB_PRIV,  "save",                           "<file>",                   1, 1, h_save,            "Save running-config to any file" },
 { MB_PRIV,  "load",                           "<file>",                   1, 1, h_load,            "Load a config file (replaces running-config)" },
 { MB_PRIV,  "reload",                         "",                         0, 0, h_reload,          "Restart: clear running-config, reload startup-config" },
 { MB_PRIV,  "validate",                       "",                         0, 0, h_validate,        "Semantic check of the whole configuration" },
 { MB_PRIV,  "compile",                        "[file.rcx]",               0, 1, h_compile,         "Validate + generate executable instructions" },
 { MB_PRIV,  "search",                         "<keyword>",                1, 8, h_search,          "Search configuration text / interface name" },
};
static const Cmd *cmd_table(int *n) { *n = (int)(sizeof CMDS / sizeof CMDS[0]); return CMDS; }

/* -------------------- parser -------------------- */
static int pat_split(const char *pat, char w[][24]) {
    int n = 0;
    while (*pat) {
        int k = 0;
        while (*pat == ' ') pat++;
        if (!*pat) break;
        while (*pat && *pat != ' ' && k < 23) w[n][k++] = *pat++;
        w[n++][k] = 0;
    }
    return n;
}
static void make_prompt(char *out, size_t n) {
    static const char *suffix[] = { ">", "#", "(config)#", "(config-if)#", "(config-router)#", "(config-router)#" };
    snprintf(out, n, "%s%s", cfg.hostname, suffix[mode]);
}
static void show_help(int ntok) {
    int n, i, k, shown = 0; const Cmd *t = cmd_table(&n);
    for (i = 0; i < n; i++) {
        char w[5][24]; int nw, ok = 1;
        if (!(t[i].modes & BIT(mode))) continue;
        nw = pat_split(t[i].pat, w);
        for (k = 0; k < ntok && k < nw; k++)
            if (!rc_is_prefix_ci(C.tok[k], w[k])) { ok = 0; break; }
        if (!ok) continue;
        printf("  %-34s %-26s %s\n", t[i].pat, t[i].usage, t[i].help); shown++;
    }
    if (!shown) puts("% Unrecognized command");
    else puts("  (abbreviations work: conf t, int g0/0, sh ip int br, no sh ...)");
}
static int h_help(int argc, char **argv) { (void)argc; (void)argv; C.n = 0; show_help(0); return 0; }

static void dispatch(void) {
    int n, i, best = -1, bestn = -1, beste = -1, amb = 0, maxm = 0;
    const Cmd *t = cmd_table(&n), *c;
    int argc, rc;
    for (i = 0; i < n; i++) {
        char w[5][24]; int nw, k, matched = 0, exact = 0;
        if (!(t[i].modes & BIT(mode))) continue;
        nw = pat_split(t[i].pat, w);
        for (k = 0; k < nw && k < C.n; k++) {
            if (!rc_is_prefix_ci(C.tok[k], w[k])) break;
            matched++; if (rc_ieq(C.tok[k], w[k])) exact++;
        }
        if (matched > maxm) maxm = matched;
        if (matched != nw) continue;
        if (nw > bestn || (nw == bestn && exact > beste)) { best = i; bestn = nw; beste = exact; amb = 0; }
        else if (nw == bestn && exact == beste) amb = 1;
    }
    if (best < 0) {
        if (maxm >= C.n) { err("Incomplete command."); return; }
        caret(maxm); err("Invalid input detected at '^' marker."); return;
    }
    if (amb) { err("Ambiguous command: \"%s\"", C.tok[0]); return; }
    c = &t[best];
    argc = C.n - bestn; C.argbase = bestn;
    if (argc < c->minA) { err("Incomplete command."); return; }
    if (argc > c->maxA) { caret(bestn + c->maxA); err("Invalid input detected at '^' marker."); return; }
    rc = c->fn(argc, C.tok + bestn);
    if (c->modes != 0 && (c->modes & ~MB_CFG) == 0) {
        if (rc == 0) st.cfg_ok++; else if (rc > 0) st.cfg_dup++;
    }
}

static void execute_line_impl(const char *line) {
    struct Ctx saved = C; size_t len; char *p; char lcopy[MAXLINE];
    st.total++;
    snprintf(lcopy, sizeof lcopy, "%s", line);
    snprintf(C.orig, sizeof C.orig, "%s", lcopy);
    len = strlen(C.orig);
    while (len && isspace((unsigned char)C.orig[len - 1])) C.orig[--len] = 0;
    memcpy(C.buf, C.orig, sizeof C.buf);
    C.n = 0; C.argbase = 0; p = C.buf;
    while (*p) {
        while (*p && isspace((unsigned char)*p)) p++;
        if (!*p) break;
        if (C.n >= MAXTOK) { err("Too many words on one line (max %d).", MAXTOK); goto done; }
        C.tok[C.n] = p; C.pos[C.n] = (int)(p - C.buf); C.n++;
        while (*p && !isspace((unsigned char)*p)) p++;
        if (*p) *p++ = 0;
    }
    if (C.n == 0 || C.tok[0][0] == '!') { st.total--; goto done; }
    { char *last = C.tok[C.n - 1]; size_t ll = strlen(last);
      if (last[ll - 1] == '?') {
        int cnt = C.n;
        last[ll - 1] = 0;
        if (!last[0]) {
            cnt--;
        }
        show_help(cnt);
        goto done;
      }
    }
    if (rc_ieq(C.tok[0], "do") && mode >= M_CONFIG) {
        Mode sm = mode; Interface *si = cur_if;
        if (C.n == 1) { err("Incomplete command."); goto done; }
        mode = M_PRIV; execute_line_impl(C.orig + C.pos[1]); mode = sm; cur_if = si;
        goto done;
    }
    dispatch();
done:
    C = saved;
}
static void execute_line(const char *line) { execute_line_impl(line); }

/* -------------------- public API -------------------- */
int rc_execute_line(const char *line) {
    execute_line_impl(line);
    return nerr;
}
void rc_set_quit_flag(int v) { quit_flag = v; }
int  rc_get_quit_flag(void)  { return quit_flag; }

void rc_gen_config_lines(void (*cb)(const char *line, void *ud), void *ud) {
    Lines L = { 0 }; int i;
    gen_config(&L);
    for (i = 0; i < L.n; i++) cb(L.v[i], ud);
    lines_free(&L);
}

int rc_run_cli(void) {
    char line[MAXLINE], prompt[100]; FILE *f;
    rc_reset_config();
    if (rlog_init(LOGFILE, RLOG_INFO) != 0) {
        fprintf(stderr, "warning: could not open %s for logging\n", LOGFILE);
    }
    RLOGI("main", "router compiler start (Linux POC)");
    puts("====================================================================");
    puts("  Network Router Configuration Compiler  (Cisco IOS style CLI)");
    puts("  Type '?' or 'help' for commands, 'exit' in user mode to quit.");
    puts("====================================================================");
    if ((f = fopen(STARTUP_FILE, "r")) != NULL) {
        fclose(f); puts("Restoring saved startup-config...");
        rc_load_file(STARTUP_FILE); mode = M_USER;
    }
    while (!quit_flag) {
        make_prompt(prompt, sizeof prompt);
        prompt_len = (int)strlen(prompt);
        printf("%s", prompt); fflush(stdout);
        if (!fgets(line, sizeof line, stdin)) break;
        execute_line_impl(line);
    }
    puts("\nBye.");
    RLOGI("main", "router compiler exit");
    rc_reset_config();
    free(errlog); errlog = NULL; nerr = cerr = 0;
    rlog_close();
    return 0;
}