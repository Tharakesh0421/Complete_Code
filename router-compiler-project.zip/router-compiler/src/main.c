#include "router_compiler.h"

int main(void) { return rc_run_cli(); }