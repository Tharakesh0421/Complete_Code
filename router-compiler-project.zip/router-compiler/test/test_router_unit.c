#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "test_util.h"
#include "router_compiler.h"

static void t_parse_ip(void) {
    uint32_t v;
    ASSERT_EQ_INT(rc_parse_ip("192.168.1.1", &v), 1);
    ASSERT_EQ_INT(v, 0xC0A80101u);
    ASSERT_EQ_INT(rc_parse_ip("0.0.0.0", &v), 1);
    ASSERT_EQ_INT(rc_parse_ip("255.255.255.255", &v), 1);
    ASSERT_EQ_INT(v, 0xFFFFFFFFu);
    ASSERT_EQ_INT(rc_parse_ip("1.2.3", &v), 0);
    ASSERT_EQ_INT(rc_parse_ip("1.2.3.4.5", &v), 0);
    ASSERT_EQ_INT(rc_parse_ip("1.2.3.256", &v), 0);
    ASSERT_EQ_INT(rc_parse_ip("1..3.4", &v), 0);
    ASSERT_EQ_INT(rc_parse_ip("", &v), 0);
}

static void t_mask(void) {
    uint32_t m;
    ASSERT_EQ_INT(rc_parse_ip("255.255.255.0", &m), 1);
    ASSERT_EQ_INT(rc_mask_ok(m), 1);
    ASSERT_EQ_INT(rc_plen(m), 24);
    ASSERT_EQ_INT(rc_parse_ip("255.0.255.0", &m), 1);
    ASSERT_EQ_INT(rc_mask_ok(m), 0);
    ASSERT_EQ_INT(rc_parse_ip("0.0.0.0", &m), 1);
    ASSERT_EQ_INT(rc_mask_ok(m), 1);
    ASSERT_EQ_INT(rc_plen(m), 0);
}

static void t_classful(void) {
    uint32_t b, ip;
    ASSERT_EQ_INT(rc_parse_ip("10.1.2.3", &ip), 1);
    ASSERT_EQ_INT(rc_classful(ip, &b), 1);
    ASSERT_EQ_INT(b, 0x0A000000u);
    ASSERT_EQ_INT(rc_parse_ip("172.16.5.5", &ip), 1);
    ASSERT_EQ_INT(rc_classful(ip, &b), 1);
    ASSERT_EQ_INT(b, 0xAC100000u);
    ASSERT_EQ_INT(rc_parse_ip("192.168.1.1", &ip), 1);
    ASSERT_EQ_INT(rc_classful(ip, &b), 1);
    ASSERT_EQ_INT(b, 0xC0A80100u);
    ASSERT_EQ_INT(rc_parse_ip("224.0.0.1", &ip), 1);
    ASSERT_EQ_INT(rc_classful(ip, &b), 0);
}

static void t_canon_iface(void) {
    char out[40];
    ASSERT_EQ_INT(rc_canon_iface("g0/0", out, sizeof out), 1);
    ASSERT_EQ_INT(strcmp(out, "GigabitEthernet0/0"), 0);
    ASSERT_EQ_INT(rc_canon_iface("fa0/1", out, sizeof out), 1);
    ASSERT_EQ_INT(strcmp(out, "FastEthernet0/1"), 0);
    ASSERT_EQ_INT(rc_canon_iface("s0/0/0", out, sizeof out), 1);
    ASSERT_EQ_INT(strcmp(out, "Serial0/0/0"), 0);
    ASSERT_EQ_INT(rc_canon_iface("lo0", out, sizeof out), 1);
    ASSERT_EQ_INT(strcmp(out, "Loopback0"), 0);
    ASSERT_EQ_INT(rc_canon_iface("lo0/1", out, sizeof out), 0);
    ASSERT_EQ_INT(rc_canon_iface("xyz1", out, sizeof out), 0);
    ASSERT_EQ_INT(rc_canon_iface("g", out, sizeof out), 0);
}

static void t_parse_uint(void) {
    unsigned long long v;
    ASSERT_EQ_INT(rc_parse_uint("0", 0, 10, &v), 1);
    ASSERT_EQ_INT(v, 0);
    ASSERT_EQ_INT(rc_parse_uint("255", 1, 255, &v), 1);
    ASSERT_EQ_INT(v, 255);
    ASSERT_EQ_INT(rc_parse_uint("256", 1, 255, &v), 0);
    ASSERT_EQ_INT(rc_parse_uint("abc", 0, 100, &v), 0);
    ASSERT_EQ_INT(rc_parse_uint("", 0, 100, &v), 0);
}

static void t_ieq(void) {
    ASSERT_EQ_INT(rc_ieq("Hello", "hello"), 1);
    ASSERT_EQ_INT(rc_ieq("show", "SHOW"), 1);
    ASSERT_EQ_INT(rc_ieq("a", "ab"), 0);
    ASSERT_EQ_INT(rc_is_prefix_ci("gi", "GigabitEthernet"), 1);
    ASSERT_EQ_INT(rc_is_prefix_ci("xyz", "GigabitEthernet"), 0);
}

int main(void) {
    printf("== unit tests ==\n");
    t_parse_ip();
    t_mask();
    t_classful();
    t_canon_iface();
    t_parse_uint();
    t_ieq();
    test_summary("unit");
    return 0;
}