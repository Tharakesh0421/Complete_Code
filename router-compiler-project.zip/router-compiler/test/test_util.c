/* test_util.c */
#define _POSIX_C_SOURCE 200809L
#include "test_util.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

int g_tests_run = 0;
int g_tests_failed = 0;

char *capture_stdout(void (*fn)(void *), void *arg)
{
    int   pipefd[2];
    pid_t pid;
    char *buf = NULL;
    size_t cap = 0, len = 0;
    ssize_t n;
    int   status;

    if (pipe(pipefd) != 0) return NULL;
    pid = fork();
    if (pid == 0) {
        close(pipefd[0]);
        dup2(pipefd[1], STDOUT_FILENO);
        close(pipefd[1]);
        fn(arg);
        fflush(stdout);
        _exit(0);
    }
    close(pipefd[1]);
    {
        char tmp[4096];
        while ((n = read(pipefd[0], tmp, sizeof tmp)) > 0) {
            if (len + (size_t)n + 1 > cap) {
                cap = (len + (size_t)n + 1) * 2;
                char *grown = realloc(buf, cap);
                if (grown == NULL) {
                    free(buf);
                    close(pipefd[0]);
                    (void)waitpid(pid, &status, 0);
                    return NULL;
                }
                buf = grown;
            }
            memcpy(buf + len, tmp, (size_t)n);
            len += (size_t)n;
        }
    }
    close(pipefd[0]);
    waitpid(pid, &status, 0);
    if (!buf) buf = malloc(1);
    buf[len] = 0;
    return buf;
}

void test_summary(const char *name)
{
    fprintf(stderr, "\n[%s] %d assertion(s) run, %d failure(s)\n",
            name, g_tests_run, g_tests_failed);
    if (g_tests_failed) exit(EXIT_FAILURE);
}