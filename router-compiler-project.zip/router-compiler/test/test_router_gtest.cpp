#include <gtest/gtest.h>
#include <stdint.h>
extern "C" {
#include "router_compiler.h"
}

TEST(ParseIP, ValidAddresses) {
    uint32_t v = 0;
    EXPECT_EQ(rc_parse_ip("192.168.1.1", &v), 1);
    EXPECT_EQ(v, 0xC0A80101u);
    EXPECT_EQ(rc_parse_ip("0.0.0.0", &v), 1);
    EXPECT_EQ(rc_parse_ip("255.255.255.255", &v), 1);
    EXPECT_EQ(v, 0xFFFFFFFFu);
}

TEST(ParseIP, InvalidAddresses) {
    uint32_t v = 0;
    EXPECT_EQ(rc_parse_ip("1.2.3", &v), 0);
    EXPECT_EQ(rc_parse_ip("1.2.3.4.5", &v), 0);
    EXPECT_EQ(rc_parse_ip("1.2.3.256", &v), 0);
    EXPECT_EQ(rc_parse_ip("", &v), 0);
}

TEST(Mask, Contiguous) {
    uint32_t m;
    ASSERT_TRUE(rc_parse_ip("255.255.255.0", &m));
    EXPECT_EQ(rc_mask_ok(m), 1);
    EXPECT_EQ(rc_plen(m), 24);
    ASSERT_TRUE(rc_parse_ip("255.0.255.0", &m));
    EXPECT_EQ(rc_mask_ok(m), 0);
}

TEST(Classful, Classes) {
    uint32_t b = 0, ip;
    ASSERT_TRUE(rc_parse_ip("10.1.2.3", &ip));
    EXPECT_EQ(rc_classful(ip, &b), 1);
    EXPECT_EQ(b, 0x0A000000u);
    ASSERT_TRUE(rc_parse_ip("224.0.0.1", &ip));
    EXPECT_EQ(rc_classful(ip, &b), 0);
}

TEST(CanonIface, Normalises) {
    char out[40];
    ASSERT_EQ(rc_canon_iface("g0/0", out, sizeof out), 1);
    EXPECT_STREQ(out, "GigabitEthernet0/0");
    ASSERT_EQ(rc_canon_iface("lo0", out, sizeof out), 1);
    EXPECT_STREQ(out, "Loopback0");
    EXPECT_EQ(rc_canon_iface("xyz1", out, sizeof out), 0);
}

TEST(Cli, HostnameAndInterface) {
    rc_reset_config();
    rc_execute_line("enable");
    rc_execute_line("configure terminal");
    rc_execute_line("hostname RT");
    rc_execute_line("interface g0/0");
    rc_execute_line("ip address 10.0.0.1 255.255.255.0");
    rc_execute_line("no shutdown");
    rc_execute_line("end");
    int warns = 0;
    EXPECT_EQ(rc_validate(&warns), 0);
}

TEST(Cli, BadIPRejected) {
    rc_reset_config();
    rc_execute_line("enable");
    rc_execute_line("configure terminal");
    rc_execute_line("interface g0/0");
    rc_execute_line("ip address 300.1.1.1 255.255.255.0");
    /* validator should still report 0 errors because the ip wasn't stored */
    int warns = 0;
    EXPECT_EQ(rc_validate(&warns), 0);
}