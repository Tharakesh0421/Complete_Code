/* test_util.h */
#ifndef TEST_UTIL_H
#define TEST_UTIL_H
#include <stddef.h>
#include <stdio.h>

extern int g_tests_run;
extern int g_tests_failed;

#define ASSERT(cond) do { \
    g_tests_run++; \
    if (!(cond)) { \
        g_tests_failed++; \
        fprintf(stderr, "FAIL %s:%d: %s\n", __FILE__, __LINE__, #cond); \
    } \
} while (0)

#define ASSERT_EQ_INT(a,b) ASSERT((a) == (b))

/* redirect stdout into a buffer, run fn, restore */
char *capture_stdout(void (*fn)(void *), void *arg);

void test_summary(const char *name);
#endif